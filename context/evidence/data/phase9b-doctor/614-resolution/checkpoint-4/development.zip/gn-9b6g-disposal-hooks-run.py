import json,time
from pathlib import Path
from grid_symbols.scan import Jar,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.receiver_trace import Declarations,ReceiverLimits
from grid_doctor.admission import Work
from grid_doctor.migrate import member
from grid_doctor.ownership import method_trace,bootstraps
start=time.perf_counter();j=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));code=Code();d=Declarations(j,Work(ReceiverLimits()));cat=json.load(open('/tmp/gn-9b6g-fixed-1.json'))['builds'][1];rows=[];methods={}
for row in cat['rows']:
 runtime=row['matches'][0]['runtimeClass']
 for name in ('a_','cfM'):
  desc='(Lcom/bitwig/ramona/core/oDc;Z)V';found=d.find('method',runtime,name,desc);key=found['owner'],name,desc;rows.append({'name':row['name'],'runtime':runtime,'slot':name,'declaration':found})
  if key not in methods:
   c=code.get(j,key[0]);m=member(c,name,desc);methods[key]=method_trace(j,c,m,bootstraps(j.zip.read(c.name+'.class'),c))
r={'sha256':j.sha256,'rows':rows,'methods':list(methods.values()),'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False};Path('/tmp/gn-9b6g-disposal-hooks-1.json').write_text(json.dumps(r,indent=2));print('slots',len(rows),'methods',len(methods));print([(m['owner'],m['name'],[(x.get('owner'),x.get('name'),x.get('descriptor'))for x in m['references']if x['opcode']in(182,183,184,185,186)])for m in methods.values()])
