import pickle,sys,collections
D=pickle.load(open(f'/tmp/gn-9b6g-fc-work/index-{sys.argv[1] if len(sys.argv)>1 and sys.argv[1] in("new","old") else "new"}.pickle','rb'))
names=D['names'];hier=D['hier'];decl=D['decl']
inc=collections.defaultdict(list)
for a,b,o,p in zip(D['callee'],D['caller'],D['off'],D['ops']):inc[a].append((b,o,p))
ids={s:i for i,s in enumerate(names)}
kids=collections.defaultdict(set)
for c,(p,ifs,f) in hier.items():
  kids[p].add(c)
  for i in ifs:kids[i].add(c)
def subs(c):
  out=set();st=[c]
  while st:
    x=st.pop()
    for k in kids.get(x,()):
      if k not in out:out.add(k);st.append(k)
  return out
def sups(c):
  out=[];st=[c];seen=set()
  while st:
    x=st.pop()
    if x in seen or x not in hier:continue
    seen.add(x);out.append(x);p,ifs,f=hier[x];st.append(p);st.extend(ifs)
  return out
def sites(key):
  return [(names[b],o,p) for b,o,p in inc.get(ids.get(key,-1),[])]
def incoming(owner,name,desc,virtual=True):
  res=[]
  owners={owner}
  if virtual:
    owners|=subs(owner)
    owners|=set(sups(owner))
  for ow in sorted(owners):
    for s in sites(f'{ow}#{name}#{desc}'):res.append((ow,)+s)
  return res
def prefix(p):
  return [(names[a],) for a in range(len(names)) if names[a].startswith(p)]
