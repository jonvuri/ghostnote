exec(open('/tmp/gn-9b6g-inspect.py').read().split('for name in sys.argv[2:]')[0])
for spec in sys.argv[2:]:
 parts=spec.split('#',2);name=parts[0];wanted=parts[1] if len(parts)>1 else '';signature=parts[2]if len(parts)>2 else None;cls=jar.code(name)
 print('CLASS',name,'parent',cls.parent)
 for m in cls.methods:
  if wanted and m.name!=wanted:continue
  if signature and m.desc!=signature:continue
  t=method_trace(jar,cls,m,bootstraps(jar.zip.read(name+'.class'),cls))
  print(m.name,m.desc,m.flags,len(m.code), 'branches',len(t['branches']), 'handlers',t['exceptionHandlers'])
  print(' '.join(str(r['offset'])+':'+r.get('owner','?')+'.'+r.get('name','?')+r.get('descriptor','') for r in t['references'] if r['opcode']in(182,183,184,185,186)))
  if wanted:
   for x in t['instructions']:print(x['offset'],x['opcode'],x.get('constant',x['args']))
