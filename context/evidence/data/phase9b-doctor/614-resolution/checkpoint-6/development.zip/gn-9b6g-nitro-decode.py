import json,hashlib
from pathlib import Path
from grid_symbols.scan import Jar,instructions,Refusal
from grid_doctor.descriptor_resolution import Code
from grid_doctor.migrate import member
from grid_doctor.fixed_descriptors import integer
from grid_doctor.ownership import constant,method_trace,bootstraps
paths=[Path('/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar'),Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar')]
results=[]
for i,path in enumerate(paths):
 jar=Jar(path);code=Code();c=code.get(jar,'com/bitwig/nitro/NitroFile');m=member(c,'<clinit>','()V');ops=instructions(m.code);arrays={}
 for ix,(off,op,args) in enumerate(ops):
  if op!=188 or args!=(8,):continue
  count=integer(c,*ops[ix-1][1:]);buf=[]
  if not isinstance(count,int)or not 16<count<256:raise Refusal('key-size')
  for j in range(count):
   block=ops[ix+1+j*4:ix+5+j*4]
   if len(block)!=4 or block[0][1]!=89 or block[3][1]!=84 or integer(c,*block[1][1:])!=j:raise Refusal('key-block')
   val=integer(c,*block[2][1:]);buf.append(val&255)
  end=ops[ix+1+count*4]
  if end[1]!=179:raise Refusal('key-field')
  field=constant(c,int.from_bytes(bytes(end[2]),'big'));arrays[field['name']]=bytes(buf)
 hits=[(k,v)for k,v in arrays.items()if len(v)==99]
 if len(hits)!=1:raise Refusal('key-unique')
 field,key=hits[0];root=json.load(open('/tmp/gn-9b6g-module-'+('old'if i==0 else'new')+'-2.json'))['objects']['root'];blobs=[]
 def visit(v):
  if isinstance(v,dict):
   for p in v.get('properties',[]):
    if p['id']==10421:blobs.append(bytes.fromhex(p['value']['bytes']))
   for child in v.values():visit(child)
  elif isinstance(v,list):
   for child in v:visit(child)
 visit(root)
 if len(blobs)!=1:raise Refusal('program-count')
 raw=blobs[0]
 if raw[0]!=2 or len(raw)!=827:raise Refusal('program-codec')
 salt=raw[1:199]+key[:16];data=raw[199:];out=[]
 for n,val in enumerate(data):
  shift=(n//(len(key)-16))&7;b=salt[n%len(salt)];rot=((b>>shift)|(b<<(8-shift)))&255
  out.append(val^key[16+n%(len(key)-16)]^rot)
 decoded=bytes(out);dest=Path('/tmp/gn-9b6g-nitro-'+str(i)+'-decoded.bin');dest.write_bytes(decoded)
 results.append({'jarSha256':jar.sha256,'keyField':field,'keySha256':hashlib.sha256(key).hexdigest(),'encodedBytes':len(raw),'decodedBytes':len(decoded),'decodedSha256':hashlib.sha256(decoded).hexdigest(),'prefixHex':decoded[:32].hex(),'initializer':method_trace(jar,c,m,bootstraps(jar.zip.read(c.name+'.class'),c))})
 print(i,len(decoded),decoded[:32],hashlib.sha256(decoded).hexdigest())
Path('/tmp/gn-9b6g-nitro-decoded-1.json').write_text(json.dumps({'builds':results,'equalDecodedBytes':Path('/tmp/gn-9b6g-nitro-0-decoded.bin').read_bytes()==Path('/tmp/gn-9b6g-nitro-1-decoded.bin').read_bytes(),'boundedAdmission':False,'limits':['Pinned codec route requires an exact operation contract.','No AST or compiler closure is established.']},indent=2)+'\n')
