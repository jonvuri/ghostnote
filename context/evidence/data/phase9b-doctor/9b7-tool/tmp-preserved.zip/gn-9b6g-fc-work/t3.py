import sys,json;sys.path.insert(0,'/tmp/gn-9b6g-fc-work')
import walk;from walk import *
from collections import Counter
jar=Jar(NEW)
P='com/bitwig/flt/document/core/master/device/'
classes=[P+'AJD','aL','Fot','MLM','BE2','rOx','yII','vAT',P+'Rzi','ehl','WXa','BgP','CbC','BMo','Hgx',P+'hpW','bj1','qZc','LX1','aI',P+'RKg','Imy',P+'Wkj',P+'OcA','com/bitwig/nitro/CcL','RuU','FCo','ZDH']
which=sys.argv[1]
roots=[]
for c in classes:
  if which=='b_':roots.append((c,'b_','(Lcom/bitwig/ramona/core/oDc;)V',c))
  if which=='al_':roots.append((c,'al_','()V',c))
  if which=='fqW':roots.append((c,'fqW','()V',c))
  if which=='ak_':roots.append((c,'ak_','()Z',c))
if which=='zjj':roots=[('com/bitwig/ramona/core/zjj','cfM','(Lcom/bitwig/ramona/core/oDc;)V',None)]
stop=lambda o,n,d:(o,n,d) in {('BgP','cfM','(ZZZ)V')}
try:
  nodes,leaves=closure(jar,roots,max_methods=int(sys.argv[2]),max_depth=40,stop=stop)
except Exception as e:
  print('REFUSED',e);sys.exit()
print('methods',len(nodes),'leaves',len(leaves),'instr',sum(n['instructions'] for n in nodes))
news=Counter();asy=set()
for n in nodes:
  for c in n['news']:news[c]+=1
  for cl in n['calls']:
    t=cl['target'][0]
    if any(k in t for k in ('base/async','LQR','cXR','dpN','nitro/FDA','concurrent','Thread','Timer')) or cl['target'][1] in('runAtEndOfCurrentEvent','asyncExec','runAsNextEvent','execute'):asy.add((n['method'][0].split('/')[-1]+'.'+n['method'][1],cl['target']))
print('NEW',dict(news))
print('ASYNC',sorted(asy)[:40])
print('MON',[(n['method'][0].split('/')[-1]+'.'+n['method'][1],str(m)[:70]) for n in nodes for m in n['monitors']])
c=Counter((l['kind'],l['target'][0].split('/')[-1]+'.'+l['target'][1],l.get('targets')) for l in leaves)
print('OPEN',sorted(c.items(),key=lambda x:-x[1])[:40])
print('STOPPED',[ (n['method'][0].split('/')[-1]+'.'+n['method'][1],cl['offset']) for n in nodes for cl in n['calls'] if cl.get('class')=='stopped'])
