import json,time
from pathlib import Path
from grid_symbols.scan import Jar,rss_bytes,Refusal
from grid_doctor.descriptor_resolution import Code
from grid_doctor.admission import Work
from grid_doctor.receiver_trace import Declarations,ReceiverLimits
from grid_doctor.migrate import member
from grid_doctor.ownership import method_trace,bootstraps
start=time.perf_counter();j=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));c=Code();d=Declarations(j,Work(ReceiverLimits()));rows=json.load(open('/tmp/gn-9b6g-registry-closure-1.json'))['selectedRows'];classes=sorted({r['matches'][0]['runtimeClass']for r in rows}|{'com/bitwig/flt/document/core/master/device/rSf','com/bitwig/flt/document/core/master/device/OLR','EIm'});traces={};slots=[]
for cls in classes:
 for name,desc in [('ap_','()V'),*[(n,'(Lcom/bitwig/ramona/serial/rsB;)V')for n in ('Hnt','MRY','UNj','IwV')]]:
  f=d.find('method',cls,name,desc);slots.append({'receiver':cls,'name':name,'descriptor':desc,'declaration':f})
  if f['status']=='declaration':
   key=f['owner'],name,desc
   if key not in traces:
    owner=c.get(j,f['owner']);m=member(owner,name,desc);traces[key]=method_trace(j,owner,m,bootstraps(j.zip.read(owner.name+'.class'),owner))
r={'slots':slots,'methods':list(traces.values()),'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False};Path('/tmp/gn-9b6g-lifecycle-slots-1.json').write_text(json.dumps(r,indent=2));print('classes',len(classes),'slots',len(slots),'bodies',len(traces));print([(t['owner'],t['name'],t['codeBytes'])for t in traces.values()]);print(r['elapsedMs'],r['peakRssBytes'])
