import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,rss_bytes,descriptor
from grid_doctor.descriptor_resolution import Code
from grid_doctor.migrate import member
from grid_doctor.renamed_fixture import rename_member
from grid_doctor.listener_map_variant import lazy_capacity_one
from grid_doctor.contracts import contract
start=time.perf_counter();source=json.load(open('/tmp/gn-9b6g-port-setter-contracts-2.json'));selected={tuple(x['method']):x for x in source['variants']};rows=[r for r in source['matched']if tuple(r['target'])in selected];builds=[]
if len(rows)!=4:raise Refusal('listener-renamed-row-count')
for index,(path,mapping)in enumerate([('/tmp/gn-9b6g-old-renamed-extra.jar','/tmp/gn-9b6g-old-renamed-map.json'),('/tmp/gn-9b6g-renamed-extra.jar','/tmp/gn-9b6g-renamed-map.json')]):
 names=json.load(open(mapping));j=Jar(Path(path));code=Code();checked=[]
 for row in rows:
  key=row['source'if index==0 else'target'];mapped=(names.get(key[0],key[0]),rename_member(key[1]),descriptor(key[2],lambda n:names.get(n,n)));c=code.get(j,mapped[0]);m=member(c,*mapped[1:]);v=contract(c,m,j.classes)if index==0 else lazy_capacity_one(c,m,j.classes)
  if v['digest']!=row['digest']:raise Refusal('listener-renamed-digest')
  checked.append({'method':list(mapped),'digest':v['digest'],'variant':v.get('listenerMapVariant')})
 builds.append({'sha256':j.sha256,'methods':checked});del j,code
r={'builds':builds,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False};raw=json.dumps(r,indent=2).encode();Path('/tmp/gn-9b6g-listener-map-renamed-1.json').write_bytes(raw);print(len(raw),r['elapsedMs'],r['peakRssBytes'])
