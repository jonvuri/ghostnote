import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.callee_contracts import compare_callees
from grid_doctor.migrate import merge
from grid_doctor.dynamic_contracts import dynamic_contract
from grid_doctor.ownership import bootstraps
start=time.perf_counter();jars=[Jar(Path(p))for p in ['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar']];code=Code();seed=json.load(open('/tmp/gn-9b6g-invariant-contracts-1.json'))
def local(j,c,m):
 try:return dynamic_contract(c,m,j.classes,bootstraps(j.zip.read(c.name+'.class'),c),exclude_assertions=True)
 except Refusal as e:
  if str(e).startswith(('dynamic-','conditional-','contract-unsupported-constant:')):return None
  raise
traces=[{'owner':'den','name':'hUR','descriptor':'(Lcom/bitwig/ramona/core/oDc;)V'}];r=compare_callees(*jars,traces,seed,code,local_contract=local);from grid_doctor.conditional_contracts import assertion_ranges
from grid_doctor.migrate import member
for row in r['matched']:
 for label,j in [('source',jars[0]),('target',jars[1])]:
  k=row[label];c=code.get(j,k[0]);row[label+'Condition']=assertion_ranges(c,member(c,*k[1:]))
r.update(elapsedMs=(time.perf_counter()-start)*1000,peakRssBytes=rss_bytes());raw=json.dumps(r,indent=2).encode()
if len(raw)>8*1024**2:raise Refusal('invariant-contract-report-limit')
Path('/tmp/gn-9b6g-invariant-contracts-2.json').write_bytes(raw);print('matched',len(r['matched']),'unmatched',r['unmatched']);print(len(raw),r['elapsedMs'],r['peakRssBytes'])
