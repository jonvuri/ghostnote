import json,time
from pathlib import Path
from grid_symbols.scan import Jar,instructions,Refusal,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.migrate import member
from grid_doctor.fixed_descriptors import integer
from grid_doctor.ownership import constant,method_trace,bootstraps
from grid_doctor.nitro_data import AstReader
from grid_doctor.callee_contracts import compare_callees
start=time.perf_counter();paths=['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'];jars=[Jar(Path(p))for p in paths];code=Code();builds=[]
def ref(c,x):return constant(c,int.from_bytes(bytes(x[2]),'big'))
def refs(c,m):return[(x,ref(c,x))for x in instructions(m.code)if x[1]in(178,179,182,183,184,185,187)]
def single(rows,label):
 if len(rows)!=1:raise Refusal(label+':'+str(len(rows)))
 return rows[0]
for j in jars:
 traces=[];c=code.get(j,'com/bitwig/nitro/NitroFile');entry=single([m for m in c.methods if m.desc=='([B)Lcom/bitwig/nitro/NitroFile;'],'file-reader-entry');reader=single([r['value']for x,r in refs(c,entry)if x[1]==187 and r['value']!='java/io/ByteArrayInputStream'],'reader-allocation');rc=code.get(j,reader);factory=single([m for m in rc.methods if m.desc.startswith('(S)L')],'reader-node-factory');registry=single([r['owner']for x,r in refs(rc,factory)if x[1]==184 and r['descriptor'].startswith('(I)L') and r['descriptor']!='(I)Ljava/lang/Class;'],'node-registry');reg=code.get(j,registry);init=member(reg,'<clinit>','()V');rr=instructions(init.code);blocks=[]
 for i,x in enumerate(rr):
  if x[1]!=184:continue
  r=ref(reg,x)
  if r['owner']==registry and r['descriptor'].startswith('(Ljava/lang/Class;L')and r['descriptor'].endswith(';)V'):
   f=ref(reg,rr[i-1]);prev=rr[i-2];cc=constant(reg,prev[2][0]if prev[1]==18 else int.from_bytes(bytes(prev[2]),'big'))
   if cc['tag']!=7 or f['tag']!=9:raise Refusal('registry-block')
   blocks.append((f['owner'],f['name'],cc['value']))
 enum=single(list({x[0]for x in blocks}),'registry-enum');ec=code.get(j,enum);em=member(ec,'<clinit>','()V');er=instructions(em.code);ids={}
 for i,x in enumerate(er):
  if x[1]!=183:continue
  r=ref(ec,x)
  if r['owner']==enum and r['descriptor']=='(Ljava/lang/String;II)V':
   n=integer(ec,*er[i-1][1:]);f=ref(ec,er[i+1]);ids[f['name']]=n
 mapping={}
 for _,field,cls in blocks:
  ident=ids[field]
  if ident in mapping:raise Refusal('registry-duplicate-id')
  mapping[ident]=cls
 def decl(owner):
  seen=set()
  while owner and owner!='java/lang/Object':
   if owner in seen or len(seen)>64:raise Refusal('registry-parent-cycle')
   if owner=='com/bitwig/nitro/Declaration':return True
   seen.add(owner);owner=j.classes[owner].parent
  return False
 raw=Path('/tmp/gn-9b6g-nitro-'+str(len(builds))+'-decoded.bin').read_bytes();parsed=AstReader(raw,mapping,{v for v in mapping.values()if decl(v)});tree=parsed.read();used=sorted({n['id']for n in parsed.nodes});constructors=[]
 for ident in used:
  c=code.get(j,mapping[ident]);singleton=[m for m in c.methods if m.name=='getInstance'and m.desc.startswith('()L')and m.flags&9==9]
  ctor=single(singleton or[m for m in c.methods if m.name=='<init>'and m.desc=='(L'+reader+';)V'],'ast-constructor')
  constructors.append({'id':ident,'class':c.name,'method':[c.name,ctor.name,ctor.desc],'singleton':bool(singleton)})
  traces.append(method_trace(j,c,ctor,bootstraps(j.zip.read(c.name+'.class'),c)))
 for c,m in [(reg,init),(ec,em),(rc,factory)]:traces.append(method_trace(j,c,m,bootstraps(j.zip.read(c.name+'.class'),c)))
 for m in rc.methods:traces.append(method_trace(j,rc,m,bootstraps(j.zip.read(rc.name+'.class'),rc)))
 builds.append({'jarSha256':j.sha256,'reader':reader,'registryClass':registry,'enumClass':enum,'entries':mapping,'tree':tree,'constructors':constructors,'methods':traces})
 print(len(builds)-1,'reader',reader,'registry',registry,'enum',enum,'entries',len(mapping),'used',len(used),'nodes',len(parsed.nodes),'singletons',sum(r['singleton']for r in constructors),flush=True)
if set(builds[0]['entries'])!=set(builds[1]['entries']):raise Refusal('registry-id-change')
seed={'typeBindings':{builds[0]['entries'][i]:builds[1]['entries'][i]for i in builds[0]['entries']},'memberBindings':[]}
for key in ['reader','registryClass','enumClass']:seed['typeBindings'][builds[0][key]]=builds[1][key]
r=compare_callees(*jars,builds[1]['methods'],seed,code);print('contracts',len(r['matched']),'unmatched',r['unmatched'],flush=True)
report={'builds':builds,'contracts':r,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False,'limits':['Registry blocks are diagnostic anchors; constructor registration, token-field order, and semantic compilation need separate closure.']};raw=json.dumps(report,indent=2).encode()
if len(raw)>8*1024**2:raise Refusal('registry-report-limit')
Path('/tmp/gn-9b6g-nitro-registry-2.json').write_bytes(raw);print('bytes',len(raw),'ms',report['elapsedMs'],'rss',report['peakRssBytes'])
