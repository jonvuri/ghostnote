exec(open('/tmp/gn-9b6g-owned-run.py').read().split('rows=[]')[0])
from grid_doctor.callee_contracts import compare_callees
from grid_symbols.scan import ancestors
from grid_doctor.migrate import merge
from grid_doctor.fixed_read_checkpoint import membership_variants
def chain(j,n):
 out=[]
 while n in j.classes:
  if n in out or len(out)>=128:raise Refusal('runtime-parent-cycle')
  out.append(n); n=j.classes[n].parent
 out.append(n); return out
jars=[Jar(Path(p))for p in paths]; owned=json.load(open('/tmp/gn-9b6g-owned-collectors-1.json')); out=[]
for i,j in enumerate(jars):
 traces=owned['builds'][i]['methods']; variants=membership_variants(j,inputs[0]['builds'][i],code,traces)
 seed=dict(inputs[2]['builds'][i]); derived={}
 for a,b in zip(inputs[1]['builds'][0]['rows'],inputs[1]['builds'][i]['rows']):
  aa=chain(jars[0],a['matches'][0]['runtimeClass']); bb=chain(j,b['matches'][0]['runtimeClass'])
  if len(aa)!=len(bb):raise Refusal('runtime-parent-depth')
  derived=merge([derived,{}],[dict(zip(aa,bb)),{}])[0]
 seed['typeBindings']=merge([seed['typeBindings'],{}],[derived,{}])[0]
 seed['memberBindings']=json.load(open('/tmp/gn-9b6g-fixed-read-3/callees-'+str(i)+'.json'))['memberBindings']; r=compare_callees(jars[0],j,traces,seed,code,variants);out.append(r)
 print(i,'matched',len(r['matched']),'unmatched',r['unmatched'],flush=True)
r={'builds':out,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes()};Path('/tmp/gn-9b6g-owned-contracts-2.json').write_text(json.dumps(r,indent=2));print(r['elapsedMs'],r['peakRssBytes'])
