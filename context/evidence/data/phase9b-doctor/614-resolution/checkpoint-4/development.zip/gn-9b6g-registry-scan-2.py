import json,time
from pathlib import Path
from grid_symbols.scan import Jar,ancestors,instructions,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.ownership import constant,method_trace,bootstraps
start=time.perf_counter();j=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));code=Code();catalog=json.load(open('/tmp/gn-9b6g-module-catalog-1.json'))['builds'][1];wanted={r['matches'][0]['descriptor']:r['name']for r in catalog['rows']};rows=[];traces={};classes=0
for n in j.classes:
 if n=='deP'or'deP'not in ancestors(j.classes,n,128):continue
 classes+=1;c=code.get(j,n)
 for m in c.methods:
  for off,op,args in instructions(m.code):
   if op not in(18,19,178,180,182,183,184,185,187):continue
   ref=constant(c,args[0]if op==18 else int.from_bytes(bytes(args[:2]),'big'));desc=ref.get('descriptor','');result=('L'+ref['value']+';')if ref.get('tag')==7 else desc.split(')')[-1]
   if result.startswith('L')and result[1:-1]in wanted:
    rows.append({'registryClass':n,'method':[m.name,m.desc],'offset':off,'descriptorClass':result[1:-1],'name':wanted[result[1:-1]],'reference':ref});traces[n,m.name,m.desc]=method_trace(j,c,m,bootstraps(j.zip.read(n+'.class'),c))
r={'rows':rows,'methods':list(traces.values()),'registryClassesScanned':classes,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False};Path('/tmp/gn-9b6g-registry-scan-2.json').write_text(json.dumps(r,indent=2));print('classes',classes,'rows',len(rows),'methods',len(traces));print([(r['registryClass'],r['name'],r['method'])for r in rows]);print(r['elapsedMs'],r['peakRssBytes'])
