"""Test receiver and argument flow without loading vendor classes."""
import unittest
from grid_symbols.scan import Class, Member, Refusal
from grid_symbols.test_resolve import FakeJar
from .read_dataflow import ReadFlow, integer, signature
from .test_descriptor_resolution import ModelCode


def model(body, desc='()I', methods=(), cp=None, parent='java/lang/Object', others=()):
    cls = Class('Receiver', parent, (), 1, [],
                [Member('method', 'read', desc, 1, bytes(body)), *methods], cp or [None])
    jar = FakeJar([cls, *others])
    flow = ReadFlow(jar, ModelCode(), [], ('Receiver', 'id', 'I'), 17, 'Descriptor')
    return flow, ('ref', 'Receiver', 'object')


def pool(owner, name, desc, tag=10):
    return [None, (1, owner), (7, 1), (1, name), (1, desc), (12, (3, 4)), (tag, (2, 5))]


class ReadDataflowTests(unittest.TestCase):
    def test_signature_arrays_and_wide_arguments(self):
        self.assertEqual(signature('([ILX;D)J'), (['[I', 'LX;', 'D'], 'J'))
        with self.assertRaisesRegex(Refusal, 'signature'):
            signature('(V)I')
        flow, receiver = model([28, 172], '(JI)I')
        with self.assertRaisesRegex(Refusal, 'local-load'):
            flow.evaluate('Receiver', 'read', '(JI)I', receiver, (('unknown', 'J', None), integer(9)))
        flow, receiver = model([29, 172], '(JI)I')
        self.assertEqual(flow.evaluate('Receiver', 'read', '(JI)I', receiver,
                                      (('unknown', 'J', None), integer(9))), {integer(9)})

    def test_known_branch_and_unknown_branch(self):
        flow, receiver = model([27, 153, 0, 5, 4, 172, 5, 172], '(I)I')
        self.assertEqual(flow.evaluate('Receiver', 'read', '(I)I', receiver, (integer(0),)), {integer(2)})
        self.assertEqual(flow.evaluate('Receiver', 'read', '(I)I', receiver, (integer(),)), {integer(1), integer(2)})

    def test_property_field_id_is_receiver_scoped(self):
        flow, receiver = model([42, 180, 0, 6, 172], cp=pool('Receiver', 'id', 'I', 9))
        self.assertEqual(flow.evaluate('Receiver', 'read', '()I', ('ref', 'Receiver', 'property')), {integer(17)})
        self.assertEqual(flow.evaluate('Receiver', 'read', '()I', receiver), {('unknown', 'I', None)})

    def test_descriptor_argument_must_keep_the_property_id(self):
        flow, _ = model([3, 172], '(Ljava/lang/Object;I)I')
        with self.assertRaisesRegex(Refusal, 'dispatch-id'):
            flow.evaluate('Receiver', 'read', '(Ljava/lang/Object;I)I', ('ref', 'Receiver', 'descriptor'),
                          (('ref', 'Receiver', 'object'), integer(18)))

    def test_property_parent_guard_is_receiver_and_field_scoped(self):
        flow, receiver = model([42, 180, 0, 6, 176], '()LDescriptor;',
                               cp=pool('Receiver', 'parent', 'LDescriptor;', 9))
        flow.property_descriptor = (('Receiver', 'parent', 'LDescriptor;'), 'Descriptor')
        self.assertEqual(flow.evaluate('Receiver', 'read', '()LDescriptor;',
                                       ('ref', 'Receiver', 'property')),
                         {('ref', 'Descriptor', 'descriptor')})
        self.assertEqual(flow.evaluate('Receiver', 'read', '()LDescriptor;', receiver),
                         {('unknown', 'LDescriptor;', None)})
        flow, _ = model([42, 180, 0, 6, 176], '()LDescriptor;',
                        cp=pool('Receiver', 'other', 'LDescriptor;', 9))
        flow.property_descriptor = (('Receiver', 'parent', 'LDescriptor;'), 'Descriptor')
        self.assertEqual(flow.evaluate('Receiver', 'read', '()LDescriptor;',
                                       ('ref', 'Receiver', 'property')),
                         {('unknown', 'LDescriptor;', None)})

    def test_unknown_vendor_receiver_refuses(self):
        flow, _ = model([3, 172])
        with self.assertRaisesRegex(Refusal, 'unknown-receiver'):
            flow.evaluate('Receiver', 'read', '()I', ('unknown', 'LReceiver;', None))

    def test_virtual_and_special_dispatch_differ(self):
        base = Class('Base', 'java/lang/Object', (), 1, [],
                     [Member('method', 'value', '()I', 1, bytes([4, 172]))], [None])
        methods = [Member('method', 'value', '()I', 1, bytes([5, 172]))]
        for opcode, expected in ((182, 2), (183, 1)):
            flow, receiver = model([42, opcode, 0, 6, 172], methods=methods,
                                   cp=pool('Base', 'value', '()I'), parent='Base', others=[base])
            self.assertEqual(flow.evaluate('Receiver', 'read', '()I', receiver), {integer(expected)})

    def test_cycle_and_back_edge_refuse(self):
        flow, receiver = model([42, 182, 0, 6, 172], cp=pool('Receiver', 'read', '()I'))
        with self.assertRaisesRegex(Refusal, 'recursion'):
            flow.evaluate('Receiver', 'read', '()I', receiver)
        flow, receiver = model([167, 0, 0])
        with self.assertRaisesRegex(Refusal, 'back-edge'):
            flow.evaluate('Receiver', 'read', '()I', receiver)

    def test_external_call_stays_a_dependency(self):
        flow, receiver = model([3, 184, 0, 6, 176], '()Ljava/lang/Integer;',
                               cp=pool('java/lang/Integer', 'valueOf', '(I)Ljava/lang/Integer;'))
        flow.evaluate('Receiver', 'read', '()Ljava/lang/Integer;', receiver)
        self.assertEqual(flow.external, {('java/lang/Integer', 'valueOf', '(I)Ljava/lang/Integer;', None)})

    def test_arithmetic_uses_jvm_integer_overflow(self):
        flow, receiver = model([27, 4, 96, 172], '(I)I')
        self.assertEqual(flow.evaluate('Receiver', 'read', '(I)I', receiver, (integer(2**31 - 1),)), {integer(-2**31)})

    def test_work_limit_refuses(self):
        flow, receiver = model([3, 172]); flow.work['states'] = 100000
        with self.assertRaisesRegex(Refusal, 'state-limit'):
            flow.evaluate('Receiver', 'read', '()I', receiver)

    def test_call_limit_refuses_before_external_dispatch(self):
        flow, receiver = model([3, 184, 0, 6, 176], '()Ljava/lang/Integer;',
                               cp=pool('java/lang/Integer', 'valueOf', '(I)Ljava/lang/Integer;'))
        flow.work['calls'] = 16000
        with self.assertRaisesRegex(Refusal, 'call-limit'):
            flow.evaluate('Receiver', 'read', '()Ljava/lang/Integer;', receiver)
        self.assertFalse(flow.external)

    def test_special_call_requires_a_known_nonnull_receiver(self):
        flow, _ = model([3, 172])
        for value in [('null', 'Ljava/lang/Object;', None), ('unknown', 'LReceiver;', None)]:
            with self.subTest(value=value), self.assertRaisesRegex(Refusal, 'unknown-receiver'):
                flow.evaluate('Receiver', 'read', '()I', value, direct=True)

    def test_private_virtual_form_refuses(self):
        base = Class('Base', 'java/lang/Object', (), 1, [],
                     [Member('method', 'value', '()I', 2, bytes([4, 172]))], [None])
        flow, receiver = model([42, 182, 0, 6, 172],
                               methods=[Member('method', 'value', '()I', 1, bytes([5, 172]))],
                               cp=pool('Base', 'value', '()I'), parent='Base', others=[base])
        with self.assertRaisesRegex(Refusal, 'private-or-unresolved-virtual'):
            flow.evaluate('Receiver', 'read', '()I', receiver)


if __name__ == '__main__':
    unittest.main()
