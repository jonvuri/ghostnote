"""Inert history-helper model, attempt 3: exact path formulas and scans.

It interprets vendor and bundled-JDK bytecode in Python with inert objects.
It loads no vendor class, starts no JVM, and initializes no runtime class.
"""
import hashlib, json, math, random, sys, time, zipfile
from collections import Counter
from pathlib import Path
from grid_symbols.scan import parse, instructions, Refusal, rss_bytes
from grid_doctor.ownership import constant, bootstraps
from grid_doctor import history_growth as hg

START = time.perf_counter()
NEW = Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar')
OLD = Path('/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar')
RENAMED_NEW, RENAMED_OLD = Path('/tmp/gn-9b6g-renamed-extra.jar'), Path('/tmp/gn-9b6g-old-renamed-extra.jar')
JDK = [Path('/tmp/gn-9b6g-runtime-new-arm64-9/java.base'), Path('/tmp/gn-9b6g-history-growth-jdk-1/java.base')]
PINNED_INPUTS = {
    str(NEW): '5c2b1895bbb9e7d08d9216de421985bb1f24b2ee62762c9451b4fe847df2469f',
    str(OLD): '382c655d0b9e8db6bd433dc6100ef3a4ee23abf6a6615f79c40f0c2645792c93',
    str(RENAMED_NEW): 'ae29e627246fa89eb35a1c11e2c2623026bd84185f161b3b19b813b9508dde7e',
    str(RENAMED_OLD): '23708ef4c362ed072410c5415857bddcbfdc71f26087760cf5158ef8bf4158d6',
    '/tmp/gn-9b6g-runtime-new-arm64-9/java.base/java/util/ArrayList.class': None,
    '/tmp/gn-9b6g-history-growth-jdk-1/java.base/java/util/Collection.class':
        '115defd3b61bd0ce2954e36c8ba43ce085fbf7780b53040c30cd9a2238f4f6ac',
}
LIMITS = {'seconds': 120, 'rssBytes': 768 * 1024**2, 'reportBytes': 8 * 1024**2,
          'instructionsPerCall': 2_000_000, 'frameDepth': 64, 'cases': 20000}


def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


hashes = {}
for p, want in PINNED_INPUTS.items():
    hashes[p] = sha(p)
    if want and hashes[p] != want:
        raise Refusal('history-growth-input-hash:' + p)


class Source:
    def __init__(self, jar):
        self.zip, self.cache = zipfile.ZipFile(jar), {}

    def load(self, name):
        if name not in self.cache:
            if name.startswith(('java/', 'jdk/')):
                for base in JDK:
                    if (base / (name + '.class')).exists():
                        raw = (base / (name + '.class')).read_bytes(); break
                else:
                    raise KeyError(name)
            else:
                raw = self.zip.read(name + '.class')
            c = parse(raw, True)
            ins = {m.name + m.desc: m for m in c.methods}
            self.cache[name] = (c, bootstraps(raw, c), ins, hashlib.sha256(raw).hexdigest())
        return self.cache[name]


# ---------------------------------------------------------------- contracts
contracts = {}
for label, path, kind in (('new', NEW, 'real'), ('renamedNew', RENAMED_NEW, 'renamed')):
    src = Source(path)
    if kind == 'renamed':
        mp = json.load(open('/tmp/gn-9b6g-renamed-map.json'))
        rc, rm = (lambda n, mp=mp: mp.get(n, n)), (lambda n: n if n.startswith('<') else 'r_' + n)
    else:
        rc = rm = (lambda n: n)
    out = hg.check_bodies(lambda n, s=src: s.load(n)[:2], rc, rm)
    contracts[label] = {'targets': len(out['targets']),
                        'instructions': sum(v['instructions'] for v in out['targets'].values()),
                        'allPinned': True}
old_rows = {}
for label, path, name in (('old', OLD, 'cZl'), ('renamedOld', RENAMED_OLD,
                          json.load(open('/tmp/gn-9b6g-old-renamed-map.json'))['cZl'])):
    c = parse(zipfile.ZipFile(path).read(name + '.class'), True)
    old_rows[label] = hg.old_structure(c)
    if old_rows[label]['structurePresent']:
        raise Refusal('history-growth-old-structure-present')

# ---------------------------------------------------------------- inert machine
WIDE = object()
ASSERT_TRUE = {('dgJ', 'cfM'), ('dfI', 'FzB'), ('com/bitwig/ramona/core/AVL', 'jOH'),
               ('com/bitwig/ramona/core/oDc', 'xPh'), ('eSw', 'FzB')}


class Obj:
    __slots__ = ('cls', 'f', 'hash')

    def __init__(self, cls, **f):
        self.cls, self.f, self.hash = cls, f, None


class Arr:
    __slots__ = ('typ', 'v')

    def __init__(self, typ, n, fill=None):
        self.typ, self.v = typ, [fill] * n


class Lambda:
    def __init__(self, handle, captured):
        self.handle, self.captured = handle, captured


class Thrown(Exception):
    pass


def i32(x):
    return ((x + 2**31) % 2**32) - 2**31


def i64(x):
    return ((x + 2**63) % 2**64) - 2**63


def jdiv(a, b):
    q = abs(a) // abs(b)
    return q if (a >= 0) == (b >= 0) else -q


class Machine:
    def __init__(self, src, fail_alloc=None):
        self.src, self.c, self.depth, self.fail_alloc = src, Counter(), 0, fail_alloc
        self.per = Counter()
        self.next_hash = 1

    def cat(self, owner):
        return 'jdk' if owner.startswith(('java/', 'jdk/')) else 'vendor'

    def lookup(self, owner, key, virtual):
        name = owner
        while name:
            c, boot, ms, _ = self.src.load(name)
            m = ms.get(key)
            if m is not None and not (m.flags & 0x400):
                return name, m
            if not virtual and m is not None:
                raise Refusal('model-abstract:' + name + key)
            name = c.parent
        # Maximally specific default method (search interfaces breadth first).
        todo, seen, found = [owner], set(), []
        while todo:
            n = todo.pop(0)
            if n in seen or not n:
                continue
            seen.add(n)
            try:
                c, _, ms, _ = self.src.load(n)
            except KeyError:
                continue
            m = ms.get(key)
            if m is not None and c.flags & 0x200 and not (m.flags & 0x400):
                found.append((n, m))
            todo += list(c.interfaces) + ([c.parent] if c.parent else [])
        if len(found) != 1:
            raise Refusal('model-resolve:' + owner + '.' + key + ':' + str(len(found)))
        return found[0]

    def subtype(self, name, target):
        if target == 'java/lang/Object' or name == target:
            return True
        todo, seen = [name], set()
        while todo:
            n = todo.pop()
            if n in seen or not n:
                continue
            seen.add(n)
            if n == target:
                return True
            try:
                c = self.src.load(n)[0]
            except KeyError:
                continue
            todo += [c.parent, *c.interfaces]
        return False

    def stub(self, owner, name, desc, args):
        key = (owner, name)
        if key == ('java/lang/System', 'identityHashCode'):
            self.c['native'] += 1
            o = args[0]
            if o.hash is None:
                o.hash = self.next_hash; self.next_hash += 1
            return o.hash
        if key == ('java/lang/System', 'arraycopy'):
            self.c['native'] += 1
            s, sp, d, dp, n = args
            self.c['arraycopySlots'] += n
            d.v[dp:dp + n] = s.v[sp:sp + n]
            return None
        if key == ('java/lang/StrictMath', 'ceil'):
            self.c['jdkStub'] += 1
            return float(math.ceil(args[0]))
        if key == ('java/util/Arrays', 'copyOf') and desc == '([Ljava/lang/Object;I)[Ljava/lang/Object;':
            self.c['jdkStub'] += 1; self.c['allocJdk'] += 1
            a = Arr(args[0].typ, args[1]); a.v[:min(args[1], len(args[0].v))] = args[0].v[:args[1]]
            return a
        if key == ('jdk/internal/util/ArraysSupport', 'newLength'):
            self.c['jdkStub'] += 1
            return args[0] + max(args[1], args[2])
        return NotImplemented

    def invoke(self, owner, name, desc, args, virtual):
        r = self.stub(owner, name, desc, args)
        if r is not NotImplemented:
            return r
        if virtual and isinstance(args[0], Lambda):
            lam = args[0]; self.c['lambdaFrame'] += 1
            target = lam.handle['target']
            call = lam.captured + args[1:]
            return self.invoke(target['owner'], target['name'], target['descriptor'], call,
                               lam.handle['kind'] in (5, 9))
        if virtual:
            recv = args[0]
            if recv is None:
                raise Refusal('model-null-receiver:' + owner + '.' + name)
            start = recv.cls if isinstance(recv, Obj) else 'java/lang/Object'
            decl, m = self.lookup(start, name + desc, True)
        else:
            decl, m = self.lookup(owner, name + desc, False)
        if m.flags & 0x100:
            raise Refusal('model-native:' + decl + '.' + name)
        return self.run(decl, m, args)

    def run(self, owner, m, args, start=0, preset=None):
        cat = self.cat(owner)
        self.c[cat + 'Calls'] += 1
        self.depth += 1
        if self.depth > LIMITS['frameDepth']:
            raise Refusal('model-depth')
        try:
            return self._run(owner, m, args, cat, start, preset)
        finally:
            self.depth -= 1

    def _run(self, owner, m, args, cat, start, preset):
        cls, boot, _, _ = self.src.load(owner)
        raw = instructions(m.code)
        at = {r[0]: i for i, r in enumerate(raw)}
        local, slot = {}, 0
        static = bool(m.flags & 8)
        params = hg.re.findall(r'\[*(?:L[^;]+;|[ZBCSIFJD])', m.desc[1:m.desc.index(')')])
        values = list(args)
        if not static:
            local[0] = values.pop(0); slot = 1
        for p, v in zip(params, values):
            local[slot] = v; slot += 2 if p in ('J', 'D') else 1
        if preset:
            local.update(preset)
        st = []
        pc = start
        key = cat + 'Instructions'
        while True:
            self.c[key] += 1
            self.per[(owner, m.name + m.desc)] += 1
            if self.c[key] > LIMITS['instructionsPerCall']:
                raise Refusal('model-instruction-limit')
            i = at[pc]; off, op, a = raw[i]
            nxt = raw[i + 1][0] if i + 1 < len(raw) else None

            def ref():
                width = 1 if op == 18 else 2
                return constant(cls, int.from_bytes(bytes(a[:width]), 'big'))

            def br():
                return off + int.from_bytes(bytes(a), 'big', signed=True)
            jump = None
            if op == 0: pass
            elif op == 1: st.append(None)
            elif 2 <= op <= 8: st.append(op - 3)
            elif op in (9, 10): st += [op - 9, WIDE]
            elif 11 <= op <= 13: st.append(float(op - 11))
            elif op in (14, 15): st += [float(op - 14), WIDE]
            elif op == 16: st.append(int.from_bytes(bytes(a), 'big', signed=True))
            elif op == 17: st.append(int.from_bytes(bytes(a), 'big', signed=True))
            elif op in (18, 19, 20):
                k = ref()
                if k['tag'] == 3: st.append(int.from_bytes(bytes.fromhex(k['value']), 'big', signed=True))
                elif k['tag'] == 4:
                    import struct; st.append(struct.unpack('>f', bytes.fromhex(k['value']))[0])
                elif k['tag'] == 5: st += [int.from_bytes(bytes.fromhex(k['value']), 'big', signed=True), WIDE]
                elif k['tag'] == 6:
                    import struct; st += [struct.unpack('>d', bytes.fromhex(k['value']))[0], WIDE]
                elif k['tag'] == 8: st.append('str:' + k['value'])
                else: raise Refusal('model-ldc')
            elif op in (21, 23, 25): st.append(local[a[0]])
            elif op in (22, 24): st += [local[a[0]], WIDE]
            elif 26 <= op <= 29: st.append(local[op - 26])
            elif 30 <= op <= 33: st += [local[op - 30], WIDE]
            elif 34 <= op <= 37: st.append(local[op - 34])
            elif 38 <= op <= 41: st += [local[op - 38], WIDE]
            elif 42 <= op <= 45: st.append(local[op - 42])
            elif op in (46, 48, 50, 51, 52, 53, 47, 49):
                idx = st.pop(); arr = st.pop()
                if arr is None: raise Refusal('model-null-array')
                if idx < 0 or idx >= len(arr.v): raise Refusal('model-array-index')
                st.append(arr.v[idx])
                if op in (47, 49): st.append(WIDE)
            elif op in (54, 56, 58): local[a[0]] = st.pop()
            elif op in (55, 57): st.pop(); local[a[0]] = st.pop(); local[a[0] + 1] = WIDE
            elif 59 <= op <= 62: local[op - 59] = st.pop()
            elif 63 <= op <= 66: st.pop(); local[op - 63] = st.pop()
            elif 67 <= op <= 70: local[op - 67] = st.pop()
            elif 71 <= op <= 74: st.pop(); local[op - 71] = st.pop()
            elif 75 <= op <= 78: local[op - 75] = st.pop()
            elif op in (79, 81, 83, 84, 85, 86, 80, 82):
                if op in (80, 82): st.pop()
                v = st.pop(); idx = st.pop(); arr = st.pop()
                if idx < 0 or idx >= len(arr.v): raise Refusal('model-array-index')
                arr.v[idx] = v
            elif op == 87: st.pop()
            elif op == 88: st.pop(); st.pop()
            elif op == 89: st.append(st[-1])
            elif op == 90: v1 = st.pop(); v2 = st.pop(); st += [v1, v2, v1]
            elif op == 91: v1 = st.pop(); v2 = st.pop(); v3 = st.pop(); st += [v1, v3, v2, v1]
            elif op == 92: st += st[-2:]
            elif op == 93: v1 = st.pop(); v2 = st.pop(); v3 = st.pop(); st += [v2, v1, v3, v2, v1]
            elif op == 95: v1 = st.pop(); v2 = st.pop(); st += [v1, v2]
            elif op in (96, 100, 104, 108, 112, 120, 122, 124, 126, 128, 130):
                b = st.pop(); x = st.pop()
                if op in (108, 112) and b == 0:
                    raise Refusal('model-div0')
                r = (x + b if op == 96 else x - b if op == 100 else x * b if op == 104
                     else jdiv(x, b) if op == 108 else x - jdiv(x, b) * b if op == 112
                     else x << (b & 31) if op == 120 else x >> (b & 31) if op == 122
                     else (x % 2**32) >> (b & 31) if op == 124 else x & b if op == 126
                     else x | b if op == 128 else x ^ b)
                st.append(i32(r))
            elif op in (97, 101, 105, 109, 113, 127, 129, 131):
                st.pop(); b = st.pop(); st.pop(); x = st.pop()
                if op in (109, 113) and b == 0:
                    raise Refusal('model-div0')
                r = (x + b if op == 97 else x - b if op == 101 else x * b if op == 105
                     else jdiv(x, b) if op == 109 else x - jdiv(x, b) * b if op == 113
                     else x & b if op == 127 else x | b if op == 129 else x ^ b)
                st += [i64(r), WIDE]
            elif op in (121, 123, 125):
                b = st.pop(); st.pop(); x = st.pop()
                r = {121: x << (b & 63), 123: x >> (b & 63), 125: (x % 2**64) >> (b & 63)}[op]
                st += [i64(r), WIDE]
            elif op in (98, 102, 106, 110):
                b = st.pop(); x = st.pop()
                st.append(x + b if op == 98 else x - b if op == 102 else x * b if op == 106 else x / b)
            elif op in (99, 103, 107, 111):
                st.pop(); b = st.pop(); st.pop(); x = st.pop()
                st += [x + b if op == 99 else x - b if op == 103 else x * b if op == 107 else x / b, WIDE]
            elif op == 116: st.append(i32(-st.pop()))
            elif op == 117: st.pop(); st += [i64(-st.pop()), WIDE]
            elif op == 132: local[a[0]] = i32(local[a[0]] + int.from_bytes(bytes(a[1:]), 'big', signed=True))
            elif op == 133: st += [st.pop(), WIDE]
            elif op in (134,): st.append(float(st.pop()))
            elif op == 135: st += [float(st.pop()), WIDE]
            elif op == 136: st.pop(); st.append(i32(st.pop()))
            elif op in (137, 138): st.pop(); v = float(st.pop()); st += ([v] if op == 137 else [v, WIDE])
            elif op in (139, 140, 141):
                v = st.pop()
                if op == 139: st.append(i32(int(v)))
                elif op == 140: st += [i64(int(v)), WIDE]
                else: st += [float(v), WIDE]
            elif op in (142, 143, 144):
                st.pop(); v = st.pop()
                if op == 142: st.append(max(-2**31, min(2**31 - 1, int(v))))
                elif op == 143: st += [max(-2**63, min(2**63 - 1, int(v))), WIDE]
                else: st.append(float(v))
            elif op == 148:
                st.pop(); b = st.pop(); st.pop(); x = st.pop(); st.append((x > b) - (x < b))
            elif op in (149, 150):
                b = st.pop(); x = st.pop(); st.append((x > b) - (x < b))
            elif op in (151, 152):
                st.pop(); b = st.pop(); st.pop(); x = st.pop(); st.append((x > b) - (x < b))
            elif 153 <= op <= 158:
                v = st.pop()
                if {153: v == 0, 154: v != 0, 155: v < 0, 156: v >= 0, 157: v > 0, 158: v <= 0}[op]: jump = br()
            elif 159 <= op <= 164:
                b = st.pop(); x = st.pop()
                if {159: x == b, 160: x != b, 161: x < b, 162: x >= b, 163: x > b, 164: x <= b}[op]: jump = br()
            elif op in (165, 166):
                b = st.pop(); x = st.pop()
                if (x is b) == (op == 165): jump = br()
            elif op == 167: jump = br()
            elif op in (172, 174, 176): return st.pop()
            elif op in (173, 175): st.pop(); return st.pop()
            elif op == 177: return None
            elif op in (178, 179):
                k = ref()
                if op == 179: raise Refusal('model-putstatic:' + k['owner'] + '.' + k['name'])
                if (k['owner'], k['name']) not in ASSERT_TRUE:
                    raise Refusal('model-getstatic:' + k['owner'] + '.' + k['name'])
                st.append(1)
            elif op == 180:
                k = ref(); o = st.pop()
                if o is None: raise Refusal('model-null-field')
                v = o.f.get(k['name'], 0 if k['descriptor'] in 'ZBCSIJFD' else None)
                st.append(v)
                if k['descriptor'] in ('J', 'D'): st.append(WIDE)
            elif op == 181:
                k = ref()
                if k['descriptor'] in ('J', 'D'): st.pop()
                v = st.pop(); o = st.pop(); o.f[k['name']] = v
            elif op in (182, 183, 184, 185):
                k = ref()
                params = hg.re.findall(r'\[*(?:L[^;]+;|[ZBCSIFJD])', k['descriptor'][1:k['descriptor'].index(')')])
                vals = []
                for p in reversed(params):
                    if p in ('J', 'D'): st.pop()
                    vals.append(st.pop())
                vals.reverse()
                if op != 184: vals.insert(0, st.pop())
                cat2 = self.cat(k['owner'])
                self.c[cat + 'CallSites'] += 1
                r = self.invoke(k['owner'], k['name'], k['descriptor'], vals, op in (182, 185))
                ret = k['descriptor'][k['descriptor'].index(')') + 1:]
                if ret != 'V':
                    st.append(r)
                    if ret in ('J', 'D'): st.append(WIDE)
            elif op == 186:
                k = ref(); entry = boot[k['bootstrapIndex']]
                if entry['handle']['target']['owner'] != 'java/lang/invoke/LambdaMetafactory':
                    raise Refusal('model-indy')
                n = len(hg.re.findall(r'\[*(?:L[^;]+;|[ZBCSIFJD])', k['descriptor'][1:k['descriptor'].index(')')]))
                cap = [st.pop() for _ in range(n)][::-1]
                self.c['lambdaAllocations'] += 1
                st.append(Lambda(entry['arguments'][1], cap))
            elif op == 187:
                k = ref(); self.c['alloc' + ('Jdk' if self.cat(k['value']) == 'jdk' else 'Vendor')] += 1
                if self.fail_alloc is not None and self.c['allocVendor'] + self.c['allocJdk'] == self.fail_alloc:
                    raise Thrown('injected-allocation-failure')
                if k['value'].endswith('Exception') or k['value'].endswith('Error'):
                    raise Refusal('model-exception-path:' + k['value'])
                st.append(Obj(k['value']))
            elif op in (188, 189):
                n = st.pop()
                if n < 0: raise Refusal('model-negative-array')
                self.c['alloc' + ('Jdk' if cat == 'jdk' else 'Vendor')] += 1
                self.c['arraySlots'] += n
                fill = 0 if op == 188 else None
                st.append(Arr('prim' if op == 188 else ref()['value'], n, fill))
            elif op == 190: st.append(len(st.pop().v))
            elif op == 191: raise Thrown('athrow')
            elif op == 192:
                k = ref(); v = st[-1]
                if v is not None and isinstance(v, Obj) and not self.subtype(v.cls, k['value']):
                    raise Refusal('model-checkcast:' + v.cls + '->' + k['value'])
            elif op == 193:
                k = ref(); v = st.pop()
                st.append(int(isinstance(v, Obj) and self.subtype(v.cls, k['value'])))
            elif op in (194, 195): raise Refusal('model-monitor')
            elif op in (198, 199):
                v = st.pop()
                if (v is None) == (op == 198): jump = br()
            else:
                raise Refusal('model-opcode:%d' % op)
            pc = jump if jump is not None else nxt


# ---------------------------------------------------------------- cases (attempt 2)
src = Source(NEW)
OBJ = 'com/bitwig/ramona/core/oDc'
SET_DESC = '(Lcom/bitwig/ramona/core/oDc;)V'


def obj(parent=None, h=None):
    o = Obj(OBJ, IwV=parent); o.hash = h; return o


def chain(depth, top=None, h=None):
    p = top
    for _ in range(depth):
        p = obj(p)
    return obj(p, h)


def arraylist(items, spare=4):
    a = Arr('java/lang/Object', len(items) + spare)
    a.v[:len(items)] = items
    return Obj('java/util/ArrayList', elementData=a, size=len(items), modCount=0)


def run_method(mach, owner, name, desc, args, start=0):
    decl, m = mach.lookup(owner, name + desc, False)
    return mach.run(decl, m, args, start)


def new_helper(mach, doc, first):
    return run_method(mach, 'dfI', 'IwV', '(Lcom/bitwig/ramona/core/oDc;)LdgI;', [doc, first])


def build_helper(elements, removed=()):
    mach = Machine(src)
    doc = Obj('dfI', Z1C=arraylist([]), dEI=None)
    h = None
    for e in elements:
        h = new_helper(mach, doc, e)
    for root in removed:
        run_method(mach, 'dgJ', 'FzB', SET_DESC, [h, root])
    return h


def snap(c):
    keys = ('vendorInstructions', 'jdkInstructions', 'vendorCalls', 'jdkCalls', 'native',
            'jdkStub', 'lambdaFrame', 'lambdaAllocations', 'allocVendor', 'allocJdk',
            'arraycopySlots', 'arraySlots')
    return {k: c.get(k, 0) for k in keys}


def table(h):
    s = h.f['MRY']
    keys = s.f['cfM'].v
    occupied = [i for i in range(s.f['UNj']) if keys[i] is not None]
    return {'n': s.f['UNj'], 'size': s.f['lYc'], 'maxFill': s.f['hUR'], 'minN': s.f['TMF'],
            'containsNull': s.f.get('FzB', 0), 'keyLength': len(keys),
            'skipped': (s.f['UNj'] - min(occupied) - len(occupied)) if occupied else 0}


def depth(e):
    d, p = 0, e.f['IwV']
    while p is not None:
        d += 1; p = p.f['IwV']
    return d


# Exact path formulas. They follow from the loop structure of the exact bodies;
# each constant is the instruction count of one fixed path, assertions disabled.
# s: set size; K: empty slots the iterator skips (K <= n - s); n: table length;
# W: sum of walked parent counts over the set elements (W <= s*D); H: helpers.
def f_match_absent(s, K, W):
    return 51 + 78 * s + 13 * K + 12 * W, 1


def f_prune_none(s, K, W):
    return 49 + 72 * s + 13 * K + 12 * W, 18 + 8 * s


def f_removed(parts):
    H = len(parts)
    return (8 + 11 * H + sum(4 + v for v, _ in parts), 35 + 46 * H + sum(j for _, j in parts))


def f_inserted(parts):
    if not parts:
        return 5, 6
    v, j = f_removed(parts)
    return v + 4, j + 5


exact, failures, cases = Counter(), [], 0


def expect(kind, params, got, want):
    global cases
    cases += 1
    if cases > LIMITS['cases']:
        raise Refusal('model-case-limit')
    exact[kind] += 1
    if tuple(got) != tuple(want):
        failures.append({'kind': kind, 'params': params, 'got': list(got), 'want': list(want)})


def within(kind, params, got, bound):
    global cases
    cases += 1
    exact[kind + ':bounded'] += 1
    if any(g > b for g, b in zip(got, bound)):
        failures.append({'kind': kind, 'params': params, 'got': list(got), 'bound': list(bound)})


summary = {'match': [], 'prune': [], 'document': [], 'editMatch': [], 'pending': [], 'cleanup': [],
           'removing': [], 'dnzRemove': [], 'partial': []}

# 1. Set scans without removal: exact formulas over size, capacity, and depth.
for s in (1, 2, 5, 12, 24, 25, 40, 60):
    for D in (0, 1, 3, 6):
        for extra in (0, 40):
            elems = [chain(D) for _ in range(s + extra)]
            h = build_helper(elems, removed=elems[s:])
            t = table(h)
            if t['size'] != s or t['containsNull']:
                raise Refusal('model-setup-size')
            W = sum(depth(e) for e in elems[:s])
            m = Machine(src)
            if run_method(m, 'dgJ', 'IwV', '(Lcom/bitwig/ramona/core/oDc;)Z', [h, obj()]) != 0:
                raise Refusal('model-unexpected-match')
            o = snap(m.c)
            expect('helper.match-absent', [s, D, t['n']], (o['vendorInstructions'], o['jdkInstructions']),
                   f_match_absent(s, t['skipped'], W))
            summary['match'].append([s, D, t['n'], t['skipped'], o['vendorInstructions'], o['vendorCalls'], o['native']])
            m = Machine(src)
            run_method(m, 'dgJ', 'FzB', SET_DESC, [h, obj()])
            o = snap(m.c)
            expect('helper.prune-none', [s, D, t['n']], (o['vendorInstructions'], o['jdkInstructions']),
                   f_prune_none(s, t['skipped'], W))
            if o['lambdaFrame'] != s or o['lambdaAllocations'] != 1 or o['native'] or table(h)['size'] != s:
                failures.append({'kind': 'prune-calls', 's': s, 'o': o})
            summary['prune'].append([s, D, t['n'], t['skipped'], o['vendorInstructions'], o['jdkInstructions'],
                                     o['vendorCalls'], o['jdkCalls'], o['lambdaFrame'], o['allocVendor']])

# Matching exits stop early and stay within the absent bound.
for s in (1, 5, 24):
    for D in (0, 3):
        root = obj()
        elems = [chain(D) for _ in range(s - 1)] + [chain(D, top=root)]
        h = build_helper(elems)
        t = table(h)
        for probe, kind in ((root, 'ancestor'), (elems[0], 'identity')):
            m = Machine(src)
            if run_method(m, 'dgJ', 'IwV', '(Lcom/bitwig/ramona/core/oDc;)Z', [h, probe]) != 1:
                raise Refusal('model-expected-match')
            o = snap(m.c)
            W = sum(depth(e) for e in elems)
            within('helper.match-' + kind, [s, D], (o['vendorInstructions'], o['jdkInstructions']),
                   f_match_absent(s, t['n'] - s, W))

# 2. Document scans over H helpers (hUR is reached by every final removal).
for H in (0, 1, 2, 3, 5, 8):
    for s in (1, 6, 30):
        for D in (0, 2):
            helpers = [build_helper([chain(D) for _ in range(s)]) for _ in range(H)]
            parts = [f_prune_none(s, table(h)['skipped'], s * D) for h in helpers]
            for name, f in (('hUR', f_removed), ('UNj', f_inserted)):
                doc = Obj('dfI', Z1C=arraylist(helpers), dEI=None)
                m = Machine(src)
                run_method(m, 'dfI', name, SET_DESC, [doc, obj()])
                o = snap(m.c)
                expect('document.' + name, [H, s, D], (o['vendorInstructions'], o['jdkInstructions']), f(parts))
                summary['document'].append([name, H, s, D, sum(table(h)['n'] for h in helpers),
                                            o['vendorInstructions'], o['jdkInstructions'],
                                            o['vendorCalls'], o['jdkCalls'], o['lambdaFrame']])


# 3. Edit match: attach the edit to matching helpers and remove them from Z1C.
def loop_free_length(owner, key):
    c, _, ms, _ = src.load(owner)
    m = ms[key]
    raw = instructions(m.code)
    for off, op, a in raw:
        if op in hg.BRANCHES or op in (167, 200):
            if off + int.from_bytes(bytes(a), 'big', signed=True) <= off:
                raise Refusal('model-loop-in:' + owner + key)
    return len(raw)


LIST_REMOVE = [('java/util/ArrayList$Itr', 'remove()V'), ('java/util/ArrayList$Itr', 'checkForComodification()V'),
               ('java/util/ArrayList', 'remove(I)Ljava/lang/Object;'),
               ('java/util/ArrayList', 'fastRemove([Ljava/lang/Object;I)V'),
               ('java/util/Objects', 'checkIndex(II)I'),
               ('jdk/internal/util/Preconditions', 'checkIndex(IILjava/util/function/BiFunction;)I')]
LIST_REMOVE_BOUND = sum(loop_free_length(o, k) for o, k in LIST_REMOVE)
for H in (1, 3, 6):
    for M in sorted({0, 1, H // 2, H}):
        s, D = 5, 2
        target = obj()
        helpers = []
        for i in range(H):
            elems = [chain(D) for _ in range(s)]
            if i < M:
                elems[-1] = chain(D, top=target)
            helpers.append(build_helper(elems))
        n = [table(h)['n'] for h in helpers]
        doc = Obj('dfI', Z1C=arraylist(helpers), dEI=None)
        edit = Obj('dfT')
        m = Machine(src)
        run_method(m, 'dfI', 'cfM', '(Lcom/bitwig/ramona/core/oDc;LdfT;)V', [doc, target, edit])
        o = snap(m.c)
        if doc.f['Z1C'].f['size'] != H - M or any(h.f.get('Hnt') is not edit for h in helpers[:M]) \
                or any(h.f.get('Hnt') is not None for h in helpers[M:]):
            raise Refusal('model-edit-match-result')
        vb = 12 + 15 * H + 2 * M + sum(16 + f_match_absent(s, n[i] - s, s * (D + 1))[0] for i in range(H))
        jb = 40 + 47 * H + M * LIST_REMOVE_BOUND
        within('document.edit-match', [H, M], (o['vendorInstructions'], o['jdkInstructions']), (vb, jb))
        summary['editMatch'].append([H, M, o['vendorInstructions'], vb, o['jdkInstructions'], jb,
                                     o['arraycopySlots'], o['native']])
doc0 = Obj('dfI', Z1C=arraylist([]), dEI=None)
m = Machine(src)
run_method(m, 'dfI', 'cfM', '(Lcom/bitwig/ramona/core/oDc;LdfT;)V', [doc0, obj(), Obj('dfT')])
expect('document.edit-match-empty', [0], (snap(m.c)['vendorInstructions'], snap(m.c)['jdkInstructions']), (5, 6))


# 4. Pending helper (dEI): creation, extension, and exact table growth.
def grow_rule(adds, initial=16, factor=0.75):
    n = hg.table_length(initial); fill = min(math.ceil(n * factor), n - 1); size = 0
    for _ in range(adds):
        old = size; size += 1
        if old >= fill:
            n = hg.table_length(size + 1); fill = min(math.ceil(n * factor), n - 1)
    return n


m = Machine(src)
doc = Obj('dfI', Z1C=arraylist([]), dEI=None)
for k in range(1, 101):
    before = snap(m.c)
    new_helper(m, doc, obj())
    after = snap(m.c)
    delta = {key: after[key] - before[key] for key in after}
    t = table(doc.f['dEI'])
    if t['n'] != grow_rule(k) or t['size'] != k or t['n'] > hg.capacity_bound(16, k):
        failures.append({'kind': 'pending-capacity', 'k': k, 'table': t})
    summary['pending'].append([k, t['n'], delta['vendorInstructions'], delta['jdkInstructions'],
                               delta['allocVendor'], delta['arraySlots'], delta['native']])
first_create = summary['pending'][0]
plain_adds = sorted({r[2] for r in summary['pending'][1:] if r[4] == 0})

# Cleanup tail of wGc from offset 112: Z1C.removeIf(empty helpers), append dEI, clear dEI.
only = obj()
empty_helper = build_helper([only], removed=[only])
for H in (0, 1, 4, 8):
    for empties in sorted({0, H // 2, H}):
        hs = [empty_helper if i < empties else build_helper([obj()]) for i in range(H)]
        doc2 = Obj('dfI', Z1C=arraylist(hs, spare=4), dEI=build_helper([obj()]))
        m3 = Machine(src)
        decl, meth = m3.lookup('dfI', 'wGc()V', False)
        m3.run(decl, meth, [doc2], start=112)
        o = snap(m3.c)
        if doc2.f['dEI'] is not None or doc2.f['Z1C'].f['size'] != H - empties + 1:
            raise Refusal('model-cleanup-result')
        summary['cleanup'].append([H, empties, o['vendorInstructions'], o['jdkInstructions'],
                                   o['lambdaFrame'], o['allocJdk'], o['arraycopySlots']])

# 5. Removal with matches. Includes clusters that wrap past the table end.
SHIFT_LEN = len(instructions(src.load('eTk')[2]['cfM(I)V'].code))
REMOVE_LEN = len(instructions(src.load('eTk')[2]['remove()V'].code))
SET_REMOVE_LEN = len(instructions(src.load('eTi')[2]['remove(Ljava/lang/Object;)Z'].code))
SET_SHIFT_LEN = len(instructions(src.load('eTi')[2]['MRY(I)V'].code))
REHASH_LEN = len(instructions(src.load('eTi')[2]['Hnt(I)V'].code))


def bound_removing(s, n, D, R):
    """Coarse structural bound: each loop-head visit runs at most its body.

    A shift examines at most s + 1 slots and visits its two loop heads at most
    2(s + 1) times. Each examined slot also hashes once (13 vendor instructions).
    A wrapped entry adds one list add, one wrapped next, and one direct removal
    with its own probe, shift, and possible halving rehash.
    """
    base = f_prune_none(s, n - s, s * D)[0]
    per_removal = REMOVE_LEN + 2 * SHIFT_LEN * (s + 1) + 13 * (s + 1) + 9 + 31 + 60
    per_wrapped = 30 + 28 + SET_REMOVE_LEN * (s + 1) + 33 + 2 * SET_SHIFT_LEN * (s + 1) + 13 * (s + 1) \
        + REHASH_LEN * (n + 1) + 40 * s
    return base + R * per_removal + s * per_wrapped


for s in (4, 12, 23):
    for frac in (0.25, 0.5, 1.0):
        for mode, h0 in (('one-cluster', 0), ('wrapping', 35)):
            root = obj()
            R = int(s * frac)
            elems = [obj(root, h0) if i < R else obj(None, h0) for i in range(s)]
            h = build_helper(elems)
            t0 = table(h)
            m = Machine(src)
            run_method(m, 'dgJ', 'FzB', SET_DESC, [h, root])
            o = snap(m.c)
            if table(h)['size'] != s - R:
                raise Refusal('model-removal-count')
            within('helper.prune-removing', [s, R, mode], (o['vendorInstructions'],),
                   (bound_removing(s, t0['n'], 1, R),))
            summary['removing'].append([mode, s, R, t0['n'], o['vendorInstructions'], bound_removing(s, t0['n'], 1, R),
                                        o['jdkInstructions'], o['native'], o['allocVendor']])

# dnz absent removal (owned R-false insertion hook) on cQy(10) with forced clusters.
for s in (0, 1, 4, 8, 11):
    for L in sorted({0, s}):
        mach = Machine(src)
        st = Obj('cQy')
        run_method(mach, 'cQy', '<init>', '(I)V', [st, 10])
        for i in range(s):
            e = obj(None, 35 if i < L else 1000 + 7919 * i)
            run_method(mach, 'eTi', 'add', '(Ljava/lang/Object;)Z', [st, e])
        probe = obj(None, 35)
        m2 = Machine(src)
        r = run_method(m2, 'eTi', 'remove', '(Ljava/lang/Object;)Z', [st, probe])
        if r != 0 or st.f.get('lYc', 0) != s:
            raise Refusal('model-dnz-remove')
        o = snap(m2.c)
        keys, mask = st.f['cfM'].v, st.f['Hnt']
        hv = (35 * 0x9e3779b9) & 0xffffffff
        pos, P = (hv ^ (hv >> 16)) & mask, 0
        while keys[pos] is not None:
            P += 1; pos = (pos + 1) & mask
        expect('open-set.remove-absent', [s, L, P], (o['vendorInstructions'], o['jdkInstructions'], o['native']),
               (44 + 24 * P, 0, 1))
        summary['dnzRemove'].append([s, L, P, st.f['UNj'], o['vendorInstructions'], o['vendorCalls'], o['native']])

# 6. Partial failure: an injected allocation failure inside one helper prune.
for fail_at in (1, 2, 3):
    root = obj()
    helpers = [build_helper([obj(root), obj()]) for _ in range(3)]
    doc = Obj('dfI', Z1C=arraylist(helpers), dEI=None)
    m = Machine(src, fail_alloc=fail_at)
    try:
        run_method(m, 'dfI', 'hUR', SET_DESC, [doc, root])
        outcome = 'completed'
    except Thrown as e:
        outcome = str(e)
    summary['partial'].append(['hUR', fail_at, outcome, [table(h)['size'] for h in helpers]])
for fail_at in (1, 2, 3, 4):
    m = Machine(src, fail_alloc=fail_at)
    doc = Obj('dfI', Z1C=arraylist([]), dEI=None)
    try:
        new_helper(m, doc, obj()); outcome = 'completed'
    except Thrown as e:
        outcome = str(e)
    summary['partial'].append(['pending', fail_at, outcome, doc.f['dEI'] is not None])

# ---------------------------------------------------------------- scans (data only)
scan_start = time.perf_counter()
zjar = zipfile.ZipFile(NEW)
callers = {'pendingEntry': [], 'pendingHelper': [], 'globalListener': Counter(), 'globalMapForeign': []}
nests = {}
for name in zjar.namelist():
    if not name.endswith('.class'):
        continue
    raw = zjar.read(name)
    cname = name[:-6]
    if cname in ('dfI', 'dgJ', 'com/bitwig/ramona/core/oDc'):
        nests[cname] = {'NestMembers': b'NestMembers' in raw, 'NestHost': b'NestHost' in raw}
    if not (b'IPH' in raw or b'LdgI;' in raw or b'BrJ' in raw or b'UNj' in raw or b'dfI' in raw):
        continue
    c = parse(raw, True)
    for meth in c.methods:
        if not meth.code:
            continue
        for off, op, a in instructions(meth.code):
            if op in (182, 183, 184, 185):
                k = constant(c, int.from_bytes(bytes(a[:2]), 'big'))
                t = (k.get('owner'), k.get('name'), k.get('descriptor'))
                if t[1] == 'IPH' and t[2] == '()LdgI;':
                    callers['pendingEntry'].append([cname, meth.name, meth.desc, off, t[0]])
                if t == ('dfI', 'IwV', '(Lcom/bitwig/ramona/core/oDc;)LdgI;'):
                    callers['pendingHelper'].append([cname, meth.name, meth.desc, off])
                if t[2] == '(Lcom/bitwig/ramona/core/BrJ;)V' and t[1] in ('cfM', 'MRY'):
                    callers['globalListener'][t[1]] += 1
            elif op in (180, 181) and cname != 'dfI':
                k = constant(c, int.from_bytes(bytes(a[:2]), 'big'))
                if k.get('owner') == 'dfI' and k.get('name') in ('dnz', 'Z1C', 'dEI'):
                    callers.setdefault('historyFieldForeign', []).append([cname, meth.name, off, k['name']])
            elif op in (178, 179) and cname != 'com/bitwig/ramona/core/oDc':
                k = constant(c, int.from_bytes(bytes(a[:2]), 'big'))
                if k.get('name') == 'UNj' and k.get('descriptor') == 'Ljava/util/Map;' \
                        and k.get('owner') == 'com/bitwig/ramona/core/oDc':
                    callers['globalMapForeign'].append([cname, meth.name, off])
callers['globalListener'] = dict(callers['globalListener'])
callers.setdefault('historyFieldForeign', [])
# The six dnz reads in the relationship hooks are the only expected nest access (E333).
KNOWN_DNZ = sorted([['dfL', 'aboutToInsertItem', 104, 'dnz'], ['dfL', 'aboutToInsertItem', 185, 'dnz'],
                    ['dfL', 'aboutToRemoveItem', 125, 'dnz'],
                    ['dfL', 'aboutToChangeOneToOneRelationship', 200, 'dnz'],
                    ['dfL', 'aboutToChangeOneToOneRelationship', 305, 'dnz'],
                    ['dfL', 'aboutToChangeOneToOneRelationship', 334, 'dnz']])
if sorted(callers['historyFieldForeign']) != KNOWN_DNZ or callers['globalMapForeign']:
    raise Refusal('history-growth-foreign-field-access')

# Field sites of the three history fields (private, so only dfI and its nest).
fields = Counter()
c, _, _, _ = src.load('dfI')
for meth in c.methods:
    for off, op, a in instructions(meth.code or b''):
        if op in (180, 181):
            k = constant(c, int.from_bytes(bytes(a[:2]), 'big'))
            if k.get('owner') == 'dfI' and k['name'] in ('dnz', 'Z1C', 'dEI'):
                fields[(k['name'], 'put' if op == 181 else 'get', meth.name + meth.desc)] += 1
field_sites = sorted([list(k) + [v] for k, v in fields.items()])

# Global identity map: every monitor site in the owner class.
c, _, _, _ = src.load('com/bitwig/ramona/core/oDc')
monitor_sites = []
for meth in c.methods:
    raw = instructions(meth.code or b'')
    refs = [off for off, op, a in raw if op == 178 and constant(c, int.from_bytes(bytes(a[:2]), 'big')).get('name') == 'UNj'
            and constant(c, int.from_bytes(bytes(a[:2]), 'big')).get('descriptor') == 'Ljava/util/Map;']
    if refs:
        calls = [constant(c, int.from_bytes(bytes(a[:2]), 'big')) for off, op, a in raw if op in (182, 185)]
        enter = [off for off, op, a in raw if op == 194]
        monitor_sites.append({'method': [meth.name, meth.desc], 'monitorEnter': enter,
                              'mapCalls': sorted({x['name'] for x in calls if x.get('owner') == 'java/util/Map'}),
                              'listenerCalls': sorted({x['name'] + x['descriptor'] for x in calls
                                                       if x.get('owner') == 'com/bitwig/ramona/core/eD'})})

# Hook gating facts in dfL: the exact call sites that reach the history bodies.
c, _, ms, chash = src.load('dfL')
hooks = {}
for key in ('aboutToInsertItem(LdeT;Lcom/bitwig/ramona/core/oDc;Lcom/bitwig/ramona/core/oDc;I)V',
            'aboutToRemoveItem(LdeT;Lcom/bitwig/ramona/core/oDc;Lcom/bitwig/ramona/core/oDc;IZ)V',
            'aboutToChangeOneToOneRelationship(LdeU;Lcom/bitwig/ramona/core/oDc;Lcom/bitwig/ramona/core/oDc;Z)V'):
    meth = ms[key]
    sites = []
    for off, op, a in instructions(meth.code):
        if op in (180, 182, 185):
            k = constant(c, int.from_bytes(bytes(a[:2]), 'big'))
            if (k.get('owner'), k.get('name')) in (('dfI', 'dnz'), ('dfI', 'hUR'), ('dfI', 'UNj'), ('dfI', 'cfM')) \
                    or (k.get('owner') == 'java/util/Set'):
                sites.append([off, k.get('name'), k.get('descriptor')])
    hooks[key] = {'codeSha256': hashlib.sha256(meth.code).hexdigest(), 'sites': sites}
scan_ms = (time.perf_counter() - scan_start) * 1000

# Relationship predicates from the preserved checkpoint-12 report (hash-checked).
pred_path = '/tmp/gn-9b6g-relationship-predicates-1.json'
if sha(pred_path) != '4aecb4efd8a20349c6560f239a96f1c753ffb49c094f97223d1e3a12e9375c06':
    raise Refusal('history-growth-predicate-input')
pred = json.load(open(pred_path))
CHAIN = {('native_device', 406), ('device_contents', 173), ('module_grid', 6428), ('module', 406),
         ('module_contents', 228), ('module_contents', 229), ('module_contents', 173)}
predicates = []
for b in pred['builds']:
    true_rows = [[r['className'], r['propertyName'], r['propertyId'], r['flags']] for r in b['rows'] if r['predicate']]
    chain_rows = [[r['className'], r['propertyName'], r['propertyId'], r['flags'], r['predicate']]
                  for r in b['rows'] if (r['className'], r['propertyId']) in CHAIN]
    true_ids = {r[2] for r in true_rows}
    predicates.append({'sha256': b['sha256'], 'true': true_rows, 'chain': chain_rows,
                       'chainTrue': [r for r in chain_rows if r[4]],
                       'trueIdsOnChain': sorted(true_ids & {p for _, p in CHAIN}),
                       'rowOwners': len({r['className'] for r in b['rows']})})
    if len(true_rows) != 7 or [r for r in chain_rows if r[4]] or len(chain_rows) != len(CHAIN):
        raise Refusal('history-growth-predicate-shape')

elapsed = (time.perf_counter() - START) * 1000
report = {
    'inputs': hashes,
    'jdkClassHashes': {n: v[3] for n, v in src.cache.items() if n.startswith(('java/', 'jdk/'))},
    'vendorClassHashes': {n: v[3] for n, v in src.cache.items() if not n.startswith(('java/', 'jdk/'))},
    'contracts': contracts, 'oldStructure': old_rows,
    'formulas': {
        'helper.match-absent': 'vendor 51 + 78s + 13K + 12W; JDK 1',
        'helper.prune-none': 'vendor 49 + 72s + 13K + 12W; JDK 18 + 8s; s lambda frames; 1 lambda allocation',
        'document.hUR': 'vendor 8 + 11H + sum_i(4 + prune_i); JDK 35 + 46H + sum_i(prune_i JDK)',
        'document.UNj': 'H = 0: vendor 5, JDK 6; else hUR + 4 vendor and + 5 JDK',
        'document.edit-match': 'H = 0: 5/6; else vendor <= 12 + 15H + 2M + sum_i(16 + match_i); '
                               'JDK <= 40 + 47H + M*%d' % LIST_REMOVE_BOUND,
        'K': 'K <= n - s (empty slots above the lowest occupied slot)', 'W': 'W <= s*D',
        'capacity': 'n = max(32, arraySize(Smax + 1)) for a helper set; arraySize(e) = max(2, nextPow2(ceil(e/0.75)))',
    },
    'exactCaseCounts': dict(exact), 'cases': cases, 'failures': failures, 'summary': summary,
    'pendingFirstCreate': first_create, 'pendingPlainAddVendorInstructions': plain_adds,
    'listRemoveLoopFreeBound': LIST_REMOVE_BOUND,
    'callers': callers, 'nestAttributes': nests, 'historyFieldSites': field_sites,
    'globalMonitorSites': monitor_sites, 'hooks': hooks, 'predicates': predicates,
    'stubs': ['System.identityHashCode (native)', 'System.arraycopy (native)', 'StrictMath.ceil',
              'Arrays.copyOf', 'ArraysSupport.newLength', 'LambdaMetafactory frames'],
    'scanMs': scan_ms, 'elapsedMs': elapsed, 'peakRssBytes': rss_bytes(), 'limits': LIMITS,
    'boundedAdmission': False, 'runtimeClassesInitialized': 0, 'runtimeObserved': False,
    'conditions': ['Every traced assertion flag is already initialized true (disabled assertions).',
                   'Set keys are non-null; the null-key slot stays unused.',
                   'Lists and sets are stable during each call; no concurrent change or reflection.',
                   'Natives, StrictMath.ceil, and generated lambda frames are stubbed and counted as calls only.',
                   'Every walked parent uses the base parent getter; bridge getters need separate bounds.',
                   'Identity hashes are inert values; native hash latency is not measured.',
                   'H, set sizes, and table lengths at entry are runtime values that the doctor does not read.'],
}
raw = json.dumps(report, indent=1).encode()
if len(raw) > LIMITS['reportBytes']:
    raise Refusal('model-report-limit')
if elapsed > LIMITS['seconds'] * 1000 or report['peakRssBytes'] > LIMITS['rssBytes']:
    raise Refusal('model-resource-limit')
out = Path(sys.argv[1])
if out.exists():
    raise Refusal('model-report-exists')
out.write_bytes(raw)
print('contracts', contracts)
print('old', {k: v['structurePresent'] for k, v in old_rows.items()})
print('cases', cases, 'failures', len(failures), dict(exact))
for f in failures[:10]:
    print('FAIL', json.dumps(f)[:300])
print('firstCreate', first_create, 'plainAdds', plain_adds)
print('cleanup', summary['cleanup'])
print('removing', summary['removing'])
print('dnzRemove', summary['dnzRemove'])
print('partial', summary['partial'])
print('callers', json.dumps(callers))
print('nests', nests)
print('fieldSites', field_sites)
print('monitorSites', len(monitor_sites), [m['monitorEnter'] for m in monitor_sites][:3])
print('predicates', json.dumps([{k: v for k, v in p.items() if k != 'chain'} for p in predicates]))
print('elapsedMs', round(elapsed, 1), 'scanMs', round(scan_ms, 1), 'rss', report['peakRssBytes'], 'bytes', len(raw))
