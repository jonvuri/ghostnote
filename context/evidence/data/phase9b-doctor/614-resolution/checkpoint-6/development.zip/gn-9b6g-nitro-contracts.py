import json,time
from pathlib import Path
from collections import Counter
from grid_symbols.scan import Jar,rss_bytes,Refusal
from grid_doctor.descriptor_resolution import Code
from grid_doctor.callee_contracts import compare_callees
start=time.perf_counter();paths=['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'];jars=[Jar(Path(p))for p in paths];code=Code();seed=json.load(open('/tmp/gn-9b6g-nitro-registry-2.json'))['contracts'];keys=[{'owner':c.name,'name':m.name,'descriptor':m.desc}for c in jars[1].classes.values()if c.name.startswith('com/bitwig/nitro/')for m in c.methods];matched={};unmatched={};work=Counter();rounds=[]
if len(keys)>10000:raise Refusal('package-method-limit')
for cycle in range(8):
 before=len(matched); todo=[k for k in keys if tuple(k.values())not in matched]
 for index in range(0,len(todo),256):
  jars[0].check();jars[1].check()
  if time.perf_counter()-start>120 or rss_bytes()>768*1024**2:raise Refusal('package-time-or-memory')
  r=compare_callees(*jars,todo[index:index+256],seed,code);seed=r;work.update(r['work'])
  for row in r['matched']:matched[tuple(row['target'])]=row
  for row in r['unmatched']:unmatched[tuple(row['target'])]=row
  if work['comparisons']>1000000 or work['instructions']>16000000:raise Refusal('package-work-limit')
 rounds.append({'round':cycle,'matched':len(matched),'types':len(seed['typeBindings']),'work':dict(work)});print(rounds[-1],flush=True)
 if len(matched)==before:break
else:raise Refusal('package-round-limit')
report={'oldSha256':jars[0].sha256,'newSha256':jars[1].sha256,'methods':len(keys),'matched':list(matched.values()),'unmatched':[v for k,v in unmatched.items()if k not in matched],'typeBindings':seed['typeBindings'],'memberBindings':seed['memberBindings'],'rounds':rounds,'work':dict(work),'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False,'limits':['Package matches are local contracts only.','No runtime dispatch, initialization, compiler closure, or event-pump exclusion is inferred.']};raw=json.dumps(report,indent=2).encode()
if len(raw)>8*1024**2:raise Refusal('package-report-limit')
Path('/tmp/gn-9b6g-nitro-contracts-1.json').write_bytes(raw);print('matched',len(matched),'unmatched',len(report['unmatched']),'bytes',len(raw),'ms',report['elapsedMs'],'rss',report['peakRssBytes'])
