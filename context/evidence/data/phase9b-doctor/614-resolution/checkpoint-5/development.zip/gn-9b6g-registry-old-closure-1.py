import json,time,collections
from pathlib import Path
from grid_symbols.scan import Jar,ancestors,instructions,rss_bytes,Refusal
from grid_doctor.descriptor_resolution import Code
from grid_doctor.migrate import member
from grid_doctor.ownership import constant,method_trace,bootstraps
start=time.perf_counter();j=Jar(Path('/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar'));code=Code();root='com/bitwig/flt/document/core/master/DhK';todo=collections.deque([(root,'<init>','()V')]);seen=set();packages={};traces={};steps=0
while todo:
 key=todo.popleft()
 if key in seen:continue
 if len(seen)>=128:raise Refusal('registry-method-limit')
 seen.add(key);c=code.get(j,key[0]);m=member(c,*key[1:]);raw=instructions(m.code);traces[key]=method_trace(j,c,m,bootstraps(j.zip.read(c.name+'.class'),c))
 if c.name!='cYu'and'cYu'in ancestors(j.classes,c.name,128):
  ctor=member(c,'<init>','()V');body=instructions(ctor.code)
  if [r[1]for r in body[:4]] not in([42,18,183,178],[42,19,183,178]):raise Refusal('registry-package-label-shape')
  label=constant(c,body[1][2][0]if body[1][1]==18 else int.from_bytes(bytes(body[1][2]),'big'))['value'];packages[c.name]=label
 for off,op,args in raw:
  steps+=1
  if steps>2000000:raise Refusal('registry-instruction-limit')
  if op!=184:continue
  r=constant(c,int.from_bytes(bytes(args),'big'))
  if r['descriptor']=='(LcYt;)V'and r['owner']in j.classes:todo.append((r['owner'],r['name'],r['descriptor']))
catalog=json.load(open('/tmp/gn-9b6g-module-catalog-1.json'))['builds'][0];wanted={r['matches'][0]['descriptor']:r for r in catalog['rows']};members=[]
for owner,label in packages.items():
 c=code.get(j,owner)
 for m in c.methods:
  raw=instructions(m.code)
  for i in range(len(raw)-2):
   rows=raw[i:i+3]
   if [r[1]for r in rows]!=[42,178,182]:continue
   field=constant(c,int.from_bytes(bytes(rows[1][2]),'big'));call=constant(c,int.from_bytes(bytes(rows[2][2]),'big'))
   if call['descriptor']!='(LcXV;)V':continue
   desc=field['descriptor'];typ=desc[1:-1]if desc.startswith('L')else''
   if typ not in wanted:continue
   members.append({'package':label,'registryClass':owner,'method':[m.name,m.desc],'offset':rows[0][0],'descriptorClass':typ,'field':field,'registration':call,'name':wanted[typ]['name'],'id':wanted[typ]['id']})
selected={x['descriptorClass']for x in members};r={'root':root,'packages':packages,'members':members,'selectedRows':[r for r in catalog['rows']if r['matches'][0]['descriptor']in selected],'excludedRows':[r for r in catalog['rows']if r['matches'][0]['descriptor']not in selected],'registrationMethods':list(traces.values()),'instructions':steps,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False,'runtimeObserved':False};Path('/tmp/gn-9b6g-registry-old-closure-1.json').write_text(json.dumps(r,indent=2));print(packages);print('selected',len(r['selectedRows']),'members',len(members),'excluded',[(r['name'],r['id'])for r in r['excludedRows']]);print(r['elapsedMs'],r['peakRssBytes'])
