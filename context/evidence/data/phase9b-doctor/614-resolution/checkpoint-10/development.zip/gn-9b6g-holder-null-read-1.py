import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.read_dataflow import ReadFlow,NULL
from grid_doctor.ownership import method_trace,bootstraps
from grid_doctor.migrate import member
start=time.perf_counter();j=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));code=Code();receiver=('ref','EIm','object');holder=('ref','mKX','holder');guards={(receiver,('EIm','IwV','LmKX;')):holder,(holder,('mKX','cfM','Ljava/lang/Object;')):NULL};flow=ReadFlow(j,code,[],('unused','unused','I'),-1,'unused',instance_values=guards);key=('EIm','LaE','()LivQ;',receiver,(),True);result=flow.evaluate(*key[:4],direct=True)
if result!={NULL}:raise Refusal('holder-null-read-result')
traces=[]
for owner,name,desc in sorted(flow.methods):
 c=code.get(j,owner);traces.append(method_trace(j,c,member(c,name,desc),bootstraps(j.zip.read(c.name+'.class'),c)))
r={'sha256':j.sha256,'root':list(key[:3]),'requiredInstanceFields':[{'receiver':k[0],'field':k[1],'value':guards[k]}for k in sorted(flow.instance_fields)],'typeTests':sorted(flow.type_tests),'returned':list(result),'cost':dict(zip(('vendorInstructions','vendorCalls','externalCalls'),flow.bounds[key])),'external':sorted(flow.external,key=str),'methods':traces,'boundedAdmission':False,'runtimeObserved':False,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes()};raw=json.dumps(r,indent=2).encode();Path('/tmp/gn-9b6g-holder-null-read-1.json').write_bytes(raw);print(r['cost'],r['typeTests'],'external',r['external']);print(len(raw),r['elapsedMs'],r['peakRssBytes'])
