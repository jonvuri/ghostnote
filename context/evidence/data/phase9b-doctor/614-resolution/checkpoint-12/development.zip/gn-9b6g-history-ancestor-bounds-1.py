import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,rss_bytes,descriptor
from grid_doctor.descriptor_resolution import Code
from grid_doctor.history_ancestor import history_ancestor
from grid_doctor.migrate import member
from grid_doctor.renamed_fixture import rename_member
from grid_doctor.callee_contracts import compare_callees
start=time.perf_counter();paths=['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'];jars=[Jar(Path(p))for p in paths];code=Code();symbols=json.load(open('/tmp/gn-9b6g-resolution-5.json'))['builds'];builds=[];roots=[]
for index,j in enumerate(jars):
 desc='(L'+symbols[index]['types']['object']+';)Z';hits=[];trials=0
 for meta in j.classes.values():
  for m in meta.methods:
   if m.desc!=desc or m.flags!=9:continue
   trials+=1
   if trials>4096:raise Refusal('ancestor-candidate-limit')
   cls=code.get(j,meta.name)
   try:r=history_ancestor(cls,member(cls,m.name,m.desc))
   except Refusal:continue
   hits.append(r)
 if len(hits)!=1:raise Refusal('ancestor-root-count:'+str(len(hits)))
 r=hits[0];roots.append(r['method']);builds.append({'sha256':j.sha256,'root':r,'candidates':trials});print(index,r['method'],trials,flush=True)
seed=json.load(open('/tmp/gn-9b6g-relationship-predicates-1.json'))['contracts'];contracts=compare_callees(*jars,[dict(zip(('owner','name','descriptor'),roots[1]))],seed,code)
if contracts['unmatched']:raise Refusal('ancestor-local-contract')
renamed=[]
for index,(path,mapping)in enumerate([('/tmp/gn-9b6g-old-renamed-extra.jar','/tmp/gn-9b6g-old-renamed-map.json'),('/tmp/gn-9b6g-renamed-extra.jar','/tmp/gn-9b6g-renamed-map.json')]):
 names=json.load(open(mapping));j=Jar(Path(path));key=roots[index];owner=names.get(key[0],key[0]);name=rename_member(key[1]);desc=descriptor(key[2],lambda n:names.get(n,n));cls=code.get(j,owner);r=history_ancestor(cls,member(cls,name,desc))
 for k in ('ownInstructions','vendorCalls','trueExit'):
  if r[k]!=builds[index]['root'][k]:raise Refusal('ancestor-renamed-cost')
 renamed.append({'sha256':j.sha256,'root':r});del j
r={'builds':builds,'renamed':renamed,'contracts':contracts,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False,'runtimeObserved':False};raw=json.dumps(r,indent=2).encode()
if len(raw)>8*1024**2:raise Refusal('ancestor-report-limit')
Path('/tmp/gn-9b6g-history-ancestor-bounds-1.json').write_bytes(raw);print(len(raw),r['elapsedMs'],r['peakRssBytes'])
