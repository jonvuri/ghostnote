import json
from pathlib import Path
p=Path('context/evidence/data/phase9b-doctor/614-resolution/compiler-cache-plan.json')
targets=[('field','com/bitwig/nitro/FDA','TMF','Ljava/util/Map;'),('field','com/bitwig/nitro/FDA','FzB','Ljava/util/Map;'),('method','com/bitwig/nitro/FDA','cfM','(Lcom/bitwig/nitro/IPO;Ljava/util/List;Ljava/util/List;Ljava/util/List;Ljava/util/List;Ljava/lang/String;Z)Lcom/bitwig/nitro/ESe;'),('method','FJj','<init>','(LGDf;Lcom/bitwig/base/io/z2y;)V')]
r={'jarSha256':'5c2b1895bbb9e7d08d9216de421985bb1f24b2ee62762c9451b4fe847df2469f','purpose':'Check compiler cache mutation sites and module invalidation scheduling. This scan does not establish concurrency exclusion.','slots':[],'methods':[],'targets':[dict(zip(('kind','owner','name','descriptor'),x))for x in targets]}
p.write_text(json.dumps(r,indent=2)+'\n')
