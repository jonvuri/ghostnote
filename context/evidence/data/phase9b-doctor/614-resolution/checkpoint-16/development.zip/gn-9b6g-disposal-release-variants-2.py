import json,time
from pathlib import Path
from grid_symbols.scan import Jar,instructions,descriptor,Refusal,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.descriptor_builders import lookup
from grid_doctor.conditional_contracts import project_assertions
from grid_doctor.contracts import contract
from grid_doctor.migrate import merge,bindings
from grid_doctor.ownership import constant,method_trace,bootstraps
from grid_doctor.renamed_fixture import rename_member
start=time.perf_counter();code=Code();seed=json.load(open('/tmp/gn-9b6g-factory-disposal-contracts-1.json'));known=[seed['typeBindings'],{tuple(r['source']):tuple(r['target'])for r in seed['memberBindings']}];jars=[Jar(Path(p))for p in ['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar']];roots=[('com/bitwig/ramona/core/HEV','NaF','(Lcom/bitwig/ramona/core/HEV;Z)V'),('com/bitwig/ramona/core/oDc','IwV','(Lcom/bitwig/ramona/core/oDc;Z)V')];builds=[];values=[]
for j,key in zip(jars,roots):
 c,m=lookup(j,code,*key);hooks=[]
 for off,op,args in instructions(m.code):
  if op!=182:continue
  ref=constant(c,int.from_bytes(bytes(args[:2]),'big'))
  if ref['owner']==c.name and ref['descriptor']==m.desc and ref['name']!=m.name:hooks.append((c.name,ref['name'],m.desc))
 if len(hooks)!=2:raise Refusal('release-hook-edges')
 rows=[];contracts=[]
 for key in [key,*hooks]:
  c,m=lookup(j,code,*key);projected,guard=project_assertions(c,m);v=contract(c,projected,j.classes);rows.append({'method':key,'guard':guard,'projectedContract':{**v,'members':[{'reference':list(k),'label':label}for k,label in v['members'].items()]},'trace':method_trace(j,c,m,bootstraps(j.zip.read(c.name+'.class'),c))});contracts.append(v)
 builds.append({'sha256':j.sha256,'rows':rows});values.append(contracts)
for a,b in zip(*values):
 if a['digest']!=b['digest']:raise Refusal('release-projected-body-difference')
 known=merge(known,bindings(a,b))
renamed=[]
for index,(p,mp)in enumerate([('/tmp/gn-9b6g-old-renamed-extra.jar','/tmp/gn-9b6g-old-renamed-map.json'),('/tmp/gn-9b6g-renamed-extra.jar','/tmp/gn-9b6g-renamed-map.json')]):
 names=json.load(open(mp));j=Jar(Path(p));rows=[]
 for source in builds[index]['rows']:
  key=source['method'];mapped=(names.get(key[0],key[0]),rename_member(key[1]),descriptor(key[2],lambda n:names.get(n,n)));c,m=lookup(j,code,*mapped);projected,guard=project_assertions(c,m);v=contract(c,projected,j.classes)
  if v['digest']!=source['projectedContract']['digest']:raise Refusal('release-renamed-body-difference')
  rows.append({'method':mapped,'guard':guard,'digest':v['digest']})
 renamed.append({'sha256':j.sha256,'rows':rows})
r={'builds':builds,'renamed':renamed,'typeBindings':known[0],'memberBindings':[{'source':list(k),'target':list(v)}for k,v in known[1].items()],'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False,'runtimeObserved':False,'conditions':['These explicit comparisons exclude only the recognized assertion blocks.','The recorded assertion flags must already be initialized and true.','The normal unregister body and both ordered hook edges match. Their callees and loop bounds remain separate.','This check does not alter the strict comparator.']};Path('/tmp/gn-9b6g-disposal-release-variants-2.json').write_text(json.dumps(r,indent=2)+'\n');print('matched',len(values[0]),'renamed',sum(len(x['rows'])for x in renamed),'ms',r['elapsedMs'],'rss',r['peakRssBytes'])
