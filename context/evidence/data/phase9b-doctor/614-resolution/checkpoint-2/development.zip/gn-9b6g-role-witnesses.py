exec(open('/tmp/gn-9b6g-anchor-explore.py').read().split('sources=[]')[0])
from grid_doctor.contracts import references
a=json.loads(Path('/tmp/gn-9b6g-roles.json').read_text());known=[a['typeBindings'],{tuple(r['source']):tuple(r['target']) for r in a['members']}]
wanted={ (r['declaring'],r['name'],r['descriptor']):r['role']for r in source['members'] if r['kind']=='method' and r['role']not in a['selected']}
found=defaultdict(list); matched=[]
for o,n in list(known[0].items()):
 if o not in old.classes or n not in new.classes:continue
 oc,nc=code(old,o),code(new,n)
 for om in oc.methods:
  uses=[]
  for r in references(oc,om):
   if r['opcode']not in (182,183,184,185):continue
   if (r['name'],r['descriptor'])not in {(x[1],x[2])for x in wanted}:continue
   dec=od.find('method',r['owner'],r['name'],r['descriptor'])
   if (dec.get('owner'),r['name'],r['descriptor'])in wanted:uses.append(wanted[dec['owner'],r['name'],r['descriptor']])
  if not uses:continue
  try:v=contract(oc,om,old.classes)
  except Refusal as e:
   for role in uses:found[role].append([o,om.name,om.desc,str(e)])
   continue
  hits=[]
  for nm in nc.methods:
   if signature_key(om,old.classes)!=signature_key(nm,new.classes):continue
   try:
    nv=contract(nc,nm,new.classes)
    if v['digest']!=nv['digest']:continue
    mapped=merge(bindings(v,nv),[{o:n},{(10,o,om.name,om.desc):(10,n,nm.name,nm.desc)}])
    mapped,u=canonical_edges(mapped,od,nd);merge(known,mapped)
   except Refusal:continue
   hits.append((nm,mapped))
  for role in uses:found[role].append([o,om.name,om.desc,len(hits)])
  if len(hits)==1:
   nm,mapped=hits[0];known=merge(known,mapped);matched.append({'source':[o,om.name,om.desc],'target':[n,nm.name,nm.desc],'roles':uses,'digest':v['digest']})
print('uses',json.dumps(found,indent=1))
print('links')
for key,role in wanted.items():print(role,known[1].get((10,*key)))
a['typeBindings']=known[0];a['members']=[{'source':list(k),'target':list(v)}for k,v in known[1].items()];a['roleWitnesses']=matched
a['roleUses']=found
Path('/tmp/gn-9b6g-role-witnesses.json').write_text(json.dumps(a,indent=2))
