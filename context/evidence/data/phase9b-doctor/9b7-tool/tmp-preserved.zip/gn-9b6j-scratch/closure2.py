"""Ad-hoc owned-tree census with init-reachability. Reads the jar as data only."""
import sys, json, re
sys.path.insert(0, '/Users/jonvuri/Development/ghostnote/brain/src/probes')
from grid_symbols.scan import Jar, ancestors, instructions, parse
from grid_doctor.fixed_descriptors import constructor_pair
from grid_doctor.ownership import constant
from pathlib import Path
from collections import Counter
jar = Jar(Path(sys.argv[1])); base = sys.argv[2]; module_report = sys.argv[3]; descriptor_base = sys.argv[4]
module_class = sys.argv[5]; factory_name, factory_desc = sys.argv[6], sys.argv[7]
SERIAL = 'com/bitwig/ramona/serial/'
anc = {}
def A(n):
    if n not in anc: anc[n] = list(ancestors(jar.classes, n)) if n in jar.classes else []
    return anc[n]
def is_doc(n): return base in A(n)
def code(n):
    if len(jar.code_cache) > 100: jar.code_cache.clear()
    return jar.code(n)
def ref(cls, args):
    owner, nt = cls.cp[args[0]*256+args[1]][1]; owner = cls.cp[cls.cp[owner][1]][1]
    ni, di = cls.cp[nt][1]; return owner, cls.cp[ni][1], cls.cp[di][1]
def params(d): return re.findall(r'L([^;]+);', d[:d.index(')')])
# descriptor catalog
by_id, by_runtime = {}, {}
for entry in jar.zip.namelist():
    if not entry.endswith('.class') or descriptor_base not in A(entry[:-6]): continue
    meta = jar.classes[entry[:-6]]
    if not any(m.name == '<init>' and m.desc == '()V' for m in meta.methods): continue
    cls = parse(jar.zip.read(entry), True)
    for m in cls.methods:
        if m.name == '<init>' and m.desc == '()V' and m.code:
            pair = constructor_pair(cls, m)
            if not pair: continue
            getters = []
            for g in cls.methods:
                if g.desc == '()Ljava/lang/Class;' and g.code and g.flags == 1:
                    raw = instructions(g.code)
                    if len(raw) == 2 and raw[0][1] in (18,19):
                        _, op, args = raw[0]; v = constant(cls, args[0] if op == 18 else args[0]*256+args[1])
                        if v['tag'] == 7: getters.append(v['value'])
            if len(getters) == 1 and is_doc(getters[0]):
                by_id.setdefault(pair[1], []).append((pair[0], getters[0], cls.name)); by_runtime[getters[0]] = (pair[0], pair[1], cls.name)
rep = json.load(open(module_report))
from grid_doctor.module_file import object_references
serial = Counter(n['classId'] for n in object_references(rep['objects']['root'])['nodes'])
tree = {}
for cid, count in serial.items():
    hits = by_id.get(cid, []); assert len(hits) == 1, (cid, hits)
    tree[hits[0][1]] = {'className': hits[0][0], 'classId': cid, 'serialized': count, 'creations': []}
tree[module_class] = {'className': by_runtime[module_class][0], 'classId': by_runtime[module_class][1], 'serialized': 0, 'creations': []}

# entries: base methods invoked on a fresh object in static factories of tree classes; serial hooks; <init>
base_methods = {(m.name, m.desc) for m in jar.classes[base].methods}
entries = {('<init>', '()V')}
for cls_name in list(tree):
    for a in A(cls_name):
        if a not in jar.classes or a == base or a in A(base): continue
        c = code(a)
        for m in c.methods:
            if not m.code or not m.flags & 8: continue
            raw = instructions(m.code); created = None
            for off, op, args in raw:
                if op == 187:
                    t = c.cp[c.cp[args[0]*256+args[1]][1]][1]
                    if is_doc(t): created = t
                elif op in (182, 183) and created:
                    o, n, d = ref(c, args)
                    if (n, d) in base_methods and o in A(created) + [created] and n != '<init>': entries.add((n, d))
for m in jar.classes[base].methods:
    if any(p.startswith(SERIAL) for p in params(m.desc)) and not m.flags & 8: entries.add((m.name, m.desc))
print('entries', sorted(entries))

def resolve(cls_name, n, d):
    for a in A(cls_name):
        if a not in jar.classes: continue
        for m in jar.classes[a].methods:
            if (m.name, m.desc) == (n, d) and not m.flags & 0x400:
                return a
    return None

def static_creations(owner, n, d, depth, seen):
    out = []
    if depth > 6 or (owner, n, d) in seen or owner not in jar.classes: return out
    seen.add((owner, n, d))
    c = code(owner)
    for m in c.methods:
        if (m.name, m.desc) != (n, d) or not m.code: continue
        for off, op, args in instructions(m.code):
            if op == 187:
                t = c.cp[c.cp[args[0]*256+args[1]][1]][1]
                if is_doc(t): out.append(t)
            elif op == 184:
                o2, n2, d2 = ref(c, args); r = d2[d2.index(')')+1:]
                if r.startswith('L') and is_doc(r[1:-1]): out.extend(static_creations(o2, n2, d2, depth+1, seen))
    return out


pending = set()
def store_evidence(c, m, created):
    ev = []
    for off, op, args in instructions(m.code):
        if op in (182, 183, 185):
            o, n, d = ref(c, args)
            if o == c.name or o in A(c.name):
                for p in params(d):
                    if p != 'java/lang/Object' and p in A(created): ev.append([o, n, d, p])
    return ev
def record(cls_name, a, n, d, c, m, created, via):
    if created not in jar.classes or jar.classes[created].flags & 0x400: return
    ev = store_evidence(c, m, created)
    if not ev: return
    row = tree.setdefault(created, {'className': by_runtime.get(created, ('?',))[0], 'classId': by_runtime.get(created, (None,None))[1], 'serialized': 0, 'creations': []})
    row['creations'].append({'for': cls_name, 'in': f'{a}.{n}{d}', 'via': via, 'store': ev[0]})
    pending.add(created)
reach_count = {}
work = list(tree); done = set()
while work:
    cls_name = work.pop()
    if cls_name in done: continue
    done.add(cls_name)
    extra = set()
    if cls_name == module_class:
        # instance methods invoked on the module class inside the static factory closure
        seen = set(); todo = [(module_class, factory_name, factory_desc, 0)]
        while todo:
            o, n, d, depth = todo.pop()
            if (o, n, d) in seen or depth > 6 or o not in jar.classes: continue
            seen.add((o, n, d)); c = code(o)
            for m in c.methods:
                if (m.name, m.desc) != (n, d) or not m.code: continue
                for off, op, args in instructions(m.code):
                    if op in (182, 183, 184):
                        o2, n2, d2 = ref(c, args)
                        if op == 184 and o2 in jar.classes: todo.append((o2, n2, d2, depth+1))
                        elif op in (182, 183) and o2 in A(module_class) and n2 != '<init>': extra.add((n2, d2))
    todo = list(entries | extra); visited = set(); reachable = []
    while todo:
        n, d = todo.pop()
        if (n, d) in visited: continue
        visited.add((n, d))
        a = resolve(cls_name, n, d)
        if a is None or a == base or a in A(base): continue
        c = code(a); m = next(x for x in c.methods if (x.name, x.desc) == (n, d))
        if not m.code: continue
        reachable.append((a, n, d))
        for off, op, args in instructions(m.code):
            if op in (182, 183, 185):
                o2, n2, d2 = ref(c, args)
                if o2 == a or o2 in A(cls_name): todo.append((n2, d2))
            elif op == 187:
                t = c.cp[c.cp[args[0]*256+args[1]][1]][1]
                if is_doc(t): creations = [(t, None)]
                else: continue
                for created, via in creations: record(cls_name, a, n, d, c, m, created, via)
            elif op == 184:
                o2, n2, d2 = ref(c, args); r = d2[d2.index(')')+1:]
                if r.startswith('L') and is_doc(r[1:-1]):
                    for created in static_creations(o2, n2, d2, 0, set()): record(cls_name, a, n, d, c, m, created, (o2, n2, d2))
    reach_count[cls_name] = len(reachable)
    for created in list(pending):
        if created not in done: work.append(created)
    pending.clear()

print('final classes', len(tree))
for k in sorted(tree, key=lambda k: (tree[k]['className'] or '')):
    v = tree[k]; print(f"{str(v['classId']):>5} {v['className']:<45} {k:<55} serialized={v['serialized']} reachable={reach_count.get(k)} creations={len(v['creations'])}")
    for c in v['creations'][:8]: print('        ', c['for'].split('/')[-1], 'in', c['in'], 'via', c['via'], 'store', c['store'][1]+c['store'][2])
