import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,rss_bytes,descriptor
from grid_doctor.descriptor_resolution import Code
from grid_doctor.migrate import member
from grid_doctor.invariant_root import invariant_root
from grid_doctor.renamed_fixture import rename_member
start=time.perf_counter();storage=json.load(open('/tmp/gn-9b6g-empty-storage-3.json'));builds=[]
paths=['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar','/tmp/gn-9b6g-old-renamed-extra.jar','/tmp/gn-9b6g-renamed-extra.jar']
for index,path in enumerate(paths):
 base=storage['builds'][index%2];key=base['reads'][0][:3];field=base['field']
 if index>=2:
  names=json.load(open('/tmp/gn-9b6g-'+('old-'if index==2 else '')+'renamed-map.json'))
  def renamed(v):return names.get(v[0],v[0]),rename_member(v[1]),descriptor(v[2],lambda n:names.get(n,n))
  key,field=renamed(key),renamed(field)
 j=Jar(Path(path));code=Code();c=code.get(j,key[0]);m=member(c,*key[1:]);r=invariant_root(c,m,field);r['sha256']=j.sha256;r['emptyReferenceEvidence']='/tmp/gn-9b6g-empty-storage-3.json';r['emptyReferenceEvidenceIsOriginalBuild']=index<2
 builds.append(r);print('build',index,r['ownInstructions'],r['vendorCalls']);del j,code
r={'builds':builds,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False};raw=json.dumps(r,indent=2).encode();Path('/tmp/gn-9b6g-invariant-root-bounds-1.json').write_bytes(raw);print(len(raw),r['elapsedMs'],r['peakRssBytes'])
