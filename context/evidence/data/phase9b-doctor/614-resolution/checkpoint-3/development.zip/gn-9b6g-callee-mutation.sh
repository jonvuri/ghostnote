set -eu
export PYTHONPATH=brain/src/probes
old_jar='/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar'
model_jar=/tmp/gn-9b6g-callee-mutant.jar
python3 -B - <<'PY'
from pathlib import Path
from grid_doctor.mutated_fixture import write_model
write_model(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'),Path('/tmp/gn-9b6g-callee-mutant.jar'),'com/bitwig/flt/document/core/master/device/i2s','SQN','()Ljava/util/List;','operation')
PY
python3 -B -m grid_doctor.descriptor_resolution --old-jar "$old_jar" --new-jar "$model_jar" --plan context/evidence/data/phase9b-doctor/614-resolution/anchor-plan.json --jdk-root /tmp/gn-9b6g-runtime-arm64-2 --report /tmp/gn-9b6g-callee-mutant-symbols.json
python3 -B -m grid_doctor.fixed_descriptors --old-jar "$old_jar" --new-jar "$model_jar" --captures context/evidence/data/phase9b-doctor/live-v20/captures.zip --report /tmp/gn-9b6g-callee-mutant-catalog.json
python3 -B -m grid_doctor.property_contracts --old-jar "$old_jar" --new-jar "$model_jar" --captures context/evidence/data/phase9b-doctor/live-v20/captures.zip --catalog /tmp/gn-9b6g-callee-mutant-catalog.json --symbols /tmp/gn-9b6g-callee-mutant-symbols.json --report /tmp/gn-9b6g-callee-mutant-properties.json
python3 -B -m grid_doctor.fixed_read_checkpoint --old-jar "$old_jar" --new-jar "$model_jar" --symbols /tmp/gn-9b6g-callee-mutant-symbols.json --catalog /tmp/gn-9b6g-callee-mutant-catalog.json --properties /tmp/gn-9b6g-callee-mutant-properties.json --output /tmp/gn-9b6g-callee-mutant-reads
