import json,time
from pathlib import Path
from grid_symbols.scan import Jar,rss_bytes
from grid_doctor.domain_paths import domain_reads
from grid_doctor.descriptor_resolution import Code
start=time.perf_counter();j=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));code=Code();cat=json.load(open('/tmp/gn-9b6g-domains-1.json'))['builds'][1];sym=json.load(open('/tmp/gn-9b6g-resolution-5.json'))['builds'][1]
r=domain_reads(j,cat,sym,code);r.update(elapsedMs=(time.perf_counter()-start)*1000,peakRssBytes=rss_bytes());Path('/tmp/gn-9b6g-domain-reads-1.json').write_text(json.dumps(r,indent=2));print(r['receivers']);print(r['work'])
