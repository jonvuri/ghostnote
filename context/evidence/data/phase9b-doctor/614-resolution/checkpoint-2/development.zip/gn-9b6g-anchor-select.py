exec(open('/tmp/gn-9b6g-anchor-explore.py').read().split('hits=defaultdict(list)')[0])
pools=json.loads(Path('/tmp/gn-9b6g-global-pools.json').read_text())
counts=pools['counts'];hits=pools['hits']
adds=defaultdict(list)
for o,n,d,v in sources:
 if o in known[0]:continue
 if counts.get(v['digest'])!=1:continue
 no,nn,ds=hits[v['digest']][0]
 try: merge(known,bindings(v,contract(code(new,no),member(code(new,no),nn,ds),new.classes)))
 except Refusal:continue
 adds[o].append(((o,n,d),(no,nn,ds),v))
for o,rows in adds.items():
 names={row[1][0] for row in rows}
 print(o,'=>',names,'unique witnesses',len(rows),flush=True)
 if len(names)!=1:continue
 # Every global unique witness must agree on its declaring class.
 known=merge(known,[{o:next(iter(names))},{}])
selected=[]
for o,rows in adds.items():
 if o not in known[0]:continue
 # Retain the shortest exact witness. Its complete pool already proves uniqueness.
 key,tgt,v=min(rows,key=lambda r:(r[2]['instructions'],r[2]['digest']))
 nv=contract(code(new,tgt[0]),member(code(new,tgt[0]),*tgt[1:]),new.classes)
 try:
  mapped=merge(bindings(v,nv),[{},{(10,*key):(10,*tgt)}])
  mapped,u=canonical_edges(mapped,od,nd); known=merge(known,mapped)
 except Refusal as e: print('conflict',key,str(e));continue
 selected.append({'source':list(key),'target':list(tgt),'digest':v['digest']})
for rnd in range(128):
 additions={}
 for o,n in list(known[0].items()):
  if o not in old.classes or n not in new.classes:continue
  a,b=old.classes[o].parent,new.classes[n].parent
  if a in old.classes and b in new.classes and a not in known[0]:
   if a in additions and additions[a]!=b:raise Refusal('parent-conflict')
   additions[a]=b
 if not additions:break
 known=merge(known,[additions,{}])
result={'types':{r:known[0].get(n) for r,n in source['types'].items()},'typeBindings':known[0],'members':[{'source':list(k),'target':list(v)}for k,v in known[1].items()],'witnesses':selected}
Path('/tmp/gn-9b6g-anchors.json').write_text(json.dumps(result,indent=2))
print('missing',[(k,v)for k,v in result['types'].items()if v is None]);print('work',work.counts)
