import json,time
from pathlib import Path
from collections import defaultdict
from grid_symbols.scan import Jar,ancestors,instructions,rss_bytes,Refusal
from grid_doctor.descriptor_resolution import Code
from grid_doctor.fixed_descriptors import integer
from grid_doctor.ownership import constant
from grid_doctor.property_contracts import bind_properties
start=time.perf_counter();code=Code();root=json.load(open('/tmp/gn-9b6g-module-old-2.json'))['objects']['root'];wanted_ids=defaultdict(set)
def walk(node):
    for prop in node['properties']:
        values=prop['value'] if isinstance(prop['value'],list) else [prop['value']]
        for value in values:
            if not isinstance(value,dict):continue
            if 'classId' in value or 'reference' in value:wanted_ids[node['classId']].add(prop['id'])
            if 'classId' in value:walk(value)
walk(root)
paths=['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'];jars=[Jar(Path(p))for p in paths];symbols=json.load(open('/tmp/gn-9b6g-resolution-5.json'))['builds'];catalogs=[]
for i,p in enumerate(['/tmp/gn-9b6g-registry-old-closure-1.json','/tmp/gn-9b6g-registry-closure-1.json']):catalogs.append({'sha256':jars[i].sha256,'rows':json.load(open(p))['selectedRows']})
source=jars[0];captured={};rows=[];work=0
for row in catalogs[0]['rows']:
    ids=wanted_ids.get(row['id'],set())
    if not ids:continue
    todo=set(ids);matches={}
    for owner in ancestors(source.classes,row['matches'][0]['descriptor'],128):
        if owner not in source.classes:continue
        cls=code.get(source,owner)
        for method in cls.methods:
            if not method.desc.startswith('()L') and method.name!='<init>':continue
            body=instructions(method.code);work+=len(body)
            if work>2000000:raise Refusal('factory-property-instruction-limit')
            for i in range(2,len(body)-1):
                off,op,args=body[i]
                if op not in (18,19) or [r[1]for r in body[i-2:i]]!=[187,89]:continue
                label=constant(cls,args[0] if op==18 else int.from_bytes(bytes(args),'big'))
                number=integer(cls,body[i+1][1],body[i+1][2])
                if label['tag']!=8 or number not in todo:continue
                typ=constant(cls,int.from_bytes(bytes(body[i-2][2]),'big'))['value']
                matches.setdefault(number,[]).append({'label':label['value'],'type':typ,'owner':owner,'method':method.name,'descriptor':method.desc,'offset':off,'relationship':symbols[0]['types']['relationship'] in ancestors(source.classes,typ,128)})
        # A property ID belongs to the nearest defining descriptor.
        todo-=matches.keys()
    rows.append({'name':row['name'],'id':row['id'],'matches':matches,'missing':sorted(todo)})
    for number,hits in matches.items():
        if len(hits)!=1 or not hits[0]['relationship']:continue
        p=hits[0];captured.setdefault((row['name'],row['id']),{})[(p['label'],number)]=p['type']
print('rows',len(rows),'properties',sum(len(r['matches'])for r in rows),'missing',[(r['name'],r['missing'])for r in rows if r['missing']], 'unbound',[(r['name'],n,h)for r in rows for n,h in r['matches'].items()if len(h)!=1 or not h[0]['relationship']],flush=True)
builds=[bind_properties(source,j,catalogs[0],catalogs[i],captured,symbols[i],code)for i,j in enumerate(jars)]
r={'source':rows,'catalogs':catalogs,'builds':builds,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'instructions':work,'boundedAdmission':False,'ownershipProved':False};raw=json.dumps(r,indent=2).encode()
if len(raw)>8*1024**2:raise Refusal('report-size')
Path('/tmp/gn-9b6g-factory-relationships-1.json').write_bytes(raw)
print('bound',[(sum(len(r['properties'])for r in b['properties']),[(r['name'],r['missing'])for r in b['properties']if r['missing']])for b in builds],'bytes',len(raw),'elapsedMs',r['elapsedMs'],'rss',r['peakRssBytes'])
