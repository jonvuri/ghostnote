import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,rss_bytes,instructions
from grid_doctor.descriptor_resolution import Code
from grid_doctor.descriptor_builders import lookup
from grid_doctor.migrate import member
from grid_doctor.ownership import constant,method_trace,bootstraps
from grid_doctor.wrapper_bounds import wrapper_bound
from grid_doctor.callee_contracts import compare_callees
from grid_doctor.read_dataflow import ReadFlow,NULL
start=time.perf_counter();jars=[Jar(Path(p))for p in ['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar']];code=Code();seed=json.load(open('/tmp/gn-9b6g-port-setter-contracts-2.json'));loops=json.load(open('/tmp/gn-9b6g-history-ancestor-bounds-1.json'))['builds'];flags=json.load(open('/tmp/gn-9b6g-relationship-predicates-1.json'))['builds'];wrapper_inputs=json.load(open('/tmp/gn-9b6g-invariant-bounds-2.json'))['rows'];inverse={v:k for k,v in seed['typeBindings'].items()};member_inverse={tuple(r['target']):tuple(r['source'])for r in seed['memberBindings']};builds=[];alltraces={}
for index,j in enumerate(jars):
 loop=loops[index]['root'];getter=loop['wrapperGetter'];cls,m=lookup(j,code,*getter);raw=instructions(m.code)
 if [r[1]for r in raw]!=[42,180,198,42,180,42,180,182,167,1,176]:raise Refusal('ancestor-wrapper-read-shape')
 # The non-null path has ten instructions. The null path has five.
 for a,b in [(2,9),(8,10)]:
  if raw[a][0]+int.from_bytes(bytes(raw[a][2]),'big',signed=True)!=raw[b][0]:raise Refusal('ancestor-wrapper-read-branch')
 if m.handlers or m.flags!=1:raise Refusal('ancestor-wrapper-read-method')
 def ref(i):
  x=constant(cls,int.from_bytes(bytes(raw[i][2]),'big'));return x['owner'],x['name'],x['descriptor']
 parent_field,property_field=ref(1),ref(4)
 if parent_field!=ref(6)or parent_field[2]!='L'+getter[0]+';'or property_field[2]!='L'+loop['predicate'][0]+';':raise Refusal('ancestor-wrapper-read-field')
 factory_slot=ref(7);rows=[];methods={(cls.name,m.name,m.desc):method_trace(j,cls,m,bootstraps(j.zip.read(cls.name+'.class'),cls))}
 for typ in ('deT','deU','deX'):
  runtime=typ if index else inverse[typ];inp=next(r for r in wrapper_inputs if r['propertyClass']==typ)['bound']['factory'];factory=(inp['owner'],inp['name'],inp['descriptor'])
  if not index:factory=member_inverse[(10,*factory)][1:]
  bound=wrapper_bound(j,code,*factory);wrapper=bound['constructors'][0]['owner'];fc,fm=lookup(j,code,runtime,*factory_slot[1:]);bridge=0;bridgecalls=0
  if (fc.name,fm.name,fm.desc)!=tuple(factory):
   ops=instructions(fm.code)
   if [r[1]for r in ops]!=[42,43,182,176]:raise Refusal('ancestor-factory-bridge')
   target=constant(fc,int.from_bytes(bytes(ops[2][2]),'big'))
   if(target['owner'],target['name'],target['descriptor'])!=tuple(factory):raise Refusal('ancestor-factory-bridge-target')
   bridge,bridgecalls=4,1
  methods[fc.name,fm.name,fm.desc]=method_trace(j,fc,fm,bootstraps(j.zip.read(fc.name+'.class'),fc))
  getter_costs=[]
  for slot in (loop['propertyGetter'],loop['parentGetter']):
   flow=ReadFlow(j,code,[],('unused','id','I'),0,'unused');receiver=('ref',wrapper,'wrapper');flow.evaluate(*slot,receiver,());cost=flow.bounds[(*slot,receiver,(),False)];getter_costs.append(cost)
   for key in flow.methods:
    c,mm=lookup(j,code,*key);methods[key]=method_trace(j,c,mm,bootstraps(j.zip.read(c.name+'.class'),c))
  # The catalog's evaluated predicate bounds include both false and true variants.
  candidates=[p for p in flags[index]['rows']if any(x[0]==runtime for x in p['predicateMethods'])]
  # deT and deU inherit the base predicate; select rows by constructor witness instead.
  allocations={tuple(a['allocation']):a for a in json.load(open('/tmp/gn-9b6g-relationship-flags-1.json'))['builds'][index]['allocations']}
  candidates=[p for p in flags[index]['rows']if allocations[tuple(p['witness'])]['constructor'][0]==runtime]
  if not candidates:raise Refusal('ancestor-predicate-coverage')
  predicate_cost=tuple(max(p['predicateBound'][k]for p in candidates)for k in range(3))
  if any(x[2]for x in getter_costs)or predicate_cost[2]:raise Refusal('ancestor-getter-external')
  rows.append({'propertyClass':runtime,'wrapper':wrapper,'factoryBound':bound,'bridgeInstructions':bridge,'bridgeCalls':bridgecalls,'getterCosts':getter_costs,'predicateCost':predicate_cost,'perAncestorInstructions':11+10+bridge+bound['constructorInstructionBound']+sum(x[0]for x in getter_costs)+predicate_cost[0],'perAncestorVendorCalls':4+1+bridgecalls+bound['vendorConstructorCalls']+sum(x[1]for x in getter_costs)+predicate_cost[1],'perAncestorObjects':1,'perAncestorExternalObjectConstructors':1})
  for trace in [bound['factory'],*bound['constructors']]:methods[trace['owner'],trace['name'],trace['descriptor']]=trace
 builds.append({'sha256':j.sha256,'root':loop['method'],'parentField':parent_field,'propertyField':property_field,'rows':rows,'aggregate':{'constantInstructions':12,'perAncestorInstructions':max(r['perAncestorInstructions']for r in rows),'constantVendorCalls':1,'perAncestorVendorCalls':max(r['perAncestorVendorCalls']for r in rows),'objectsPerAncestor':1,'externalObjectConstructorsPerAncestor':1}})
 if index:alltraces=methods
 print(index,[(r['propertyClass'],r['perAncestorInstructions'],r['perAncestorVendorCalls'])for r in rows],flush=True)
contracts=compare_callees(*jars,list(alltraces.values()),seed,code)
r={'builds':builds,'contracts':contracts,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False,'runtimeObserved':False,'conditions':['All wrapper classes and object getter dispatch must match these exact contracts.','The parent chain must remain finite, stable, and cycle-free.','The catalog property classes, flag provenance, and disabled initialized assertion fields must remain valid.','External Object constructor bodies, class initialization, and exceptional paths are excluded.']};raw=json.dumps(r,indent=2).encode()
if len(raw)>8*1024**2:raise Refusal('ancestor-aggregate-report-limit')
Path('/tmp/gn-9b6g-history-aggregate-1.json').write_bytes(raw);print('matched',len(contracts['matched']),'unmatched',contracts['unmatched']);print(len(raw),r['elapsedMs'],r['peakRssBytes'])
