import json,time
from pathlib import Path
from grid_symbols.scan import Jar,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.read_dataflow import fixed_read_flow
start=time.perf_counter();j=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));code=Code()
base=Path('context/evidence/data/phase9b-doctor/614-resolution/checkpoint-2')
symbols=json.loads((base/'symbols.json').read_text())['builds'][1];catalog=json.loads((base/'catalog.json').read_text())['builds'][1];properties=json.loads((base/'properties.json').read_text())['builds'][1];flags=json.loads((base/'fixed-read/reads-1.json').read_text())['requiredTrueFlags']
r=fixed_read_flow(j,code,symbols,catalog,properties,flags);r.update(elapsedMs=(time.perf_counter()-start)*1000,peakRssBytes=rss_bytes());Path('/tmp/gn-9b6g-read-flow-1.json').write_text(json.dumps(r,indent=2));print(r['work']);print('methods',len(r['methods']));print('errors',[(p['className'],p['propertyName'],p['error'])for p in r['paths']if p['error']])
