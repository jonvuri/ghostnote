import json,time,hashlib
from pathlib import Path
from collections import Counter
from grid_symbols.scan import Jar,rss_bytes,Refusal
from grid_doctor.contracts import contract
from grid_doctor.descriptor_resolution import Code
from grid_doctor.migrate import member
from grid_doctor.module_file import object_references
from grid_doctor.ownership import method_trace,bootstraps
start=time.perf_counter()
paths=['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar']
jars=[Jar(Path(p)) for p in paths];code=Code();symbols=json.load(open('/tmp/gn-9b6g-resolution-5.json'))
target=code.get(jars[1],'com/bitwig/ramona/serial/gJi');signature='(I)L'+symbols['builds'][0]['types']['object']+';'
expected=contract(target,member(target,'cfM','(I)Lcom/bitwig/ramona/core/oDc;'),jars[1].classes)['digest']
expected_class=Counter(contract(target,m,jars[1].classes)['digest'] for m in target.methods)
candidates=[]; comparisons=0
for cls in jars[0].classes.values():
    for m in cls.methods:
        if m.desc != signature:continue
        body=code.get(jars[0],cls.name);actual=member(body,m.name,m.desc);comparisons+=1
        if comparisons>100000:raise Refusal('reference-comparison-limit')
        if contract(body,actual,jars[0].classes)['digest']!=expected:continue
        if Counter(contract(body,x,jars[0].classes)['digest'] for x in body.methods)==expected_class:
            candidates.append(body.name)
if len(candidates)!=1:raise Refusal('reference-class-count:'+str(candidates))
traces=[]
for jar,name in zip(jars,[candidates[0],target.name]):
    cls=code.get(jar,name)
    traces.append({'sha256':jar.sha256,'class':name,'methods':[method_trace(jar,cls,m,bootstraps(jar.zip.read(name+'.class'),cls))for m in cls.methods]})
modules=[json.load(open('/tmp/gn-9b6g-module-'+label+'-2.json'))for label in ('old','new')]
graphs=[object_references(r['objects']['root'])for r in modules]
if graphs[0]!=graphs[1]:raise Refusal('reference-graph-difference')
r={'tables':traces,'graphs':graphs,'comparisons':comparisons,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'ownershipProved':False,'boundedAdmission':False}
raw=json.dumps(r,indent=2).encode()
if len(raw)>8*1024**2:raise Refusal('report-size')
Path('/tmp/gn-9b6g-object-refs-1.json').write_bytes(raw)
print(candidates,'objects',len(graphs[0]['nodes']),'references',len(graphs[0]['references']),'comparisons',comparisons,'bytes',len(raw),'elapsedMs',r['elapsedMs'],'rss',r['peakRssBytes'])
