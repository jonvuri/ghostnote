exec(open('/tmp/gn-9b6g-anchor-explore.py').read().split('sources=[]')[0])
from grid_doctor.contracts import references
from grid_symbols.scan import ancestors
a=json.loads(Path('/tmp/gn-9b6g-role-witnesses.json').read_text());known=[a['typeBindings'],{tuple(r['source']):tuple(r['target'])for r in a['members']}]
r=next(r for r in source['members']if r['role']=='native-value-setter');o=r['declaring'];n=known[0][o]
om=member(code(old,o),r['name'],r['descriptor']);v=contract(code(old,o),om,old.classes)
receiver=source['types']['decimal-atom'];nr=known[0][receiver]
for nm in code(new,n).methods:
 if signature_key(nm,new.classes)!=signature_key(om,old.classes):continue
 nv=contract(code(new,n),nm,new.classes)
 if nv['digest']!=v['digest']:continue
 mapped=bindings(v,nv)
 valid=True;trace=[]
 for oldref,newref in list(mapped[1].items()):
  tag,oo,on,ds=oldref
  if tag not in (10,11) or oo not in set(ancestors(old.classes,receiver)):continue
  odc=od.find('method',receiver,on,ds);ndc=nd.find('method',nr,newref[2],newref[3])
  oc,nc=code(old,odc['owner']),code(new,ndc['owner']);omi,nmi=member(oc,on,ds),member(nc,newref[2],newref[3])
  ov,nvv=contract(oc,omi,old.classes),contract(nc,nmi,new.classes)
  trace.append([oo,on,ds,odc['owner'],newref,ndc['owner'],ov['digest']==nvv['digest']])
  if ov['digest']!=nvv['digest']:valid=False;continue
  try:mapped=merge(mapped,bindings(ov,nvv));merge(known,mapped)
  except Refusal:valid=False;continue
 print(nm.name,valid,json.dumps(trace))
