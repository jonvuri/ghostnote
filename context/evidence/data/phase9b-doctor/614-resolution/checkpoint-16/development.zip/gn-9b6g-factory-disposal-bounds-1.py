import json,time
from pathlib import Path
from grid_symbols.scan import Jar,rss_bytes,Refusal
from grid_doctor.admission import Work,lineage
from grid_doctor.receiver_trace import ReceiverLimits
start=time.perf_counter();input=json.load(open('/tmp/gn-9b6g-factory-disposal-wrappers-1.json'));builds=[]
for index,p in enumerate(['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar']):
 j=Jar(Path(p));b=input['builds'][index];methods={(m.get('owner')or m['method'][0]):m for m in b['methods']};rows=[]
 for r in b['receivers']:
  if not r['baseReached']:raise Refusal('factory-disposal-incomplete')
  maps=[];instructions=0;listeners=0
  for owner in r['chain']:
   m=methods[owner]
   if m['kind']=='map-removal-delegate':maps.extend(m['mapFields']);instructions+=m['instructionBound']
   elif m['kind']=='listener-removal-delegate':instructions+=m['ownInstructionBound'];listeners+=len(m['blocks'])
   else:raise Refusal('factory-disposal-wrapper-kind')
  chain,end=lineage(j,r['runtime'],Work(ReceiverLimits()));keys=[]
  for slot in [('hashCode','()I'),('equals','(Ljava/lang/Object;)Z')]:
   found=[(name,m.flags)for name in chain for m in j.classes[name].methods if(m.name,m.desc)==slot]
   keys.append({'slot':slot,'declarations':found,'externalParent':end})
  rows.append({'runtime':r['runtime'],'wrapperInstructionBound':instructions,'wrapperMethods':len(r['chain']),'mapRemoveCalls':len(maps),'mapFields':maps,'listenerRemoveCalls':listeners,'keyMethods':keys})
 builds.append({'sha256':j.sha256,'rows':rows,'maximumWrapperInstructions':max(x['wrapperInstructionBound']for x in rows),'maximumMapRemovals':max(x['mapRemoveCalls']for x in rows),'maximumListenerRemovals':max(x['listenerRemoveCalls']for x in rows)});print(index,builds[-1]['maximumWrapperInstructions'],builds[-1]['maximumMapRemovals'],'customKeys',[x['runtime']for x in rows if any(k['declarations']or k['externalParent']!='java/lang/Object'for k in x['keyMethods'])],flush=True)
r={'builds':builds,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False,'runtimeObserved':False,'conditions':['These counts exclude base disposal, map bodies, listener removal callees, and assertion initialization.','The objects must have the exact recorded factory classes.','Each non-null static map must be an exact stable HashMap with an admitted size.','The external Object methods and native identity hashing remain separate dependencies.']};Path('/tmp/gn-9b6g-factory-disposal-bounds-1.json').write_text(json.dumps(r,indent=2)+'\n')
