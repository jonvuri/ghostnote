import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,rss_bytes
from grid_doctor.admission import Work
from grid_doctor.receiver_trace import Declarations,ReceiverLimits
from grid_doctor.descriptor_resolution import Code
from grid_doctor.descriptor_builders import lookup
from grid_doctor.disposal_wrappers import map_wrapper,listener_flags_delegate
from grid_doctor.ownership import method_trace,bootstraps
start=time.perf_counter();code=Code();inputs=json.load(open('/tmp/gn-9b6g-factory-release-2.json'))['builds'];rows=[]
for index,path in enumerate(['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar']):
 j=Jar(Path(path));d=Declarations(j,Work(ReceiverLimits()));base='com/bitwig/ramona/core/'+('oDc'if index else'HEV');slot='ix_'if index else'dC_';methods={};receivers=[]
 for item in inputs[index]['rows']:
  runtime=item['runtime'];found=d.find('method',runtime,slot,'()V');chain=[]
  while found['status']=='declaration'and found['owner']!=base:
   owner=found['owner']
   if owner in chain or len(chain)>=128:raise Refusal('factory-disposal-chain')
   chain.append(owner)
   if owner not in methods:
    c,m=lookup(j,code,owner,slot,'()V')
    try:r=map_wrapper(j,code,c,m);r['kind']='map-removal-delegate'
    except Refusal as first:
     try:r=listener_flags_delegate(c,m);r['kind']='listener-removal-delegate';r['trace']=method_trace(j,c,m,bootstraps(j.zip.read(c.name+'.class'),c))
     except Refusal as second:r={'owner':owner,'refusal':[str(first),str(second)]}
    methods[owner]=r
   if 'refusal'in methods[owner]:break
   found=d.find('method',*methods[owner]['delegate'])
  receivers.append({'runtime':runtime,'chain':chain,'baseReached':found['status']=='declaration'and found['owner']==base})
 rows.append({'sha256':j.sha256,'receivers':receivers,'methods':list(methods.values())});print(index,'receivers',len(receivers),'methods',len(methods),'refused',[r for r in methods.values()if 'refusal'in r],flush=True)
r={'builds':rows,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False};Path('/tmp/gn-9b6g-factory-disposal-wrappers-1.json').write_text(json.dumps(r,indent=2)+'\n')
