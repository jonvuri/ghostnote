import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.dynamic_contracts import dynamic_contract
from grid_doctor.migrate import member,bindings,merge
from grid_doctor.ownership import bootstraps
start=time.perf_counter();jars=[Jar(Path(p))for p in ['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar']];code=Code();rows=[];seed=json.load(open('/tmp/gn-9b6g-lifecycle-contracts-5.json'));known=[seed['typeBindings'],{tuple(r['source']):tuple(r['target'])for r in seed['memberBindings']}]
pairs=[(('cXV','ffA','(Lcom/bitwig/ramona/core/HEV;Lcom/bitwig/ramona/serial/vWM;Lcom/bitwig/base/serial/mvZ;Lcom/bitwig/ramona/serial/hwy;)V'),('der','cfM','(Lcom/bitwig/ramona/core/oDc;Lcom/bitwig/ramona/serial/iYN;Lcom/bitwig/base/serial/Wkj;Lcom/bitwig/ramona/serial/RYd;)V')),(('qOW','ffA','(Lcom/bitwig/ramona/serial/GCp;)V'),('EIm','cfM','(Lcom/bitwig/ramona/serial/rsB;)V'))]
for pair in pairs:
 vals=[]
 for j,k in zip(jars,pair):
  c=code.get(j,k[0]);m=member(c,*k[1:]);vals.append(dynamic_contract(c,m,j.classes,bootstraps(j.zip.read(c.name+'.class'),c)))
 row={'pair':pair,'digests':[v['digest']for v in vals],'counts':[len(v['tokens'])for v in vals],'differences':[(i,a,b)for i,(a,b)in enumerate(zip(vals[0]['tokens'],vals[1]['tokens']))if a!=b]};print(row,flush=True)
 try:merge(known,bindings(*vals));row['merge']='matched'
 except Refusal as e:
  row['merge']=str(e)
  if vals[0]['digest']==vals[1]['digest']:
   proposed=bindings(*vals)
   row['conflicts']=[(i,k,known[i][k],v)for i in range(2)for k,v in proposed[i].items()if k in known[i]and known[i][k]!=v]
   print('conflicts',row['conflicts'])
 rows.append(row)
r={'pairs':rows,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False};Path('/tmp/gn-9b6g-local-differences-2.json').write_text(json.dumps(r,indent=2)+'\n')
