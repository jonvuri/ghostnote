import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,ancestors,instructions,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.constructor_paths import constructor_path
from grid_doctor.fixed_descriptors import integer
from grid_doctor.migrate import member
from grid_doctor.ownership import constant
start=time.perf_counter();code=Code();out=[];src=json.load(open('/tmp/gn-9b6g-builder-census-3.json'))['builds']
for i,path in enumerate(['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar']):
 j=Jar(Path(path));result=[];base='cYs'if i==0 else'deN'
 for row in src[i]['rows']:
  selected=constructor_path(j,code,row['receiver']);props=[]
  for reg in row['registrations']:
   owner,name,desc=reg['source'];c=code.get(j,owner)
   methods=[member(c,name,desc)]if reg['kind']=='getter'else[member(c,'<init>',x['descriptor'])for x in selected if x['owner']==owner]
   hits=[]
   for m in methods:
    raw=instructions(m.code)
    for k in range(len(raw)-3):
     block=raw[k:k+4]
     if [x[1]for x in block[:2]]!=[187,89]or block[2][1]not in(18,19):continue
     typ=constant(c,int.from_bytes(bytes(block[0][2]),'big'))['value']
     if base not in ancestors(j.classes,typ,128):continue
     label=constant(c,block[2][2][0]if block[2][1]==18 else int.from_bytes(bytes(block[2][2]),'big'));num=integer(c,block[3][1],block[3][2])
     if label['tag']!=8 or num is None:continue
     hits.append({'name':label['value'],'id':num,'class':typ,'source':[owner,m.name,m.desc],'offset':block[0][0]})
   props.append({'registration':reg,'allocations':hits})
  result.append({'name':row['name'],'id':row['id'],'receiver':row['receiver'],'properties':props})
 out.append({'sha256':j.sha256,'rows':result});print(i,'allocs',sum(len(p['allocations'])for r in result for p in r['properties']),'unresolved',[(r['name'],p['registration']['source'],len(p['allocations']))for r in result for p in r['properties']if len(p['allocations'])!=1],flush=True)
diffs=[]
for a,b in zip(out[0]['rows'],out[1]['rows']):
 aa={(x['name'],x['id'])for p in a['properties']for x in p['allocations']};bb={(x['name'],x['id'])for p in b['properties']for x in p['allocations']}
 if aa!=bb:diffs.append({'name':a['name'],'removed':sorted(aa-bb),'added':sorted(bb-aa)})
r={'builds':out,'differences':diffs,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False};raw=json.dumps(r,separators=(',',':')).encode()
if len(raw)>8*1024**2:raise Refusal('labels-report-limit')
Path('/tmp/gn-9b6g-builder-labels-1.json').write_bytes(raw);print('differences',diffs);print(len(raw),r['elapsedMs'],r['peakRssBytes'])
