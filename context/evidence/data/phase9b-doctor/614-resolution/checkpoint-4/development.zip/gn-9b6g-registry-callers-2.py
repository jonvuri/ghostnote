import json,time,zipfile
from pathlib import Path
from grid_symbols.scan import parse,instructions,rss_bytes,Refusal
from grid_doctor.ownership import constant,method_trace,bootstraps
start=time.perf_counter();owner='com/bitwig/flt/document/core/master/QfF';rows=[];traces=[];work=0
class Data:
 def __init__(self,z):self.zip=z
 def code(self,n):return parse(self.zip.read(n+'.class'),True)
with zipfile.ZipFile('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar')as z:
 j=Data(z)
 for n in z.namelist():
  if not n.endswith('.class'):continue
  raw=z.read(n)
  if owner.encode()not in raw :continue
  c=parse(raw,True)
  for m in c.methods:
   found=[]
   for off,op,args in instructions(m.code):
    work+=1
    if work>16000000:raise Refusal('instruction-limit')
    if op not in(182,183,184,185):continue
    r=constant(c,int.from_bytes(bytes(args[:2]),'big'))
    if r.get('owner')==owner and r['name']=='<init>'and r['descriptor']=='()V':found.append(off)
   if found:
    rows.append({'source':[c.name,m.name,m.desc],'offsets':found});traces.append(method_trace(j,c,m,bootstraps(raw,c)))
r={'rows':rows,'methods':traces,'instructions':work,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False};Path('/tmp/gn-9b6g-registry-callers-2.json').write_text(json.dumps(r,indent=2));print(rows,r['elapsedMs'],r['peakRssBytes'])
