import json,time
from pathlib import Path
from collections import Counter,defaultdict
from grid_symbols.scan import Jar,parse,instructions,Refusal,rss_bytes
from grid_doctor.ownership import constant
start=time.perf_counter();j=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));outside=defaultdict(list);dynamic=[];work=Counter()
for name in j.classes:
 if not name.startswith('com/bitwig/nitro/'):continue
 c=parse(j.zip.read(name+'.class'),True);work['classes']+=1
 for m in c.methods:
  work['methods']+=1
  for off,op,args in instructions(m.code):
   work['instructions']+=1
   if 182<=op<=186:
    r=constant(c,int.from_bytes(bytes(args[:2]),'big'))
    row={'caller':[name,m.name,m.desc],'offset':off,'opcode':op,'target':r}
    if op==186:dynamic.append(row)
    elif not r['owner'].startswith('com/bitwig/nitro/'):outside[r['owner']].append(row)
   if work['instructions']>2000000:raise Refusal('nitro-edge-limit')
r={'jarSha256':j.sha256,'outside':dict(outside),'dynamic':dynamic,'work':dict(work),'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False,'limits':['Package edge census does not prove runtime reachability or exclusion.']};Path('/tmp/gn-9b6g-nitro-edges-1.json').write_text(json.dumps(r,indent=2)+'\n');print('work',dict(work),'dynamic',len(dynamic),'outside',len(outside));print('vendor',[(k,len(v))for k,v in outside.items()if k in j.classes]);print('ms',r['elapsedMs'],'rss',r['peakRssBytes'])
