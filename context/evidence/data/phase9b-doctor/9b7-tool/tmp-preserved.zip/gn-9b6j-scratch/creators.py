"""Ad-hoc: find every method that creates (NEW) or returns (static) the given classes across the jar."""
import sys
sys.path.insert(0, '/Users/jonvuri/Development/ghostnote/brain/src/probes')
from grid_symbols.scan import Jar, parse, instructions
from pathlib import Path
jar = Jar(Path(sys.argv[1])); wanted = set(sys.argv[2:])
for entry in jar.zip.namelist():
    if not entry.endswith('.class'): continue
    data = jar.zip.read(entry)
    if not any(w.encode() in data for w in wanted): continue
    cls = parse(data, True)
    for m in cls.methods:
        if not m.code: continue
        for off, op, args in instructions(m.code):
            if op == 187:
                t = cls.cp[cls.cp[args[0]*256+args[1]][1]][1]
                if t in wanted: print(f'NEW {t} in {cls.name}.{m.name}{m.desc} flags={m.flags}')
            elif op == 184:
                owner, nt = cls.cp[args[0]*256+args[1]][1]; owner = cls.cp[cls.cp[owner][1]][1]
                ni, di = cls.cp[nt][1]; n, d = cls.cp[ni][1], cls.cp[di][1]
                ret = d[d.index(')')+1:]
                if ret.startswith('L') and ret[1:-1] in wanted and owner != cls.name: print(f'STATIC {owner}.{n}{d} called in {cls.name}.{m.name}{m.desc} flags={m.flags}')
