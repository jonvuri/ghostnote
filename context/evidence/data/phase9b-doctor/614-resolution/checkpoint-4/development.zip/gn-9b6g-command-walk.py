import json,time,sys
from pathlib import Path
from collections import deque
from grid_symbols.scan import Jar,ancestors,instructions,Refusal,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.admission import Work
from grid_doctor.receiver_trace import Declarations,ReceiverLimits
from grid_doctor.migrate import member
from grid_doctor.ownership import constant,method_trace,bootstraps
from grid_doctor.assertion_guards import requirements
from grid_doctor.dispatch_paths import reachable
start=time.perf_counter();j=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));code=Code();d=Declarations(j,Work(ReceiverLimits()));s=json.load(open('/tmp/gn-9b6g-resolution-5.json'))['builds'][1];case=sys.argv[1];roles={x['role']:x['reference'][1:]for x in s['members']};cases={'value':('native-value-setter','decimal-atom'),'cable':('cable-source-setter','destination-atom'),'delete':('module-delete','module'),'close':('close','grid'),'dispose':('disposal','module'),'factory':('module-factory',None)};role,rtype=cases[case];runtime=s['types'][rtype]if rtype else None;root=roles[role];todo=deque([((runtime or root[0],*root[1:]),runtime)]);traces={};contexts=set();frontier=[];edges=[];flags=set();counts=0
while todo:
 (owner,name,desc),receiver=todo.popleft();found=d.find('method',owner,name,desc)
 if found['status']!='declaration':
  frontier.append({'caller':[owner,name,desc],'receiver':receiver,'status':'lookup-unresolved','resolution':found});continue
 key=found['owner'],name,desc;context=key,receiver
 if context in contexts:continue
 if len(contexts)>=1024 or len(traces)>=512:raise Refusal('command-method-limit')
 contexts.add(context);cls=code.get(j,key[0]);m=member(cls,name,desc)
 if m.flags&(256|1024):frontier.append({'caller':key,'receiver':receiver,'status':'native-or-abstract'});continue
 guard=requirements(j,{cls.name},code);flags.update(guard['fields']);selected=reachable(cls,m,None,set(guard['fields']));traces[key]=method_trace(j,cls,m,bootstraps(j.zip.read(cls.name+'.class'),cls));lineage=set(ancestors(j.classes,receiver,128))if receiver else set()
 for offset,op,args in instructions(m.code):
  counts+=1
  if counts>2000000:raise Refusal('command-instruction-limit')
  if offset not in selected or not 182<=op<=186:continue
  ref=constant(cls,args[0]*256+args[1]);edge={'caller':key,'receiver':receiver,'offset':offset,'opcode':op,'target':ref};edges.append(edge)
  if len(edges)>16000:raise Refusal('command-edge-limit')
  if op==186:frontier.append(edge);continue
  target=ref['owner'],ref['name'],ref['descriptor']
  if ref['owner']not in j.classes:frontier.append(edge)
  elif op==184:todo.append((target,None))
  elif op==183 and ref['name']!='<init>' and ref['owner']in lineage:todo.append((target,receiver))
  elif op in(182,185)and ref['owner']in lineage:
   symbolic=d.find('method',*target)
   todo.append(((symbolic['owner'],*target[1:])if symbolic['status']=='declaration'and symbolic['flags']&2 else(receiver,*target[1:]),receiver))
  else:frontier.append(edge)
r={'sha256':j.sha256,'role':role,'root':root,'runtimeHypothesis':runtime,'requiredTrueFlags':sorted(flags),'methods':list(traces.values()),'edges':edges,'frontier':frontier,'instructions':counts,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'limits':['Same-family virtual calls are receiver hypotheses. Data flow is not proved.','Assertion fields are conditional. Other virtual, dynamic, and external calls remain unresolved.'],'boundedAdmission':False};Path('/tmp/gn-9b6g-command-walk-'+case+'-3.json').write_text(json.dumps(r,indent=2));print(case,'methods',len(traces),'contexts',len(contexts),'edges',len(edges),'frontier',len(frontier),'elapsedMs',r['elapsedMs'],'RSS',r['peakRssBytes'])
