import json,time
from pathlib import Path
from collections import deque
from grid_symbols.scan import Jar,ancestors,instructions,Refusal,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.admission import Work
from grid_doctor.receiver_trace import Declarations,ReceiverLimits
from grid_doctor.migrate import member
from grid_doctor.ownership import constant,method_trace,bootstraps
from grid_doctor.assertion_guards import requirements
from grid_doctor.dispatch_paths import reachable
start=time.perf_counter();j=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));code=Code();d=Declarations(j,Work(ReceiverLimits()));runtime='com/bitwig/flt/document/core/master/g2L';lineage=set(ancestors(j.classes,runtime,128));roots=[(runtime,n,s)for n,s in [('FFu','(Ljava/lang/String;)V'),('qFI','(Ljava/lang/String;)V'),('LIK','(Z)V'),('sc','(Z)V'),('Txc','(Z)V'),('mtS','(Z)V')]];todo=deque(roots);traces={};frontier=[];edges=[];flags=set();counts=0
while todo:
 owner,name,desc=todo.popleft();found=d.find('method',owner,name,desc)
 if found['status']!='declaration':raise Refusal('project-lookup')
 key=found['owner'],name,desc
 if key in traces:continue
 if len(traces)>=512:raise Refusal('project-method-limit')
 cls=code.get(j,key[0]);m=member(cls,name,desc);guard=requirements(j,{cls.name},code);flags.update(guard['fields']);selected=reachable(cls,m,None,set(guard['fields']));traces[key]=method_trace(j,cls,m,bootstraps(j.zip.read(cls.name+'.class'),cls))
 for offset,op,args in instructions(m.code):
  counts+=1
  if counts>2000000:raise Refusal('project-instruction-limit')
  if offset not in selected or not 182<=op<=186:continue
  ref=constant(cls,args[0]*256+args[1]);edge={'caller':key,'offset':offset,'opcode':op,'target':ref};edges.append(edge)
  if len(edges)>16384:raise Refusal('project-edge-limit')
  if op==186:frontier.append(edge);continue
  target=ref['owner'],ref['name'],ref['descriptor']
  if ref['owner']not in j.classes:frontier.append(edge)
  elif op in (183,184):todo.append(target)
  elif ref['owner']in lineage:todo.append((runtime,*target[1:]))
  else:frontier.append(edge)
r={'sha256':j.sha256,'roots':roots,'runtimeHypothesis':runtime,'requiredTrueFlags':sorted(flags),'methods':list(traces.values()),'edges':edges,'frontier':frontier,'instructions':counts,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'limits':['Calls on project base types are receiver hypotheses. Data flow is not proved.','Assertion fields are conditional. Other virtual, dynamic, and external calls remain unresolved.'],'boundedAdmission':False};Path('/tmp/gn-9b6g-project-walk-1.json').write_text(json.dumps(r,indent=2));print('methods',len(traces),'edges',len(edges),'frontier',len(frontier));print(json.dumps(frontier,indent=1))
