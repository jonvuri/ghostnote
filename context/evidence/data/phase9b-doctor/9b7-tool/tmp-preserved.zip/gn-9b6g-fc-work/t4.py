import sys;sys.path.insert(0,'/tmp/gn-9b6g-fc-work')
import walk;from walk import *
jar=Jar(NEW);P='com/bitwig/flt/document/core/master/device/'
root=eval(sys.argv[1]);targets=sys.argv[2].split(',')
stop=lambda o,n,d:(o,n,d)==('BgP','cfM','(ZZZ)V')
nodes,leaves=closure(jar,[root],max_methods=512,max_depth=40,stop=stop)
by={n['method']:n for n in nodes}
for n in nodes:
  hit=[c for c in n['news'] if c in targets]+[cl['target'] for cl in n['calls'] if cl['target'][0] in targets]
  if hit:
    chain=[];x=n
    while x:
      chain.append(x['method'][0].split('/')[-1]+'.'+x['method'][1]+(('@'+str(x['from'][3])) if x['from'] else ''))
      f=x['from'];x=by.get(f[:3]) if f else None
    print(hit[:3],' <- '.join(chain))
