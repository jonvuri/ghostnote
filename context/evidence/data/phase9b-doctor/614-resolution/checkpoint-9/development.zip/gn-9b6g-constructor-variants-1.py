import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.constructor_variants import map_capacity_one,empty_holder
from grid_doctor.callee_contracts import compare_callees
from grid_doctor.contracts import contract
from grid_doctor.migrate import member
start=time.perf_counter();jars=[Jar(Path(p))for p in ['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar']];code=Code();seed=json.load(open('/tmp/gn-9b6g-factory-constructor-contracts-1.json'));keys={tuple(r['target'])for r in seed['unmatched']};variants=[]
def local(j,c,m):
 if j is jars[1]and(c.name,m.name,m.desc)in keys:
  return empty_holder(j,code,c,m)if c.name=='EIm'else map_capacity_one(c,m,j.classes)
 return contract(c,m,j.classes)
traces=[dict(zip(('owner','name','descriptor'),key))for key in sorted(keys)];r=compare_callees(*jars,traces,seed,code,local_contract=local)
for row in r['matched']:
 k=row['target'];c=code.get(jars[1],k[0]);v=local(jars[1],c,member(c,*k[1:]));row['variant']=v['constructorVariant']
r.update(elapsedMs=(time.perf_counter()-start)*1000,peakRssBytes=rss_bytes());raw=json.dumps(r,indent=2).encode()
if len(raw)>8*1024**2:raise Refusal('constructor-variant-report-limit')
Path('/tmp/gn-9b6g-constructor-variants-1.json').write_bytes(raw);print('matched',len(r['matched']),'unmatched',r['unmatched']);print([(x['target'],x['variant']['kind'])for x in r['matched']]);print(len(raw),r['elapsedMs'],r['peakRssBytes'])
