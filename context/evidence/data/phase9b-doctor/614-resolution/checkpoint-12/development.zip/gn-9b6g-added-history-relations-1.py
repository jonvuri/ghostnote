import json
from pathlib import Path
source=json.load(open('/tmp/gn-9b6g-relationship-predicates-1.json'));builds=[]
selected={('module',6785),('module',6054),('auxiliary_device_remote_controls',7005),('nitro_atom',228),('nitro_atom',229),('bipolar_toggleable_decimal_value_atom',3605),('boolean_value_atom',3605)}
for b in source['builds']:
 rows=[r for r in b['rows'] if (r['className'],r['propertyId'])in selected]
 if len(rows)!=len(selected)or any(r['predicate']for r in rows):raise ValueError('added relationship coverage or predicate')
 builds.append({'sha256':b['sha256'],'rows':rows})
r={'builds':builds,'boundedAdmission':False,'runtimeObserved':False,'conditions':['These seven schema rows name the traced default-child and generated-port relationships.','The result does not establish which children exist, parent identity, or state stability.','The surrounding clone, initialization, attachment, and disposal paths remain separate.']}
Path('/tmp/gn-9b6g-added-history-relations-1.json').write_text(json.dumps(r,indent=2)+'\n')
print('builds',len(builds),'relationships each',len(selected),'all false')
