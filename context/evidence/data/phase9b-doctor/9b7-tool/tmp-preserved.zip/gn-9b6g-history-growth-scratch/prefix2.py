"""Inert history-helper model, attempt 4: exact formulas checked against the module.

It interprets vendor and bundled-JDK bytecode in Python with inert objects.
It loads no vendor class, starts no JVM, and initializes no runtime class.
"""
import hashlib, json, math, random, sys, time, zipfile
from collections import Counter
from pathlib import Path
from grid_symbols.scan import parse, instructions, Refusal, rss_bytes
from grid_doctor.ownership import constant, bootstraps
from grid_doctor import history_growth as hg

START = time.perf_counter()
NEW = Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar')
OLD = Path('/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar')
RENAMED_NEW, RENAMED_OLD = Path('/tmp/gn-9b6g-renamed-extra.jar'), Path('/tmp/gn-9b6g-old-renamed-extra.jar')
JDK = [Path('/tmp/gn-9b6g-runtime-new-arm64-9/java.base'), Path('/tmp/gn-9b6g-history-growth-jdk-1/java.base')]
PINNED_INPUTS = {
    str(NEW): '5c2b1895bbb9e7d08d9216de421985bb1f24b2ee62762c9451b4fe847df2469f',
    str(OLD): '382c655d0b9e8db6bd433dc6100ef3a4ee23abf6a6615f79c40f0c2645792c93',
    str(RENAMED_NEW): 'ae29e627246fa89eb35a1c11e2c2623026bd84185f161b3b19b813b9508dde7e',
    str(RENAMED_OLD): '23708ef4c362ed072410c5415857bddcbfdc71f26087760cf5158ef8bf4158d6',
    '/tmp/gn-9b6g-runtime-new-arm64-9/java.base/java/util/ArrayList.class': None,
    '/tmp/gn-9b6g-history-growth-jdk-1/java.base/java/util/Collection.class':
        '115defd3b61bd0ce2954e36c8ba43ce085fbf7780b53040c30cd9a2238f4f6ac',
}
LIMITS = {'seconds': 120, 'rssBytes': 768 * 1024**2, 'reportBytes': 8 * 1024**2,
          'instructionsPerCall': 2_000_000, 'frameDepth': 64, 'cases': 20000}


def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


hashes = {}
for p, want in PINNED_INPUTS.items():
    hashes[p] = sha(p)
    if want and hashes[p] != want:
        raise Refusal('history-growth-input-hash:' + p)


class Source:
    def __init__(self, jar):
        self.zip, self.cache = zipfile.ZipFile(jar), {}

    def load(self, name):
        if name not in self.cache:
            if name.startswith(('java/', 'jdk/')):
                for base in JDK:
                    if (base / (name + '.class')).exists():
                        raw = (base / (name + '.class')).read_bytes(); break
                else:
                    raise KeyError(name)
            else:
                raw = self.zip.read(name + '.class')
            c = parse(raw, True)
            ins = {m.name + m.desc: m for m in c.methods}
            self.cache[name] = (c, bootstraps(raw, c), ins, hashlib.sha256(raw).hexdigest())
        return self.cache[name]


# ---------------------------------------------------------------- contracts
contracts = {}
for label, path, kind in (('new', NEW, 'real'), ('renamedNew', RENAMED_NEW, 'renamed')):
    src = Source(path)
    if kind == 'renamed':
        mp = json.load(open('/tmp/gn-9b6g-renamed-map.json'))
        rc, rm = (lambda n, mp=mp: mp.get(n, n)), (lambda n: n if n.startswith('<') else 'r_' + n)
    else:
        rc = rm = (lambda n: n)
    out = hg.check_bodies(lambda n, s=src: s.load(n)[:2], rc, rm)
    contracts[label] = {'targets': len(out['targets']),
                        'instructions': sum(v['instructions'] for v in out['targets'].values()),
                        'allPinned': True}
old_rows = {}
for label, path, name in (('old', OLD, 'cZl'), ('renamedOld', RENAMED_OLD,
                          json.load(open('/tmp/gn-9b6g-old-renamed-map.json'))['cZl'])):
    c = parse(zipfile.ZipFile(path).read(name + '.class'), True)
    old_rows[label] = hg.old_structure(c)
    if old_rows[label]['structurePresent']:
        raise Refusal('history-growth-old-structure-present')

# ---------------------------------------------------------------- inert machine
WIDE = object()
ASSERT_TRUE = {('dgJ', 'cfM'), ('dfI', 'FzB'), ('com/bitwig/ramona/core/AVL', 'jOH'),
               ('com/bitwig/ramona/core/oDc', 'xPh'), ('eSw', 'FzB')}


class Obj:
    __slots__ = ('cls', 'f', 'hash')

    def __init__(self, cls, **f):
        self.cls, self.f, self.hash = cls, f, None


class Arr:
    __slots__ = ('typ', 'v')

    def __init__(self, typ, n, fill=None):
        self.typ, self.v = typ, [fill] * n


class Lambda:
    def __init__(self, handle, captured):
        self.handle, self.captured = handle, captured


class Thrown(Exception):
    pass


def i32(x):
    return ((x + 2**31) % 2**32) - 2**31


def i64(x):
    return ((x + 2**63) % 2**64) - 2**63


def jdiv(a, b):
    q = abs(a) // abs(b)
    return q if (a >= 0) == (b >= 0) else -q


class Machine:
    def __init__(self, src, fail_alloc=None):
        self.src, self.c, self.depth, self.fail_alloc = src, Counter(), 0, fail_alloc
        self.per = Counter()
        self.next_hash = 1

    def cat(self, owner):
        return 'jdk' if owner.startswith(('java/', 'jdk/')) else 'vendor'

    def lookup(self, owner, key, virtual):
        name = owner
        while name:
            c, boot, ms, _ = self.src.load(name)
            m = ms.get(key)
            if m is not None and not (m.flags & 0x400):
                return name, m
            if not virtual and m is not None:
                raise Refusal('model-abstract:' + name + key)
            name = c.parent
        # Maximally specific default method (search interfaces breadth first).
        todo, seen, found = [owner], set(), []
        while todo:
            n = todo.pop(0)
            if n in seen or not n:
                continue
            seen.add(n)
            try:
                c, _, ms, _ = self.src.load(n)
            except KeyError:
                continue
            m = ms.get(key)
            if m is not None and c.flags & 0x200 and not (m.flags & 0x400):
                found.append((n, m))
            todo += list(c.interfaces) + ([c.parent] if c.parent else [])
        if len(found) != 1:
            raise Refusal('model-resolve:' + owner + '.' + key + ':' + str(len(found)))
        return found[0]

    def subtype(self, name, target):
        if target == 'java/lang/Object' or name == target:
            return True
        todo, seen = [name], set()
        while todo:
            n = todo.pop()
            if n in seen or not n:
                continue
            seen.add(n)
            if n == target:
                return True
            try:
                c = self.src.load(n)[0]
            except KeyError:
                continue
            todo += [c.parent, *c.interfaces]
        return False

    def stub(self, owner, name, desc, args):
        key = (owner, name)
        if key == ('java/lang/System', 'identityHashCode'):
            self.c['native'] += 1
            o = args[0]
            if o.hash is None:
                o.hash = self.next_hash; self.next_hash += 1
            return o.hash
        if key == ('java/lang/System', 'arraycopy'):
            self.c['native'] += 1
            s, sp, d, dp, n = args
            self.c['arraycopySlots'] += n
            d.v[dp:dp + n] = s.v[sp:sp + n]
            return None
        if key == ('java/lang/StrictMath', 'ceil'):
            self.c['jdkStub'] += 1
            return float(math.ceil(args[0]))
        if key == ('java/util/Arrays', 'copyOf') and desc == '([Ljava/lang/Object;I)[Ljava/lang/Object;':
            self.c['jdkStub'] += 1; self.c['allocJdk'] += 1
            a = Arr(args[0].typ, args[1]); a.v[:min(args[1], len(args[0].v))] = args[0].v[:args[1]]
            return a
        if key == ('jdk/internal/util/ArraysSupport', 'newLength'):
            self.c['jdkStub'] += 1
            return args[0] + max(args[1], args[2])
        return NotImplemented

    def invoke(self, owner, name, desc, args, virtual):
        r = self.stub(owner, name, desc, args)
        if r is not NotImplemented:
            return r
        if virtual and isinstance(args[0], Lambda):
            lam = args[0]; self.c['lambdaFrame'] += 1
            target = lam.handle['target']
            call = lam.captured + args[1:]
            return self.invoke(target['owner'], target['name'], target['descriptor'], call,
                               lam.handle['kind'] in (5, 9))
        if virtual:
            recv = args[0]
            if recv is None:
                raise Refusal('model-null-receiver:' + owner + '.' + name)
            start = recv.cls if isinstance(recv, Obj) else 'java/lang/Object'
            decl, m = self.lookup(start, name + desc, True)
        else:
            decl, m = self.lookup(owner, name + desc, False)
        if m.flags & 0x100:
            raise Refusal('model-native:' + decl + '.' + name)
        return self.run(decl, m, args)

    def run(self, owner, m, args, start=0, preset=None):
        cat = self.cat(owner)
        self.c[cat + 'Calls'] += 1
        self.depth += 1
        if self.depth > LIMITS['frameDepth']:
            raise Refusal('model-depth')
        try:
            return self._run(owner, m, args, cat, start, preset)
        finally:
            self.depth -= 1

    def _run(self, owner, m, args, cat, start, preset):
        cls, boot, _, _ = self.src.load(owner)
        raw = instructions(m.code)
        at = {r[0]: i for i, r in enumerate(raw)}
        local, slot = {}, 0
        static = bool(m.flags & 8)
        params = hg.re.findall(r'\[*(?:L[^;]+;|[ZBCSIFJD])', m.desc[1:m.desc.index(')')])
        values = list(args)
        if not static:
            local[0] = values.pop(0); slot = 1
        for p, v in zip(params, values):
            local[slot] = v; slot += 2 if p in ('J', 'D') else 1
        if preset:
            local.update(preset)
        st = []
        pc = start
        key = cat + 'Instructions'
        while True:
            self.c[key] += 1
            self.per[(owner, m.name + m.desc)] += 1
            if self.c[key] > LIMITS['instructionsPerCall']:
                raise Refusal('model-instruction-limit')
            i = at[pc]; off, op, a = raw[i]
            nxt = raw[i + 1][0] if i + 1 < len(raw) else None

            def ref():
                width = 1 if op == 18 else 2
                return constant(cls, int.from_bytes(bytes(a[:width]), 'big'))

            def br():
                return off + int.from_bytes(bytes(a), 'big', signed=True)
            jump = None
            if op == 0: pass
            elif op == 1: st.append(None)
            elif 2 <= op <= 8: st.append(op - 3)
            elif op in (9, 10): st += [op - 9, WIDE]
            elif 11 <= op <= 13: st.append(float(op - 11))
            elif op in (14, 15): st += [float(op - 14), WIDE]
            elif op == 16: st.append(int.from_bytes(bytes(a), 'big', signed=True))
            elif op == 17: st.append(int.from_bytes(bytes(a), 'big', signed=True))
            elif op in (18, 19, 20):
                k = ref()
                if k['tag'] == 3: st.append(int.from_bytes(bytes.fromhex(k['value']), 'big', signed=True))
                elif k['tag'] == 4:
                    import struct; st.append(struct.unpack('>f', bytes.fromhex(k['value']))[0])
                elif k['tag'] == 5: st += [int.from_bytes(bytes.fromhex(k['value']), 'big', signed=True), WIDE]
                elif k['tag'] == 6:
                    import struct; st += [struct.unpack('>d', bytes.fromhex(k['value']))[0], WIDE]
                elif k['tag'] == 8: st.append('str:' + k['value'])
                else: raise Refusal('model-ldc')
            elif op in (21, 23, 25): st.append(local[a[0]])
            elif op in (22, 24): st += [local[a[0]], WIDE]
            elif 26 <= op <= 29: st.append(local[op - 26])
            elif 30 <= op <= 33: st += [local[op - 30], WIDE]
            elif 34 <= op <= 37: st.append(local[op - 34])
            elif 38 <= op <= 41: st += [local[op - 38], WIDE]
            elif 42 <= op <= 45: st.append(local[op - 42])
            elif op in (46, 48, 50, 51, 52, 53, 47, 49):
                idx = st.pop(); arr = st.pop()
                if arr is None: raise Refusal('model-null-array')
                if idx < 0 or idx >= len(arr.v): raise Refusal('model-array-index')
                st.append(arr.v[idx])
                if op in (47, 49): st.append(WIDE)
            elif op in (54, 56, 58): local[a[0]] = st.pop()
            elif op in (55, 57): st.pop(); local[a[0]] = st.pop(); local[a[0] + 1] = WIDE
            elif 59 <= op <= 62: local[op - 59] = st.pop()
            elif 63 <= op <= 66: st.pop(); local[op - 63] = st.pop()
            elif 67 <= op <= 70: local[op - 67] = st.pop()
            elif 71 <= op <= 74: st.pop(); local[op - 71] = st.pop()
            elif 75 <= op <= 78: local[op - 75] = st.pop()
            elif op in (79, 81, 83, 84, 85, 86, 80, 82):
                if op in (80, 82): st.pop()
                v = st.pop(); idx = st.pop(); arr = st.pop()
                if idx < 0 or idx >= len(arr.v): raise Refusal('model-array-index')
                arr.v[idx] = v
            elif op == 87: st.pop()
            elif op == 88: st.pop(); st.pop()
            elif op == 89: st.append(st[-1])
            elif op == 90: v1 = st.pop(); v2 = st.pop(); st += [v1, v2, v1]
            elif op == 91: v1 = st.pop(); v2 = st.pop(); v3 = st.pop(); st += [v1, v3, v2, v1]
            elif op == 92: st += st[-2:]
            elif op == 93: v1 = st.pop(); v2 = st.pop(); v3 = st.pop(); st += [v2, v1, v3, v2, v1]
            elif op == 95: v1 = st.pop(); v2 = st.pop(); st += [v1, v2]
            elif op in (96, 100, 104, 108, 112, 120, 122, 124, 126, 128, 130):
                b = st.pop(); x = st.pop()
                if op in (108, 112) and b == 0:
                    raise Refusal('model-div0')
                r = (x + b if op == 96 else x - b if op == 100 else x * b if op == 104
                     else jdiv(x, b) if op == 108 else x - jdiv(x, b) * b if op == 112
                     else x << (b & 31) if op == 120 else x >> (b & 31) if op == 122
                     else (x % 2**32) >> (b & 31) if op == 124 else x & b if op == 126
                     else x | b if op == 128 else x ^ b)
                st.append(i32(r))
            elif op in (97, 101, 105, 109, 113, 127, 129, 131):
                st.pop(); b = st.pop(); st.pop(); x = st.pop()
                if op in (109, 113) and b == 0:
                    raise Refusal('model-div0')
                r = (x + b if op == 97 else x - b if op == 101 else x * b if op == 105
                     else jdiv(x, b) if op == 109 else x - jdiv(x, b) * b if op == 113
                     else x & b if op == 127 else x | b if op == 129 else x ^ b)
                st += [i64(r), WIDE]
            elif op in (121, 123, 125):
                b = st.pop(); st.pop(); x = st.pop()
                r = {121: x << (b & 63), 123: x >> (b & 63), 125: (x % 2**64) >> (b & 63)}[op]
                st += [i64(r), WIDE]
            elif op in (98, 102, 106, 110):
                b = st.pop(); x = st.pop()
                st.append(x + b if op == 98 else x - b if op == 102 else x * b if op == 106 else x / b)
            elif op in (99, 103, 107, 111):
                st.pop(); b = st.pop(); st.pop(); x = st.pop()
                st += [x + b if op == 99 else x - b if op == 103 else x * b if op == 107 else x / b, WIDE]
            elif op == 116: st.append(i32(-st.pop()))
            elif op == 117: st.pop(); st += [i64(-st.pop()), WIDE]
            elif op == 132: local[a[0]] = i32(local[a[0]] + int.from_bytes(bytes(a[1:]), 'big', signed=True))
            elif op == 133: st += [st.pop(), WIDE]
            elif op in (134,): st.append(float(st.pop()))
            elif op == 135: st += [float(st.pop()), WIDE]
            elif op == 136: st.pop(); st.append(i32(st.pop()))
            elif op in (137, 138): st.pop(); v = float(st.pop()); st += ([v] if op == 137 else [v, WIDE])
            elif op in (139, 140, 141):
                v = st.pop()
                if op == 139: st.append(i32(int(v)))
                elif op == 140: st += [i64(int(v)), WIDE]
                else: st += [float(v), WIDE]
            elif op in (142, 143, 144):
                st.pop(); v = st.pop()
                if op == 142: st.append(max(-2**31, min(2**31 - 1, int(v))))
                elif op == 143: st += [max(-2**63, min(2**63 - 1, int(v))), WIDE]
                else: st.append(float(v))
            elif op == 148:
                st.pop(); b = st.pop(); st.pop(); x = st.pop(); st.append((x > b) - (x < b))
            elif op in (149, 150):
                b = st.pop(); x = st.pop(); st.append((x > b) - (x < b))
            elif op in (151, 152):
                st.pop(); b = st.pop(); st.pop(); x = st.pop(); st.append((x > b) - (x < b))
            elif 153 <= op <= 158:
                v = st.pop()
                if {153: v == 0, 154: v != 0, 155: v < 0, 156: v >= 0, 157: v > 0, 158: v <= 0}[op]: jump = br()
            elif 159 <= op <= 164:
                b = st.pop(); x = st.pop()
                if {159: x == b, 160: x != b, 161: x < b, 162: x >= b, 163: x > b, 164: x <= b}[op]: jump = br()
            elif op in (165, 166):
                b = st.pop(); x = st.pop()
                if (x is b) == (op == 165): jump = br()
            elif op == 167: jump = br()
            elif op in (172, 174, 176): return st.pop()
            elif op in (173, 175): st.pop(); return st.pop()
            elif op == 177: return None
            elif op in (178, 179):
                k = ref()
                if op == 179: raise Refusal('model-putstatic:' + k['owner'] + '.' + k['name'])
                if (k['owner'], k['name']) not in ASSERT_TRUE:
                    raise Refusal('model-getstatic:' + k['owner'] + '.' + k['name'])
                st.append(1)
            elif op == 180:
                k = ref(); o = st.pop()
                if o is None: raise Refusal('model-null-field')
                v = o.f.get(k['name'], 0 if k['descriptor'] in 'ZBCSIJFD' else None)
                st.append(v)
                if k['descriptor'] in ('J', 'D'): st.append(WIDE)
            elif op == 181:
                k = ref()
                if k['descriptor'] in ('J', 'D'): st.pop()
                v = st.pop(); o = st.pop(); o.f[k['name']] = v
            elif op in (182, 183, 184, 185):
                k = ref()
                params = hg.re.findall(r'\[*(?:L[^;]+;|[ZBCSIFJD])', k['descriptor'][1:k['descriptor'].index(')')])
                vals = []
                for p in reversed(params):
                    if p in ('J', 'D'): st.pop()
                    vals.append(st.pop())
                vals.reverse()
                if op != 184: vals.insert(0, st.pop())
                cat2 = self.cat(k['owner'])
                self.c[cat + 'CallSites'] += 1
                r = self.invoke(k['owner'], k['name'], k['descriptor'], vals, op in (182, 185))
                ret = k['descriptor'][k['descriptor'].index(')') + 1:]
                if ret != 'V':
                    st.append(r)
                    if ret in ('J', 'D'): st.append(WIDE)
            elif op == 186:
                k = ref(); entry = boot[k['bootstrapIndex']]
                if entry['handle']['target']['owner'] != 'java/lang/invoke/LambdaMetafactory':
                    raise Refusal('model-indy')
                n = len(hg.re.findall(r'\[*(?:L[^;]+;|[ZBCSIFJD])', k['descriptor'][1:k['descriptor'].index(')')]))
                cap = [st.pop() for _ in range(n)][::-1]
                self.c['lambdaAllocations'] += 1
                st.append(Lambda(entry['arguments'][1], cap))
            elif op == 187:
                k = ref(); self.c['alloc' + ('Jdk' if self.cat(k['value']) == 'jdk' else 'Vendor')] += 1
                if self.fail_alloc is not None and self.c['allocVendor'] + self.c['allocJdk'] == self.fail_alloc:
                    raise Thrown('injected-allocation-failure')
                if k['value'].endswith('Exception') or k['value'].endswith('Error'):
                    raise Refusal('model-exception-path:' + k['value'])
                st.append(Obj(k['value']))
            elif op in (188, 189):
                n = st.pop()
                if n < 0: raise Refusal('model-negative-array')
                self.c['alloc' + ('Jdk' if cat == 'jdk' else 'Vendor')] += 1
                self.c['arraySlots'] += n
                fill = 0 if op == 188 else None
                st.append(Arr('prim' if op == 188 else ref()['value'], n, fill))
            elif op == 190: st.append(len(st.pop().v))
            elif op == 191: raise Thrown('athrow')
            elif op == 192:
                k = ref(); v = st[-1]
                if v is not None and isinstance(v, Obj) and not self.subtype(v.cls, k['value']):
                    raise Refusal('model-checkcast:' + v.cls + '->' + k['value'])
            elif op == 193:
                k = ref(); v = st.pop()
                st.append(int(isinstance(v, Obj) and self.subtype(v.cls, k['value'])))
            elif op in (194, 195): raise Refusal('model-monitor')
            elif op in (198, 199):
                v = st.pop()
                if (v is None) == (op == 198): jump = br()
            else:
                raise Refusal('model-opcode:%d' % op)
            pc = jump if jump is not None else nxt


