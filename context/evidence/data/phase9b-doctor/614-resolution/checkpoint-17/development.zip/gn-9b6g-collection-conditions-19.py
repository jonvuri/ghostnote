"""Listener tracking-mode writers and fixed Hgx lambda listener conditions."""
import hashlib, json, time
from pathlib import Path
from grid_symbols.scan import Jar, Refusal, rss_bytes, instructions
from grid_doctor.descriptor_resolution import Code
from grid_doctor.descriptor_builders import lookup
from grid_doctor.listener_removal import removal_contract
from grid_doctor import listener_mode as lm
from grid_doctor import owned_collectors as oc

START = time.perf_counter()
JARS = [('/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar',
         '382c655d0b9e8db6bd433dc6100ef3a4ee23abf6a6615f79c40f0c2645792c93'),
        ('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar',
         '5c2b1895bbb9e7d08d9216de421985bb1f24b2ee62762c9451b4fe847df2469f')]
LISTENER = [('rHF', 'removeListener', '(LNpn;)V'), ('TT', 'removeListener', '(Lfoz;)V')]
HOLDER = [{'class': 'tqm', 'register': 'Wrf', 'blocks': [('dRD', 'neE'), ('dwY', 'nwQ')]},
          {'class': 'Hgx', 'register': 'BAa', 'blocks': [('Scv', 'jFL'), ('jhH', 'hDc')]}]


class Bounded(Jar):
    began = None

    def check(self):
        super().check()
        if time.perf_counter() - self.began > 115:
            raise Refusal('listener-mode-deadline')


def body_strings(cls, method):
    out = []
    for r in instructions(method.code):
        if r[1] in (18, 19):
            v = oc.constant(cls, r[2][0] if r[1] == 18 else r[2][0] * 256 + r[2][1])
            if v.get('tag') == 8:
                out.append([r[0], v['value']])
        elif 182 <= r[1] <= 185:
            out.append([r[0], list(oc.method_ref(cls, r))])
    return out


def run(b):
    path, pin = JARS[b]
    Bounded.began = time.perf_counter()
    jar = Bounded(Path(path))
    code = Code()
    jar.code = lambda name: code.get(jar, name)
    try:
        if jar.sha256 != pin:
            raise Refusal('jar-fingerprint')
        owner, name, desc = LISTENER[b]
        cls, method = lookup(jar, code, owner, name, desc)
        removal = removal_contract(jar, code, cls, method)
        add = lookup(jar, code, owner, 'addListener', desc)
        add_rows = [oc.method_ref(add[0], r) for r in instructions(add[1].code) if r[1] == 184]
        result = {'sha256': jar.sha256, 'removal': removal, 'addStaticCalls': [list(x) for x in add_rows],
                  'agentDebugClasses': sum(1 for n in jar.classes if n.startswith('com/bitwig/flt/app/agent_debug/'))}
        holder = HOLDER[b]
        hcls = code.get(jar, holder['class'])
        reg = [m for m in hcls.methods if m.name == holder['register'] and m.desc == '()V'][0]
        result['lambdas'] = []
        for flag, field in holder['blocks']:
            lam = lm.lambda_listener(jar, hcls, field)
            guard = lm.guarded_registration(hcls, reg, flag, field)
            other = [s for s in oc.field_sites(jar, [[hcls.name, field, lam['field'][2]]])['sites']]
            result['lambdas'].append({'listener': lam, 'registration': guard,
                                      'fieldSites': [[s['class'], *s['method'], s['offset'], s['opcode']] for s in other]})
        # Registration site census for the add slot on the value class chain.
        add_slot = result['lambdas'][0]['registration']['addCall']
        receivers = set()
        current = add_slot[0]
        census = lm.callers(jar, add_slot[0], add_slot[1], add_slot[2], 4096) if False else None
        sites = oc.invocation_sites(jar, add_slot[1], add_slot[2], 20000)
        chain_owner = lookup(jar, code, add_slot[0], add_slot[1], add_slot[2])[0].name
        sub = {chain_owner}
        for n, c in jar.classes.items():
            cur, d = n, 0
            while cur in jar.classes and d < 128:
                if cur == chain_owner:
                    sub.add(n)
                    break
                cur, d = jar.classes[cur].parent, d + 1
        relevant = [(c.name, m.name, m.desc, rows[i][0]) for c, m, rows, i in sites if oc.method_ref(c, rows[i])[0] in sub]
        result['registrationCensus'] = {'addSlot': add_slot, 'declaration': chain_owner,
                                        'sitesOnValueChain': len(relevant), 'allSlotSites': len(sites),
                                        'fixedHolderSites': [list(x) for x in relevant if x[0] == hcls.name],
                                        'sampleOtherSites': [list(x) for x in relevant if x[0] != hcls.name][:12]}
        if removal['mode']:
            field = removal['mode']['requiredFalseField']
            gcls, gm = lookup(jar, code, removal['mode']['getter'][0], *removal['mode']['getter'][1:])
            getter_field, getter = lm.mode_getter(gcls, gm)
            if getter_field != field:
                raise Refusal('mode-field-mismatch')
            writers, reads, scanned = lm.mode_writers(jar, field)
            rows = []
            for w in writers:
                wc = code.get(jar, w['class'])
                wm = [m for m in wc.methods if [m.name, m.desc] == w['method']][0]
                value = lm.constant_store(wc, wm, w['offset'])
                up = lm.callers(jar, w['class'], *w['method'])
                rows.append({'writer': [w['class'], *w['method'], w['offset']], 'stores': value,
                             'monitor': any(r[1] == 194 for r in instructions(wm.code)), 'callers': up})
            result['mode'] = {'field': field, 'getter': getter, 'writers': rows, 'reads': reads, 'scannedClasses': scanned}
            # Upward chain from the only writer caller. Each step is checked by name and body.
            chain = []
            callers = {tuple([c['class'], *c['method']]) for r in rows for c in r['callers']}
            if len(callers) != 1:
                raise Refusal('mode-writer-caller-count')
            command = callers.pop()
            ccls = code.get(jar, command[0])
            cm = [m for m in ccls.methods if (m.name, m.desc) == command[1:]][0]
            chain.append({'method': list(command), 'calls': body_strings(ccls, cm)})
            up = lm.callers(jar, *command)
            lambdas = {tuple([u['class'], *u['method']]) for u in up}
            if len(lambdas) != 1:
                raise Refusal('mode-command-caller-count')
            lam = lambdas.pop()
            lcls = code.get(jar, lam[0])
            lmeth = [m for m in lcls.methods if (m.name, m.desc) == lam[1:]][0]
            handles = lm.lambda_handles(jar, *lam)
            indy = []
            for m in lcls.methods:
                for r in instructions(m.code):
                    if r[1] == 186:
                        k = oc.constant(lcls, r[2][0] * 256 + r[2][1])
                        if k['bootstrapIndex'] in handles:
                            indy.append([m.name, m.desc, r[0], k['name'], k['descriptor']])
            chain.append({'method': list(lam), 'flags': lmeth.flags, 'bootstraps': handles, 'registeredAt': indy})
            dispatch = [m for m in lcls.methods if any(r[1] == 182 and oc.method_ref(lcls, r)[1] == 'asyncExec'
                                                      for r in instructions(m.code))]
            chain.append({'dispatch': [[m.name, m.desc, body_strings(lcls, m)] for m in dispatch]})
            inits = [m for m in lcls.methods if m.name == '<init>']
            construct = [lm.callers(jar, lcls.name, '<init>', m.desc) for m in inits]
            chain.append({'constructedBy': construct})
            result['mode']['chain'] = chain
            # The tail tracking field shares the debug command. Record its writers too.
            tail = [c for c in chain[0]['calls'] if isinstance(c[1], list) and c[1][0] != field[0]
                    and c[1][2] == '()V' and c[1][0] not in ('java/lang/String',)]
            result['mode']['otherCommandCalls'] = tail
        return result
    finally:
        jar.close()


builds = [run(0), run(1)]
report = {'builds': builds, 'elapsedMs': round((time.perf_counter() - START) * 1000, 3), 'peakRssBytes': rss_bytes(),
          'boundedAdmission': False, 'runtimeClassesInitialized': 0,
          'conditions': ['Field and invoke sites are symbolic. Reflection, Unsafe, VarHandle, JNI, and dynamic class loading are not excluded.',
                         'A listed writer path is retained. The scan does not prove it does not run during the doctor sequence.',
                         'The JDK lambda proxy inherits Object.equals and implements only its listed interfaces.',
                         'A registration count is a static site count. It is not a runtime listener count.']}
raw = json.dumps(report, indent=1).encode() + b'\n'
if len(raw) > 8 * 1024 ** 2:
    raise Refusal('report-limit')
with open('/tmp/gn-9b6g-collection-conditions-19.json', 'xb') as out:
    out.write(raw)
for b in builds:
    print(b['sha256'][:8], 'mode', b['removal']['mode'] and b['removal']['mode']['requiredFalseField'], 'agentDebug', b['agentDebugClasses'],
          'addStatic', b['addStaticCalls'])
    for l in b['lambdas']:
        print('  lambda', l['listener']['field'], l['listener']['interfaces'], l['registration']['addCall'], 'fieldSites', l['fieldSites'])
    print('  census', {k: v for k, v in b['registrationCensus'].items() if k != 'sampleOtherSites'})
    if 'mode' in b:
        for w in b['mode']['writers']:
            print('  writer', w['writer'], 'stores', w['stores'], 'monitor', w['monitor'], 'callers', [(c['class'], c['method']) for c in w['callers']])
        print('  reads', len(b['mode']['reads']), 'chain', json.dumps(b['mode']['chain'])[:1500])
print('elapsedMs', report['elapsedMs'], 'rss', report['peakRssBytes'], 'bytes', len(raw))
