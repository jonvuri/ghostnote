"""9b.6g factory-closure trace for the fixed Amplify factory route on 6.1.4.

Reads class bytes as data only. It does not initialize vendor classes or
run vendor code. It writes a branch table with explicit conditions.
"""
import hashlib,json,resource,sys,time,collections,zipfile,struct
from pathlib import Path
from grid_symbols.scan import parse,instructions,Refusal
from grid_doctor.ownership import constant,bootstraps
T0=time.time()
OUT=Path(sys.argv[1]);LOG=Path(sys.argv[2])
if OUT.exists() or LOG.exists():raise Refusal('factory-closure-report-exists')
NEWSHA='5c2b1895bbb9e7d08d9216de421985bb1f24b2ee62762c9451b4fe847df2469f'
LIMITS={'seconds':120,'rss':768*1024**2,'report_bytes':8*1024**2,'trace_methods':512,'edges':16000,'walk_states':4096,'walk_depth':40}
LOGL=[]
def log(*a):
  s=' '.join(str(x) for x in a);LOGL.append(s);print(s)
def check_limits():
  if time.time()-T0>LIMITS['seconds']:raise Refusal('factory-closure-time')
  if resource.getrusage(resource.RUSAGE_SELF).ru_maxrss>LIMITS['rss']:raise Refusal('factory-closure-rss')
# ---- in-memory reverse index and hierarchy (class bytes as data)
class Index:
  def __init__(self,z):
    self.ids={};self.names=[];self.inc=collections.defaultdict(list);self.hier={};self.decl={};self.handles=[];self.work=collections.Counter()
    for e in z.namelist():
      if not e.endswith('.class'):continue
      c=parse(z.read(e),True);self.work['classes']+=1
      self.hier[c.name]=(c.parent,c.interfaces,c.flags);self.decl[c.name]={(m.name,m.desc):m.flags for m in c.methods}
      cp=c.cp
      def ref(i):
        tag,(o,nt)=cp[i];return cp[cp[o][1]][1],cp[cp[nt][1][0]][1],cp[cp[nt][1][1]][1]
      for ent in cp:
        if ent and ent[0]==15:
          try:own,n,d=ref(ent[1][1]);self.handles.append((c.name,own,n,d))
          except Exception:pass
      for m in c.methods:
        if not m.code:continue
        self.work['methods']+=1;me=self.iid(c.name+'#'+m.name+'#'+m.desc)
        for pos,op,a in instructions(m.code):
          self.work['instructions']+=1
          if 178<=op<=185:
            own,n,d=ref(a[0]<<8|a[1]);self.inc[self.iid(own+'#'+n+'#'+d)].append((me,pos,op))
          elif op==187:
            self.inc[self.iid(cp[cp[a[0]<<8|a[1]][1]][1]+'#new#')].append((me,pos,op))
      check_limits()
    self.kids=collections.defaultdict(set)
    for c,(p,ifs,f) in self.hier.items():
      self.kids[p].add(c)
      for i in ifs:self.kids[i].add(c)
  def iid(self,s):
    i=self.ids.get(s)
    if i is None:i=self.ids[s]=len(self.names);self.names.append(s)
    return i
  def sites(self,key):return [(self.names[b],o,p) for b,o,p in self.inc.get(self.ids.get(key,-1),[])]
  def subs(self,c):
    out=set();st=[c]
    while st:
      x=st.pop()
      for k in self.kids.get(x,()):
        if k not in out:out.add(k);st.append(k)
    return out
  def sups(self,c):
    out=[];st=[c];seen=set()
    while st:
      x=st.pop()
      if x in seen or x not in self.hier:continue
      seen.add(x);out.append(x);p,ifs,f=self.hier[x];st.append(p);st.extend(ifs)
    return out
  def incoming(self,owner,name,desc):
    """Closed-world incoming invocation sites, including supertype and subtype owners."""
    res=[]
    for ow in sorted({owner}|self.subs(owner)|set(self.sups(owner))):
      for s in self.sites(f'{ow}#{name}#{desc}'):
        if s[2] in(182,183,184,185):res.append((ow,)+s)
    return res
  def dispatch_targets(self,owner,name,desc):
    H=self.hier;out=set()
    for c in self.subs(owner)|{owner}:
      if c not in H or H[c][2]&0x0600:continue
      x=c;found=None
      while x in H:
        fl=self.decl.get(x,{}).get((name,desc))
        if fl is not None:found=(x,fl);break
        x=H[x][0]
      out.add(found[0] if found and not found[1]&0x400 else ('default-or-missing',c))
    return out
# ---- receiver-aware bounded walker
class Jar:
  def __init__(s,p):s.z=zipfile.ZipFile(p);s.c={}
  def has(s,n):
    try:s.z.getinfo(n+'.class');return True
    except KeyError:return False
  def code(s,n):
    if n not in s.c:s.c[n]=parse(s.z.read(n+'.class'),True)
    return s.c[n]
def split(desc):
  i=1;out=[]
  while desc[i]!=')':
    j=i
    while desc[j]=='[':j+=1
    if desc[j]=='L':j=desc.index(';',j)
    out.append(desc[i:j+1]);i=j+1
  return out,desc[i+1:]
W=lambda t:t in('J','D')
def chain(jar,c):
  out=[]
  while c and not c.startswith('java/') and jar.has(c):
    out.append(c);c=jar.code(c).parent
  return out
def resolve(jar,owner,name,desc,special=False):
  """Resolve along the superclass chain; then interfaces for defaults."""
  for c in chain(jar,owner):
    for m in jar.code(c).methods:
      if m.name==name and m.desc==desc:return c,m
  # default methods
  seen=set();st=list(jar.code(owner).interfaces) if jar.has(owner) else []
  for c in chain(jar,owner):st+=list(jar.code(c).interfaces)
  hits=[]
  while st:
    i=st.pop()
    if i in seen or not jar.has(i):continue
    seen.add(i);ci=jar.code(i)
    for m in ci.methods:
      if m.name==name and m.desc==desc and not m.flags&0x400:hits.append((i,m))
    st+=list(ci.interfaces)
  if len(hits)==1:return hits[0]
  return None,None
_AF={}
LAZY=True
def assertion_flag(jar,owner,name):
  k=(owner,name)
  if k in _AF:return _AF[k]
  r=False
  if jar.has(owner):
    c=jar.code(owner);f=[x for x in c.fields if x.name==name and x.desc=='Z']
    if f and f[0].flags&0x1018==0x1018:
      cl=[m for m in c.methods if m.name=='<clinit>']
      if cl:
        ins=instructions(cl[0].code)
        for i,(p,op,a) in enumerate(ins[:12]):
          if op==182:
            cc=constant(c,a[0]<<8|a[1])
            if cc['name']=='desiredAssertionStatus':
              # expect: ifne ->X iconst_1 goto iconst_0 putstatic flag
              for (p2,op2,a2) in ins[i+1:i+6]:
                if op2==179:
                  c2=constant(c,a2[0]<<8|a2[1]);r=(c2['owner']==owner and c2['name']==name);break
          if r:break
  _AF[k]=r;return r
LOADS={21:'I',22:'J',23:'F',24:'D',25:'A'}
def analyze(jar,cname,m,this_type,arg_types=None,limit=4096):
  """Abstract interpretation tracking receiver identities. Values are tuples (kind,detail)."""
  cls=jar.code(cname);ins=instructions(m.code);idx={p:i for i,(p,_,_) in enumerate(ins)}
  args,_=split(m.desc);loc={};k=0
  if not m.flags&8:loc[0]=('this',this_type);k=1
  for i,a in enumerate(args):
    loc[k]=('param',(i,(arg_types or {}).get(i,a)));k+=2 if W(a) else 1
  sites=[];states={0:([],loc)};work=[0];seen=0;handlers=[(h[0],h[1],h[2]) for h in m.handlers] if m.handlers else []
  for h in (m.handlers or []):
    states.setdefault(h[2],([('exc',None)],{}));work.append(h[2])
  visited=set()
  while work:
    p=work.pop()
    key=(p,repr(states[p]))
    if key in visited:continue
    visited.add(key);seen+=1
    if seen>limit:raise Refusal('walk-state-limit')
    st,lc=states[p];st=list(st);lc=dict(lc)
    i=idx[p];pos,op,a=ins[i];nxt=[ins[i+1][0]] if i+1<len(ins) else []
    U=('?',None)
    def pop(n=1):
      r=[]
      for _ in range(n):r.append(st.pop() if st else U)
      return r
    if op in(0,):pass
    elif op==1:st.append(('null',None))
    elif 2<=op<=8 or op in(16,17):st.append(('int',a))
    elif op in(9,10,14,15):st.append(('wide',None))
    elif op in(11,12,13):st.append(U)
    elif op in(18,19):
      c=constant(cls,a[0] if op==18 else a[0]<<8|a[1]);st.append(('const',c.get('value')))
    elif op==20:st.append(('wide',None))
    elif op in(21,23):st.append(U)
    elif op in(22,24):st.append(('wide',None))
    elif op==25:st.append(lc.get(a[0],U))
    elif 26<=op<=45:
      t=(op-26)//4;n=(op-26)%4
      st.append(('wide',None) if t in(1,3) else (lc.get(n,U) if t==4 else U))
    elif 46<=op<=53:pop(2);st.append(('wide',None) if op in(47,49) else U)
    elif op in(54,56):pop();lc[a[0]]=U
    elif op in(55,57):pop();lc[a[0]]=('wide',None)
    elif op==58:lc[a[0]]=pop()[0]
    elif 59<=op<=78:
      t=(op-59)//4;n=(op-59)%4;v=pop()[0];lc[n]=v
    elif 79<=op<=86:pop(3)
    elif op==87:pop()
    elif op==88:
      v=pop()[0]
      if v[0]!='wide':pop()
    elif op==89:v=st[-1] if st else U;st.append(v)
    elif op==90:v=pop()[0];w=pop()[0];st+= [v,w,v]
    elif op==91:
      v=pop()[0];w=pop()[0]
      if w[0]=='wide':st+=[v,w,v]
      else:x=pop()[0];st+=[v,x,w,v]
    elif op==92:
      v=st[-1] if st else U
      if v[0]=='wide':st.append(v)
      else:w=st[-2];st+=[w,v]
    elif op in(93,94):
      v=pop()[0]
      if v[0]=='wide':
        w=pop()[0]
        if op==94 and w[0]!='wide':x=pop()[0];st+=[v,x,w,v]
        else:st+=[v,w,v]
      else:
        w=pop()[0];x=pop()[0]
        if op==94 and x[0]!='wide':y=pop()[0];st+=[w,v,y,x,w,v]
        else:st+=[w,v,x,w,v]
    elif op==95:v=pop()[0];w=pop()[0];st+=[v,w]
    elif 96<=op<=115:pop(2);st.append(('wide',None) if (op-96)%4 in(1,3) else U)
    elif 116<=op<=119:pop();st.append(('wide',None) if (op-116)%4 in(1,3) else U)
    elif 120<=op<=125:pop(2);st.append(('wide',None) if op in(121,123,125) else U)
    elif 126<=op<=131:pop(2);st.append(('wide',None) if op in(127,129,131) else U)
    elif op==132:lc[a[0]]=U
    elif 133<=op<=147:pop();st.append(('wide',None) if op in(133,135,138,140,141,143) else U)
    elif 148<=op<=152:pop(2);st.append(U)
    elif 153<=op<=158 or op in(198,199):
      v=pop()[0];d=struct.unpack('>h',bytes(a))[0]
      af=v[0]=='static' and assertion_flag(jar,v[1][0],v[1][1]) and op in(153,154)
      lz=v[0]=='static' and op==199 and LAZY and v[1][2].startswith('L')
      if lz:
        nxt=[pos+d];sites.append({'offset':pos,'kind':'lazy-pruned','opcode':op,'value':v})
      elif af:
        nxt=[pos+d] if op==154 else nxt
        sites.append({'offset':pos,'kind':'assert-pruned','opcode':op,'value':v})
      else:
        nxt=nxt+[pos+d]
        sites.append({'offset':pos,'kind':'branch','opcode':op,'value':v})
    elif 159<=op<=166:pop(2);d=struct.unpack('>h',bytes(a))[0];nxt=nxt+[pos+d]
    elif op==167:d=struct.unpack('>h',bytes(a))[0];nxt=[pos+d]
    elif op in(170,171):
      pop();
      if op==170:nxt=[pos+a[0]]+[pos+x for x in a[3:]]
      else:nxt=[pos+a[0]]+[pos+a[1+2*j+1] for j in range(len(a[1:])//2)]
    elif 172<=op<=177:
      if op!=177:pop()
      nxt=[]
    elif op in(178,179,180,181):
      c=constant(cls,a[0]<<8|a[1]);t=c['descriptor']
      if op==178:st.append(('static',(c['owner'],c['name'],t)) if not W(t) else ('wide',None))
      elif op==179:pop()
      elif op==180:r=pop()[0];st.append(('field',(r,c['owner'],c['name'],t)) if not W(t) else ('wide',None))
      else:v=pop()[0];r=pop()[0]
      sites.append({'offset':pos,'kind':'field','opcode':op,'ref':c,'receiver':None if op in(178,179) else (r if op==180 else r),'value':v if op in(179,181) else None})
    elif 182<=op<=185:
      c=constant(cls,a[0]<<8|a[1]);ar,ret=split(c['descriptor']);vals=pop(len(ar))[::-1]
      r=pop()[0] if op!=184 else None
      sites.append({'offset':pos,'kind':'call','opcode':op,'ref':c,'receiver':r,'args':vals})
      if r and r[0]=='new' and c['name']=='<init>':
        # mark initialized
        st=[('newi',r[1]) if x==r else x for x in st];lc={kk:(('newi',r[1]) if vv==r else vv) for kk,vv in lc.items()}
      if ret!='V':st.append(('wide',None) if W(ret) else ('ret',(c['owner'],c['name'],c['descriptor'],pos)))
    elif op==186:
      c=constant(cls,a[0]<<8|a[1]);ar,ret=split(c['descriptor']);vals=pop(len(ar))[::-1]
      sites.append({'offset':pos,'kind':'indy','opcode':op,'ref':c,'args':vals})
      st.append(('indy',(c['name'],c['descriptor'],pos)))
    elif op==187:
      c=constant(cls,a[0]<<8|a[1]);st.append(('new',(c['value'],pos)))
      sites.append({'offset':pos,'kind':'new','opcode':op,'class':c['value']})
    elif op==188:pop();st.append(('array',None));sites.append({'offset':pos,'kind':'newarray','opcode':op})
    elif op==189:pop();st.append(('array',None));sites.append({'offset':pos,'kind':'newarray','opcode':op})
    elif op==190:pop();st.append(U)
    elif op==191:pop();nxt=[]
    elif op==192:v=pop()[0];st.append(v)
    elif op==193:pop();st.append(U)
    elif op in(194,195):v=pop()[0];sites.append({'offset':pos,'kind':'monitor','opcode':op,'value':v})
    elif op==197:pop(a[2]);st.append(('array',None))
    else:raise Refusal(f'walk-op:{op}')
    for q in nxt:
      if q not in states:states[q]=(st,lc);work.append(q)
      else:
        ost,olc=states[q]
        if len(ost)!=len(st):raise Refusal('walk-stack-merge')
        mst=[x if x==y else U for x,y in zip(ost,st)];mlc={kk:vv for kk,vv in olc.items() if lc.get(kk)==vv}
        if (mst,mlc)!=(ost,olc):states[q]=(mst,mlc);work.append(q)
        else:work.append(q) if False else None
  # deduplicate sites by offset keeping the last-merged view
  out={}
  for s in sites:out[(s['offset'],s['kind'])]=s
  return [out[k] for k in sorted(out)],handlers

def closure(jar,roots,max_methods=512,max_depth=24,exact_params=None,stop=lambda o,n,d:False,overrides=None):
  """roots: list of (owner,name,desc,this_type). Returns nodes and leaves."""
  nodes={};leaves=[];order=[]
  stack=[(o,n,d,t,0,None,None) for o,n,d,t in roots]
  while stack:
    o,n,d,t,depth,parent,ptypes=stack.pop(0)
    decl,m=resolve(jar,o,n,d) if jar.has(o) else (None,None)
    key=(decl,n,d,t,repr(ptypes))
    if decl is None:
      leaves.append({'kind':'unresolved','target':(o,n,d),'from':parent});continue
    if key in nodes:continue
    if len(nodes)>=max_methods:raise Refusal('closure-method-limit')
    if not m.code:
      leaves.append({'kind':'abstract-or-native','target':(decl,n,d),'flags':m.flags,'from':parent});nodes[key]=None;continue
    sites,h=analyze(jar,decl,m,t,ptypes)
    rec={'method':(decl,n,d),'this':t,'depth':depth,'from':parent,'handlers':[list(x) for x in (m.handlers or [])],'instructions':len(instructions(m.code)),'calls':[],'news':[],'monitors':[],'indy':[],'statics':[],'branches':[s for s in sites if s['kind']=='branch' and s['value'][0] in ('static','field','ret')]}
    nodes[key]=rec;order.append(key)
    for s in sites:
      if s['kind']=='new':rec['news'].append(s['class'])
      elif s['kind']=='monitor' and s['opcode']==194:rec['monitors'].append(s['value'])
      elif s['kind']=='indy':rec['indy'].append(s['ref'])
      elif s['kind']=='field' and s['opcode'] in(178,179):rec['statics'].append((s['opcode'],s['ref']['owner'],s['ref']['name']))
      elif s['kind']=='call':
        c=s['ref'];r=s['receiver'];op=s['opcode'];co,cn,cd=c['owner'],c['name'],c['descriptor']
        row={'offset':s['offset'],'opcode':op,'target':(co,cn,cd),'receiver':r[0] if r else None}
        rec['calls'].append(row)
        if co.startswith('java/') or co.startswith('javax/') or co.startswith('jdk/') or co.startswith('sun/') or not jar.has(co):
          row['class']='external';continue
        if stop(co,cn,cd):row['class']='stopped';continue
        nt=None
        if op==184:nt=None;row['class']='static'
        elif op==183:
          if cn=='<init>' and r and r[0]=='new':nt=r[1][0];row['class']='constructor';row['newClass']=nt
          elif r and r[0]=='this':nt=t;row['class']='special-this'
          else:nt=co;row['class']='special'
        else:
          if r and r[0]=='this' and t:nt=t;row['class']='virtual-this'
          elif r and r[0] in('new','newi'):nt=r[1][0];row['class']='virtual-new'
          elif r and r[0]=='param' and exact_params and (decl,n,d,r[1][0]) in exact_params:
            nt=exact_params[(decl,n,d,r[1][0])];row['class']='virtual-param-witness';row['witness']=nt
          elif overrides and (co,cn,cd) in overrides:
            nt=overrides[(co,cn,cd)];row['class']='virtual-supplied-witness';row['witness']=nt
          else:
            _h=HIER
            tg=_h.dispatch_targets(co,cn,cd)
            if tg is not None and len(tg)==1 and isinstance(next(iter(tg)),str):
              only=next(iter(tg));row['class']='monomorphic';row['witness']=only;nt=None
              if depth+1<=max_depth:stack.append((only,cn,cd,None,depth+1,(decl,n,d,s['offset']),None))
              continue
            row['class']='open-dispatch';row['targets']=len(tg) if tg is not None else None;row['receiverValue']=repr(r)[:160];leaves.append({'kind':'open-dispatch','targets':row['targets'],'target':(co,cn,cd),'receiver':repr(r)[:160],'from':(decl,n,d),'offset':s['offset']});continue
        tgt_owner=nt if (op in(182,185) and nt) else co
        if op==183 and row['class']=='constructor':tgt_owner=co
        if depth+1>max_depth:leaves.append({'kind':'depth','target':(co,cn,cd),'from':(decl,n,d)});continue
        stack.append((tgt_owner,cn,cd,nt if op!=184 else None,depth+1,(decl,n,d,s['offset']),None))
  return [nodes[k] for k in order if nodes[k]],leaves
# ---- facts and branch table
P='com/bitwig/flt/document/core/master/device/'
NEWJ='/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'
h=hashlib.sha256(Path(NEWJ).read_bytes()).hexdigest()
if h!=NEWSHA:raise Refusal('factory-closure-jar-hash')
jar=Jar(NEWJ);IDX=Index(jar.z);HIER=IDX
log('index',dict(IDX.work),'rss',resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
def body(owner,name,desc):
  d,m=resolve(jar,owner,name,desc)
  if m is None or not m.code:raise Refusal('missing:'+owner+'.'+name+desc)
  c=jar.code(d);ins=instructions(m.code)
  rows=[]
  for pos,op,a in ins:
    r={'offset':pos,'op':op}
    if op in(178,179,180,181,182,183,184,185,186,187,192,193,189):r['c']=constant(c,a[0]<<8|a[1])
    elif op in(18,):r['c']=constant(c,a[0])
    elif op in(16,):r['v']=a[0]
    elif op==17:r['v']=struct.unpack('>h',bytes(a))[0]
    elif 153<=op<=168 or op in(198,199):r['t']=pos+struct.unpack('>h',bytes(a))[0]
    elif op in(170,171):r['a']=a
    rows.append(r)
  return d,m,rows
def calls(rows,name=None,owner=None):
  return [r for r in rows if r['op'] in(182,183,184,185) and (name is None or r['c']['name']==name) and (owner is None or r['c']['owner']==owner)]
def need(cond,msg):
  if not cond:raise Refusal('factory-closure-contract:'+msg)
def short(k):return k.replace(P,'device/')
NODES=[]
def node(nid,path,classification,conditions,witness=None,bound=None,reason=None,evidence=None):
  assert classification in('excluded','bounded','open')
  n={'id':nid,'path':path,'classification':classification,'conditions':conditions}
  if witness is not None:n['witness']=witness
  if bound is not None:n['bound']=bound
  if reason is not None:n['reason']=reason
  if evidence is not None:n['evidence']=evidence
  NODES.append(n)
ASSERT='Assertion-disabled flags are initialized true; assertion branches are excluded only under that condition.'
# ---------------- 1. warm route and UUID cache
_,_,vinit=body('vDL','<init>','(LHpk;I)V')
need([r['op'] for r in vinit[:5]]==[42,43,4,28,183] and vinit[4]['c']['descriptor']=='(LHpk;ZI)V','vDL-init-clone-flag')
_,_,ginit3=body('GDf','<init>','(LHpk;ZI)V')
need([r['op'] for r in ginit3[:6]]==[42,43,28,29,9,183],'GDf-init-ttl-zero')
_,_,tl=body('com/bitwig/flt/app/TL','<init>','([Ljava/lang/String;[Ljava/lang/String;)V')
cap=[tl[i-1].get('v') for i,r in enumerate(tl) if r['op']==183 and r['c']['owner']=='vDL']
_,_,qf=body('qf','<init>','(Ljava/io/File;I[Ljava/lang/String;)V')
capq=[qf[i-1].get('v') for i,r in enumerate(qf) if r['op']==183 and r['c']['owner']=='vDL']
need(cap==[200] and capq==[20],'vDL-capacities')
vnew=IDX.sites('vDL#new#');need(sorted(x[0].split('#')[0] for x in vnew)==['com/bitwig/flt/app/TL','qf'],'vDL-allocations')
quy=IDX.dispatch_targets('Xa','QuY','()LvDL;')
need(quy=={'com/bitwig/flt/app/TL','qf'},'Xa-QuY-targets')
_,_,tq=body('com/bitwig/flt/app/TL','QuY','()LvDL;');_,_,qq=body('qf','QuY','()LvDL;')
need(tq[1]['c']['name']=='kIh' and qq[1]['c']['name']=='tp2','QuY-getters')
_,_,lyc=body(P+'rSf','lYc','(Ljava/util/UUID;)L'+P+'rSf;')
need([r['c']['name'] for r in calls(lyc)]==['fJR','cfM','cfM'],'lYc-shape')
_,_,fjr=body('iJW','fJR','()LvDL;');need(fjr[0]['c']['name']=='MRY' and fjr[1]['c']['name']=='QuY','iJW-fJR')
iJWw=[x for x in IDX.sites('iJW#MRY#LXa;') if x[2]==179];need(len(iJWw)==1,'iJW-single-writer')
node('W1','rSf.lYc(UUID) -> iJW.fJR() -> Xa.QuY()','bounded',
  ['iJW.MRY is non-null; its single writer is '+iJWw[0][0]+'@'+str(iJWw[0][1])+'.','Closed-world dispatch: no generated Xa implementation.'],
  witness={'dispatchTargets':sorted(quy),'inheritors':'MVg, app/RKg, gJi and testing/CuM inherit TL.QuY','getters':{'TL.QuY':'getfield TL.kIh','qf.QuY':'getfield qf.tp2'}},
  bound={'instructions':'3 (fJR) + 2 (QuY getter)','vendorCalls':2})
node('W2','vDL construction','bounded',['TL.kIh and qf.tp2 are each assigned once in their constructors.'],
  witness={'vDL.<init>':'GDf.<init>(Hpk, true, capacity)','GDf.<init>(Hpk,Z,I)':'passes lconst_0 TTL','capacity':{'TL':cap[0],'qf':capq[0]},'allocations':[short(x[0])+'@'+str(x[1]) for x in vnew]},
  bound={'cloneFlag':True,'ttlMillis':0,'capacityC':'200 for TL family, 20 for qf'})
_,mvc,vcu=body('vDL','cfM','(Ljava/util/UUID;)L'+P+'hpW;')
ops=[(r['offset'],r['op'],r.get('c',{}).get('name')) for r in vcu]
need(any(o==35 and op==194 for o,op,_ in ops) and any(o==41 and n=='get' for o,_,n in ops) and any(o==63 and op==198 for o,op,_ in ops),'vDL-cfM-UUID-shape')
need([list(x) for x in mvc.handlers]==[[36,52,55,0],[55,59,55,0]],'vDL-cfM-UUID-handlers')
hntw=IDX.sites('vDL#Hnt#Ljava/util/Map;')
writers=sorted({short(x[0]) for x in hntw if x[0].split('#')[1] not in('<init>',)})
node('W3','vDL.cfM(UUID): synchronized(vDL.Hnt) { Hnt.get(uuid) }','open',
  ['The UUID map is a HashMap from vDL.<init>.', 'Map users: '+', '.join(writers)],
  reason='monitor: existing vendor monitor vDL.Hnt; contention from the add callback vDL.cfM(z2y,hpW) (nested inside the GDf.FzB monitor) and the remove callback vDL.MRY(z2y,hpW). JDK HashMap.get and UUID.hashCode/equals bodies are not modeled.',
  bound={'mapSize':'|vDL.Hnt| <= |GDf.FzB| <= C before each insertion completes (put only in the add callback after the capacity loop)'})
_,_,gmo=body('GDf','MRY','(Ljava/lang/Object;)Ljava/lang/Object;')
need([r['c']['name'] for r in calls(gmo)]==['cfM','cfM','cfM'] and gmo[1]['c']['name']=='Hnt','GDf-MRY-shape')
_,_,gco=body('vDL','cfM','(Ljava/lang/Object;)Z');need([r['op'] for r in gco]==[4,172],'GDf-cfM-Object-true')
# removal callback callers
rem_cb=IDX.incoming('GDf','cfM','(Lcom/bitwig/base/io/z2y;Ljava/lang/Object;)V')
clear=IDX.incoming('GDf','cfM','()V')
fjj=IDX.sites('FJj#new#');unj=IDX.incoming('GDf','UNj','(Lcom/bitwig/base/io/z2y;)V');evict=IDX.incoming('GDf','IwV','()V')
_,mgi,giw=body('GDf','IwV','(Lcom/bitwig/base/io/z2y;)Ljava/lang/Object;')
need(any(r['offset']==378 and r['c']['name']=='TMF' for r in giw if 'c' in r) and any(r['offset']==383 and r['op']==158 for r in giw),'GDf-ttl-gate')
need(any(r['offset']==130 and r.get('c',{}).get('name')=='cfM' for r in giw),'GDf-stale-callback')
node('W4','UUID cache hit condition','open',
  ['Key: java.util.UUID a6cd650b-c4de-46c6-8741-c07a0a9bfec2 (UUID.equals by value).',
   'A hit returns the cached template object stored by the add callback vDL.cfM(z2y,hpW): key = template.iYN.MRY (bundled root property device_UUID 6369 = a6cd650bc4de46c68741c07a0a9bfec2 in both bundled files).',
   'Hit iff an earlier load in this process completed GDf.IwV(z2y) insertion (capacity C > 0) and no later remove callback ran for that template.',
   'TTL zero can still hit: TTL only gates the FJj timer at GDf.IwV@377-406; FJj is allocated only there.',
   'The hit path reads no file, makes no lastModified/length check, and does not update eKv.IwV access time; LRU age is the load time.'],
  reason='runtime state: the first factory call in a fresh process misses. No existing fixed-doctor read observes vDL.Hnt or GDf.FzB.',
  evidence={'removeCallbackCallers':[short(x[1])+'@'+str(x[2]) for x in rem_cb],'clearCallers':[(x[0],short(x[1])) for x in clear],
    'FJjAllocations':[short(x[0])+'@'+str(x[1]) for x in fjj],'GDf.UNj(z2y)callers':[short(x[1])+'@'+str(x[2]) for x in unj],'GDf.IwV()callers':[short(x[1])+'@'+str(x[2]) for x in evict]})
node('W5','UUID-entry removal routes for vDL','bounded',
  ['vDL TTL = 0 (W2).','GDf.cfM() clear is invoked only by dij.cfM (a different GDf subclass); TL.KAS/pvS clear other caches, not vDL.','No reflection or method-handle call of GDf.cfM()/UNj.'],
  witness={'excluded':['FJj timer route GDf.UNj(z2y) (TTL 0)','GDf.cfM() clear (no vDL receiver site)'],
           'retained':['capacity eviction GDf.IwV() when a new file insertion finds |FzB| >= C (disposes the LRU template through AOm.ix_)','stale replacement in GDf.IwV(z2y) for the same z2y key (only on a miss path)']},
  bound={'entryLifetime':'until C further distinct template files are loaded through GDf.IwV(z2y) after it in LRU order, or the process ends'})
node('W6','GDf.MRY(Object): clone decision','bounded',['GDf.Hnt is final and true for both vDL instances (W2).','vDL inherits GDf.cfM(Object)=iconst_1 ireturn.'],
  witness={'path':'checkcast oDc; oDc.cfM(RKg.FzB) -> bbQ.cfM().cfM(obj, policy); zjj.cfM(clone); return clone','appliesTo':'both hit and miss results'},
  bound={'ownInstructions':len(gmo)})
node('W7','Template stability during clone','open',['No monitor is held while the template is cloned (W3 releases vDL.Hnt before GDf.MRY).'],
  reason='concurrency: another thread can evict and dispose (AOm.ix_) or recompile the shared template during the clone. Requires single-thread use of TL.kIh or a proof that no other loader runs.')
# cold miss
_,mvz,vz=body('vDL','cfM','(Lcom/bitwig/base/io/z2y;)L'+P+'hpW;')
node('W8','Cold miss: iJW.cfM(UUID) -> Xa.MRY(UUID) file; new z2y; GDf.Hnt(z2y) -> GDf.IwV(z2y)','open',
  ['Taken whenever W4 misses, including the first call in a process.'],
  reason='file access (File.lastModified, File.length, Uev.UNj().cfM(File) read and deserialize), external interface dispatch Xa.MRY(UUID), monitors GDf.FzB and the per-key lock from GDf.IwV.computeIfAbsent (indy Function), deserialization der.cfM(Jkg,rsB) and unconditional compile BgP.cfM(rsB)->cfM(false,false,true), capacity eviction that disposes another template, and the nested add callback.',
  evidence={'GDf.IwV(z2y)handlers':[list(x) for x in mgi.handlers],'vDL.cfM(z2y)handlers':[list(x) for x in mvz.handlers],
    'failure':'a load exception is wrapped in sQv; the per-key lock object stays in GDf.IwV (the remove at 409-431 is skipped); no cache entry is added'})
# ---------------- 2. clone and compile skip
_,_,bl=body('BgP','bl_','()V');_,_,pg=body('BgP','Pgx','()V')
def interp(rows,env,ret_on=('cfM','(ZZZ)V')):
  """Evaluate the guard structure of bl_/Pgx for one boolean assignment."""
  by={r['offset']:i for i,r in enumerate(rows)};i=0;st=[];events=[];steps=0
  while True:
    steps+=1
    if steps>500:raise Refusal('interp-steps')
    r=rows[i];op=r['op'];c=r.get('c',{})
    nxt=i+1
    if op==42:st.append('this')
    elif op==178:st.append(('static',c['name']))
    elif op==180:
      st.pop();st.append(('f',c['name']))
    elif op in(182,):
      n=c['name'];ar=c['descriptor']
      if n in('Guv','wYK'):st.pop();st.append(('cnt',n))
      elif n=='BBT':st.pop();st.append(0)
      elif n=='cfM' and ar=='(ZZZ)V':st=st[:-4];events.append('compile');env=dict(env,ERO=env['EROafter'])
      elif n in('Bpn','iW2'):events.append('ports:'+n);return events
      elif n=='d_':st=st[:-2]
      elif n=='hUR':st=st[:-2];st.append(('hash',))
      else:raise Refusal('interp-call:'+n)
    elif op==96:a=st.pop();b=st.pop();st.append(('sum',))
    elif op in(3,4):st.append(op-3)
    elif op==18:st.append(('const',))
    elif op==87:st.pop()
    elif op==89:st.append(st[-1])
    elif op==54 or op==60:env=dict(env,local=st.pop())
    elif op==27:st.append(env['local'])
    elif op==181:
      v=st.pop();st.pop();events.append('put:'+c['name'])
    elif op in(153,154,157,158,198,199):
      v=st.pop()
      if v==('static','MRY'):tk=(op==154)  # assertion flag true
      else:
        if v==('sum',):val=env['S']
        elif isinstance(v,tuple) and v[0]=='f':val={'IwV':env['I'],'hUR':env['H'],'FzB':env['F'],'dEI':env['D'],'UNj':env['U'],'ERO':env['ERO']}[v[1]]
        elif isinstance(v,int):val=bool(v)
        else:val=bool(v)
        tk={153:not val,154:val,157:val,158:not val,198:not val,199:val}[op]
      if tk:nxt=by[r['t']]
    elif op==167:nxt=by[r['t']]
    elif op==177:return events
    elif op==181:pass
    else:raise Refusal('interp-op:'+str(op))
    i=nxt
import itertools
table=[];
for S,I,H,F,D,U,EA in itertools.product([False,True],repeat=7):
  env={'S':S,'I':I,'H':H,'F':F,'D':D,'U':U,'ERO':False,'EROafter':EA}
  eb=interp(bl,env);ep=interp(pg,env)
  table.append(((S,I,H,F,D,U,EA),eb,ep))
def f_bl(S,I,H,F,D,U,EA):
  comp=(not S) and (I or (H and F));ports=S or (comp and EA)
  return comp,ports
def f_pg(S,I,H,F,D,U,EA):return (not D) and (not S) and (H or I)
for (a,eb,ep) in table:
  comp,ports=f_bl(*a)
  need(('compile' in eb)==comp and (any(e.startswith('ports') for e in eb))==ports,'bl-formula')
  need(('compile' in ep)==f_pg(*a),'Pgx-formula')
  need(('put:dEI' in ep)==(not a[4]),'Pgx-dEI')
_,_,qz=body('QZn','cfM','(LBgP;ILjava/util/List;)V')
sw=[r for r in qz if r['op']==171][0];keys=dict(zip(sw['a'][1::2],[sw['offset']+x for x in sw['a'][2::2]]))
put=[r for r in qz if r['op']==181];fmap={k:[p['c']['name'] for p in put if p['offset']>=t][0] for k,t in keys.items()}
need(fmap=={9972:'iHb',15756:'nVd',15757:'ucQ'},'QZn-list-setter')
flags={}
for g in ('Ucl','MIO'):
  _,_,rr=body('QZn',g,'()LdeT;')
  ids=[r.get('v') for r in rr if r['op']==17]
  flags[g]=ids
need(flags['Ucl'][:2]==[15756,264] and flags['MIO'][:2]==[15757,264],'nitro-list-flags')
_,_,hb=body('deZ','hbP','()Z');need(hb[1]['c']['name']=='FzB' and hb[2].get('v')==8 and hb[3]['op']==126,'deZ-hbP-bit8')
_,_,pol=body('com/bitwig/ramona/core/RKg','cfM','(LdeZ;Lcom/bitwig/ramona/core/oDc;)Z');need(pol[1]['c']['name']=='hbP','policy-relationship')
_,_,pol2=body('com/bitwig/ramona/core/RKg','cfM','(Lcom/bitwig/ramona/core/bnq;Lcom/bitwig/ramona/core/OLR;)Z');need([r['op'] for r in pol2]==[4,172],'policy-children')
_,_,bpi=body('BgP','<init>','()V');need(any(r['op']==181 and r['c']['name']=='dEI' for r in bpi) and not any(r['op']==181 and r['c']['name']=='ERO' for r in bpi),'BgP-init')
ero=[(short(x[0]),x[1]) for x in IDX.sites('BgP#ERO#Lcom/bitwig/nitro/ESe;') if x[2]==181]
lw={f:[(short(x[1]),x[2]) for x in IDX.incoming('Mdi',n,'()V')] for f,n in (('jG','jG'),('wZs','wZs'))}
node('C1','Nitro list copy in the clone','bounded',
  ['RKg.FzB policy: relationship copied iff deZ.hbP() = (deZ.FzB & 8) != 0; list children always cloned (RKg.cfM(bnq,OLR) = true).','Descriptor flags are those traced in relationship-flags-1 (field deZ.FzB on 6.1.4).'],
  witness={'QZn.cfM(BgP,I,List)':{str(k):'BgP.'+v for k,v in fmap.items()},'flags':{'nitro_inputs 15756':264,'nitro_outputs 15757':264,'generated ports 228/229':385},
           'bit8':{'264':bool(264&8),'385':bool(385&8)}},
  bound={'copiedListSize':'|clone.nVd| = |template.nVd|, |clone.ucQ| = |template.ucQ| when the template lists are stable during the clone','Amplify':'3 inputs (thru, in, stereoize) + 1 output (out) in both bundled files'})
node('C2','BgP clone callbacks: bbQ.Hnt -> clone.b_(orig) -> BgP.b_ -> Mdi/K2G.b_ -> woZ -> BgP.bl_, then BgP.Pgx','bounded',
  [ASSERT,'Fresh clone: BgP.<init> sets dEI=false and does not write ERO (null). ERO writers: '+', '.join(f'{a}@{b}' for a,b in ero)+'.','BBT() is iconst_0.'],
  witness={'S':'Guv()+wYK() > 0 where Guv=|nVd| (null=0) and wYK=|ucQ|','bl_':'compile <=> !S && (IwV!=null || (hUR && FzB!=null)); ports <=> S || (compile && ERO!=null afterwards)',
           'Pgx':'compile <=> !dEI && !S && (hUR || IwV!=null); dEI := true when entered with dEI false','checkedAssignments':len(table)},
  bound={'nonemptyPath':'no compile in bl_ or Pgx; |nVd| input ports and |ucQ| output ports built through BgP.cfM(gez)/MRY(gez); FCo/ZDH constructors 51/57 vendor instructions and 7 vendor calls each (port-constructors-1)'})
node('C3','Decidability and witness of the compile skip','open',
  ['The skip needs only S > 0 on the copied lists.','The fixed doctor reads 15756/15757 (bound in all-properties-3: QZn.Ucl/QZn.MIO) only on the returned clone, after the callbacks ran.',
   'Template list writers: Mdi.jG@BgP.cfM(FDA..)@313 and Mdi.wZs@368 (compile completion clears and refills), QZn list/insert setters.'],
  reason='state not observed before the call: the cached template is not read by the fixed doctor; a post-call S>0 read is a post hoc witness, not a guard. Template lists can be cleared by an in-flight compile completion from the cold load unless compile completion and clone are serialized on one thread.',
  evidence={'listClearCallers':lw})
_,_,zj=body('com/bitwig/ramona/core/zjj','cfM','(Lcom/bitwig/ramona/core/oDc;)V')
node('C4','zjj.cfM(clone)','open',['Creates one zp3 visitor and calls zjj.cfM(oDc,null,Irb).'],reason='unknown interface dispatch: Irb.visit/Irb.cfM (22 implementations), oDc.ng_ (2818 targets) over the clone tree; traversal size depends on the runtime clone tree.')
# ---------------- 4. bbQ failure behavior
B='com/bitwig/ramona/core/bbQ';O='com/bitwig/ramona/core/oDc';Y='com/bitwig/ramona/core/YFZ'
hand={}
for o,n,d in [(B,'cfM','(Lcom/bitwig/ramona/core/oDc;Lcom/bitwig/ramona/core/RKg;)Lcom/bitwig/ramona/core/oDc;'),(B,'cfM','(Ljava/util/Collection;Lcom/bitwig/ramona/core/RKg;)V'),(B,'Hnt','()V'),(B,'FzB','()V'),(B,'MRY','()V'),(B,'cfM','(Lcom/bitwig/ramona/core/oDc;Lcom/bitwig/ramona/core/oDc;)V'),(B,'cfM','()Lcom/bitwig/ramona/core/bbQ;'),(Y,'cfM','()V'),(Y,'MRY','()V'),(Y,'Hnt','()Lcom/bitwig/ramona/core/bbQ;'),(O,'VT1','()V'),(O,'vqJ','()V'),(O,'PWm','()Z'),('der','cfM','(Lcom/bitwig/base/serial/Jkg;Lcom/bitwig/ramona/serial/rsB;)Lcom/bitwig/ramona/core/OLR;'),('dpN','MRY','(LeoG;)V')]:
  d,m,_=body(o,n,d);hand[short(o).split('/')[-1]+'.'+n+d[:60]]=[list(x) for x in m.handlers]
_,_,bc=body(B,'cfM','(Ljava/util/Collection;Lcom/bitwig/ramona/core/RKg;)V')
off={r['c']['name']:r['offset'] for r in calls(bc) if r['c']['owner']==O and r['c']['name'] in('VT1','vqJ')}
need(off=={'VT1':134,'vqJ':234},'bbQ-counter-offsets')
_,_,bo=body(B,'cfM','(Lcom/bitwig/ramona/core/oDc;Lcom/bitwig/ramona/core/RKg;)Lcom/bitwig/ramona/core/oDc;')
need([r['offset'] for r in calls(bo,'MRY','()V')]==[84],'bbQ-cleanup-offset')
_,_,dp=body('dpN','MRY','(LeoG;)V');yo=[(r['offset'],r['c']['name']) for r in calls(dp,owner=Y)];need(yo==[(191,'cfM'),(335,'MRY')],'dpN-YFZ')
tlw=sorted(short(x[0]) for x in IDX.sites(B+'#FzB#Ljava/lang/ThreadLocal;'))
pwm=sorted(short(x[1]) for x in IDX.incoming(O,'PWm','()Z'))
node('B1','bbQ clone context and cleanup','open',
  ['Handler table (empty list = no handler): '+json.dumps(hand),
   'bbQ.FzB ThreadLocal holds YFZ; users: '+', '.join(tlw)+'. YFZ.cfM installs it at dpN.MRY(eoG)@191; YFZ.MRY removes it at @335; dpN.MRY has only handler [302,307) on the OOI.cfM() true path.',
   'Clone order in bbQ.cfM(Collection,RKg): TMF=true; IwV=roots; oDc.VT1 (+1 on ThreadLocal<Integer> qc1)@134; copy; Hnt() reverse b_ callbacks; FzB() reverse al_ callbacks (only hpW has ak_()=true); oDc.vqJ (-1)@234; per-root fqW(); TMF=false. Cleanup bbQ.MRY() (null IwV, clear both cQA(50) maps, clear lists) only at bbQ.cfM(oDc,RKg)@84.'],
  reason='failure effect: no general finally. An exception between offsets 134 and 234 leaves the per-thread oDc counter permanently incremented: oDc.PWm() stays true, so later oDc.G_() on that thread skips nqu() for I_()-true objects (PWm users: '+', '.join(pwm)+'). der.cfM(Jkg,rsB) restores its own increment in a handler; nothing repairs a leaked clone increment. An exception after 234 or in fqW leaves TMF=true and both maps/lists filled; a fresh bbQ is garbage, but a YFZ-owned bbQ stays referenced by YFZ.Hnt (YFZ.Hnt then returns a fresh bbQ per clone because TMF is true) until YFZ.MRY at dpN.MRY@335, which an event failure outside the OOI handler skips. Partial clones stay reachable from these maps. Retain the uncertain-state latch; never retry.',
  bound={'retainedObjectsAfterFailure':'one bbQ with two cQA maps and two lists of at most the partially cloned node count; one leaked counter increment per failed clone'})
# ---------------- 3. outer module wrap and initialization
roots_new={'mvZ':None}
cb=json.load(open('/tmp/gn-9b6g-constructor-bounds-2.json'))['builds'][1]
need(cb['sha256']==NEWSHA and len(cb['roots'])==30,'constructor-bounds-2')
rootmap={r['root'][0]:(r['id'],r['name'],r['vendorInstructions'],r['vendorCalls']) for r in cb['roots']}
pc=json.load(open('/tmp/gn-9b6g-port-constructors-1.json'))['builds'][1];need(pc['sha256']==NEWSHA,'port-constructors-1')
for r in pc['roots']:rootmap[r['root'][0]]=('port',r['root'][0],r['vendorInstructions'],r['vendorCalls'])
GROUPS={}
def group(name,roots,stop=lambda o,n,d:False):
  check_limits()
  try:nodes,leaves=closure(jar,roots,max_methods=LIMITS['trace_methods'],max_depth=LIMITS['walk_depth'],stop=stop)
  except Refusal as e:
    GROUPS[name]={'refused':str(e)};log('group',name,'refused',e);return None
  news=collections.Counter();cbk=collections.Counter();asy=set();mon=collections.Counter();handlers=[]
  for n in nodes:
    for c in n['news']:news[c]+=1
    for m in n['monitors']:mon[str(m)[:100]]+=1
    for x in n['indy']:cbk['indy:'+x['name']+x['descriptor']]+=1
    if n['handlers']:handlers.append([short('.'.join(n['method'][:2])),n['handlers']])
    for cl in n['calls']:
      t=cl['target']
      if any(k in t[0] for k in ('base/async','LQR','cXR','dpN','nitro/FDA','java/util/concurrent','java/lang/Thread','java/util/Timer','java/io/File')) or t[1] in('runAtEndOfCurrentEvent','asyncExec','runAsNextEvent','execute'):asy.add(short(n['method'][0]+'.'+n['method'][1])+' -> '+short(t[0]+'.'+t[1]))
  op=collections.Counter((l['kind'],short(l['target'][0]+'.'+l['target'][1]+l['target'][2][:30]),l.get('targets')) for l in leaves)
  mapped={c:rootmap.get(c) for c in news if not c.startswith('java/')}
  GROUPS[name]={'methods':len(nodes),'instructionsReached':sum(n['instructions'] for n in nodes),'allocations':dict(news),
    'allocationMap':{short(k):(list(v) if v else 'unmapped') for k,v in mapped.items()},'monitors':dict(mon),'dynamicSites':dict(cbk),'asyncFileOrQueueRefs':sorted(asy),
    'handlers':handlers[:64],'openLeaves':[{'kind':k[0],'target':k[1],'targets':k[2],'sites':v} for k,v in op.most_common(64)],'openLeafKinds':dict(collections.Counter(l['kind'] for l in leaves)),
    'stopped':[short(n['method'][0]+'.'+n['method'][1])+'@'+str(cl['offset']) for n in nodes for cl in n['calls'] if cl.get('class')=='stopped']}
  log('group',name,'methods',len(nodes),'leaves',len(leaves),'rss',resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
  return GROUPS[name]
R=P+'rSf';H=P+'hpW'
_,_,rinit=body(R,'<init>','()V')
gm=group('rSf.MRY(hpW)',[(R,'MRY','(L'+H+';)V',R)])
gg=group('rSf.G_()',[(R,'G_','()V',R)])
gz=group('zjj.cfM(clone)',[('com/bitwig/ramona/core/zjj','cfM','(Lcom/bitwig/ramona/core/oDc;)V',None)])
stopc=lambda o,n,d:(o,n,d)==('BgP','cfM','(ZZZ)V')
for c in ['BgP','BMo','Hgx',H,P+'RKg',P+'Wkj',P+'OcA','RuU']:
  group('b_:'+short(c),[(c,'b_','(Lcom/bitwig/ramona/core/oDc;)V',c)],stop=stopc)
group('al_:hpW',[(H,'al_','()V',H)])
group('fqW:hpW',[(H,'fqW','()V',H)])
node('R1','rSf.<init> -> CEE.<init> -> JXO...','open',['factory-constructor-census-1 lists the module 1902 chain.'],reason='unmapped: rSf (module 1902) is not one of the 30 constructor-bounds-2 roots; its direct constructor closure has no bound artifact.')
def gnode(nid,path,g,extra):
  if g is None or 'refused' in (g or {}):
    node(nid,path,'open',extra,reason='closure-method-limit or walk refusal: '+str(g and g.get('refused')));return
  node(nid,path,'open',extra+[ASSERT,'Lazy static descriptor singletons (static ifnonnull) are taken as initialized.','Receivers are exact for this and new objects; other virtual sites are monomorphic in the closed world or retained.'],
    reason='retained edges: '+str(g['openLeafKinds'])+' open dispatch sites, '+str(len(g['monitors']))+' monitor kinds, '+str(len(g['dynamicSites']))+' dynamic sites; see groups[\''+path+'\'] for the exact lists.',
    evidence={'methods':g['methods'],'instructionsReached':g['instructionsReached'],'allocationMap':g['allocationMap'],'monitors':g['monitors'],'dynamicSites':g['dynamicSites'],'async':g['asyncFileOrQueueRefs']})
gnode('R2','rSf.MRY(hpW)',gm,['Sets a fresh UUID.randomUUID (external SecureRandom), contents relationship, name, hQm/wuu/IwV(hpW.uva())/MYI.'])
gnode('R3','rSf.G_() -> hgq.G_ -> oDc.G_ (Dgc.ap_, I_() && !PWm() -> nqu) -> rSf.pYg',gg,['Creates the default children; nqu runs only while oDc.PWm() is false (see B1).'])
gnode('C5','zjj.cfM(clone) closure',gz,[])
for c in ['BgP','BMo','Hgx','hpW','RKg','Wkj','OcA','RuU']:
  k='b_:'+short(c if '/' in c else c) if c not in('hpW','RKg','Wkj','OcA') else 'b_:device/'+c
  gnode('C6:'+c,'reverse callback '+k,GROUPS.get(k),['Only these eight Amplify/port classes override oDc.b_ with a non-empty body; the other classes resolve to the empty oDc.b_.'] + (['BgP.cfM(ZZZ) compile calls are stopped; they are excluded only under C2 S>0.'] if c=='BgP' else []))
gnode('C7','reverse al_ callback for hpW (the only class with ak_()=true)',GROUPS.get('al_:hpW'),[])
gnode('C8','root fqW() after counter decrement',GROUPS.get('fqW:hpW'),[])
# ---------------- 5. browsing EIm holder setters
inc=lambda k:[(short(x[1]),x[2]) for x in IDX.incoming(*k.split('#'))]
chainA={k:inc(k) for k in [P+'Ac#Ucl#()V',P+'Ac#tp2#()V',P+'Ac#dnz#()V',P+'ISf#jFL#()V',P+'IPO#Lcd#()V',P+'ISf#Lcd#()V',P+'mjS#MRY#()V']}
chainG={k:inc(k) for k in [P+'g2L#wGc#()V',P+'g2L#ejd#()V',P+'nZA#Coi#()V',P+'vz3#ODA#()V',P+'nZA#ODA#()V']}
mjs=[short(x[0]) for x in IDX.sites(P+'mjS#new#')];iok=[short(x[0]) for x in IDX.sites(P+'iok#new#')];ooi=[short(x[0]) for x in IDX.sites(P+'OOI#new#')]
axc=IDX.sites('aXC#new#')+IDX.sites('aXP#new#')
hs=[h for h in IDX.handles if (h[1],h[2]) in {(P+'Ac','Nnn'),(P+'Ac','dnz'),(P+'g2L','ejd'),(P+'Ac','Ucl'),(P+'g2L','wGc')}]
_,_,zt=body(P+'ztR','MRY','(L'+P+'ISf;ILjava/util/List;)Ljava/lang/Object;')
s1=[r for r in zt if r['op']==171][0];k1={k:s1['offset']+t for k,t in zip(s1['a'][1::2],s1['a'][2::2])}
lcd=[r['offset'] for r in calls(zt,'Lcd')];key1=[k for k,t in k1.items() if t<=lcd[0] and not any(t2>t and t2<=lcd[0] for t2 in k1.values())]
_,_,kj=body(P+'kj2','cfM','(L'+P+'nZA;ILjava/util/List;)Ljava/lang/Object;')
s2=[r for r in kj if r['op']==171][0];k2={k:s2['offset']+t for k,t in zip(s2['a'][1::2],s2['a'][2::2])}
oda=[r['offset'] for r in calls(kj,'ODA')];key2=[k for k,t in k2.items() if t<=oda[0] and not any(t2>t and t2<=oda[0] for t2 in k2.values())]
need(key1==[5446] and key2==[6632],'browsing-action-ids')
_,_,dv=body('deV','cfM','(Lcom/bitwig/ramona/core/oDc;Ljava/util/List;)Ljava/lang/Object;')
need([r['c']['name'] for r in calls(dv)]==['ng_','E3','MRY'],'deV-cfM')
derc=[short(x[0]) for x in IDX.sites('der#MRY#(Lcom/bitwig/ramona/core/OLR;ILjava/util/List;)Ljava/lang/Object;')]
devc=[short(x[1]) for x in IDX.incoming('deV','cfM','(Lcom/bitwig/ramona/core/oDc;Ljava/util/List;)Ljava/lang/Object;')]
need(derc==['deV#cfM#(Lcom/bitwig/ramona/core/oDc;Ljava/util/List;)Ljava/lang/Object;'],'der-MRY-entry')
node('S1','EIm holder setter device/Ac.Nnn (Runnable from Ac.Ucl via eos.cfM(Collection,true,Runnable))','excluded',
  ['Closed world: no reflection or generated lambda outside the listed handles.','Ac/ISf/mjS chain incoming sets: '+json.dumps({short(k):v for k,v in chainA.items()}),
   'mjS is allocated only in '+', '.join(mjs)+'; iok (Runnable to Ac.dnz) only in '+', '.join(iok)+'.','aXC (ISf.Lcd via FAu) has no allocation site; reflection-only.',
   'Fixed doctor issues descriptor actions only through deV.cfM with deV id 951 (item 4 ping); no live tracking or UI browser session interacts during the sequence.'],
  witness={'onlyDispatchEntry':'der.MRY(OLR,I,List) is invoked only by '+derc[0]+' with key deV.E3() (final id); callers of deV.cfM: '+', '.join(devc),'actionArm':'ztR.MRY(ISf,I,List) lookupswitch key 5446 -> ISf.Lcd -> IPO.Lcd -> ISf.jFL -> Ac.dnz -> Ac.tp2 -> Ac.Ucl','fixedKey':'951 != 5446','factoryRoute':'no Ac/ISf/IPO/mjS/iok method appears in the W/C/R closures'},
  reason=None)
node('S2','EIm holder setter device/g2L.wGc (from g2L.ejd)','excluded',
  ['Incoming sets: '+json.dumps({short(k):v for k,v in chainG.items()}),'OOI (Runnable to g2L.ejd) is allocated only in '+', '.join(ooi)+' (an existing g2L).','aXP (nZA.ODA via Uyp) has no allocation site; reflection-only.',
   'g2L.ejd calls wGc only when g2L.lYc (tad) is non-null; vz3.E3 must hold a g2L.'],
  witness={'actionArm':'kj2.cfM(nZA,I,List) lookupswitch key 6632 -> nZA.ODA -> vz3.ODA -> nZA.Coi -> vz3.E3.ejd -> wGc','fixedKey':'951 != 6632','factoryRoute':'no g2L/nZA/vz3/kj2/OOI method appears in the W/C/R closures'})
node('S3','Browsing setters through an existing browser session object or reflection','open',
  ['Ac and g2L are abstract; a pre-existing session (ISf.d3() Ac or vz3.E3 g2L) can run iok/OOI Runnables or mjS.MRY callbacks on the event thread.','Method handles to these methods: '+json.dumps([[short(a),short(b),c,d] for a,b,c,d in hs])],
  reason='external/UI state: a user or browser session started before or during the fixed sequence is not excluded by bytecode; needs a state witness (no active session on the target chain) and stability through the sequence. Reflection-only aXC/aXP instantiation is also retained.')
# ---------------- 6. async route
CU='com/bitwig/base/async/CuM'
_,_,sub=body(CU,'cfM','(Ljava/lang/Object;Ljava/util/concurrent/Callable;Lcom/bitwig/base/async/oRV;)V')
_,_,can=body(CU,'cfM','(Ljava/lang/Object;)V')
_,mw,wk=body(CU,'cfM','(Lcom/bitwig/base/async/WzZ;ILjava/util/concurrent/Callable;Ljava/lang/Object;Lcom/bitwig/base/async/oRV;)V')
_,_,cmp=body(CU,'cfM','(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Exception;Lcom/bitwig/base/async/oRV;Lcom/bitwig/base/async/WzZ;I)V')
need([r['c']['name'] for r in calls(can) if r['c']['owner']=='java/util/concurrent/atomic/AtomicInteger']==['incrementAndGet'],'CuM-cancel')
need(not any(r['c']['name'] in('interrupt','cancel','remove') for r in calls(can)),'CuM-cancel-no-stop')
need(wk[3]['op']==159 and [list(x) for x in mw.handlers]==[[12,43,46,9]],'CuM-worker')
need([r['offset'] for r in cmp if r['op']==159]==[169] and any(r['op']==165 for r in cmp),'CuM-completion-gates')
_,_,lq=body('LQR','cfM','(Ljava/lang/Object;Ljava/util/concurrent/Callable;Lcom/bitwig/base/async/oRV;)V')
_,ml,lw2=body('LQR','cfM','(LHuq;Ljava/util/concurrent/CompletableFuture;Ljava/util/concurrent/Callable;)V')
_,mc,lc=body('LQR','cfM','()V')
need(any(r.get('c',{}).get('name')=='cancel' for r in lq) and [list(x) for x in ml.handlers]==[[15,28,31,9]] and any(r.get('c',{}).get('name')=='get' and r['c']['owner']=='java/util/concurrent/Future' for r in lc),'LQR-shape')
cxr=[short(x[0]) for x in IDX.sites('cXR#new#')];tln=[short(x[0]) for x in IDX.sites('TL#new#')];lqn=[short(x[0]) for x in IDX.sites('LQR#new#')]
asyncrefs={k:v.get('asyncFileOrQueueRefs') for k,v in GROUPS.items() if isinstance(v,dict) and 'methods' in v}
node('A1','Async route dpN -> cXR -> TL (base/async/CuM task queue)','open',
  ['cXR allocated only in '+', '.join(cxr)+'; TL (default package) only in '+', '.join(tln)+'.','TL.cfM/MRY start and stop a PSD activity tracker around CuM.cfM()/MRY().'],
  reason='Cancellation CuM.cfM(Object) only increments the WzZ AtomicInteger generation. It does not interrupt the executor thread, remove the map entry, or call CuM.MRY(). A started worker checks the generation once before Callable.call (offset 8) and runs call() to completion; completion is posted with QYb.asyncExec and returns early on a generation mismatch (offset 169) or a replaced WzZ, without callback, map removal, or CuM.MRY(). Worker handler [12,43)->46 catches Exception only; an Error posts no completion. Therefore a generation change or a cancel call proves neither termination nor completion of the callable or its side effects.')
node('A2','LQR CompletableFuture queue','open',['LQR allocated only in '+', '.join(lqn)+'.'],
  reason='Future.cancel(true) on a CompletableFuture does not interrupt; the worker lambda checks Huq.cfM identity only before call() and then completes the old future; a replaced or cancelled future does not stop running work. LQR.cfM() close waits on each Future.get() without timeout; a cancelled future throws CancellationException, which neither handler [121,144)->147/166 catches, so the close loop can stop with entries already cleared. An Error in the worker (handler type cp#9 only) leaves the future incomplete and the close wait unbounded.')
node('A3','Does the fixed factory route enter the async route?','open',
  ['Warm hit with S>0 (W4, C2): the traced W/C/R closures contain no CuM/LQR/cXR/TL submit; references found: '+json.dumps(asyncrefs)],
  witness={'excludedArms':'compile calls BgP.cfM(ZZZ) in bl_/Pgx are not executed when S>0 (C2)'},
  reason='retained edge: the cold miss (W8) always compiles the template (BgP.cfM(rsB) -> cfM(false,false,true)) and enters the compiler/FDA cache and task queues; the warm path has open dispatch leaves (C4-C8, R2-R3) and runAtEndOfCurrentEvent deferrals that are not closed. No witness excludes a cold miss for the first call in a process.')
# ---------------- output
rep={'result':'refused','reason':'factory-route-closure-incomplete','boundedAdmission':False,'runtimeClassesInitialized':0,'writeAuthority':False,
  'jar':{'path':NEWJ,'sha256':h},'scope':'6.1.4 actual jar only; 6.0.6 and renamed fixtures not traced in this report',
  'conditions':[ASSERT,'Closed-world bytecode: no reflection, Proxy, generated classes, or native callbacks into these paths.','Lazy static descriptor singletons initialized (walker prunes static ifnonnull lazy-init arms).','Receiver precision is flow-merged per instruction site.','A passing local check is a conditional result, not admission.'],
  'branchTable':NODES,'groups':GROUPS,'work':dict(IDX.work),'limits':LIMITS,'elapsedMs':round((time.time()-T0)*1000,3),'peakRssBytes':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}
data=json.dumps(rep,indent=1,sort_keys=False,default=list).encode()
if len(data)>LIMITS['report_bytes']:raise Refusal('factory-closure-report-size')
OUT.write_bytes(data)
log('result',rep['result'],'nodes',len(NODES),'classes',collections.Counter(n['classification'] for n in NODES),'bytes',len(data),'elapsedMs',rep['elapsedMs'],'peakRssBytes',rep['peakRssBytes'])
LOG.write_text('\n'.join(LOGL)+'\n')
