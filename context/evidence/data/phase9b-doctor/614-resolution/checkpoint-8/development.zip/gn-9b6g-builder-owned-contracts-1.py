import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.owned_flow import runtime_parent_bindings
from grid_doctor.callee_contracts import compare_callees
from grid_doctor.fixed_read_checkpoint import membership_variants
from grid_doctor.migrate import merge
start=time.perf_counter();code=Code();jars=[Jar(Path(p))for p in ['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar']];catalogs=[]
for i,j in enumerate(jars):
 rows=json.load(open('/tmp/gn-9b6g-fixed-1.json'))['builds'][i]['rows'];registry=json.load(open('/tmp/gn-9b6g-registry-'+('old-'if i==0 else'')+'closure-1.json'))['selectedRows'];selected={(r['name'],r['id']):r for r in rows+registry};catalogs.append({'sha256':j.sha256,'rows':list(selected.values())})
parents,witnesses=runtime_parent_bindings(*jars,*catalogs);seed=json.load(open('/tmp/gn-9b6g-invariant-contracts-1.json'));seed['typeBindings']=merge([seed['typeBindings'],{}],[parents,{}])[0];symbols=json.load(open('/tmp/gn-9b6g-resolution-5.json'))['builds'][1];traces=json.load(open('/tmp/gn-9b6g-builder-owned-flow-1-1.json'))['methods'];variants=membership_variants(jars[1],symbols,code,traces);r=compare_callees(*jars,traces,seed,code,variants);r.update(runtimeParentInputs=witnesses,elapsedMs=(time.perf_counter()-start)*1000,peakRssBytes=rss_bytes());raw=json.dumps(r,indent=2).encode()
if len(raw)>8*1024**2:raise Refusal('builder-owned-contract-limit')
Path('/tmp/gn-9b6g-builder-owned-contracts-1.json').write_bytes(raw);print('matched',len(r['matched']),'unmatched',r['unmatched']);print(len(raw),r['elapsedMs'],r['peakRssBytes'])
