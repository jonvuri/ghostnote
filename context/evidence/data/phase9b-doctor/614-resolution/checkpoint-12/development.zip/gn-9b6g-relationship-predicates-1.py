import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,instructions,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.migrate import member
from grid_doctor.read_dataflow import ReadFlow,integer
from grid_doctor.ownership import constant
from grid_doctor.callee_contracts import compare_callees
start=time.perf_counter();jars=[Jar(Path(p))for p in ['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar']];code=Code();flags=json.load(open('/tmp/gn-9b6g-relationship-flags-1.json'))['builds'];symbols=json.load(open('/tmp/gn-9b6g-resolution-5.json'))['builds'];builds=[]
for i,j in enumerate(jars):
 base=symbols[i]['types']['relationship'];c=code.get(j,base);candidates=[]
 for m in c.methods:
  raw=instructions(m.code)
  if m.desc=='()Z'and not m.handlers and [x[1]for x in raw]==[42,180,16,126,153,4,167,3,172]and raw[2][2]==(32,):candidates.append(m)
 if len(candidates)!=1:raise Refusal('relationship-predicate-base-slot')
 slot=candidates[0].name;alloc={tuple(r['allocation']):r for r in flags[i]['allocations']};rows=[];methods=set()
 for row in flags[i]['rows']:
  if row['error']:raise Refusal('relationship-predicate-flags-unbound')
  a=alloc[tuple(row['witness'])];runtime=a['constructor'][0];receiver=('ref',runtime,'property');field=tuple(a['fieldProvenance']['field']);flow=ReadFlow(j,code,[],('unused','id','I'),row['propertyId'],'unused',instance_values={(receiver,field):integer(row['flags'])});key=(base,slot,'()Z',receiver,(),False);out=flow.evaluate(*key[:3],key[3],key[4])
  if out not in ({integer(0)},{integer(1)}):raise Refusal('relationship-predicate-unresolved')
  methods.update(flow.methods);rows.append(dict(row,predicate=next(iter(out))[2]==1,predicateBound=flow.bounds[key],predicateMethods=sorted(flow.methods),fieldConditions=sorted(flow.instance_fields)))
 builds.append({'sha256':j.sha256,'slot':[base,slot,'()Z'],'rows':rows,'methods':sorted(methods)});print(i,'paths',len(rows),'methods',len(methods),'true',[(r['className'],r['propertyName'],r['flags'])for r in rows if r['predicate']],flush=True)
seed=json.load(open('/tmp/gn-9b6g-port-invariant-contracts-1.json'));traces=[dict(zip(('owner','name','descriptor'),x))for x in builds[1]['methods']];compared=compare_callees(*jars,traces,seed,code);r={'builds':builds,'contracts':compared,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False,'runtimeObserved':False};raw=json.dumps(r,indent=2).encode()
if len(raw)>8*1024**2:raise Refusal('relationship-predicate-report-limit')
Path('/tmp/gn-9b6g-relationship-predicates-1.json').write_bytes(raw);print('matched',len(compared['matched']),'unmatched',compared['unmatched']);print(len(raw),r['elapsedMs'],r['peakRssBytes'])
