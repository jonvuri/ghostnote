import json,time
from pathlib import Path
from grid_symbols.scan import Jar,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.wrapper_bounds import compare_wrappers
start=time.perf_counter();old=Jar(Path('/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar'));new=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));c=Code();s=json.load(open('/tmp/gn-9b6g-resolution-5.json'));p=json.load(open('/tmp/gn-9b6g-properties-4.json'));r=[]
for i,j in enumerate((old,new)):
 seed=json.load(open('/tmp/gn-9b6g-fixed-read-3/slots-'+str(i)+'.json'));r.append(compare_wrappers(old,j,p['builds'][i],s['builds'][i],seed,c))
out={'builds':r,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes()};Path('/tmp/gn-9b6g-wrapper-contracts-1.json').write_text(json.dumps(out,indent=2));print([(len(x['bounds']),len(x['contracts']['matched']),x['contracts']['unmatched'])for x in r])
