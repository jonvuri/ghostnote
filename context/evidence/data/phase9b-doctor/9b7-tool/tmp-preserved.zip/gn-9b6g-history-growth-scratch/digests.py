import json, zipfile, sys
from grid_symbols.scan import parse
from grid_doctor.ownership import bootstraps
from grid_doctor.history_growth import check_bodies
path, kind = sys.argv[1], sys.argv[2]
z = zipfile.ZipFile(path)
def load(n):
    raw = z.read(n + '.class'); c = parse(raw, True); return c, bootstraps(raw, c)
if kind == 'renamed':
    m = json.load(open('/tmp/gn-9b6g-renamed-map.json'))
    rc = lambda n: m.get(n, n); rm = lambda n: n if n.startswith('<') else 'r_' + n
else:
    rc = rm = lambda n: n
r = check_bodies(load, rc, rm, pinned={})
print(json.dumps({k: v['digest'] for k, v in r['targets'].items()}, indent=1))
print(json.dumps({k: (v['instructions'], v['flags'], v['handlers']) for k, v in r['targets'].items()}), file=sys.stderr)
