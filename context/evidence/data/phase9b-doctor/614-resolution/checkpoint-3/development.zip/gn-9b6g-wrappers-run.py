import json,time
from pathlib import Path
from grid_symbols.scan import Jar,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.wrapper_bounds import wrapper_bound
start=time.perf_counter();j=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));code=Code();rows=[]
for spec in [('deU','E3','(Lcom/bitwig/ramona/core/oDc;)Lcom/bitwig/ramona/core/bnq;'),('deT','cfM','(Lcom/bitwig/ramona/core/oDc;)Lcom/bitwig/ramona/core/brd;')]:rows.append(wrapper_bound(j,code,*spec))
r={'builds':rows,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes()};Path('/tmp/gn-9b6g-wrappers-1.json').write_text(json.dumps(r,indent=2));print([(x['objectAllocations'],x['constructorInstructionBound'],x['vendorConstructorCalls'])for x in rows])
