import json,time
from pathlib import Path
from grid_symbols.scan import Jar,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.disposal_wrappers import captured_wrappers
start=time.perf_counter();old=Jar(Path('/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar'));new=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));c=Code();s=json.load(open('/tmp/gn-9b6g-resolution-5.json'));p=json.load(open('/tmp/gn-9b6g-fixed-1.json'));rows=[]
for i,j in enumerate((old,new)):
 seed=json.load(open('/tmp/gn-9b6g-fixed-read-3/slots-'+str(i)+'.json'));rows.append(captured_wrappers(old,j,p['builds'][i],s['builds'][i],seed,c))
r={'builds':rows,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes()};Path('/tmp/gn-9b6g-disposal-wrapper-contracts-3.json').write_text(json.dumps(r,indent=2));print([(len(x['methods']),sum(y['baseReached']for y in x['receivers']),len(x['contracts']['matched']),x['contracts']['unmatched'])for x in rows]);print(r['elapsedMs'],r['peakRssBytes'])
