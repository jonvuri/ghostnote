import json,time,zipfile,itertools,collections
from pathlib import Path
from grid_symbols.scan import parse
from grid_doctor.ownership import method_trace,bootstraps
from grid_doctor.assertion_guards import disabled_field
from grid_doctor.read_dataflow import signature
start=time.perf_counter()
class Node:
 def __init__(self,managed):self.managed=managed;self.children=[];self.flags=0
class Iterator:
 def __init__(self,values):self.values=values;self.index=0
class Failure(Exception):pass

def load(index):
 path=['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'][index];z=zipfile.ZipFile(path);owner='com/bitwig/ramona/core/'+('oDc'if index else'HEV');raw=z.read(owner+'.class');c=parse(raw,True);jar=type('J',(),{'zip':z})();names={'dispose':'ix_'if index else'dC_','managed':'I_'if index else'H_','walk':'wGc'if index else'MkF','release':'IwV'if index else'NaF','children':'tB1'if index else'dpx','before':'a_','after':'cfM'if index else'ffA'};methods={}
 for role in('dispose','walk','release'):
  desc='()V'if role=='dispose'else'(Z)V'if role=='walk'else'(L'+owner+';Z)V';m=next(m for m in c.methods if(m.name,m.desc)==(names[role],desc));assert not m.handlers;methods[role]=method_trace(jar,c,m,bootstraps(raw,c))
 return owner,names,disabled_field(c),methods

def execute(inp,parents,managed,fail_at=None):
 owner,names,guard,methods=inp;nodes=[Node(v)for v in managed]
 for i,p in enumerate(parents,1):nodes[p].children.append(nodes[i])
 counts=collections.Counter();steps=collections.Counter();depths=[0]
 for p in parents:depths.append(depths[p]+1)
 R=0;C=0
 for i in range(1,len(nodes)):
  p=parents[i-1];C+=int(managed[p])
  while True:
   R+=int(managed[p])
   if not p:break
   p=parents[p-1]
 def run(role,args,depth=0):
  if depth>128:raise ValueError('stack limit')
  counts[role]+=1
  if role=='dispose'and counts[role]==fail_at:raise Failure()
  raw=methods[role]['instructions'];ix={r['offset']:i for i,r in enumerate(raw)};local=dict(enumerate(args));stack=[];pc=0
  while True:
   steps[role]+=1
   if sum(steps.values())>2000000:raise ValueError('work limit')
   i=ix[pc];r=raw[i];op=r['opcode'];a=r['args'];following=raw[i+1]['offset']if i+1<len(raw)else None
   if op==1:stack.append(None)
   elif 2<=op<=8:stack.append(op-3)
   elif 26<=op<=29:stack.append(local[op-26])
   elif 42<=op<=45:stack.append(local[op-42])
   elif op in(21,25):stack.append(local[a[0]])
   elif op in(54,58):local[a[0]]=stack.pop()
   elif 75<=op<=78:local[op-75]=stack.pop()
   elif op==89:stack.append(stack[-1])
   elif op==18:
    value=r['constant'];assert value['tag']==3;stack.append(int(value['value'],16))
   elif op==128:b=stack.pop();stack.append(stack.pop()|b)
   elif op==178:
    ref=r['constant'];assert(ref['owner'],ref['name'],ref['descriptor'])==guard;stack.append(1)
   elif op==180:
    assert r['constant']['descriptor']=='I';stack.append(stack.pop().flags)
   elif op==181:
    assert r['constant']['descriptor']=='I';v=stack.pop();stack.pop().flags=v
   elif op==192:assert r['constant']['value']==owner
   elif op in(153,154,167):
    take=True if op==167 else(stack.pop()==0)==(op==153)
    if take:following=pc+int.from_bytes(bytes(a),'big',signed=True)
   elif op in(182,184,185):
    ref=r['constant'];argtypes,result=signature(ref['descriptor']);n=len(argtypes)+(op!=184);args=stack[-n:]if n else[]
    if n:del stack[-n:]
    out=None
    if ref['owner']==owner:
     role2=next((k for k,v in names.items()if v==ref['name']),None)
     if role2 in methods:run(role2,args,depth+1)
     elif role2=='managed':counts['managed']+=1;out=int(args[0].managed)
     elif role2=='children':assert args[1]is None;counts['collect']+=1;out=list(args[0].children)
     elif role2 in('before','after'):counts[role2]+=1
     else:raise ValueError(('vendor call',ref))
    elif ref['owner']=='java/util/List'and ref['name']=='iterator':counts['iterator']+=1;out=Iterator(args[0])
    elif ref['owner']=='java/util/Iterator':
     counts[ref['name']]+=1;it=args[0]
     if ref['name']=='hasNext':out=int(it.index<len(it.values))
     elif ref['name']=='next':out=it.values[it.index];it.index+=1
     else:raise ValueError('iterator call')
    elif ref['owner']=='thz'and ref['name']=='cfM'and ref['descriptor']=='(Ljava/lang/Object;)V':counts['trackingFalse']+=1
    else:raise ValueError(('call',ref))
    if result!='V':stack.append(out)
   elif op==177:return
   else:raise ValueError(('opcode',role,pc,op))
   pc=following
 try:run('dispose',[nodes[0]]);failed=False
 except Failure:failed=True
 N=len(nodes);M=sum(managed);D=max(depths)
 if not failed:
  assert counts['dispose']==N and counts['walk']==M and counts['release']==R
  assert counts['collect']==N+M+R and counts['iterator']==N+M+R
  assert counts['managed']==N+M and counts['before']==counts['after']==R
  assert counts['hasNext']==2*N+M+2*R-1 and counts['next']==N-1+R
  assert all(n.flags==0x80000000 for n in nodes) and R<=N*D
 return {'N':N,'M':M,'D':D,'R':R,'C':C,'counts':dict(counts),'steps':dict(steps),'failed':failed,'disposed':sum(n.flags==0x80000000 for n in nodes)}
results=[]
for index in(0,1):
 inp=load(index);basis=[execute(inp,p,m)for p,m in[([], [False]),([],[True]),([0],[True,False]),([0,1],[True,False,False])]]
 b0,b1,b2,b3=basis;A=b0['steps']['dispose'];B=b1['steps']['dispose']-A;E=b2['steps']['dispose']-2*A-B;F=b1['steps']['walk'];G=b2['steps']['walk']-F;H=b2['steps']['release'];I=b3['steps']['release']-2*H;cases=0;worst=0;samples=[]
 def check(p,m):
  global_unused=None
  r=execute(inp,p,m);N,M,R,C=(r[k]for k in('N','M','R','C'));assert r['steps']['dispose']==A*N+B*M+E*(N-1);assert r['steps'].get('walk',0)==F*M+G*C;assert r['steps'].get('release',0)==H*R+I*(R-C);return r
 for n in range(1,6):
  for parents in itertools.product(*(range(i)for i in range(1,n))):
   for managed in itertools.product((False,True),repeat=n):
    r=check(parents,managed);cases+=1;worst=max(worst,sum(r['steps'].values()))
 for n in(32,77):
  for parents in([i-1 for i in range(1,n)],[0]*(n-1),[(i-1)//2 for i in range(1,n)]):
   for managed in([False]*n,[True]*n,[True]+[False]*(n-1),[bool(i%2)for i in range(n)]):
    r=check(parents,managed);samples.append(r);cases+=1;worst=max(worst,sum(r['steps'].values()))
 failure=execute(inp,[0,0],[False]*3,3);assert failure['failed']and failure['disposed']==1
 results.append({'build':index,'methods':list(inp[3].values()),'cases':cases,'maxOwnInstructions':worst,'coefficients':{'dispose':{'perNode':A,'perManaged':B,'perTreeEdge':E},'walk':{'perManaged':F,'perManagedImmediateChild':G},'release':{'perReleaseVisit':H,'perReleaseChildEdge':I}},'samples':samples,'partialFailure':failure});print(index,cases,results[-1]['coefficients'],flush=True)
r={'builds':results,'elapsedMs':(time.perf_counter()-start)*1000,'runtimeClassesInitialized':0,'boundedAdmission':False,'conditions':['The owned graph is a stable finite tree with distinct children.','Assertion fields are initialized and true. New tracking remains false.','The managed predicate and both hook slots have the fixed factory contracts.','Owned collection and iterator bodies use inert models. Their costs are excluded.','Disposal wrappers, maps, listener removals, native operations, and failure latency need separate bounds.','R counts visits below managed ancestors; C counts their immediate children. R is at most N times D.']};Path('/tmp/gn-9b6g-disposal-tree-model-1.json').write_text(json.dumps(r,indent=2)+'\n')
