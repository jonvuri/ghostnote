import json,time
from pathlib import Path
from grid_symbols.scan import Jar,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.descriptor_builders import lookup
from grid_doctor.ownership import method_trace,bootstraps
from grid_doctor.callee_contracts import compare_callees
start=time.perf_counter();jars=[Jar(Path(p))for p in ['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar']];code=Code();seed=json.load(open('/tmp/gn-9b6g-disposal-listener-bounds-2.json'))['contracts'];traces=[]
for key in [('TT','removeListener','(Lfoz;)V'),('TT','addListener','(Lfoz;)V'),('TT','getListeners','()Ljava/util/List;'),('apd','Hnt','()Z'),('eOU','<init>','()V')]:
 c,m=lookup(jars[1],code,*key);traces.append(method_trace(jars[1],c,m,bootstraps(jars[1].zip.read(c.name+'.class'),c)))
r=compare_callees(*jars,traces,seed,code);r.update(elapsedMs=(time.perf_counter()-start)*1000,peakRssBytes=rss_bytes());Path('/tmp/gn-9b6g-listener-storage-contracts-1.json').write_text(json.dumps(r,indent=2));print('matched',len(r['matched']),'unmatched',r['unmatched'])
