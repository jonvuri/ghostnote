import sys,time,zipfile
from pathlib import Path
from grid_symbols.scan import parse,instructions
from grid_doctor.ownership import constant
path=sys.argv[1]; targets={tuple(x.split('#')) for x in sys.argv[2:]}
z=zipfile.ZipFile(path); t=time.perf_counter(); n=0
for e in z.infolist():
    if not e.filename.endswith('.class'): continue
    raw=z.read(e)
    if not any(o.encode() in raw for o,_,_ in targets): continue
    c=parse(raw,True)
    for m in c.methods:
        rows=instructions(m.code)
        for i,(off,op,a) in enumerate(rows):
            if op in (181,179,180):
                ref=constant(c,a[0]*256+a[1])
                if (ref['owner'],ref['name'],ref['descriptor']) in targets and op!=180:
                    ctx=[(r[1],(constant(c,r[2][0]*256+r[2][1]) if r[1] in(187,183,182,184,185,180,178,192) else r[2])) for r in rows[max(0,i-6):i]]
                    print(c.name,m.name,m.desc,off,op,ref['name'],ctx)
print('elapsed',time.perf_counter()-t)
