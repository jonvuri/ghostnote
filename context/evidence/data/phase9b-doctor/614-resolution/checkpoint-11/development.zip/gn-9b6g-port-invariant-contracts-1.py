import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.callee_contracts import compare_callees
start=time.perf_counter();jars=[Jar(Path(p))for p in ['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar']];seed=json.load(open('/tmp/gn-9b6g-port-flows-1.json'))['contracts'];traces=[dict(zip(('owner','name','descriptor'),x))for x in json.load(open('/tmp/gn-9b6g-port-invariant-reads-1.json'))['methods']];r=compare_callees(*jars,traces,seed,Code());r.update(elapsedMs=(time.perf_counter()-start)*1000,peakRssBytes=rss_bytes());raw=json.dumps(r,indent=2).encode()
if len(raw)>8*1024**2:raise Refusal('port-invariant-contract-report-limit')
Path('/tmp/gn-9b6g-port-invariant-contracts-1.json').write_bytes(raw);print('matched',len(r['matched']),'unmatched',r['unmatched']);print(len(raw),r['elapsedMs'],r['peakRssBytes'])
