import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.callee_contracts import compare_callees
start=time.perf_counter();jars=[Jar(Path(p))for p in ['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar']];code=Code();seed=json.load(open('/tmp/gn-9b6g-invariant-read-contracts-1.json'));traces=[{'owner':'com/bitwig/flt/document/core/master/device/GPn','name':'ng_','descriptor':'()LdeS;'},{'owner':'com/bitwig/flt/document/core/master/device/GPn','name':'ERO','descriptor':'()Lcom/bitwig/flt/document/core/master/device/HmS;'}];r=compare_callees(*jars,traces,seed,code);r.update(elapsedMs=(time.perf_counter()-start)*1000,peakRssBytes=rss_bytes());raw=json.dumps(r,indent=2).encode()
if len(raw)>8*1024**2:raise Refusal('default-binding-report-limit')
Path('/tmp/gn-9b6g-default-descriptor-bindings-1.json').write_bytes(raw);print(r['matched'],r['unmatched']);print(r['elapsedMs'],r['peakRssBytes'])
