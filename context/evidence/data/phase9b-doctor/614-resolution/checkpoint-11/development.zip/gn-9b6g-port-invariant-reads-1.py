import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,ancestors,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.descriptor_builders import lookup
from grid_doctor.assertion_guards import requirements
from grid_doctor.owned_flow import getter_field
from grid_doctor.migrate import member
from grid_doctor.read_dataflow import ReadFlow
start=time.perf_counter();j=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));code=Code();symbols=json.load(open('/tmp/gn-9b6g-resolution-5.json'))['builds'][1];roles={r['role']:r['reference']for r in symbols['members']};key=roles['property-id'];cls=code.get(j,key[1]);pf=getter_field(cls,member(cls,*key[2:]),'I');base=code.get(j,symbols['types']['property-base']);parents={getter_field(base,m,'L'+symbols['types']['descriptor-base']+';')for m in base.methods if m.desc=='()L'+symbols['types']['descriptor-base']+';'}
if len(parents)!=1:raise Refusal('invariant-parent-field-count')
parent=parents.pop();catalog=json.load(open('/tmp/gn-9b6g-port-catalog-1.json'))['builds'][1]['rows'];anchors={(r['name'],r['id']):r['matches'][0]for r in catalog};reports=[json.load(open('/tmp/gn-9b6g-port-property-bindings-1-1.json'))];rows=[r for p in reports for r in p['properties']];source=json.load(open('/tmp/gn-9b6g-invariant-projection-2.json'));reads={}
for row in source['rows']:
 refs=[x['reference']for x in row['instructions']if x['opcode']==182 and x['reference']['descriptor'].startswith('(Lcom/bitwig/ramona/core/oDc;)')and x['reference']['descriptor']!='(Lcom/bitwig/ramona/core/oDc;)Lcom/bitwig/ramona/core/uzc;']
 if refs:
  if len(refs)!=1:raise Refusal('invariant-read-count')
  reads[row['method'][0]]=refs[0]
owners=set()
for a in anchors.values():
 for key in ('descriptor','runtimeClass'):owners.update(ancestors(j.classes,a[key],128))
for row in rows:
 for p in row['properties']:owners.update(ancestors(j.classes,p['targetClass'],128))
guards=requirements(j,{n for n in owners if any(f.desc=='Z'and f.flags==4120 for f in j.classes[n].fields)},code);paths=[];methods=set();work={'instructions':0,'states':0,'calls':0}
for row in rows:
 a=anchors[row['name'],row['id']]
 for p in row['properties']:
  typ=p['targetClass']
  if typ not in reads:continue
  ref=reads[typ];flow=ReadFlow(j,code,guards['fields'],pf,p['id'],a['descriptor'],work,property_descriptor=(parent,p['target'][0]));key=(ref['owner'],ref['name'],ref['descriptor'],('ref',typ,'property'),(('ref',a['runtimeClass'],'object'),),False)
  flow.evaluate(*key[:3],key[3],key[4]);bound=flow.bounds[key];methods.update(flow.methods);paths.append({'className':row['name'],'classId':row['id'],'propertyName':p['name'],'propertyId':p['id'],'entry':list(key[:3]),'normalReadBound':dict(zip(('vendorInstructions','vendorCalls','externalCalls'),bound)),'methods':sorted(flow.methods),'external':sorted(flow.external,key=str),'staticFields':sorted(flow.static_fields)})
r={'sha256':j.sha256,'paths':paths,'methods':sorted(methods),'assertionGuards':guards,'work':work,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False};raw=json.dumps(r,indent=2).encode()
if len(raw)>8*1024**2:raise Refusal('invariant-direct-read-report-limit')
Path('/tmp/gn-9b6g-port-invariant-reads-1.json').write_bytes(raw);print('paths',len(paths),'methods',len(methods),'guards',len(guards['fields']),'work',work);print('max', {k:max(x['normalReadBound'][k]for x in paths)for k in ['vendorInstructions','vendorCalls','externalCalls']});print(len(raw),r['elapsedMs'],r['peakRssBytes'])
