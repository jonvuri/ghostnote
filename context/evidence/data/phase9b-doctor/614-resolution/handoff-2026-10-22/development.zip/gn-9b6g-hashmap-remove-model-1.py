import json,time,hashlib,itertools,random
from pathlib import Path
from collections import Counter
from grid_symbols.scan import parse
from grid_doctor.ownership import method_trace,bootstraps
from grid_doctor.read_dataflow import signature
start=time.perf_counter();base=Path('/tmp/gn-9b6g-runtime-new-arm64-9/java.base')
class Reader:
 def read(self,n):return(base/n).read_bytes()
j=type('J',(),{'zip':Reader()})();methods={};hashes={}
wanted={'java/util/HashMap':{'remove','hash','removeNode','afterNodeRemoval','replacementNode','comparableClassFor'},'java/util/HashMap$Node':{'<init>'},'java/util/HashMap$TreeNode':{'getTreeNode','root','find','removeTreeNode','untreeify','balanceDeletion','rotateLeft','rotateRight','moveRootToFront'},'java/lang/Object':{'<init>','equals','hashCode'}}
for owner,names in wanted.items():
 raw=j.zip.read(owner+'.class');c=parse(raw,True);hashes[owner]=hashlib.sha256(raw).hexdigest()
 for m in c.methods:
  if m.name in names:methods[owner,m.name,m.desc]=method_trace(j,c,m,bootstraps(raw,c))
NODE='java/util/HashMap$Node';TREE='java/util/HashMap$TreeNode';MAP='java/util/HashMap'
class Obj:
 def __init__(self,typ,**fields):self.typ=typ;self.fields=fields
class InjectedFailure(Exception):pass

def execute(map_object,query,fail_allocate=None):
 counts=Counter();stackmax=0
 def run(key,args,depth=0):
  nonlocal stackmax
  stackmax=max(stackmax,depth)
  if depth>128:raise ValueError('stack bound')
  if key==('java/lang/Object','hashCode','()I'):counts['nativeIdentityHash']+=1;return args[0].fields['hash']
  m=methods[key];raw=m['instructions'];ix={r['offset']:i for i,r in enumerate(raw)};local=dict(enumerate(args));stack=[];pc=0;counts['calls']+=1
  while True:
   counts['instructions']+=1
   if counts['instructions']>2000000:raise ValueError('instruction bound')
   i=ix[pc];r=raw[i];op=r['opcode'];a=r['args'];following=raw[i+1]['offset']if i+1<len(raw)else None
   if op==1:stack.append(None)
   elif 2<=op<=8:stack.append(op-3)
   elif op==16:stack.append(int.from_bytes(bytes(a),'big',signed=True))
   elif 26<=op<=29:stack.append(local[op-26])
   elif 42<=op<=45:stack.append(local[op-42])
   elif op in(21,25):stack.append(local[a[0]])
   elif op in(54,58):local[a[0]]=stack.pop()
   elif 59<=op<=62:local[op-59]=stack.pop()
   elif 75<=op<=78:local[op-75]=stack.pop()
   elif op==87:stack.pop()
   elif op==89:stack.append(stack[-1])
   elif op==90:
    v=stack.pop();u=stack.pop();stack.extend([v,u,v])
   elif op==91:
    v=stack.pop();u=stack.pop();w=stack.pop();stack.extend([v,w,u,v])
   elif op==178:
    ref=r['constant'];assert(ref['owner'],ref['name'],ref['descriptor'])==(TREE,'$assertionsDisabled','Z');stack.append(1)
   elif op==180:stack.append(stack.pop().fields[r['constant']['name']])
   elif op==181:
    v=stack.pop();stack.pop().fields[r['constant']['name']]=v
   elif op==187:
    assert r['constant']['value']==NODE;counts['allocations']+=1
    if fail_allocate==counts['allocations']:raise InjectedFailure()
    stack.append(Obj(NODE,hash=0,key=None,value=None,next=None))
   elif op==192:
    target=r['constant']['value'];assert target==TREE
    assert stack[-1]is None or isinstance(stack[-1],Obj)and stack[-1].typ==TREE
   elif op==193:
    target=r['constant']['value'];v=stack.pop()
    if target==TREE:stack.append(int(isinstance(v,Obj)and v.typ==TREE))
    elif target=='java/lang/Comparable':stack.append(0)
    else:raise ValueError(('type test',target))
   elif op==50:
    k=stack.pop();stack.append(stack.pop()[k])
   elif op==83:
    v=stack.pop();k=stack.pop();stack.pop()[k]=v
   elif op==190:stack.append(len(stack.pop()))
   elif op in(96,100,124,126,130):
    b=stack.pop();v=stack.pop();out=v+b if op==96 else v-b if op==100 else (v&0xffffffff)>>(b&31)if op==124 else v&b if op==126 else v^b;stack.append(((out+2**31)%2**32)-2**31)
   elif op in(*range(153,168),198,199):
    take=True
    if op in(198,199):take=(stack.pop()is None)==(op==198)
    elif 153<=op<=158:
     v=stack.pop();take=(v==0,v!=0,v<0,v>=0,v>0,v<=0)[op-153]
    elif 159<=op<=166:
     b=stack.pop();v=stack.pop()
     if op>=165:take=(v is b)==(op==165)
     else:take=(v==b,v!=b,v<b,v>=b,v>b,v<=b)[op-159]
    if take:following=pc+int.from_bytes(bytes(a),'big',signed=True)
   elif op in(182,183,184):
    ref=r['constant'];argtypes,result=signature(ref['descriptor']);n=len(argtypes)+(op!=184);args=stack[-n:]if n else[]
    if n:del stack[-n:]
    target=(ref['owner'],ref['name'],ref['descriptor']);out=run(target,args,depth+1)
    if result!='V':stack.append(out)
   elif op in(172,176):return stack.pop()
   elif op==177:return None
   else:raise ValueError(('opcode',key,pc,op))
   pc=following
 try:value=run((MAP,'remove','(Ljava/lang/Object;)Ljava/lang/Object;'),[map_object,query]);failed=False
 except InjectedFailure:value=None;failed=True
 return value,dict(counts),stackmax,failed

def fixture(n,tree,same_hash=False):
 capacity=512;keys=[];nodes=[]
 for i in range(n):
  h=512 if same_hash else (i+1)*capacity;key=Obj('Key',hash=h^(h>>16));keys.append(key);nodes.append(Obj(TREE if tree else NODE,hash=h,key=key,value=object(),next=None,parent=None,left=None,right=None,prev=None,red=False))
 for i,node in enumerate(nodes):
  node.fields['next']=nodes[i+1]if i+1<n else None
  node.fields['prev']=nodes[i-1]if i else None
 if tree:
  def subtree(lo,hi,parent=None):
   if lo>=hi:return None
   mid=(lo+hi)//2;node=nodes[mid];node.fields['parent']=parent;node.fields['left']=subtree(lo,mid,node);node.fields['right']=subtree(mid+1,hi,node);return node
  root=subtree(0,n)
  # The root need not be the first node. getTreeNode follows parent links.
 table=[None]*capacity
 if nodes:table[0]=nodes[0]
 return Obj(MAP,table=table,size=n,modCount=0),keys,nodes

def validate(m,expected):
 head=m.fields['table'][0];seen=[];current=head
 while current is not None:
  assert current not in seen;seen.append(current);current=current.fields['next']
 assert m.fields['size']==len(expected)==len(seen)
 assert {id(x.fields['key'])for x in seen}=={id(x)for x in expected}
 if head is not None and head.typ==TREE:
  root=head
  while root.fields['parent']is not None:root=root.fields['parent']
  assert not root.fields['red'];visited=[]
  def check(node,parent):
   if node is None:return 1
   assert node not in visited;visited.append(node);assert node.fields['parent']is parent
   left,right=node.fields['left'],node.fields['right'];a,b=check(left,node),check(right,node);assert a==b
   if node.fields['red']:assert (left is None or not left.fields['red'])and(right is None or not right.fields['red'])
   return a+int(not node.fields['red'])
  check(root,None);assert set(visited)==set(seen)
  for i,node in enumerate(seen):assert node.fields['prev']is(seen[i-1]if i else None)
 elif head is not None:assert all(x.typ==NODE for x in seen)
 return len(seen)
summary=[];maxima=Counter();cases=0
for tree in(False,True):
 sizes=(1,3,7,15,31,63,127)if tree else range(65)
 for n in sizes:
  for same_hash in(False,True):
   for pos in range(-1,n):
    m,keys,nodes=fixture(n,tree,same_hash);query=keys[pos]if pos>=0 else Obj('Key',hash=512);expected_value=nodes[pos].fields['value']if pos>=0 else None
    value,c,depth,failed=execute(m,query);expected=[x for x in keys if x is not query];assert not failed and value is expected_value;validate(m,expected)
    assert c.get('nativeIdentityHash',0)==1 and c.get('allocations',0)<=max(0,n-1)
    assert c['instructions']<=2000+2000*n
    cases+=1;maxima.update({})
    for k,v in c.items():maxima[k]=max(maxima[k],v)
    if pos in(-1,0,n-1)and n in(0,3,7,63,127):summary.append({'tree':tree,'sameHash':same_hash,'size':n,'position':pos,'counts':c,'depth':depth})
# Repeated removal also checks that balancing and conversion preserve later operations.
for n in(7,31,127):
 for order in('forward','reverse','random'):
  m,keys,nodes=fixture(n,True,True);indices=list(range(n))
  if order=='reverse':indices.reverse()
  elif order=='random':random.Random(614).shuffle(indices)
  expected=list(keys)
  for k in indices:
   value,c,depth,failed=execute(m,keys[k]);assert not failed and value is nodes[k].fields['value'];expected.remove(keys[k]);validate(m,expected);cases+=1
m,keys,nodes=fixture(3,True,True);_,c,_,failed=execute(m,keys[0],1);assert failed and m.fields['size']==3
r={'classSha256':hashes,'methods':list(methods.values()),'cases':cases,'maxima':dict(maxima),'samples':summary,'allocationFailure':{'propagates':failed,'reportedSize':m.fields['size'],'allocationsAttempted':c['allocations'],'retryPermitted':False},'elapsedMs':(time.perf_counter()-start)*1000,'boundedAdmission':False,'runtimeClassesInitialized':0,'conditions':['Exact HashMap receiver with a stable valid table and node structures.','Non-null keys use Object.hashCode and Object.equals and do not implement Comparable.','TreeNode assertions must already be initialized and disabled.','Native identity hashing uses an inert 32-bit stub.','The loose instruction assertion is a test limit, not an admitted analytical bound.','Capacity, concurrency, initialization, native latency, and actual map limits remain separate.']};Path('/tmp/gn-9b6g-hashmap-remove-model-1.json').write_text(json.dumps(r,indent=2)+'\n');print('cases',cases,'maxima',dict(maxima),'ms',r['elapsedMs'])
