import json,time
from pathlib import Path
from grid_symbols.scan import Jar,rss_bytes,Refusal,ancestors
from grid_doctor.descriptor_resolution import Code
from grid_doctor.assertion_guards import requirements
from grid_doctor.read_dataflow import ReadFlow,unknown
start=time.perf_counter();jar=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));code=Code();slots=json.load(open('/tmp/gn-9b6g-lifecycle-slots-2.json'))['slots'];classes=sorted({s['receiver']for s in slots});owners=set()
for cls in classes:owners.update(ancestors(jar.classes,cls,jar.limits.depth))
owners={o for o in owners if o in jar.classes and any(f.desc=='Z'and f.flags==4120 for f in jar.classes[o].fields)}
flags=requirements(jar,owners,code);paths=[];work={'states':0,'instructions':0,'calls':0}
for cls in classes:
 flow=ReadFlow(jar,code,flags['fields'],('unused','unused','I'),0,'unused',work);error=None;ret=None
 try:ret=sorted(flow.evaluate(cls,'ar_','()V',('ref',cls,'object')))
 except Refusal as e:error=str(e)
 paths.append({'receiver':cls,'error':error,'return':ret,'external':sorted(flow.external,key=repr),'methods':sorted(flow.methods)})
r={'jarSha256':jar.sha256,'paths':paths,'assertions':flags,'work':work,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False};Path('/tmp/gn-9b6g-lifecycle-assertions-1.json').write_text(json.dumps(r,indent=2)+'\n');print('paths',len(paths),'errors',[(p['receiver'],p['error'])for p in paths if p['error']],'external',[(p['receiver'],p['external'])for p in paths if p['external']],'flags',len(flags['fields']),'work',work,'ms',r['elapsedMs'],'rss',r['peakRssBytes'])
