import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.descriptor_builders import lookup
from grid_doctor.callee_contracts import compare_callees
from grid_doctor.migrate import merge
from grid_doctor.dynamic_contracts import dynamic_contract
from grid_doctor.ownership import bootstraps,method_trace
start=time.perf_counter();jars=[Jar(Path(p))for p in ['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar']];code=Code();seed=json.load(open('/tmp/gn-9b6g-history-ancestor-bounds-1.json'))['contracts'];known=[seed['typeBindings'],{tuple(r['source']):tuple(r['target'])for r in seed['memberBindings']}]
for name in ['port-constructors-1']:
 s=json.load(open('/tmp/gn-9b6g-'+name+'.json'))['contracts'];known=merge(known,[s['typeBindings'],{tuple(r['source']):tuple(r['target'])for r in s['memberBindings']}])
seed={'typeBindings':known[0],'memberBindings':[{'source':list(k),'target':list(v)}for k,v in known[1].items()]}
specs=set()
for name in ['port-setters-1','port-terminal-stores-1','port-terminal-stores-2','port-terminal-stores-3','port-setter-hooks-1','port-record-hooks-1','port-name-history-1','port-name-history-2','port-listener-registrations-1']:
 for line in Path('/tmp/gn-9b6g-'+name+'.txt').read_text().splitlines():
  if line.startswith('LOOKUP'):
   p=line.split();specs.add(tuple(p[3:6]))
for m in json.load(open('/tmp/gn-9b6g-port-listener-map-incoming-1.json'))['methods']:specs.add((m['owner'],m['name'],m['descriptor']))
traces=[]
for spec in sorted(specs):
 c,m=lookup(jars[1],code,*spec);traces.append(method_trace(jars[1],c,m,bootstraps(jars[1].zip.read(c.name+'.class'),c)))
def local(j,c,m):
 try:return dynamic_contract(c,m,j.classes,bootstraps(j.zip.read(c.name+'.class'),c))
 except Refusal as e:
  if str(e).startswith(('dynamic-','contract-unsupported-constant:')):return None
  raise
r=compare_callees(*jars,traces,seed,code,local_contract=local);r.update(traces=traces,elapsedMs=(time.perf_counter()-start)*1000,peakRssBytes=rss_bytes());raw=json.dumps(r,indent=2).encode()
if len(raw)>8*1024**2:raise Refusal('setter-contract-report-limit')
Path('/tmp/gn-9b6g-port-setter-contracts-1.json').write_bytes(raw);print('matched',len(r['matched']),'unmatched',r['unmatched']);print(len(raw),r['elapsedMs'],r['peakRssBytes'])
