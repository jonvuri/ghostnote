import sys
from pathlib import Path
from grid_symbols.scan import parse
from grid_doctor.ownership import method_trace, bootstraps
roots=[Path('/tmp/gn-9b6g-collection-conditions-runtime-new-3/java.base'),Path('/tmp/gn-9b6g-runtime-new-arm64-9/java.base'),Path('/tmp/gn-9b6g-collection-conditions-runtime-new-1/java.base')]
class R:
    def read(self,n):
        for r in roots:
            p=r/n
            if p.exists(): return p.read_bytes()
        raise KeyError(n)
jar=type('J',(),{'zip':R()})()
for spec in sys.argv[1:]:
    owner,name,desc=spec.split('#')
    raw=jar.zip.read(owner+'.class');c=parse(raw,True)
    ms=[m for m in c.methods if (name=='*' or m.name==name) and (desc=='*' or m.desc==desc)]
    for m in ms:
        t=method_trace(jar,c,m,bootstraps(raw,c))
        print('==',owner,m.name,m.desc,'flags',m.flags,'n',len(t['instructions']),'H',t['exceptionHandlers'])
        for x in t['instructions']: print(' ',x['offset'],x['opcode'],x.get('constant',x['args']))
