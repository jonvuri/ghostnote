import sys;sys.path.insert(0,'/tmp/gn-9b6g-fc-work')
from walk import *
jar=Jar(NEW);R='com/bitwig/flt/document/core/master/device/rSf'
nodes,leaves=closure(jar,[(R,'MRY','(Lcom/bitwig/flt/document/core/master/device/hpW;)V',R)],max_depth=int(sys.argv[1]) if len(sys.argv)>1 else 6)
print('methods',len(nodes),'leaves',len(leaves))
for n in nodes:
  print(n['depth'],n['method'][0].split('/')[-1],n['method'][1],n['method'][2][:60],'this',str(n['this']).split('/')[-1],'ins',n['instructions'],'H',n['handlers'],'new',n['news'],'mon',[str(x)[:60] for x in n['monitors']],'indy',[x['name'] for x in n['indy']])
from collections import Counter
print(Counter(l['kind'] for l in leaves))
for l in leaves:
  if l['kind']!='depth':print(' ',l['kind'],l.get('targets'),l['target'],str(l.get('receiver',''))[:100],l.get('from'))
