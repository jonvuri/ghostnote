import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,instructions,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.descriptor_builders import lookup
from grid_doctor.assertion_guards import requirements
from grid_doctor.dispatch_paths import reachable
from grid_doctor.ownership import constant,method_trace,bootstraps
from grid_doctor.migrate import member
start=time.perf_counter();j=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));code=Code();classes=[r['propertyClass']for r in json.load(open('/tmp/gn-9b6g-invariant-bounds-2.json'))['rows']];seen=set();todo=[];rows=[];traces=[]
for typ in classes:
 c,m=lookup(j,code,typ,'hUR','(Lcom/bitwig/ramona/core/oDc;)V');todo.append((c.name,m.name,m.desc))
while todo:
 key=todo.pop()
 if key in seen:continue
 if len(seen)>=128:raise Refusal('invariant-projection-limit')
 seen.add(key);c=code.get(j,key[0]);m=member(c,*key[1:]);guards=requirements(j,{c.name},code);condition={'fields':guards['fields']};selected=reachable(c,m,None,set(map(tuple,guards['fields'])));body=[]
 for off,op,args in instructions(m.code):
  if off not in selected:continue
  row={'offset':off,'opcode':op,'args':args}
  if op in (178,179,180,181,182,183,184,185,187,189,192,193):
   ref=constant(c,int.from_bytes(bytes(args[:2]),'big'));row['reference']=ref
   if op==183 and(ref['name'],ref['descriptor'])==key[1:]:
    sc,sm=lookup(j,code,ref['owner'],ref['name'],ref['descriptor']);todo.append((sc.name,sm.name,sm.desc))
  body.append(row)
 rows.append({'method':list(key),'condition':condition,'instructions':body});traces.append(method_trace(j,c,m,bootstraps(j.zip.read(c.name+'.class'),c)))
r={'sha256':j.sha256,'rows':rows,'methods':traces,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False};Path('/tmp/gn-9b6g-invariant-projection-2.json').write_text(json.dumps(r,indent=2)+'\n')
for row in rows:
 print(row['method'],'guards',row['condition']);print([(r['offset'],r['reference'])for r in row['instructions']if'reference'in r]);print('opcodes',[(r['offset'],r['opcode'])for r in row['instructions']])
print(r['elapsedMs'],r['peakRssBytes'])
