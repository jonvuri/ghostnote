import json,time
from pathlib import Path
from grid_symbols.scan import Jar,rss_bytes
from grid_doctor.property_contracts import bind_properties,captured_properties
from grid_doctor.descriptor_resolution import Code
start=time.perf_counter();old=Jar(Path('/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar'));new=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'))
res=json.load(open('/tmp/gn-9b6g-resolution-3.json'));cat=json.load(open('/tmp/gn-9b6g-fixed-1.json'));props=captured_properties(Path('context/evidence/data/phase9b-doctor/live-v20/captures.zip'));code=Code();out=[]
for i,jar in enumerate([old,new]):
 out.append(bind_properties(old,jar,cat['builds'][0],cat['builds'][i],props,res['builds'][i],code))
r={'builds':out,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes()}
Path('/tmp/gn-9b6g-properties-3.json').write_text(json.dumps(r,indent=2))
print(json.dumps({**{k:v for k,v in r.items()if k!='builds'},'work':[b['work']for b in out],'dispatch':out[1]['propertyDispatch']},indent=2))
