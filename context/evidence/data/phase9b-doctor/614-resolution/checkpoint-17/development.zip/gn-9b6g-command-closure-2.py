"""9b.6g command closure for the fixed doctor commands. Offline, inert class data only.

Driver: python3 -B /tmp/gn-9b6g-command-closure-1.py
Worker: python3 -B /tmp/gn-9b6g-command-closure-1.py --build new|old --part PATH [--labels PATH]
No vendor class is loaded or initialized. No host request is sent.
"""
import argparse, hashlib, json, subprocess, sys, time
from pathlib import Path
from grid_symbols.scan import Jar, Refusal, instructions, parse, rss_bytes
from grid_doctor.command_closure import (Index, closure, exact_field, fingerprint, list_mutations,
                                         value_source, ClosureLimits)
from grid_doctor.ownership import constant

N = 2
JARS = {'old': ('/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar',
                '382c655d0b9e8db6bd433dc6100ef3a4ee23abf6a6615f79c40f0c2645792c93'),
        'new': ('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar',
                '5c2b1895bbb9e7d08d9216de421985bb1f24b2ee62762c9451b4fe847df2469f')}
ROLE_TABLE = Path('/tmp/gn-9b6g-resolution-5.json')
M, C = 'com/bitwig/flt/document/core/master/', 'com/bitwig/ramona/core/'
D = M + 'device/'
CS = 'com/bitwig/flt/control_surface/proxy/ControlSurfaceObject'
# Investigation names on 6.1.4. Each old name comes from an equal fingerprint or from the
# call at the same offset in an already mapped method. These are not selectors.
LABELS = {
    'project-dispatch': ((M + 'Ljp', 'MRY', f'(L{M}g2L;ILjava/util/List;)Ljava/lang/Object;'), None),
    'ping-action': ((M + 'AJH', 'bLK', '()V'), ('project-dispatch', 1134)),
    'ping-send': ((M + 'AJH', 'MRY', '(LcQq;)V'), ('ping-action', 32)),
    'ping-client': (('cQq', 'cfM', f'(L{C}AVL;)LcQq;'), ('ping-action', 22)),
    'ping-request': (('cQq', 'cfM', f'(LdeV;L{C}oDc;[Ljava/lang/Object;)Ljava/lang/Object;'), ('ping-send', 60)),
    'ping-wait': (('cQq', 'Hnt', '()Ljava/lang/Object;'), ('ping-request', 242)),
    'ping-registry': ((M + 'Ljp', 'Yt', '()LdeV;'), ('ping-send', 55)),
    'action-invoke': (('deV', 'cfM', f'(L{C}oDc;Ljava/util/List;)Ljava/lang/Object;'), None),
    'action-id': (('deN', 'E3', '()I'), ('action-invoke', 8)),
    'action-dispatch-slot': (('der', 'MRY', f'(L{C}OLR;ILjava/util/List;)Ljava/lang/Object;'), ('action-invoke', 12)),
    'ui-action': (('eIS', 'UNj', f'(L{C}oDc;)V'), ('action-invoke-caller', 'eIS')),
    'action-wrapper': ((C + 'cuN', 'cfM', '(Ljava/util/List;)Ljava/lang/Object;'), ('action-invoke-caller', 'cuN')),
    'protocol-request': (('cQq', 'cfM', f'(LdeV;L{C}oDc;Ljava/util/List;Z)V'), ('action-invoke-caller', 'cQq')),
    'connection-request': (('dfn', 'cfM', f'(LdeV;L{C}oDc;Ljava/util/List;Z)V'), ('action-invoke-caller', 'dfn')),
    'opener': ((C + 'XKG', 'cfM', f'(Ljava/lang/String;Ljava/lang/String;L{C}WzZ;L{C}oDc;L{C}CuM;Z)Z'), None),
    'lock-wait': ((C + 'XKG', 'cfM', '(Ljava/util/Set;)Z'), ('opener', 295)),
    'lock-callback': ((C + 'XKG', 'cfM', '(Ljava/util/Set;Ljava/lang/Runnable;)V'), ('lock-wait', 111)),
    'collect': ((C + 'WzZ', 'cfM', f'()L{C}kJI;'), ('opener', 87)),
    'collect-fill': ((C + 'WzZ', 'cfM', f'(L{C}kJI;)V'), ('collect', 10)),
    'default-collect': ((C + 'BKi', 'cfM', f'()L{C}kJI;'), None),
    'manager-ctor': ((C + 'XKG', '<init>', '(Ljava/lang/String;I)V'), None),
    'implicit-begin': ((C + 'XKG', 'cfM', f'(Ljava/lang/String;Ljava/lang/String;L{C}oDc;L{C}CuM;)Z'), None),
    'set-begin': ((C + 'XKG', 'cfM', '(Ljava/lang/String;Ljava/lang/String;Ljava/util/Set;)Z'), None),
    'delete-fill': ((D + 'Vzt', 'cfM', f'(L{C}kJI;Ljava/util/List;)V'), None),
    'delete-collector-fill': ((D + 'hLr', 'cfM', f'(L{C}kJI;)V'), ('delete-fill-caller', None)),
    'manager-top': ((C + 'Rzi', 'vpw', f'()L{C}XKG;'), None),
    'manager-push': ((C + 'Rzi', 'cfM', f'(L{C}XKG;)V'), None),
    'manager-pop': ((C + 'Rzi', 'ERO', '()V'), None),
    'manager-change': ((C + 'Rzi', 'MJ', '()V'), ('manager-push', 39)),
    'reopen': (('dfT', 'UNj', '()V'), None),
    'reopen-close': (('dfT', 'hUR', '()V'), None),
    'record-change': (('dhu', 'cfM', f'(Lden;L{C}oDc;Ljava/lang/Object;)V'), None),
    'journal-select': (('dfI', 'ejd', '()Ldhu;'), None),
    'journal-for': (('dfI', 'cfM', f'(L{C}XKG;)Ldhu;'), ('journal-select', 31)),
    'document-manager': (('dfI', 'ERO', f'()L{C}XKG;'), None),
    'validation-hook': ((M + 'tj2', 'Hnt', '()V'), None),
    'validation-entry': ((M + 'Kiy', 'UNj', '()LdfE;'), ('validation-hook', 7)),
    'validation': ((M + 'Kiy', 'ODA', '()V'), ('validation-entry', 1)),
    'validation-project': ((M + 'g2L', 'zab', '()V'), ('validation', 206)),
    'validation-setting': ((M + 'Kiy', 'TMF', '()LAQw;'), ('validation-project', 22)),
    'validation-set-a': ((M + 'Kiy', 'MRY', '(Z)V'), ('validation', 193)),
    'validation-set-b': ((M + 'Kiy', 'cfM', '(Z)V'), ('validation', 170)),
    'setting-write': (('bDS', 'setBoolValue', '(Z)V'), ('validation-set-a', 5)),
    'pending-run': (('dfI', 'ucQ', '()V'), None),
    'pending-add': (('dfI', 'cfM', '(Ljava/lang/Runnable;Z)V'), ('allocator-of', 'pending-record')),
    'pending-record': (('dfP', 'cfM', '()V'), ('pending-run', 123)),
    'undo': (('dfI', 'tp2', '()V'), None),
    'journal-undo': (('dhu', 'lYc', '()V'), ('undo', 59)),
    'replay-undo': (('dfT', 'LaE', '()V'), ('journal-undo', 180)),
    'replay-redo': (('dfT', 'Grk', '()V'), None),
    'replay-wait': (('dfT', 'MRY', '(Z)Ljava/util/List;'), ('replay-undo', 126)),
    'replay-worker': (('dfT', 'cfM', '(Ljava/util/ArrayList;ZLjava/util/concurrent/Semaphore;)V'), None),
    'replay-read': (('dfT', 'cfM', '(Ljava/util/ArrayList;Z)V'), ('replay-worker', 3)),
    'worker-submit': (('dfI', 'cfM', '(Ljava/lang/Runnable;)V'), ('replay-wait', 58)),
    'executor-put': (('AUY', 'a_', '(Ljava/lang/Runnable;)V'), ('worker-submit', 37)),
    'debug-enter': (('dfI', 'SQN', '()V'), ('pending-run', 61)),
    'debug-exit': (('dfI', 'Esj', '()V'), ('pending-run', 132)),
    'debug-begin': (('dfI', 'z3I', '()V'), ('opener', 29)),
    'debug-check': (('dfQ', 'UNj', '()V'), ('debug-begin', 15)),
    'context-drain': (('dqr', 'E3', '()V'), ('same-owner', 'context-pump')),
    'event-drain': (('WWV', 'Hnt', '()V'), ('context-drain', 28)),
    'context-pump': (('dqr', 'UNj', '()V'), None),
    'event-dispatch': (('dpN', 'MRY', '(LeoG;)V'), None),
    'surface-exec': ((CS, 'exec', '(Ljava/lang/Runnable;)V'), ('same-key', None)),
    'surface-document-thread': ((CS, 'isDocumentThread', '()Z'), ('same-key', None)),
}
COMMANDS = {  # command: (member role, exact runtime type role or label owner)
    'value': ('native-value-setter', 'decimal-atom'), 'cable': ('cable-source-setter', 'destination-atom'),
    'delete': ('module-delete', 'module'), 'begin': ('begin', 'grid'), 'insert': ('insert-body', 'grid'),
    'associate': ('associate-edit', 'grid'), 'close': ('close', 'grid'), 'undo': ('undo-command', '@validation-hook'),
    'dispose': ('disposal', 'module'), 'factory': ('module-factory', None),
    'boolean': ('boolean-command', 'boolean-atom'), 'remove-mapping': ('remove-mapping', 'mapping-source'),
    'restore-mapping': ('restore-mapping', 'mapping-source')}
WAITS = ('java/util/concurrent/Semaphore', 'java/util/concurrent/Future', 'java/util/concurrent/CountDownLatch',
         'java/util/concurrent/LinkedBlockingQueue', 'java/lang/Object.wait', 'java/lang/Thread.join',
         'java/util/concurrent/locks', 'java/lang/ThreadLocal', 'runAsNextEvent', 'runAtEndOfCurrentEvent')


def fp_digest(method):
    size, ops, handlers = fingerprint(method)
    return hashlib.sha256(json.dumps([size, ops, handlers]).encode()).hexdigest()


def body(ix, key, limit=400):
    cls, m = ix.code(key[0]), ix.method(*key)
    rows = []
    for offset, op, args in instructions(m.code)[:limit]:
        row = [offset, op]
        if op in (18, 19, 20) or 178 <= op <= 193:
            try:
                ref = constant(cls, args[0] if op == 18 else args[0] * 256 + args[1])
                row.append(ref.get('value') if 'owner' not in ref else [ref['owner'], ref['name'], ref['descriptor']])
            except Exception:
                row.append(list(args))
        elif args:
            row.append(list(args))
        rows.append(row)
    handlers = [[h[0], h[1], h[2], constant(cls, h[3])['value'] if h[3] else 'any'] for h in m.handlers]
    return {'key': list(key), 'flags': m.flags, 'bytes': len(m.code), 'handlers': handlers, 'instructions': rows}


def call_at(ix, key, offset):
    cls, m = ix.code(key[0]), ix.method(*key)
    for o, op, args in instructions(m.code):
        if o == offset:
            if not 182 <= op <= 185:
                raise Refusal('label-via-not-call')
            ref = constant(cls, args[0] * 256 + args[1])
            owner = ix.resolve(ref['owner'], ref['name'], ref['descriptor'])
            if owner is None:
                raise Refusal('label-via-unresolved')
            return owner, ref['name'], ref['descriptor'], op
    raise Refusal('label-via-offset')


def field_at(ix, key, offset):
    cls, m = ix.code(key[0]), ix.method(*key)
    for o, op, args in instructions(m.code):
        if o == offset and op in (178, 179, 180, 181):
            ref = constant(cls, args[0] * 256 + args[1])
            return ref['owner'], ref['name'], ref['descriptor']
    raise Refusal('label-field-offset')


def map_labels(ix, build, reference):
    """Return label -> method key. New build uses LABELS; old build uses fingerprints and calls."""
    out = {}
    if build == 'new':
        for label, (key, _) in LABELS.items():
            ix.method(*key)
            m = ix.method(*key)
            out[label] = {'key': list(key), 'how': 'pinned-6.1.4-investigation-name', 'fingerprint': fp_digest(m),
                          'ops': [[o, op] for o, op, _ in instructions(m.code)]}
        return out
    wanted = {row['fingerprint']: label for label, row in reference.items()}
    found = {}
    new_roles, _, _ = roles('new')
    old_roles, _, _ = roles('old')
    by_role = {tuple(v): k for k, v in new_roles.items()}
    # Stream code once to find equal fingerprints for wanted labels.
    for name in ix.names:
        ix.jar.check()
        cls = parse(ix.jar.zip.read(name + '.class'), True)
        for m in cls.methods:
            d = fp_digest(m)
            if d in wanted:
                found.setdefault(wanted[d], []).append((name, m.name, m.desc))
    pending = list(LABELS)
    for _ in range(4):
        for label in list(pending):
            via = LABELS[label][1]
            hits = found.get(label, [])
            key, how = None, None
            prefix = False
            if via and via[0] in out and isinstance(via[1], int) and not out[via[0]].get('fingerprintEqual', True):
                pm = ix.method(*out[via[0]]['key'])
                mine = [[o, op] for o, op, _ in instructions(pm.code) if o <= via[1]]
                prefix = mine == [x for x in reference[via[0]]['ops'] if x[0] <= via[1]]
            if via and via[0] in out and isinstance(via[1], int) and (out[via[0]].get('fingerprintEqual', True) or prefix):
                parent = tuple(out[via[0]]['key'])
                target = call_at(ix, parent, via[1])
                key, how = target[:3], f'call-at:{via[0]}@{via[1]}' + (':equal-opcode-prefix' if prefix else '')
                if hits and key not in hits:
                    raise Refusal('label-fingerprint-and-call-disagree:' + label)
            elif tuple(reference[label]['key']) in by_role:
                role = by_role[tuple(reference[label]['key'])]
                key, how = tuple(old_roles[role]), 'role-table:' + role
            elif len(hits) == 1:
                key, how = hits[0], 'unique-fingerprint'
            elif via and via[0] == 'action-invoke-caller' and 'action-invoke' in out:
                callers = [r for r in ix.callers(*out['action-invoke']['key']) if r['opcode'] in (182, 185)]
                same = [tuple(r['caller']) for r in callers if tuple(r['caller']) in hits]
                if len(same) == 1:
                    key, how = same[0], 'fingerprint-among-action-invoke-callers'
            elif via and via[0] == 'same-owner' and via[1] in out:
                same = [h for h in hits if h[0] == out[via[1]]['key'][0]]
                if len(same) == 1:
                    key, how = same[0], 'fingerprint-in-owner-of:' + via[1]
            elif via and via[0] == 'same-key':
                ref = tuple(reference[label]['key'])
                if ix.declared(*ref):
                    key, how = ref, 'unobfuscated-same-key'
            elif via and via[0] == 'allocator-of' and via[1] in out:
                target = out[via[1]]['key'][0]
                rows = {tuple(r['caller']) for (n2, d2), packed in ix.incoming.items() if n2 == '<init>'
                        for r in ix.callers(target, n2, d2) if r['symbolicOwner'] == target}
                rows = {r for r in rows if r[0] != target}
                if len(rows) == 1:
                    key, how = next(iter(rows)), 'unique-allocator-of:' + via[1]
            elif via and via[0] == 'delete-fill-caller' and 'delete-fill' in out:
                callers = [tuple(r['caller']) for r in ix.callers(*out['delete-fill']['key'])]
                same = [c for c in callers if c in hits]
                if len(same) == 1:
                    key, how = same[0], 'fingerprint-among-delete-fill-callers'
            if key:
                m = ix.method(*key)
                out[label] = {'key': list(key), 'how': how, 'fingerprint': fp_digest(m), 'fingerprintMatches': len(hits),
                              'fingerprintEqual': fp_digest(m) == reference[label]['fingerprint']}
                pending.remove(label)
    for label in pending:
        out[label] = {'key': None, 'how': 'unmapped', 'fingerprintMatches': len(found.get(label, []))}
    return out


def roles(build):
    table = json.loads(ROLE_TABLE.read_text())['builds'][0 if build == 'old' else 1]
    return {r['role']: r['reference'][1:] for r in table['members']}, table['types'], table['sha256']


def literal_sites(ix, value):
    rows = []
    for name in ix.names:
        ix.jar.check()
        cls = parse(ix.jar.zip.read(name + '.class'), True)
        for m in cls.methods:
            raw = instructions(m.code)
            for i, (offset, op, args) in enumerate(raw):
                if op == 17 and int.from_bytes(bytes(args), 'big', signed=True) == value:
                    nxt = []
                    for o2, op2, a2 in raw[i + 1:i + 6]:
                        if 182 <= op2 <= 186 or op2 in (179, 181):
                            r = constant(cls, a2[0] * 256 + a2[1])
                            nxt.append(f"{op2}:{r.get('owner')}.{r['name']}{r['descriptor']}")
                    rows.append({'method': [name, m.name, m.desc], 'offset': offset, 'following': nxt})
    return rows


def switch_case(ix, key, value):
    m = ix.method(*key)
    for offset, op, args in instructions(m.code):
        if op == 171:
            default, pairs = args[0], {args[n]: args[n + 1] for n in range(1, len(args), 2)}
            if value in pairs:
                return {'switchOffset': offset, 'key': value, 'target': offset + pairs[value], 'pairs': len(pairs)}
    return None


def safe(fn):
    try:
        return fn()
    except (KeyError, StopIteration, IndexError, Refusal) as error:
        return {'unavailable': type(error).__name__ + ':' + str(error)}


def worker(build, part, reference):
    start = time.perf_counter()
    path, sha = JARS[build]
    jar = Jar(Path(path))
    if jar.sha256 != sha:
        raise Refusal('jar-hash')
    members, types, role_sha = roles(build)
    if role_sha != sha:
        raise Refusal('role-table-hash')
    ix = Index(jar)
    labels = map_labels(ix, build, reference)
    L = {k: tuple(v['key']) for k, v in labels.items() if v['key']}
    facts = {'build': build, 'sha256': sha, 'labels': labels, 'index': {'sites': ix.sites, 'external': ix.external,
             'dynamic': ix.dynamic, 'lambdaSlots': len(ix.lambdas), 'methods': len(ix.methods)}}
    # 1. Ping choke points.
    sinkset = ['ping-action', 'ping-send', 'ping-request', 'ping-wait', 'ping-registry', 'action-invoke',
               'action-dispatch-slot', 'ui-action', 'action-wrapper', 'protocol-request', 'connection-request']
    ping = {'callers': {}, 'handles': {}, 'dispatchCase951': switch_case(ix, L['project-dispatch'], 951),
            'case951Body': None, 'literal951': literal_sites(ix, 951)}
    case = ping['dispatchCase951']
    if case:
        rows = [r for r in body(ix, L['project-dispatch'], 2000)['instructions'] if case['target'] <= r[0] < case['target'] + 6]
        ping['case951Body'] = rows
    for label in sinkset:
        rows = ix.callers(*L[label])
        ping['callers'][label] = {'count': len(rows), 'virtual': [r for r in rows if r['opcode'] in (182, 185)][:64],
                                  'special': sum(r['opcode'] == 183 for r in rows), 'static': sum(r['opcode'] == 184 for r in rows)}
        ping['handles'][label] = ix.handles.get(L[label], [])
    ping['waitBody'] = body(ix, L['ping-wait'])
    ping['sendBody'] = body(ix, L['ping-send'])
    ping['actionInvokeBody'] = body(ix, L['action-invoke'])
    facts['ping'] = ping
    # 2. Exact-dispatch closures for each fixed command root.
    sinks = [L[k] for k in L]
    closures, cores = {}, {}
    for command, (role, runtime_role) in COMMANDS.items():
        ref = members[role]
        if runtime_role is None:
            runtime = None
        elif runtime_role.startswith('@'):
            runtime = L[runtime_role[1:]][0] if runtime_role[1:] in L else None
        else:
            runtime = types[runtime_role]
        owner = ix.resolve(runtime, *ref[1:]) if runtime else ix.resolve(*ref)
        root = (owner, ref[1], ref[2], runtime)
        t0 = time.perf_counter()
        try:
            r = closure(ix, [root], sinks)
        except Refusal as error:
            closures[command] = {'root': list(root), 'refused': str(error)}
            continue
        cores[command] = [tuple(k) for k in r['core']]
        names = {v: k for k, v in L.items()}
        hits = {}
        for h in r['sinkHits']:
            label = names[tuple(h['sink'])]
            if label not in hits or len(h['chain']) < len(hits[label]['chain']):
                hits[label] = {'this': h['this'], 'chain': h['chain']}
        waits = [e for e in r['externalCalls'] if any(w in e[0][0] + '.' + e[0][1] or w == e[0][1] for w in WAITS)]
        closures[command] = {'root': list(root), 'coreMethods': r['coreMethods'], 'edges': r['edges'],
                             'frontierSites': r['frontierSites'], 'openReceiverSites': r['openReceiverSites'],
                             'labelsInCore': sorted(hits), 'labelChains': hits, 'blockingOrQueueExternals': waits,
                             'frontier': r['frontier'], 'elapsedMs': round((time.perf_counter() - t0) * 1000, 3)}
    facts['closures'] = closures
    # 3. Lock collectors.
    memo = {}
    opener = body(ix, L['opener'])
    default_field = field_at(ix, L['implicit-begin'], 4)
    shared_field = field_at(ix, L['default-collect'], 31)
    facts['locks'] = {
        'opener': {'isEmptyTests': [r for r in opener['instructions'] if len(r) > 2 and 'isEmpty' in str(r[2])],
                   'branches': [r for r in opener['instructions'] if r[1] in (153, 154, 158)],
                   'lockWaitCalls': [r[0] for r in opener['instructions'] if len(r) > 2 and r[2] == list(L['lock-wait'])],
                   'collectCalls': [r[0] for r in opener['instructions'] if len(r) > 2 and r[2] == list(L['collect'])]},
        'defaultCollectorField': list(default_field), 'defaultCollectorExact': sorted(map(str, exact_field(ix, *default_field[:2], memo)[0] or [])),
        'defaultCollectorWriters': [[list(k), o] for k, o in ix.field_writes(*default_field[:2])],
        'sharedCollectorField': list(shared_field), 'sharedCollectorWriters': [[list(k), o] for k, o in ix.field_writes(*shared_field[:2])],
        'defaultCollectBody': body(ix, L['default-collect']),
        'collectCallers': ix.callers(*L['collect']), 'fillVirtualCallers': [r for r in ix.callers(*L['collect-fill']) if r['opcode'] != 183],
        'defaultFillBody': body(ix, (L['default-collect'][0], L['collect-fill'][1], L['collect-fill'][2])),
        'deleteFill': body(ix, L['delete-fill']), 'lockWait': body(ix, L['lock-wait']), 'lockCallback': body(ix, L['lock-callback'])}
    begins = {}
    begin_ref = members['begin']
    for command in ('value', 'cable', 'delete', 'boolean', 'remove-mapping', 'restore-mapping', 'insert', 'undo', 'dispose', 'factory', 'close'):
        core = cores.get(command, [])
        sites = []
        for node in core:
            cls, m = ix.code(node[0]), ix.method(*node[:3])
            for offset, op, args in instructions(m.code):
                if not 182 <= op <= 185:
                    continue
                ref = constant(cls, args[0] * 256 + args[1])
                if ref['name'] == begin_ref[1] and ref['descriptor'] == begin_ref[2]:
                    kind, src = value_source(cls, m, offset, 0)
                    shape = None
                    if kind == 'op' and src[1] == 189:
                        prev = [x for x in instructions(m.code) if x[0] < src[0]][-1]
                        shape = 'explicit-empty-array' if prev[1] == 3 else 'explicit-array-op' + str(prev[1])
                    sites.append({'site': [*node[:3], offset], 'array': shape or kind})
                if (ref['owner'], ref['name'], ref['descriptor']) in (L['implicit-begin'], L['set-begin']) or (
                        ref['name'] == L['opener'][1] and ref['descriptor'] == L['opener'][2]):
                    sites.append({'site': [*node[:3], offset], 'call': f"{ref['owner']}.{ref['name']}{ref['descriptor']}"})
        begins[command] = sites
    facts['locks']['beginSites'] = begins
    # 4. Manager identity.
    top = body(ix, L['manager-top'])
    rzi, stack = next(r[2] for r in top['instructions'] if r[1] == 180)[:2]
    reopen = body(ix, L['reopen'])
    efield = [r[2] for r in reopen['instructions'] if r[1] == 180 and r[2][2] == L['manager-top'][2][2:]][0]
    journal = body(ix, L['journal-for'])
    facts['manager'] = {
        'stackField': [rzi, stack], 'stackWriters': [[list(k), o] for k, o in ix.field_writes(rzi, stack)],
        'stackFlags': next(f.flags for f in ix.jar.classes[rzi].fields if f.name == stack),
        'stackUses': list_mutations(ix, rzi, stack),
        'push': body(ix, L['manager-push']), 'pop': body(ix, L['manager-pop']), 'change': body(ix, L['manager-change']),
        'pushCallers': ix.callers(*L['manager-push']), 'popCallers': ix.callers(*L['manager-pop']),
        'editManagerField': efield, 'editManagerWriters': [[list(k), o] for k, o in ix.field_writes(efield[0], efield[1])],
        'reopenCallers': ix.callers(*L['reopen']), 'recordChange': body(ix, L['record-change']),
        'recordChangeCallers': ix.callers(*L['record-change'])[:32], 'journalFor': journal,
        'documentManager': body(ix, L['document-manager'])}
    jowner, jname = next(r[2] for r in journal['instructions'] if r[1] == 180)[:2]
    facts['manager']['journalMapField'] = [jowner, jname]
    facts['manager']['journalMapUses'] = list_mutations(ix, jowner, jname)
    facts['manager']['journalMapWriters'] = [[list(k), o] for k, o in ix.field_writes(jowner, jname)]
    # 5. Validation fan-out.
    sfield = field_at(ix, L['validation-setting'], 1)
    facts['validation'] = {
        'hook': body(ix, L['validation-hook']), 'entry': body(ix, L['validation-entry']), 'body': body(ix, L['validation']),
        'project': body(ix, L['validation-project']), 'settingField': list(sfield),
        'settingExact': sorted(map(str, exact_field(ix, sfield[0], sfield[1], memo)[0] or [])),
        'settingWhy': exact_field(ix, sfield[0], sfield[1], memo)[1],
        'settingUses': list_mutations(ix, sfield[0], sfield[1]),
        'settingGetterCallers': ix.callers(*L['validation-setting']),
        'settingWrite': body(ix, L['setting-write']),
        'hookOwnerSubtypes': sorted(ix.subtypes(L['validation-hook'][0])),
        'documentSubtypes': sorted(ix.subtypes(types['edit-document']))}
    lfield = field_at(ix, L['validation-set-b'], 1)
    owner_cls = ix.code(lfield[0])
    getters = []
    for m in owner_cls.methods:
        ops = instructions(m.code)
        if len(ops) == 3 and ops[0][1] == 42 and ops[1][1] == 180 and ops[2][1] == 176:
            ref = constant(owner_cls, ops[1][2][0] * 256 + ops[1][2][1])
            if ref['name'] == lfield[1]:
                getters.append((lfield[0], m.name, m.desc))
    calls = [r for r in facts['validation']['body']['instructions'] if r[1] in (182, 183, 184, 185)]
    facts['validation'].update({'listenedField': list(lfield), 'listenedFieldUses': list_mutations(ix, lfield[0], lfield[1]),
                                'listenedGetterCallers': {'.'.join(g): ix.callers(*g) for g in getters},
                                'lastCall': calls[-1][2] if calls else None, 'bodyBytes': facts['validation']['body']['bytes']})
    sclass = facts['validation']['settingExact'][0] if facts['validation']['settingExact'] else None
    if sclass:
        getter = ix.resolve(sclass, 'getBoolValue', '()Z')
        facts['validation']['settingReadBody'] = body(ix, (getter, 'getBoolValue', '()Z')) if getter else None
    # 6. Pending runnables, replay, rollback, debug guard, and thread entry.
    facts['pending'] = {'run': body(ix, L['pending-run']), 'add': body(ix, L['pending-add']),
                        'addCallers': ix.callers(*L['pending-add']), 'record': body(ix, L['pending-record'])}
    facts['replay'] = {k: body(ix, L[k]) for k in ('replay-undo', 'replay-redo', 'replay-wait', 'replay-worker', 'replay-read', 'worker-submit', 'executor-put')}
    facts['rollback'] = {'undo': body(ix, L['undo']), 'journalUndo': body(ix, L['journal-undo'])}
    flag = field_at(ix, L['debug-enter'], 0)
    facts['debug'] = {k: body(ix, L[k]) for k in ('debug-enter', 'debug-exit', 'debug-begin', 'debug-check')}
    facts['debug']['flagField'] = list(flag)
    facts['debug']['flagFlags'] = next(f.flags for f in ix.jar.classes[flag[0]].fields if f.name == flag[1])
    facts['debug']['flagWriters'] = [[list(k), o] for k, o in ix.field_writes(flag[0], flag[1])]
    facts['debug']['enterCallers'] = len(ix.callers(*L['debug-enter']))
    facts['debug']['exitCallers'] = len(ix.callers(*L['debug-exit']))
    facts['thread'] = {'exec': body(ix, L['surface-exec']), 'documentThread': body(ix, L['surface-document-thread'])}
    facts['drain'] = {'contextDrain': body(ix, L['context-drain']), 'contextPump': body(ix, L['context-pump'])}
    facts['work'] = {'elapsedMs': round((time.perf_counter() - start) * 1000, 3), 'peakRssBytes': rss_bytes(),
                     'retainedCodeClasses': len(ix.cache), 'limits': vars(ix.limits)}
    jar.check()
    data = json.dumps(facts, indent=1, default=str).encode()
    if len(data) > 8 * 1024 ** 2:
        raise Refusal('part-report-limit')
    with open(part, 'xb') as f:
        f.write(data)
    print(build, 'elapsedMs', facts['work']['elapsedMs'], 'rss', facts['work']['peakRssBytes'], 'bytes', len(data))


def phase_b(build, part, reference_part, commands=('close', 'delete', 'value'), extras=True):
    """Second scan: pinned closures, undo frontier targets, and the edit writer queue."""
    start = time.perf_counter()
    path, sha = JARS[build]
    jar = Jar(Path(path))
    if jar.sha256 != sha:
        raise Refusal('jar-hash')
    first = json.loads(Path(reference_part).read_text())
    if first['sha256'] != sha:
        raise Refusal('phase-a-hash')
    ix = Index(jar)
    L = {k: tuple(v['key']) for k, v in first['labels'].items() if v['key']}
    sinks = [L[k] for k in L]
    closures = first['closures']
    facts = {'build': build, 'sha256': sha}
    # 2b. Conditional variants. Each pin is a runtime condition, not a trace result.
    names = {v: k for k, v in L.items()}
    hook_owner = L['validation-hook'][0]
    journal_doc = field_at(ix, L['record-change'], 7)  # journal -> edit document field
    pins = {tuple(journal_doc[:2]): {hook_owner}}
    pinned = {}
    for command in commands:
        if time.perf_counter() - start > 70:
            pinned[command] = {'skipped': 'time-budget'}
            continue
        root = tuple(closures[command]['root'])
        r = closure(ix, [root], sinks, pins=pins)
        hits = sorted({names[tuple(h['sink'])] for h in r['sinkHits']})
        pinned[command] = {'pins': r['pins'], 'coreMethods': r['coreMethods'], 'edges': r['edges'],
                           'frontierSites': r['frontierSites'], 'labelsInCore': hits,
                           'validationChain': next((h['chain'] for h in r['sinkHits'] if names[tuple(h['sink'])] == 'validation-setting'), None)}
    facts['pinnedDocumentClosures'] = pinned
    if not extras:
        facts['work'] = {'elapsedMs': round((time.perf_counter() - start) * 1000, 3), 'peakRssBytes': rss_bytes(),
                         'retainedCodeClasses': len(ix.cache)}
        jar.check()
        with open(part, 'xb') as f:
            f.write(json.dumps(facts, indent=1, default=str).encode())
        print(build, 'phase C elapsedMs', facts['work']['elapsedMs'], 'rss', facts['work']['peakRssBytes'])
        return
    change = closures['undo']
    change_rows = {}
    for row in change['frontier']:
        k = row[0]
        if k[0] != 'receiver-open' or k[5] > 16:
            continue
        for body_key in ix.hierarchy_targets(k[1], k[2], k[3]):
            try:
                r = closure(ix, [(*body_key, body_key[0])], sinks)
                change_rows['.'.join(body_key)] = {'slot': k[1:4], 'coreMethods': r['coreMethods'], 'frontierSites': r['frontierSites'],
                                                   'labelsInCore': sorted({names[tuple(h['sink'])] for h in r['sinkHits']})}
            except Refusal as error:
                change_rows['.'.join(body_key)] = {'slot': k[1:4], 'refused': str(error)}
    facts['undoFrontierTargets'] = change_rows
    worker_field = field_at(ix, L['worker-submit'], 33)
    rows = []
    for (wk, off) in ix.field_writes(worker_field[0], worker_field[1]):
        ins = body(ix, wk, 4000)['instructions']
        rows.append({'writer': list(wk), 'offset': off, 'before': [r for r in ins if off - 14 <= r[0] < off]})
    facts['replayWorker'] = {'field': list(worker_field), 'writers': rows,
                             'executorConstructors': [body(ix, (L['executor-put'][0], m.name, m.desc))['instructions']
                                                      for m in ix.code(L['executor-put'][0]).methods if m.name == '<init>']}
    facts['work'] = {'elapsedMs': round((time.perf_counter() - start) * 1000, 3), 'peakRssBytes': rss_bytes(),
                     'retainedCodeClasses': len(ix.cache)}
    jar.check()
    data = json.dumps(facts, indent=1, default=str).encode()
    if len(data) > 8 * 1024 ** 2:
        raise Refusal('part-report-limit')
    with open(part, 'xb') as f:
        f.write(data)
    print(build, 'phase B elapsedMs', facts['work']['elapsedMs'], 'rss', facts['work']['peakRssBytes'], 'bytes', len(data))


PING = ['ping-action', 'ping-send', 'ping-request', 'ping-wait', 'ping-registry', 'action-invoke', 'action-dispatch-slot',
        'ui-action', 'action-wrapper', 'protocol-request', 'connection-request']
GLOBAL_CONDITIONS = [
    'Class bytes are data. Runtime receivers, field values, listener sets, and queue contents are not observed.',
    'Reflection, Unsafe, serialization, native code, generated classes, and JDK callbacks are not modeled.',
    'Vendor assertions are disabled at run time (the assertion-gated branches are excluded only under this condition).',
    'Exact-dispatch core: a call enters only with an exact receiver or one in-jar hierarchy target. Every other site is a listed frontier edge.',
    'A frontier edge is open. It is neither an exclusion nor a proof of reachability.']


def tables(P):
    def labels_in(b, command, pinned=False):
        src = P[b]['pinnedDocumentClosures' if pinned else 'closures'].get(command, {})
        return set(src.get('labelsInCore', []))

    def key(b, label):
        return P[b]['labels'][label]['key']

    def ping_choke(b):
        f, c = P[b], P[b]['ping']['callers']
        one = lambda label, parent: c[label]['count'] == 1 and c[label]['virtual'][0]['caller'] == key(b, parent)
        slot = [r['caller'] for r in c['action-dispatch-slot']['virtual']] == [key(b, 'action-invoke')]
        handles = not any(f['ping']['handles'].values())
        case = f['ping']['case951Body'] and f['ping']['case951Body'][1][2][1] == key(b, 'ping-action')[1]
        return bool(one('ping-action', 'project-dispatch') and one('ping-send', 'ping-action') and one('ping-request', 'ping-send')
                    and one('ping-wait', 'ping-request') and slot and handles and case and c['action-invoke']['count'] == 4)

    def setting_exact(b):
        v = P[b]['validation']
        read = v.get('settingReadBody') or {}
        ops = [r[1] for r in read.get('instructions', [])]
        return (len(v['settingExact']) == 1 and [r['caller'] for r in v['settingGetterCallers']] == [key(b, 'validation-project')]
                and len(v['settingUses']) == 2 and ops == [42, 180, 172])

    def lock_default(b):
        k = P[b]['locks']
        return (k['defaultCollectorExact'] == [key(b, 'default-collect')[0]] and len(k['sharedCollectorWriters']) == 1
                and k['sharedCollectorWriters'][0][0][1] == '<clinit>' and all(r['caller'] == key(b, 'opener') for r in k['collectCallers'])
                and [r['caller'] for r in k['fillVirtualCallers']] == [key(b, 'collect')] and k['defaultFillBody']['instructions'] == [[0, 177]]
                and k['opener']['lockWaitCalls'] == [295])

    def begin_form(b, command):
        sites = P[b]['locks']['beginSites'].get(command, [])
        arrays = [x['array'] for x in sites if 'array' in x]
        calls = [x['call'] for x in sites if 'call' in x]
        if arrays and set(arrays) == {'explicit-empty-array'}:
            return 'explicit-empty-array'
        if any(c.endswith(key(b, 'implicit-begin')[2]) and key(b, 'implicit-begin')[1] in c for c in calls):
            return 'default-collector'
        if command == 'delete' and calls:
            return 'delete-collector'
        return 'no-begin-in-core' if not sites else 'other'

    def delete_fill_safe(b):
        ins = P[b]['locks']['deleteFill']['instructions']
        calls = [r[2] for r in ins if r[1] in (182, 185)]
        return len(calls) == 2 and calls[1][1] == P[b]['labels']['collect']['key'][1] or len(calls) == 2

    def manager_static(b):
        m = P[b]['manager']
        uses = [(u['method'][1], u['nextCall']) for u in m['stackUses']]
        adds = [u for u in uses if u[1] == 'add']
        removes = [u for u in uses if u[1] in ('remove', 'clear')]
        return (len(m['stackWriters']) == 1 and m['stackWriters'][0][0][1] == '<init>' and len(adds) == 2 and len(removes) == 1
                and len(m['editManagerWriters']) == 1 and m['editManagerWriters'][0][0][1] == '<init>'
                and [u['nextCall'] for u in m['journalMapUses'] if u['nextCall'] == 'put'] == ['put'])

    def no_manager_labels(b, command):
        return not ({'manager-push', 'manager-pop', 'manager-change', 'reopen', 'reopen-close'} & (labels_in(b, command) | labels_in(b, command, True)))

    def holds(fn, *args):
        return [b for b in ('old', 'new') if fn(b, *args)]

    rows = {}
    commands = list(P['new']['closures'])
    for command in commands:
        r = []
        core = {b: P[b]['closures'][command] for b in ('old', 'new')}
        r.append({'path': 'synchronous ping wait inside the exact-dispatch core', 'classification': 'excluded',
                  'witness': 'Ping wait has one caller chain: project dispatcher case 951 -> ping action -> ping send -> ping request -> wait loop. '
                             'The only virtual entry into the action slot is the action invoke method; no method handle targets the chain. '
                             'No ping label is in this command core.',
                  'conditions': ['exact-core receivers hold at run time', 'no reflective or native call into the chain'],
                  'build': [b for b in holds(lambda b: ping_choke(b) and not (set(PING) & labels_in(b, command)))]})
        def pinned_ok(b):
            row = P[b]['pinnedDocumentClosures'].get(command, {})
            return 'labelsInCore' in row and 'validation-setting' in row['labelsInCore'] and not (set(PING) & set(row['labelsInCore']))
        computed = all('labelsInCore' in P[b]['pinnedDocumentClosures'].get(command, {}) for b in ('old', 'new'))
        reaches = computed and all('validation-setting' in P[b]['pinnedDocumentClosures'][command]['labelsInCore'] for b in ('old', 'new'))
        if command in P['new']['pinnedDocumentClosures'] and computed and not reaches:
            r.append({'path': 'validation under the document pin', 'classification': 'excluded',
                      'witness': 'The pinned core of this command does not reach the validation body.', 'conditions': ['document pin'],
                      'build': ['old', 'new']})
        elif command in P['new']['pinnedDocumentClosures'] and not computed:
            r.append({'path': 'validation under the document pin', 'classification': 'retained-open',
                      'reason': 'The pinned closure did not run inside the scan budget.', 'build': ['old', 'new']})
        elif command in P['new']['pinnedDocumentClosures']:
            r.append({'path': 'journal close -> validation -> project setting read -> expression or action route to ping',
                      'classification': 'excluded',
                      'witness': 'With the edit document pinned to the project-document class, validation enters the core. The project setting field has one '
                                 'in-jar writer (a fresh setting object), one getter caller, and a field-read getter. No ping label enters the pinned core.',
                      'conditions': ['edit document runtime class equals the project-document class (guard not present in the doctor today)',
                                     'no reflective write to the validation setting field'],
                      'build': holds(lambda b: setting_exact(b) and pinned_ok(b)),
                      'notComputed': [b for b in ('old', 'new') if 'labelsInCore' not in P[b]['pinnedDocumentClosures'].get(command, {})]})
            if any(pinned_ok(b) for b in ('old', 'new')):
                v = {b: P[b]['validation'] for b in ('old', 'new')}
                r.append({'path': 'validation -> validation setting write -> listener fire', 'classification': 'bounded',
                          'bound': 'One change test and at most one fireValueChanged call over the listeners of the validation setting. '
                                   'The field has one getter, one getter caller (a value read), and no listener registration site in class data.',
                          'conditions': ['no reflective listener registration on this field'], 'build': holds(lambda b: setting_exact(b))})
                r.append({'path': 'validation -> validity setting write -> listener fire', 'classification': 'retained-open',
                          'reason': 'Getter callers register UI and application listeners; their number and bodies are runtime data. '
                                    'Needs a runtime listener count or more trace work on each getter caller.',
                          'getterCallers': {b: sum(len(x) for x in v[b]['listenedGetterCallers'].values()) for b in v},
                          'build': ['old', 'new']})
                same_tail = v['old']['lastCall'] == v['new']['lastCall']
                r.append({'path': 'validation end notification', 'classification': 'retained-open',
                          'reason': '6.1.4 validation body: %d bytes, last call %s. 6.0.6: %d bytes, last call %s. '
                                    'A changed tail call adds an observer notification on 6.1.4; observer sets are runtime data.' % (
                                        v['new']['bodyBytes'], v['new']['lastCall'], v['old']['bodyBytes'], v['old']['lastCall']),
                          'build': ['new'] if not same_tail else ['old', 'new']})
                r.append({'path': 'Undo and Redo availability notifications after close or undo', 'classification': 'retained-open',
                          'reason': 'They go through listener fire methods that are frontier sites in every core. Needs a runtime listener count.',
                          'build': ['old', 'new']})
        fr = {b: core[b].get('frontierSites') for b in ('old', 'new')}
        r.append({'path': 'ping, pump, or drain reached through a frontier edge (listener, pending runnable, parameter, collection, or abstract slot)',
                  'classification': 'retained-open',
                  'reason': 'Frontier receivers come from parameters, collections, listener lists, or multi-target slots. Their runtime targets are not '
                            'fixed by class data. Needs per-site provenance trace work or a runtime inventory of listeners and pending runnables.',
                  'bound': 'If reached, the ping wait loops on an untimed completion flag and pumps one context event per iteration: no work, '
                           'allocation, or wait bound.',
                  'frontierSites': fr,
                  'largestFrontierSlots': sorted(([x[0][1], x[0][2], x[0][3], x[0][5], x[1]] for x in core['new'].get('frontier', [])
                                                  if x[0][0] == 'receiver-open'), key=lambda x: -x[3])[:10],
                  'build': ['old', 'new']})
        form = {b: begin_form(b, command) for b in ('old', 'new')}
        if form['new'] == 'default-collector':
            r.append({'path': 'opener lock wait at offset 295 (default collector)', 'classification': 'excluded',
                      'witness': 'Default collector field has one writer storing a fresh default collector. It returns a shared static lock holder; '
                                 'the static field has one writer (class initializer); the fill override is empty; the collect slot has three callers, '
                                 'all in the opener; the fill slot has one virtual caller (base collect). The set stays empty, so branch 208 skips 295.',
                      'conditions': ['lock count 0 at entry (doctor witness reads it)', 'no reflective write into the shared lock set',
                                     'the journal begin notification does not add to the passed lock set'],
                      'build': holds(lambda b: lock_default(b) and begin_form(b, command) == 'default-collector')})
        elif form['new'] == 'explicit-empty-array':
            r.append({'path': 'opener lock wait at offset 295 (explicit empty lock array)', 'classification': 'excluded',
                      'witness': 'The begin call site pushes iconst_0; anewarray edit-lock. The set collector copies an empty set (E336 route).',
                      'conditions': ['lock count 0 at entry'], 'build': holds(lambda b: begin_form(b, command) == 'explicit-empty-array')})
        elif form['new'] == 'delete-collector':
            r.append({'path': 'opener lock wait at offset 295 (delete collector)', 'classification': 'excluded',
                      'witness': 'The delete collector inherits the allocating base collect. Its fill can only mark the holder invalid; it adds no lock. '
                                 'An invalid holder makes begin return false at offset 100 before any wait; the doctor then sees no new Undo head.',
                      'conditions': ['lock count 0 at entry'], 'build': holds(lambda b: begin_form(b, command) == 'delete-collector')})
        elif command == 'begin':
            r.append({'path': 'attach begin lock wait', 'classification': 'excluded',
                      'witness': 'The doctor passes Array.newInstance(edit-lock, 0); the set route copies an empty set.',
                      'conditions': ['lock count 0 at entry'], 'build': ['old', 'new']})
        else:
            r.append({'path': 'opener lock wait', 'classification': 'excluded',
                      'witness': 'No begin or opener call site is in this command core.', 'conditions': ['exact-core receivers hold'],
                      'build': holds(lambda b: begin_form(b, command) == 'no-begin-in-core')})
        r.append({'path': 'context manager change -> change hook -> end-of-event drain', 'classification': 'excluded',
                  'witness': 'Manager stack list is private final with one constructor writer; its only add sites are the constructor and the push '
                             'method, and its only remove site is the pop method. Push and pop call the change hook only for a different top. '
                             'No push, pop, change, or reopen label is in the command core, with or without the document pin. '
                             'Reopen paths (record-change, append, grid resize) push the edit manager, which has one constructor writer and equals '
                             'the journal key that selected the journal from the current top.',
                  'conditions': ['frontier edges do not push a different manager', 'journal map has only the one put site'],
                  'build': holds(lambda b: manager_static(b) and no_manager_labels(b, command))})
        labels = {b: labels_in(b, command) for b in ('old', 'new')}
        if 'pending-run' in labels['new']:
            r.append({'path': 'close -> pending runnable list -> Runnable.run', 'classification': 'retained-open',
                      'reason': 'The pending add method is not in any exact command core on either build, so in-core code adds no runnable. '
                                'Entry residue and frontier additions remain. The doctor does not read the pending list today: needs a runtime '
                                'observation (pending list size at entry and before close) or more trace work on the 11 add sites.',
                      'bound': 'k runnables run in order, k = pending list size at close; each body is unknown. The list clear is skipped when a runnable throws.',
                      'build': holds(lambda b: 'pending-run' in labels_in(b, command) and 'pending-add' not in labels_in(b, command))})
        if 'debug-enter' in labels['new'] or 'debug-begin' in labels['new']:
            r.append({'path': 'thread-local undo debug guard', 'classification': 'bounded',
                      'bound': 'Per bracket: at most 2 ThreadLocal.get calls and 2 integer updates; 1 ThreadLocal.get and 2 field reads per opener check. '
                               'The guard flag is private static final and set once in the document class initializer.',
                      'conditions': ['vendor assertions disabled (else the check can throw at begin)',
                                     'a throwing pending runnable leaves the counter raised on this thread'],
                      'build': holds(lambda b: P[b]['debug']['flagFlags'] == 26 and len(P[b]['debug']['flagWriters']) == 1)})
        if 'worker-submit' in labels['new']:
            r.append({'path': ('undo replay worker submit' if command == 'undo' else 'close -> edit writer submit') + ' -> bounded queue put',
                      'classification': 'bounded',
                      'bound': 'One untimed LinkedBlockingQueue.put. It waits only when the writer queue is full (capacity from the writer constructor). '
                               'An interrupt drops the task after a log call.',
                      'conditions': ['writer thread makes progress'], 'build': ['old', 'new']})
        if 'replay-wait' in labels['new']:
            same = P['old']['replay'] and all(P['old']['replay'][k]['handlers'] == P['new']['replay'][k]['handlers'] for k in P['new']['replay'])
            r.append({'path': 'undo -> journal undo -> replay -> Semaphore(0) acquire', 'classification': 'retained-open',
                      'reason': 'Untimed acquire on the document thread. The worker releases only after a normal return of the file read. '
                                'EOF and IOException are caught (release happens). Other Throwable types, and failures before the try range, skip the release. '
                                'An interrupted queue put drops the worker task. This needs a runtime failure observation or acceptance as a parity limit; '
                                'it cannot be closed offline.',
                      'bound': 'Normal path: one edit-file read on the worker; wait = queue backlog plus read time. Failure path: unbounded.',
                      'parity': 'identical handler tables on both builds' if same else 'handler tables differ',
                      'build': ['old', 'new']})
            r.append({'path': 'undo partial failure state', 'classification': 'bounded',
                      'bound': 'Undo sets the undoing flag, then calls journal undo; journal undo sets the replay head, replays, then clears it. '
                               'Neither method has a handler: a failure leaves both flags set. Keep the uncertain-state latch.',
                      'build': holds(lambda b: not P[b]['rollback']['undo']['handlers'] and not P[b]['rollback']['journalUndo']['handlers'])})
        rows[command] = r
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--build')
    ap.add_argument('--part')
    ap.add_argument('--labels')
    ap.add_argument('--phase', default='A')
    a = ap.parse_args()
    if a.build and a.phase == 'B':
        phase_b(a.build, a.part, a.labels)
        return
    if a.build and a.phase == 'C':
        phase_b(a.build, a.part, a.labels, ('cable', 'begin'), False)
        return
    if a.build:
        reference = json.loads(Path(a.labels).read_text())['labels'] if a.labels else None
        worker(a.build, a.part, reference)
        return
    base = Path(f'/tmp/gn-9b6g-command-closure-{N}')
    parts = {b: Path(f'{base}-{b}.json') for b in ('new', 'old')}
    second = {b: Path(f'{base}-{b}-pinned.json') for b in ('new', 'old')}
    third = {b: Path(f'{base}-{b}-pinned-2.json') for b in ('new', 'old')}
    for b in ('new', 'old'):
        cmd = [sys.executable, '-B', __file__, '--build', b, '--part', str(parts[b])]
        if b == 'old':
            cmd += ['--labels', str(parts['new'])]
        subprocess.run(cmd, check=True)
        subprocess.run([sys.executable, '-B', __file__, '--build', b, '--phase', 'B', '--part', str(second[b]),
                        '--labels', str(parts[b])], check=True)
        subprocess.run([sys.executable, '-B', __file__, '--build', b, '--phase', 'C', '--part', str(third[b]),
                        '--labels', str(parts[b])], check=True)
    P = {b: json.loads(parts[b].read_text()) for b in parts}
    for b in P:
        P[b].update({k: v for k, v in json.loads(second[b].read_text()).items() if k not in ('build', 'sha256', 'work')})
        P[b]['workPinned'] = json.loads(second[b].read_text())['work']
        extra = json.loads(third[b].read_text())
        P[b]['pinnedDocumentClosures'].update(extra['pinnedDocumentClosures'])
        P[b]['workPinned2'] = extra['work']
    label_parity = {k: {'old': P['old']['labels'][k].get('key'), 'how': P['old']['labels'][k]['how'],
                        'bodyEqual': P['old']['labels'][k].get('fingerprintEqual')} for k in P['new']['labels']}
    report = {'boundedAdmission': False, 'runtimeClassesInitialized': 0, 'writeAuthority': False, 'completeTable': False,
              'jars': {b: P[b]['sha256'] for b in P}, 'conditions': GLOBAL_CONDITIONS,
              'labels': {k: P['new']['labels'][k]['key'] for k in P['new']['labels']}, 'labelParity': label_parity,
              'bodyDifferences': [k for k, v in label_parity.items() if v['bodyEqual'] is False],
              'branchTables': tables(P),
              'closureSummary': {b: {c: {k: v for k, v in r.items() if k in ('root', 'coreMethods', 'edges', 'frontierSites',
                                                                               'openReceiverSites', 'labelsInCore', 'elapsedMs', 'refused')}
                                     for c, r in P[b]['closures'].items()} for b in P},
              'pinned': {b: P[b]['pinnedDocumentClosures'] for b in P},
              'undoFrontierTargets': {b: P[b]['undoFrontierTargets'] for b in P},
              'replayWorker': {b: P[b]['replayWorker'] for b in P},
              'parts': {b: [{'path': str(x), 'sha256': hashlib.sha256(x.read_bytes()).hexdigest(), 'bytes': x.stat().st_size}
                            for x in (parts[b], second[b], third[b])] for b in P},
              'work': {b: {'phaseA': P[b]['work'], 'phaseB': P[b]['workPinned'], 'phaseC': P[b]['workPinned2']} for b in P},
              'limits': {'sites': 1000000, 'edgesPerClosure': 16384, 'nodesPerClosure': 4096, 'codeClasses': 256,
                         'secondsPerScan': 120, 'rssBytes': 768 * 1024 ** 2, 'reportBytes': 8 * 1024 ** 2}}
    data = (json.dumps(report, indent=1, default=str) + '\n').encode()
    if len(data) > 8 * 1024 ** 2:
        raise Refusal('report-limit')
    out = Path(f'{base}.json')
    with out.open('xb') as f:
        f.write(data)
    print('report', out, len(data), hashlib.sha256(data).hexdigest())


if __name__ == '__main__':
    main()
