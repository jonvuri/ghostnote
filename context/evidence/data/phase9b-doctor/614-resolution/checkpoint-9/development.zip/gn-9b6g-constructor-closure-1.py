import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,instructions,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.assertion_guards import requirements
from grid_doctor.dispatch_paths import reachable
from grid_doctor.descriptor_builders import lookup
from grid_doctor.migrate import member
from grid_doctor.ownership import constant,method_trace,bootstraps
start=time.perf_counter();j=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));code=Code();src=json.load(open('/tmp/gn-9b6g-factory-constructor-census-1.json'));todo=[(m['owner'],m['name'],m['descriptor'])for m in src['methods']];seen=set();rows=[];traces=[]
while todo:
 key=todo.pop()
 if key in seen:continue
 if len(seen)>=512:raise Refusal('constructor-closure-method-limit')
 seen.add(key);c=code.get(j,key[0]);m=member(c,*key[1:]);guard=requirements(j,{c.name},code);selected=reachable(c,m,None,set(map(tuple,guard['fields'])));calls=[];allocations=[];backedges=[]
 for off,op,args in instructions(m.code):
  if off not in selected:continue
  if op in(182,183,184,185,186,187,188,189,197):
   ref=constant(c,int.from_bytes(bytes(args[:2]),'big'))if op!=188 else{'arrayType':args[0]}
   item={'offset':off,'opcode':op,'reference':ref}
   if op in(187,188,189,197):allocations.append(item)
   else:
    if op in(183,184)and ref['owner']in j.classes:
     cc,mm=lookup(j,code,ref['owner'],ref['name'],ref['descriptor']);item['directTarget']=[cc.name,mm.name,mm.desc];todo.append((cc.name,mm.name,mm.desc))
    calls.append(item)
  if op in(*range(153,169),198,199,200,201)and off+int.from_bytes(bytes(args),'big',signed=True)<=off:backedges.append(off)
 rows.append({'method':list(key),'selectedInstructions':len(selected),'assertionGuards':guard['fields'],'calls':calls,'allocations':allocations,'backedges':backedges,'handlers':m.handlers});traces.append(method_trace(j,c,m,bootstraps(j.zip.read(c.name+'.class'),c)))
r={'sha256':j.sha256,'rows':rows,'methods':traces,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False};raw=json.dumps(r,separators=(',',':')).encode()
if len(raw)>8*1024**2:raise Refusal('constructor-closure-report-limit')
Path('/tmp/gn-9b6g-constructor-closure-1.json').write_bytes(raw);print('methods',len(rows),'branches',[(x['method'],x['backedges'],x['handlers'])for x in rows if x['backedges']or x['handlers']]);print('virtual and dynamic',[(x['method'],c)for x in rows for c in x['calls']if c['opcode']in(182,185,186)]);print('external',sorted({(c['reference']['owner'],c['reference']['name'],c['reference']['descriptor'])for x in rows for c in x['calls']if'owner'in c['reference']and c['reference']['owner']not in j.classes}));print(len(raw),r['elapsedMs'],r['peakRssBytes'])
