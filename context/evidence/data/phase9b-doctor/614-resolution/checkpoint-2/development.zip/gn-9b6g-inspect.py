import json,zipfile,sys
from pathlib import Path
from grid_symbols.scan import parse
from grid_doctor.ownership import bootstraps,method_trace
from grid_doctor.migrate import member
OLD=Path('/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar')
NEW=Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar')
class Data:
 def __init__(self,p): self.zip=zipfile.ZipFile(p)
 def code(self,n):return parse(self.zip.read(n+'.class'),True)
jar=Data(OLD if sys.argv[1]=='old' else NEW)
for name in sys.argv[2:]:
 cls=jar.code(name)
 print('\nCLASS',name,'parent',cls.parent,'interfaces',cls.interfaces)
 print('FIELDS',[(f.name,f.desc,f.flags) for f in cls.fields])
 print('METHODS',[(m.name,m.desc,m.flags,len(m.code)) for m in cls.methods])
 for m in cls.methods:
  if m.name!='<clinit>':continue
  t=method_trace(jar,cls,m,bootstraps(jar.zip.read(name+'.class'),cls))
  print(json.dumps(t,indent=1))
