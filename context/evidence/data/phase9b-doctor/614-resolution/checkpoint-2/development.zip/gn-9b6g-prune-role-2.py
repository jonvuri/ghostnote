import copy,json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal
from grid_doctor.descriptor_resolution import Code,extend
D=Path('context/evidence/data/phase9b-doctor');plan=json.load(open('/tmp/gn-9b6g-pruned-plan-2.json'));report=json.load(open('/tmp/gn-9b6g-resolution-3.json'));seeds=json.load(open(D/'614-bindings/bindings.json'));candidate=json.load(open(D/'v20-preparation/candidate.json'))
old=Jar(Path('/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar'));new=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));code=Code()
def identities(b):return b['types'],[(r['role'],r['reference'],r['status'])for r in b['members']]
expected=identities(report['builds'][1]);checks=[];work=0
for category in ('roleWitnesses',):
 tested={tuple(x['source']) for x in json.load(open('/tmp/gn-9b6g-prune-checks-2.json'))['checks']}
 for row in [r for r in plan[category] if tuple(r['source']) not in tested][:20]:
  new.check();trial=copy.deepcopy(plan);trial[category].remove(row)
  try:
   result=extend(old,new,candidate,seeds['builds'][1],trial,report['censuses'][1],code)
   work+=result['work']['comparisons']
   if work>100000:raise Refusal('prune-comparison-limit')
   equal=identities(result)==expected
  except Refusal as e:
   if str(e).endswith('-limit') or 'deadline'in str(e):raise
   equal=False
  if equal:plan=trial
  checks.append({'category':category,'source':row['source'],'removed':equal})
 print(category,len(plan[category]),flush=True)
Path('/tmp/gn-9b6g-pruned-plan-3.json').write_text(json.dumps(plan,indent=2)+'\n');Path('/tmp/gn-9b6g-prune-checks-3.json').write_text(json.dumps({'checks':checks,'comparisons':work},indent=2)+'\n')
