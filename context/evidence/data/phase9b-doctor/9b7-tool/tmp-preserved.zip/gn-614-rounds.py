exec(open('/tmp/gn-614-survey.py').read().split('index=defaultdict')[0])
def rounds(jar):
    ks={n:digest(class_shape(c,lambda x:'vendor' if x in jar.classes else x)) for n,c in jar.classes.items()}; out=[ks]
    for i in range(2):
        prev=ks;ks={n:digest(class_shape(c,lambda x:prev.get(x,x))) for n,c in jar.classes.items()};out.append(ks)
    return out
olds,news=rounds(old),rounds(new)
for role, n in prior['types'].items():
    pools=[[x for x,k in b.items() if k==a[n]] for a,b in zip(olds,news)]
    print(role,n,[len(p) for p in pools],pools[0] if len(pools[0])<4 else '')
for a,b in [('QY','RuU'),('Xuo','Qe')]:
    print('PAIR',a,b,'round keys',[x[a]==y[b] for x,y in zip(olds,news)])
    ac,bc=old.classes[a],new.classes[b]
    ash=class_shape(ac,lambda x:'vendor' if x in old.classes else x)
    bsh=class_shape(bc,lambda x:'vendor' if x in new.classes else x)
    print('counts',len(ac.fields),len(bc.fields),len(ac.methods),len(bc.methods))
    print('removed method shapes',list((Counter(tuple(x) for x in ash[-1])-Counter(tuple(x) for x in bsh[-1])).elements()))
    print('added method shapes',list((Counter(tuple(x) for x in bsh[-1])-Counter(tuple(x) for x in ash[-1])).elements()))
