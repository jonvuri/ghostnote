import json,time
from pathlib import Path
from grid_symbols.scan import Jar,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.callee_contracts import compare_callees
from grid_doctor.migrate import merge
from grid_doctor.fixed_read_checkpoint import membership_variants
start=time.perf_counter();paths=['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'];jars=[Jar(Path(p))for p in paths];code=Code();seeds=[json.load(open('/tmp/gn-9b6g-resolution-5.json'))['builds'][1],json.load(open('/tmp/gn-9b6g-factory-owned-1.json'))['builds'][1]['contracts']]
known=[{},{}]
for s in seeds:known=merge(known,[s['typeBindings'],{tuple(r['source']):tuple(r['target'])for r in s['memberBindings']}])
seed={'typeBindings':known[0],'memberBindings':[{'source':list(k),'target':list(v)}for k,v in known[1].items()]};traces=json.load(open('/tmp/gn-9b6g-lifecycle-slots-2.json'))['methods'];r=compare_callees(*jars,traces,seed,code);r.update(elapsedMs=(time.perf_counter()-start)*1000,peakRssBytes=rss_bytes());Path('/tmp/gn-9b6g-lifecycle-contracts-1.json').write_text(json.dumps(r,indent=2)+'\n');print('matched',len(r['matched']),'unmatched',r['unmatched']);print(r['elapsedMs'],r['peakRssBytes'])
