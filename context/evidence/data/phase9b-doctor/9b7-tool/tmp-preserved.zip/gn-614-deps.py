exec(open('/tmp/gn-614-rounds.py').read().split('for role, n')[0])
import re
for a,b in [('QY','RuU'),('Xuo','Qe')]:
    def refs(c):return set([c.parent,*c.interfaces,*[n for m in c.fields+c.methods for n in re.findall('L([^;]+);',m.desc)]])
    print(a,b)
    for n in sorted(refs(old.classes[a])):
        if n not in old.classes:continue
        matches=[x for x in refs(new.classes[b]) if x in new.classes and olds[0][n]==news[0][x]]
        if len(matches)!=1:print('changed/ambiguous reference',n,'matches',matches)
        elif olds[1][n]!=news[1][matches[0]]:print('one-hop drift',n,matches[0])
