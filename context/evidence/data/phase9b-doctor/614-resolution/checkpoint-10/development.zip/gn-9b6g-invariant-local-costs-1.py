import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,instructions,ancestors,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.descriptor_builders import lookup
from grid_doctor.assertion_guards import requirements
from grid_doctor.dispatch_paths import reachable
from grid_doctor.ownership import constant
start=time.perf_counter();j=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));code=Code();wrappers={x['propertyClass']:x for x in json.load(open('/tmp/gn-9b6g-invariant-bounds-2.json'))['rows']};reads={(x['classId'],x['propertyId']):x for x in json.load(open('/tmp/gn-9b6g-invariant-direct-reads-1.json'))['paths']};owned=json.load(open('/tmp/gn-9b6g-builder-owned-flow-2-1.json'))['paths']+json.load(open('/tmp/gn-9b6g-default-flows-2.json'))['builds'][1]['owned']['paths'];collectors={(x['classId'],x['propertyId']):x for x in owned};reports=[json.load(open('/tmp/gn-9b6g-builder-property-bindings-3-0.json'))]+[json.load(open('/tmp/gn-9b6g-builder-property-bindings-4-'+str(i)+'.json'))for i in range(9)]+[json.load(open('/tmp/gn-9b6g-default-property-bindings-2-1.json'))];props=[r for x in reports for r in x['properties']];results=[];traces={}
for row in props:
 for p in row['properties']:
  typ=p['targetClass']
  if typ not in wrappers:continue
  w=wrappers[typ]['bound'];key=(row['id'],p['id']);active=set()
  def evaluate(owner):
   c,m=lookup(j,code,owner,'hUR','(Lcom/bitwig/ramona/core/oDc;)V');identity=(c.name,m.name,m.desc)
   if identity in active:raise Refusal('invariant-cost-recursion')
   active.add(identity);g=requirements(j,{c.name},code);selected=reachable(c,m,None,set(map(tuple,g['fields'])));body=[x for x in instructions(m.code)if x[0]in selected];traces[identity]={'method':list(identity),'selectedInstructions':len(body),'guards':g['fields']};v={'vendorInstructions':len(body),'vendorCalls':0,'externalCalls':0,'perChildInstructions':0,'perChildExternalCalls':0,'explicitObjects':0,'iteratorAllocations':0}
   if c.name=='dfb':
    # Keep the loop body under disabled assertions. It has no vendor call.
    loop=[x for x in body if 70<=x[0]<=178]
    if len(loop)!=12 or [x[1]for x in loop]!=[45,185,153,45,185,192,58,178,154,178,154,167]:raise Refusal('invariant-cost-relationship-loop')
    v['perChildInstructions']=12;v['perChildExternalCalls']=2;v['iteratorAllocations']=1
   for off,op,args in body:
    if op in(*range(153,169),198,199,200)and off+int.from_bytes(bytes(args),'big',signed=True)<=off and(c.name,off)!=('dfb',178):raise Refusal('invariant-cost-loop')
    if op not in(182,183,184,185,186):continue
    ref=constant(c,int.from_bytes(bytes(args[:2]),'big'))
    if op==183 and ref['name']=='hUR'and ref['descriptor']==m.desc:
     child=evaluate(ref['owner']);v['vendorCalls']+=1
     for field,n in child.items():v[field]+=n
    elif op==182 and ref['descriptor']=='(Lcom/bitwig/ramona/core/oDc;)Lcom/bitwig/ramona/core/uzc;':
     bc,bm=lookup(j,code,typ,ref['name'],ref['descriptor']);raw=instructions(bm.code)
     if [x[1]for x in raw]!=[42,43,182,176]or bm.handlers:raise Refusal('invariant-cost-wrapper-bridge')
     called=constant(bc,int.from_bytes(bytes(raw[2][2]),'big'));factory=w['factory']
     if (called['owner'],called['name'],called['descriptor'])!=(factory['owner'],factory['name'],factory['descriptor']):raise Refusal('invariant-cost-wrapper-target')
     v['vendorInstructions']+=len(raw)+w['constructorInstructionBound'];v['vendorCalls']+=2+w['vendorConstructorCalls'];v['externalCalls']+=1;v['explicitObjects']+=1
    elif op==182 and ref['name']=='ar_'and ref['descriptor']=='()V'and c.name=='deZ':
     vc,vm=lookup(j,code,wrappers[typ]['wrapper'],ref['name'],ref['descriptor'])
     if list(vm.code)!=[177]or vm.handlers:raise Refusal('invariant-cost-wrapper-invariant')
     v['vendorInstructions']+=1;v['vendorCalls']+=1
    elif op==182 and ref['descriptor'].startswith('(Lcom/bitwig/ramona/core/oDc;)')and key in reads:
     read=reads[key]
     if [ref['owner'],ref['name'],ref['descriptor']]!=read['entry']:raise Refusal('invariant-cost-read-target')
     for field,n in read['normalReadBound'].items():v[field]+=n
     v['vendorCalls']+=1
    elif c.name=='dfb'and op==182 and ref['name']=='Hnt'and ref['descriptor']=='(Lcom/bitwig/ramona/core/oDc;Ljava/lang/String;)Ljava/util/List;':
     hc,hm=lookup(j,code,typ,ref['name'],ref['descriptor']);raw=instructions(hm.code)
     if hc.name!='dfb'or [x[1]for x in raw]!=[187,89,183,78,42,43,45,44,182,45,176]:raise Refusal('invariant-cost-fresh-list')
     if key not in collectors:raise Refusal('invariant-cost-collector-missing')
     bound=collectors[key]['normalCollectorBound']
     for field,n in bound.items():v[field]+=n
     v['vendorInstructions']+=len(raw);v['vendorCalls']+=2;v['externalCalls']+=1;v['explicitObjects']+=1
    elif c.name=='dfb'and op==182 and ref['name']=='ODA'and ref['descriptor']=='()LcUb;':
     gc,gm=lookup(j,code,typ,ref['name'],ref['descriptor'])
     if [x[1]for x in instructions(gm.code)]!=[42,180,176]or gm.handlers:raise Refusal('invariant-cost-ownership-getter')
     v['vendorInstructions']+=3;v['vendorCalls']+=1
    elif c.name=='dfb'and op==185 and ref['owner']in('java/util/List','java/util/Iterator')and ref['name']in('isEmpty','iterator','hasNext','next'):
     v['externalCalls']+=1
    else:raise Refusal('invariant-cost-open-call:'+str((identity,off,ref)))
   active.remove(identity);return v
  cost=evaluate(typ);results.append({'className':row['name'],'classId':row['id'],'propertyName':p['name'],'propertyId':p['id'],'propertyClass':typ,'cost':cost})
r={'sha256':j.sha256,'paths':results,'localMethods':list(traces.values()),'boundedAdmission':False,'runtimeObserved':False,'conditions':['Exact initialized descriptors, property identities, and disabled assertion flags.','N bounds each fresh relationship output list. The constant sum includes one loop body and can overestimate.','Exact list implementations and stable source collections require separate guards.','External bodies, root descriptor loops, lock properties, class initialization, and failure paths remain separate.'],'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes()};raw=json.dumps(r,indent=2).encode()
if len(raw)>8*1024**2:raise Refusal('invariant-local-report-limit')
Path('/tmp/gn-9b6g-invariant-local-costs-1.json').write_bytes(raw);print('paths',len(results),'methods',len(traces));print('max',{k:max(x['cost'][k]for x in results)for k in results[0]['cost']});print(len(raw),r['elapsedMs'],r['peakRssBytes'])
