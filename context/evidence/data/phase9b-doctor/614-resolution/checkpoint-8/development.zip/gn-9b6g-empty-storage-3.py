import json,time,hashlib
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.empty_storage import empty_list_references
from grid_doctor.admission import validate_seed
start=time.perf_counter();code=Code();out=[]
for i,path in enumerate(['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar']):
 j=Jar(Path(path));scan=json.load(open('/tmp/gn-9b6g-'+('old-'if i==0 else'')+'invariant-storage-1.json'));p=Path('context/evidence/data/phase9b-doctor/614-resolution/'+('old-'if i==0 else'')+'invariant-storage-plan.json');raw=p.read_bytes();plan=json.loads(raw);field=('cXV','MkF','Ljava/util/List;')if i==0 else('der','wGc','Ljava/util/List;')
 if hashlib.sha256(raw).hexdigest()!=scan['inputHashes']['plan']or not any((r['owner'],r['name'],r['descriptor'])==field for r in plan['targets']):raise Refusal('empty-storage-plan')
 validate_seed(j,scan);r=empty_list_references(j,code,field,scan);out.append(r)
r={'builds':out,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False};Path('/tmp/gn-9b6g-empty-storage-3.json').write_text(json.dumps(r,indent=2)+'\n');print(r)
