import json,time
from pathlib import Path
from grid_symbols.scan import Jar,rss_bytes,descriptor
from grid_doctor.descriptor_resolution import Code
from grid_doctor.descriptor_builders import lookup
from grid_doctor.listener_removal import removal_contract
from grid_doctor.renamed_fixture import rename_member
start=time.perf_counter();code=Code();rows=[]
inputs=[('/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','rHF','Npn',None),('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar','TT','foz',None),('/tmp/gn-9b6g-old-renamed-extra.jar','rHF','Npn','/tmp/gn-9b6g-old-renamed-map.json'),('/tmp/gn-9b6g-renamed-extra.jar','TT','foz','/tmp/gn-9b6g-renamed-map.json')]
for path,owner,arg,mapping in inputs:
 names=json.load(open(mapping))if mapping else{};key=(names.get(owner,owner),rename_member('removeListener')if mapping else'removeListener',descriptor('(L'+arg+';)V',lambda n:names.get(n,n)));j=Jar(Path(path));c,m=lookup(j,code,*key);r=removal_contract(j,code,c,m);rows.append({'sha256':j.sha256,'bound':r});print(r['storageForm'],r['ownInstructionBound']);del j
r={'builds':rows,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False};Path('/tmp/gn-9b6g-listener-removal-bounds-1.json').write_text(json.dumps(r,indent=2)+'\n');print(r['elapsedMs'],r['peakRssBytes'])
