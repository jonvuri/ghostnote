"""Ad-hoc: callers of several methods, including MethodHandle constants (lambdas). Reads class bytes as data."""
import sys
sys.path.insert(0, '/Users/jonvuri/Development/ghostnote/brain/src/probes')
from grid_symbols.scan import Jar, parse, instructions
from pathlib import Path
jar = Jar(Path(sys.argv[1])); wanted = {tuple(w.split('#')) for w in sys.argv[2:]}  # owner#name#desc or #name#desc
names = {w[1] for w in wanted}
for entry in jar.zip.namelist():
    if not entry.endswith('.class'): continue
    data = jar.zip.read(entry)
    if not any(n.encode() in data for n in names): continue
    cls = parse(data, True)
    # method handle constants
    for i, item in enumerate(cls.cp):
        if item is None: continue
        tag, val = item
        if tag == 15:
            kind, ref = val; t2, v2 = cls.cp[ref]
            if t2 in (9,10,11):
                owner, nt = v2; owner = cls.cp[cls.cp[owner][1]][1]; ni, di = cls.cp[nt][1]
                for w in wanted:
                    if (w[0] in ('', owner)) and (cls.cp[ni][1], cls.cp[di][1]) == (w[1], w[2]):
                        print(f'HANDLE in {cls.name}: kind={kind} {owner}.{w[1]}{w[2]}')
    for m in cls.methods:
        if not m.code: continue
        for off, op, args in instructions(m.code):
            if op in (182,183,184,185):
                owner, nt = cls.cp[args[0]*256+args[1]][1]; owner = cls.cp[cls.cp[owner][1]][1]
                ni, di = cls.cp[nt][1]; n, d = cls.cp[ni][1], cls.cp[di][1]
                for w in wanted:
                    if (w[0] in ('', owner)) and (n, d) == (w[1], w[2]):
                        print(f'CALL {op} {owner}.{n}{d} in {cls.name}.{m.name}{m.desc} flags={m.flags}')
