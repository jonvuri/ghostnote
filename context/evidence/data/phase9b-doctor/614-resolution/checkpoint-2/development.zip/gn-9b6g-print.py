import json,sys
r=json.load(open(sys.argv[1]));methods=r.get('methods',r.get('traces',[]))
if 'builds'in r:methods=r['builds'][int(sys.argv[2])]['traces']; names=sys.argv[3:]
else:names=sys.argv[2:]
for row in methods:
 m=row.get('trace',row); key=m['owner']+'.'+m['name']+m['descriptor']
 if names and not any(n in key for n in names):continue
 print('\n',key,m['flags'],'handlers',m['exceptionHandlers'])
 for x in m['instructions']:
  print(x['offset'],x['opcode'],x.get('constant',x['args']))
