import json,zipfile,time
from collections import defaultdict
from pathlib import Path
from grid_symbols.scan import Jar,descriptor,Refusal,instructions
from grid_doctor.contracts import contract,signature_key
from grid_doctor.migrate import member,bindings,merge
from grid_doctor.descriptor_resolution import Code
from grid_doctor.fixed_descriptors import integer
from grid_doctor.ownership import constant,method_trace,bootstraps
start=time.perf_counter();z=zipfile.ZipFile('context/evidence/data/phase9b-doctor/live-v20/captures.zip');props=defaultdict(dict)
def visit(o):
 if isinstance(o,dict):
  if {'className','classId','properties'}<=o.keys():
   for p in o['properties']:
    if 'descriptorClass'in p:props[o['className'],o['classId']][p['name'],p['id']]=p['descriptorClass'].replace('.','/')
  for v in o.values():visit(v)
 elif isinstance(o,list):
  for v in o:visit(v)
for n in z.namelist():visit(json.loads(z.read(n)))
print('property pairs',sum(len(p)for p in props.values()),flush=True)
cat=json.load(open('/tmp/gn-9b6g-fixed-1.json'));res=json.load(open('/tmp/gn-9b6g-resolution-3.json'))
old=Jar(Path('/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar'));new=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));code=Code();known=[res['builds'][1]['typeBindings'],{tuple(r['source']):tuple(r['target'])for r in res['builds'][1]['memberBindings']}]
for a,b in zip(cat['builds'][0]['rows'],cat['builds'][1]['rows']):
 am,bm=a['matches'][0],b['matches'][0]
 known=merge(known,[{am['runtimeClass']:bm['runtimeClass'],am['descriptor']:bm['descriptor']},{}])
 ao,bo=am['descriptor'],bm['descriptor']
 for depth in range(128):
  ao,bo=old.classes[ao].parent,new.classes[bo].parent
  if ao not in old.classes or bo not in new.classes:break
  known=merge(known,[{ao:bo},{}])
results=[];count=0
for a,b in zip(cat['builds'][0]['rows'],cat['builds'][1]['rows']):
 pair=a['name'],a['id'];wanted=props[pair];todo=set(wanted);owner=a['matches'][0]['descriptor'];selected=[]
 while owner in old.classes and todo:
  oc=code.get(old,owner);nc=code.get(new,known[0][owner])
  for om in oc.methods:
   raw=instructions(om.code)
   if not om.desc.startswith('()L') and om.name != '<init>':continue
   labels=[]
   for i,(_,op,args)in enumerate(raw[:-1]):
    if op not in (18,19):continue
    val=constant(oc,args[0]if op==18 else args[0]*256+args[1])
    num=integer(oc,raw[i+1][1],raw[i+1][2])
    if val['tag']==8 and (val['value'],num)in todo:labels.append((val['value'],num))
   if not labels:continue
   ov=contract(oc,om,old.classes);hits=[]
   for nm in nc.methods:
    if signature_key(om,old.classes)!=signature_key(nm,new.classes):continue
    count+=1
    if count>100000:raise Refusal('work')
    try:
     nv=contract(nc,nm,new.classes)
     if nv['digest']!=ov['digest']:continue
     mapped=bindings(ov,nv);merge(known,mapped)
    except Refusal:continue
    hits.append((nm,mapped))
   for label in labels:
    property_class=wanted[label]
    row={'property':label,'sourceClass':property_class,'source':[owner,om.name,om.desc],'matchCount':len(hits)}
    if len(hits)==1:
     nm,mapped=hits[0];known=merge(known,mapped);row.update(target=[nc.name,nm.name,nm.desc],targetClass=known[0][property_class],digest=ov['digest'])
     todo.remove(label)
    selected.append(row)
  owner=oc.parent
 results.append({'name':a['name'],'id':a['id'],'properties':selected,'missing':list(todo)})
print('missing',[(x['name'],x['missing'])for x in results if x['missing']],flush=True)
print('mappedproperties',{x:known[0].get(x)for x in cat['sourcePropertyClasses']})
Path('/tmp/gn-9b6g-properties-2.json').write_text(json.dumps({'properties':results,'typeBindings':known[0],'memberBindings':[{'source':list(k),'target':list(v)}for k,v in known[1].items()],'comparisons':count,'elapsedMs':(time.perf_counter()-start)*1000},indent=2))
