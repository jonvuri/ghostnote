import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,rss_bytes,ancestors
from grid_doctor.descriptor_resolution import Code
from grid_doctor.constructor_flags import allocation_flags
from grid_doctor.migrate import member
start=time.perf_counter();inputs=[json.load(open('/tmp/gn-9b6g-'+n+'.json'))for n in ['builder-labels-1','default-labels-2','port-labels-1']];symbols=json.load(open('/tmp/gn-9b6g-resolution-5.json'))['builds'];builds=[]
for i,path in enumerate(['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar']):
 j=Jar(Path(path));code=Code();field=('cYF','Uhv','I')if i==0 else('deZ','FzB','I');base=symbols[i]['types']['relationship'];rows=[];cache={}
 for data in inputs:
  if data['builds'][i]['sha256']!=j.sha256:raise Refusal('relationship-flag-input-jar')
  for row in data['builds'][i]['rows']:
   for p in row['properties']:
    if len(p['allocations'])!=1:raise Refusal('relationship-flag-allocation-count')
    a=p['allocations'][0]
    if base not in ancestors(j.classes,a['class'],128):continue
    key=(*a['source'],a['offset'])
    if key not in cache:
     c=code.get(j,key[0]);m=member(c,*key[1:3])
     try:cache[key]=allocation_flags(j,code,c,m,key[3],field)
     except Refusal as e:cache[key]={'error':str(e),'allocation':list(key)}
    result=cache[key];rows.append({'className':row['name'],'classId':row['id'],'propertyName':a['name'],'propertyId':a['id'],'flags':result.get('flags'),'historyBit32':bool(result['flags']&32)if 'flags'in result else None,'error':result.get('error'),'witness':list(key)})
 builds.append({'sha256':j.sha256,'rows':rows,'allocations':list(cache.values())});print(i,'rows',len(rows),'allocations',len(cache),'errors',[(r['className'],r['propertyName'],r['error'])for r in rows if r['error']],'historyTrue',[(r['className'],r['propertyName'],r['flags'])for r in rows if r['historyBit32']],flush=True);del j,code
r={'builds':builds,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False,'runtimeObserved':False};raw=json.dumps(r,indent=2).encode()
if len(raw)>8*1024**2:raise Refusal('relationship-flag-report-limit')
Path('/tmp/gn-9b6g-relationship-flags-1.json').write_bytes(raw);print(len(raw),r['elapsedMs'],r['peakRssBytes'])
