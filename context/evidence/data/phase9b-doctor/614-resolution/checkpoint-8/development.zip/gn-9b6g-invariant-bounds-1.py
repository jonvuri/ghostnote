import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,ancestors,instructions,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.descriptor_builders import lookup
from grid_doctor.wrapper_bounds import wrapper_bound
from grid_doctor.ownership import constant,method_trace,bootstraps
start=time.perf_counter();j=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));code=Code();src=json.load(open('/tmp/gn-9b6g-builder-labels-1.json'))['builds'][1]['rows'];classes={a['class']for r in src for p in r['properties']for a in p['allocations']};results=[];traces={}
for typ in sorted(classes):
 if 'deZ'not in ancestors(j.classes,typ,128):continue
 try:
  c,m=lookup(j,code,typ,'hUR','(Lcom/bitwig/ramona/core/oDc;)V')
  if c.name!='deZ':raise Refusal('overridden-invariant')
  c,m=lookup(j,code,typ,'FzB','(Lcom/bitwig/ramona/core/oDc;)Lcom/bitwig/ramona/core/uzc;');raw=instructions(m.code)
  if [x[1]for x in raw]!=[42,43,182,176]or m.handlers:raise Refusal('wrapper-bridge-shape')
  traces[c.name,m.name,m.desc]=method_trace(j,c,m,bootstraps(j.zip.read(c.name+'.class'),c));ref=constant(c,int.from_bytes(bytes(raw[2][2]),'big'));fc,fm=lookup(j,code,typ,ref['name'],ref['descriptor']);b=wrapper_bound(j,code,fc.name,fm.name,fm.desc);wrapper=constant(fc,int.from_bytes(bytes(instructions(fm.code)[0][2]),'big'))['value'];vc,vm=lookup(j,code,wrapper,'ar_','()V')
  if vm.handlers or list(vm.code)!=[177]:raise Refusal('wrapper-invariant-not-empty')
  traces[vc.name,vm.name,vm.desc]=method_trace(j,vc,vm,bootstraps(j.zip.read(vc.name+'.class'),vc))
  for t in[b['factory'],*b['constructors'],*b['initializers']]:traces[t['owner'],t['name'],t['descriptor']]=t
  results.append({'propertyClass':typ,'wrapper':wrapper,'invariant':[vc.name,vm.name,vm.desc],'bound':b})
 except Refusal as e:results.append({'propertyClass':typ,'refusal':str(e)})
r={'sha256':j.sha256,'classes':sorted(classes),'rows':results,'methods':list(traces.values()),'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False};raw=json.dumps(r,indent=2).encode()
if len(raw)>8*1024**2:raise Refusal('invariant-bound-report-limit')
Path('/tmp/gn-9b6g-invariant-bounds-1.json').write_bytes(raw);print('classes',len(classes),'properties',len(results),'bounded',sum('bound'in r for r in results),'refused',[r for r in results if'refusal'in r]);print('methods',len(traces),len(raw),r['elapsedMs'],r['peakRssBytes'])
