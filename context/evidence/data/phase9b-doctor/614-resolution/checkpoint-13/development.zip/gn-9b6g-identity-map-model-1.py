import json,time,hashlib
from pathlib import Path
start=time.perf_counter();source=Path('/tmp/gn-9b6g-runtime-new-arm64-8.json');report=json.loads(source.read_text());cls=next(c for c in report['classes']if c['name']=='java/util/IdentityHashMap');methods={m['name']:m for m in cls['methods']if m['name']in('get','maskNull','hash','nextKeyIndex')}
if set(methods)!={'get','maskNull','hash','nextKeyIndex'}:raise ValueError('method coverage')
def execute(table,query,identity_hash):
 total=0;native=0
 def run(name,args):
  nonlocal total,native
  m=methods[name];raw=m['instructions'];ix={r['offset']:i for i,r in enumerate(raw)};local=dict(enumerate(args));stack=[];pc=0
  while True:
   total+=1
   if total>10000:raise ValueError('inert instruction limit')
   i=ix[pc];r=raw[i];op=r['opcode'];a=r['args'];following=raw[i+1]['offset']if i+1<len(raw)else None
   if 26<=op<=29:stack.append(local[op-26])
   elif 42<=op<=45:stack.append(local[op-42])
   elif op in(21,25):stack.append(local[a[0]])
   elif op in(54,58):local[a[0]]=stack.pop()
   elif 59<=op<=62:local[op-59]=stack.pop()
   elif 75<=op<=78:local[op-75]=stack.pop()
   elif 2<=op<=8:stack.append(op-3)
   elif op==1:stack.append(None)
   elif op==16:stack.append(int.from_bytes(bytes(a),'big',signed=True))
   elif op==180:
    ref=r['constant']
    if(ref['owner'],ref['name'],ref['descriptor'])!=('java/util/IdentityHashMap','table','[Ljava/lang/Object;'):raise ValueError('field')
    stack.pop();stack.append(table)
   elif op==190:stack.append(len(stack.pop()))
   elif op==50:
    k=stack.pop();stack.append(stack.pop()[k])
   elif op in(96,100,120,126):
    b=stack.pop();v=stack.pop();out=v+b if op==96 else v-b if op==100 else v<<(b&31)if op==120 else v&b;out=((out+2**31)%2**32)-2**31;stack.append(out)
   elif op in(199,162,166,167):
    take=True
    if op==199:take=stack.pop()is not None
    elif op in(162,166):
     b=stack.pop();v=stack.pop();take=v>=b if op==162 else v is not b
    if take:following=pc+int.from_bytes(bytes(a),'big',signed=True)
   elif op==184:
    ref=r['constant'];target=ref['name']
    if ref['owner']=='java/lang/System'and target=='identityHashCode':stack.pop();stack.append(identity_hash);native+=1
    elif ref['owner']=='java/util/IdentityHashMap':
     n=2 if target in('hash','nextKeyIndex')else 1;values=stack[-n:];del stack[-n:];stack.append(run(target,values))
    else:raise ValueError('external call')
   elif op in(172,176):return stack.pop()
   else:raise ValueError(('opcode',name,pc,op))
   pc=following
  raise ValueError('no return')
 value=run('get',[object(),query]);return value,total,native
cases=0;worst=0;exact=0
for capacity in(2,4,8,16,32,64):
 length=2*capacity
 for native_hash in range(capacity):
  initial=((native_hash<<1)-(native_hash<<8))&(length-1)
  for collisions in range(capacity):
   for found in(False,True):
    table=[None]*length;query=object();sentinel=object()
    for k in range(collisions):table[(initial+2*k)%length]=object()
    slot=(initial+2*collisions)%length
    if found:table[slot]=query;table[slot+1]=sentinel
    value,steps,native=execute(table,query,native_hash);bound=(45 if found else 43)+24*collisions
    if value is not(sentinel if found else None)or steps>bound or native!=1:raise ValueError(('model result',capacity,native_hash,collisions,found,steps,bound,native))
    cases+=1;worst=max(worst,steps);exact+=steps==bound
out={'inputSha256':hashlib.sha256(source.read_bytes()).hexdigest(),'classSha256':cls['sha256'],'cases':cases,'exactBoundCases':exact,'maxInstructionsObserved':worst,'bound':{'nonnullKeyFound':{'constant':45,'perCollision':24},'nonnullKeyAbsent':{'constant':43,'perCollision':24},'nativeIdentityHashCalls':1},'elapsedMs':(time.perf_counter()-start)*1000,'boundedAdmission':False,'runtimeClassesInitialized':0,'conditions':['These tests interpret extracted class data with an inert identity-hash stub.','The table must be stable, valid, have a power-of-two length, and contain an empty key slot.','The query is non-null. Collision count is bounded by the number of existing entries.','Native hashing, synchronization waits, concurrent changes, and actual entry limits are not measured.']};Path('/tmp/gn-9b6g-identity-map-model-1.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
