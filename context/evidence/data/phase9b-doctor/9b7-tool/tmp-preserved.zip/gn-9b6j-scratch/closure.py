"""Ad-hoc owned-tree census closure. Reads the jar as data only."""
import sys, json, re
sys.path.insert(0, '/Users/jonvuri/Development/ghostnote/brain/src/probes')
from grid_symbols.scan import Jar, ancestors, instructions, parse
from grid_doctor.fixed_descriptors import constructor_pair
from grid_doctor.ownership import constant
from pathlib import Path
jar = Jar(Path(sys.argv[1])); base = sys.argv[2]; module_report = sys.argv[3]; descriptor_base = sys.argv[4]
seed_names = sys.argv[5:]
anc = {}
def A(n):
    if n not in anc: anc[n] = list(ancestors(jar.classes, n)) if n in jar.classes else []
    return anc[n]
def is_doc(n): return base in A(n)
# descriptor catalog: (name,id) -> runtime, runtime -> (name,id)
by_id, by_runtime = {}, {}
for entry in jar.zip.namelist():
    if not entry.endswith('.class'): continue
    meta = jar.classes[entry[:-6]]
    if not any(m.name == '<init>' and m.desc == '()V' for m in meta.methods): continue
    if descriptor_base not in A(entry[:-6]): continue
    data = jar.zip.read(entry); cls = parse(data, True)
    for m in cls.methods:
        if m.name == '<init>' and m.desc == '()V' and m.code:
            pair = constructor_pair(cls, m)
            if not pair: continue
            getters = []
            for g in cls.methods:
                if g.desc == '()Ljava/lang/Class;' and g.code and g.flags == 1:
                    raw = instructions(g.code)
                    if len(raw) == 2 and raw[0][1] in (18,19):
                        _, op, args = raw[0]; v = constant(cls, args[0] if op == 18 else args[0]*256+args[1])
                        if v['tag'] == 7: getters.append(v['value'])
            if len(getters) == 1:
                by_id.setdefault(pair[1], []).append((pair[0], getters[0], cls.name))
                by_runtime[getters[0]] = (pair[0], pair[1], cls.name)
print('descriptor pairs', len(by_runtime))
rep = json.load(open(module_report))
from grid_doctor.module_file import object_references
nodes = object_references(rep['objects']['root'])['nodes']
from collections import Counter
serial = Counter(n['classId'] for n in nodes)
tree = {}
for cid, count in serial.items():
    hits = by_id.get(cid, [])
    if len(hits) != 1: print('AMBIGUOUS', cid, hits)
    name, runtime, desc = hits[0]
    tree[runtime] = {'className': name, 'classId': cid, 'serialized': count, 'creations': []}
for s in seed_names:
    if s not in tree: tree[s] = {'className': by_runtime.get(s, ('?',))[0], 'classId': by_runtime.get(s, (None,None))[1], 'serialized': 0, 'creations': []}
print('seed classes', len(tree))

def creations_in(code, m, depth=0, seen=None):
    """NEW X (doc) and static factories returning doc types, following static bodies to depth 6."""
    out = []
    for off, op, args in instructions(m.code):
        if op == 187:
            t = code.cp[code.cp[args[0]*256+args[1]][1]][1]
            if is_doc(t): out.append(('new', t, code.name, m.name, m.desc))
        elif op == 184:
            owner, nt = code.cp[args[0]*256+args[1]][1]; owner = code.cp[code.cp[owner][1]][1]
            ni, di = code.cp[nt][1]; n, d = code.cp[ni][1], code.cp[di][1]
            ret = d[d.index(')')+1:]
            if ret.startswith('L') and is_doc(ret[1:-1]) and owner in jar.classes and depth < 6:
                key = (owner, n, d)
                if seen is None: seen = set()
                if key in seen: continue
                seen.add(key)
                if len(jar.code_cache) > 100: jar.code_cache.clear()
                oc = jar.code(owner)
                for mm in oc.methods:
                    if (mm.name, mm.desc) == (n, d) and mm.code:
                        inner = creations_in(oc, mm, depth+1, seen)
                        if not inner and ret[1:-1] in jar.classes and not (jar.classes[ret[1:-1]].flags & 0x400):
                            out.append(('static-return', ret[1:-1], code.name, m.name, m.desc))
                        out.extend((k, t, code.name, m.name, m.desc, 'via', owner, n, d) for (k, t, *_rest) in inner)
    return out

def store_evidence(code, m, created):
    """A this-call with a vendor parameter type that is an ancestor of the created class."""
    ev = []
    for off, op, args in instructions(m.code):
        if op in (182, 183, 185):
            owner, nt = code.cp[args[0]*256+args[1]][1]; owner = code.cp[code.cp[owner][1]][1]
            ni, di = code.cp[nt][1]; n, d = code.cp[ni][1], code.cp[di][1]
            params = re.findall(r'L([^;]+);', d[:d.index(')')])
            if owner in A(code.name) or owner == code.name:
                for p in params:
                    if p != 'java/lang/Object' and p in A(created): ev.append((owner, n, d, p))
    return ev

work = list(tree); done = set()
while work:
    cls = work.pop()
    if cls in done: continue
    done.add(cls)
    for a in A(cls):
        if a not in jar.classes or a == base or a in A(base): continue
        if len(jar.code_cache) > 100: jar.code_cache.clear()
        code = jar.code(a)
        for m in code.methods:
            if not m.code or m.flags & 8: continue   # instance methods only
            for c in creations_in(code, m):
                created = c[1]
                if jar.classes[created].flags & 0x400: continue  # abstract
                ev = store_evidence(code, m, created)
                if not ev: continue
                tree.setdefault(created, {'className': by_runtime.get(created, ('?',))[0], 'classId': by_runtime.get(created, (None,None))[1], 'serialized': 0, 'creations': []})
                tree[created]['creations'].append({'for': cls, 'in': f'{a}.{m.name}{m.desc}', 'kind': c[0], 'via': c[6:] if len(c) > 6 else None, 'store': ev[0]})
                if created not in done: work.append(created)
print('final classes', len(tree))
for k in sorted(tree, key=lambda k: (tree[k]['className'] or '')):
    v = tree[k]; print(f"{v['classId']:>5} {v['className']:<45} {k:<55} serialized={v['serialized']} creations={len(v['creations'])}")
    for c in v['creations'][:6]: print('        ', c)
