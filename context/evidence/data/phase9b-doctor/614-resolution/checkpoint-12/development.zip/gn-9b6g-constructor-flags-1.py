import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,rss_bytes,descriptor
from grid_doctor.descriptor_resolution import Code
from grid_doctor.constructor_flags import flag_origin
start=time.perf_counter();j=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));code=Code();specs=[('deT','(Ljava/lang/String;ILder;Lder;LcUb;Ljava/lang/String;ILjava/lang/Integer;I)V'),('deU','(Ljava/lang/String;ILder;Lder;LcUb;Ljava/lang/String;ZI)V'),('deX','(Ljava/lang/String;ILder;Lder;Ljava/lang/String;I)V')];rows=[]
for owner,desc in specs:
 try:r=flag_origin(j,code,owner,desc,('dfb','FzB','I'))
 except Refusal as e:r={'root':[owner,desc],'error':str(e)}
 rows.append(r);print(owner,r.get('origin'),r.get('error'))
r={'sha256':j.sha256,'rows':rows,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False};Path('/tmp/gn-9b6g-constructor-flags-1.json').write_text(json.dumps(r,indent=2)+'\n');print(r['elapsedMs'],r['peakRssBytes'])
