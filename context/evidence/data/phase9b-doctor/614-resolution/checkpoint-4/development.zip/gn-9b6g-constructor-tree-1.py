import json,time,collections
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,instructions,ancestors,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.migrate import member
from grid_doctor.ownership import constant,method_trace,bootstraps
start=time.perf_counter();j=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));code=Code();rows=json.load(open('/tmp/gn-9b6g-registry-closure-1.json'))['selectedRows'];roots=sorted({r['matches'][0]['runtimeClass']for r in rows}|{'com/bitwig/flt/document/core/master/device/rSf'});todo=collections.deque((c,'<init>','()V')for c in roots);traces={};calls=[];alloc=[];frontier=[];steps=0
while todo:
 key=todo.popleft()
 if key in traces:continue
 if len(traces)>=512:raise Refusal('constructor-trace-limit')
 c=code.get(j,key[0]);hits=[m for m in c.methods if (m.name,m.desc)==key[1:]]
 if len(hits)!=1:frontier.append({'source':key,'reason':'missing-constructor'});continue
 m=hits[0];traces[key]=method_trace(j,c,m,bootstraps(j.zip.read(c.name+'.class'),c))
 for off,op,args in instructions(m.code):
  steps+=1
  if steps>2000000:raise Refusal('constructor-work-limit')
  if op==187:
   r=constant(c,int.from_bytes(bytes(args),'big'));typ=r['value'];alloc.append({'source':key,'offset':off,'type':typ,'ownedBase':'com/bitwig/ramona/core/oDc'in ancestors(j.classes,typ,128)if typ in j.classes else False})
  if op not in(182,183,184,185,186):continue
  r=constant(c,int.from_bytes(bytes(args[:2]),'big'));edge={'source':key,'offset':off,'opcode':op,'target':r};calls.append(edge)
  if op==183 and r['name']=='<init>'and r['owner']in j.classes:todo.append((r['owner'],r['name'],r['descriptor']))
  else:frontier.append(edge)
r={'roots':roots,'methods':list(traces.values()),'allocations':alloc,'calls':calls,'frontier':frontier,'instructions':steps,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False,'limits':['Constructor calls are a syntactic closure. Virtual calls, static initialization, and default methods remain separate.']};Path('/tmp/gn-9b6g-constructor-tree-1.json').write_text(json.dumps(r,indent=2));print('roots',len(roots),'methods',len(traces),'alloc',len(alloc),'ownedalloc',[a for a in alloc if a['ownedBase']],'frontier',len(frontier));print(r['elapsedMs'],r['peakRssBytes'])
