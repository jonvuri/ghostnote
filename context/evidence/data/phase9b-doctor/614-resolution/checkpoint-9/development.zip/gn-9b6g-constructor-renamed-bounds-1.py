import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,rss_bytes,descriptor
from grid_doctor.descriptor_resolution import Code
from grid_doctor.assertion_guards import requirements
from grid_doctor.constructor_bounds import direct_bounds
from grid_doctor.renamed_fixture import rename_member
start=time.perf_counter();source=json.load(open('/tmp/gn-9b6g-constructor-bounds-2.json'));results=[]
for i,(path,mapping)in enumerate([('/tmp/gn-9b6g-old-renamed-extra.jar','/tmp/gn-9b6g-old-renamed-map.json'),('/tmp/gn-9b6g-renamed-extra.jar','/tmp/gn-9b6g-renamed-map.json')]):
 names=json.load(open(mapping));j=Jar(Path(path));code=Code();base=source['builds'][i]
 def key(v):return names.get(v[0],v[0]),rename_member(v[1]),descriptor(v[2],lambda n:names.get(n,n))
 flags={key(k)for k in base['assertionGuards']};verified={tuple(f)for owner in {k[0]for k in flags}for f in requirements(j,{owner},code)['fields']}
 if not flags<=verified:raise Refusal('renamed-constructor-guard')
 r=direct_bounds(j,code,[key(row['root'])for row in base['roots']],flags);r['sha256']=j.sha256
 if len(r['methods'])!=len(base['methods'])or r['work']!=base['work']:raise Refusal('renamed-constructor-work')
 for a,b in zip(base['roots'],r['roots']):
  if any(a[k]!=b[k]for k in ['vendorInstructions','vendorCalls','externalCalls']):raise Refusal('renamed-constructor-cost')
  if {names.get(k,k):v for k,v in a['explicitObjects'].items()}!=b['explicitObjects']:raise Refusal('renamed-constructor-allocation')
  if [{'method':list(key(x['method'])),'offset':x['offset'],'count':x['count']}for x in a['dynamicSites']]!=b['dynamicSites']:raise Refusal('renamed-constructor-dynamic')
  b.update(name=a['name'],id=a['id'])
 results.append(r);print('build',i,'roots',len(r['roots']),'methods',len(r['methods']),'same costs',True)
 del j,code
r={'builds':results,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False};raw=json.dumps(r,indent=2).encode()
if len(raw)>8*1024**2:raise Refusal('renamed-constructor-report-limit')
Path('/tmp/gn-9b6g-constructor-renamed-bounds-1.json').write_bytes(raw);print(len(raw),r['elapsedMs'],r['peakRssBytes'])
