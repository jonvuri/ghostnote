import json,time,sys
from pathlib import Path
from grid_symbols.scan import Jar,rss_bytes,Refusal
from grid_doctor.descriptor_resolution import Code
from grid_doctor.read_dataflow import fixed_read_flow
case=sys.argv[1];base=Path('context/evidence/data/phase9b-doctor/614-resolution/checkpoint-2');old='/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar';paths={'old':old,'new':'/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar','old-renamed':'/tmp/gn-9b6g-old-renamed-extra.jar','new-renamed':'/tmp/gn-9b6g-renamed-extra.jar'}
if case in ('old','new'):
 i=0 if case=='old'else 1;s,c,p=[json.loads((base/(x+'.json')).read_text())['builds'][i]for x in ('symbols','catalog','properties')];r=Path('/tmp/gn-9b6g-fixed-read-3/reads-'+str(i)+'.json')
else:
 prefix='old-'if case=='old-renamed'else '';s=json.loads((base/('old-renamed.json'if prefix else'new-renamed.json')).read_text())['builds'][1];c=json.load(open('/tmp/gn-9b6g-'+prefix+'renamed-catalog-1.json'))['builds'][1];p=json.load(open('/tmp/gn-9b6g-'+prefix+'renamed-properties-1.json'))['builds'][1];r=Path('/tmp/gn-9b6g-'+prefix+'renamed-fixed-read-1/reads-1.json')
flags=json.loads(r.read_text())['requiredTrueFlags'];start=time.perf_counter();j=Jar(Path(paths[case]));code=Code()
if any(x['sha256']!=j.sha256 for x in(s,c,p)):raise Refusal('input-fingerprint')
out=fixed_read_flow(j,code,s,c,p,flags);out.update(elapsedMs=(time.perf_counter()-start)*1000,peakRssBytes=rss_bytes());dest=Path('/tmp/gn-9b6g-'+case+'-dataflow-2.json')
with dest.open('x')as f:json.dump(out,f,indent=2)
errors=[(x['className'],x['propertyName'],x['error'])for x in out['paths']if x['error']];print(case,out['work'],errors,out['elapsedMs'],out['peakRssBytes']);sys.exit(bool(errors))
