import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,instructions,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.descriptor_builders import registrations
from grid_doctor.fixed_descriptors import constructor_pair
from grid_doctor.ownership import constant,method_trace,bootstraps
from grid_doctor.migrate import member
start=time.perf_counter();code=Code();mapping=json.load(open('/tmp/gn-9b6g-invariant-read-contracts-1.json'))['typeBindings'];inverse={v:k for k,v in mapping.items()};names=['com/bitwig/flt/document/core/master/device/HmS'];out=[]
for i,path in enumerate(['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar']):
 j=Jar(Path(path));rows=[];builders=[]
 for name in names:
  n=inverse[name]if i==0 else name;c=code.get(j,n);ctor=member(c,'<init>','()V');pair=constructor_pair(c,ctor)
  if not pair:raise Refusal('default-constructor-anchor')
  hits=[]
  for m in c.methods:
   if m.desc!='()Ljava/lang/Class;'or m.flags!=1 or m.handlers:continue
   raw=instructions(m.code)
   if len(raw)==2 and raw[0][1]in(18,19)and raw[1][1]==176:
    ref=constant(c,raw[0][2][0]if raw[0][1]==18 else int.from_bytes(bytes(raw[0][2]),'big'))
    if ref['tag']==7:hits.append((m,ref['value']))
  if len(hits)!=1:raise Refusal('default-class-getter')
  getter,runtime=hits[0];bs=bootstraps(j.zip.read(n+'.class'),c)
  rows.append({'name':pair[0],'id':pair[1],'count':1,'scope':'previously-bound-descriptor-type','runtimeObserved':False,'matches':[{'descriptor':n,'runtimeClass':runtime,'constructor':method_trace(j,c,ctor,bs),'classGetter':method_trace(j,c,getter,bs)}]})
  b=registrations(j,code,n,('cXV','ffA','(Ljava/util/List;)V')if i==0 else('der','cfM','(Ljava/util/List;)V'),('cXV','ffA','(LcYs;Ljava/util/List;)V')if i==0 else('der','cfM','(LdeN;Ljava/util/List;)V'),attribute=('cXZ','ffA','(Ljava/lang/String;Ljava/lang/Object;)V')if i==0 else('dev','cfM','(Ljava/lang/String;Ljava/lang/Object;)V'));b.update(name=pair[0],id=pair[1]);builders.append(b)
 out.append({'sha256':j.sha256,'rows':rows,'builders':builders});print(i,[(r['name'],r['id'],r['matches'][0]['runtimeClass'])for r in rows],[(b['name'],b['count'])for b in builders])
r={'builds':out,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False};Path('/tmp/gn-9b6g-default-catalog-2.json').write_text(json.dumps(r,indent=2)+'\n');print(r['elapsedMs'],r['peakRssBytes'])
