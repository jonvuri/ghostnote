import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,ancestors,rss_bytes
start=time.perf_counter();j=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'))
local=json.load(open('/tmp/gn-9b6g-invariant-local-costs-2.json'));root=json.load(open('/tmp/gn-9b6g-invariant-root-bounds-1.json'))['builds'][1]
if local['sha256']!=j.sha256 or root['sha256']!=j.sha256:raise Refusal('invariant-aggregate-input-jar')
paths={(r['classId'],r['propertyId']):r for r in local['paths']}
reports=[json.load(open('/tmp/gn-9b6g-builder-property-bindings-3-0.json'))]+[json.load(open('/tmp/gn-9b6g-builder-property-bindings-4-'+str(i)+'.json'))for i in range(9)]+[json.load(open('/tmp/gn-9b6g-default-property-bindings-2-1.json'))]
rows=[]
for source in reports:
 for row in source['properties']:
  values=[];locks=[];unused=[]
  for p in row['properties']:
   line=set(ancestors(j.classes,p['targetClass'],128))
   if 'deZ' in line:
    if (row['id'],p['id'])not in paths:raise Refusal('invariant-aggregate-missing-value:'+str((row['id'],p['id'])))
    values.append(paths[row['id'],p['id']])
   elif 'deM' in line:locks.append(p)
   else:unused.append(p['id'])
  if locks and (row['id']!=163 or [(p['name'],p['id'])for p in locks]!=[('delete_lock',2018)]):raise Refusal('invariant-aggregate-lock-needs-input')
  own=root['ownInstructions'];cost={'vendorInstructions':own['constant']+own['perValue']*len(values),'vendorCalls':len(values),'externalCalls':1,'perChildInstructions':0,'perChildExternalCalls':0,'explicitObjects':0,'iteratorAllocations':0}
  if locks:
   lock=json.load(open('/tmp/gn-9b6g-invariant-lock-read-1.json'))['builds'][1]
   if lock['sha256']!=j.sha256:raise Refusal('invariant-aggregate-lock-jar')
   inv=lock['invariant']['roots'][0]
   if inv['externalCalls'] or inv['dynamicSites'] or inv['explicitObjects']:raise Refusal('invariant-aggregate-lock-open-body')
   cost['vendorInstructions']+=root['ownInstructions']['perLock']+lock['normalGetterBound']['vendorInstructions']+inv['vendorInstructions']
   cost['vendorCalls']+=root['vendorCalls']['perLock']+lock['normalGetterBound']['vendorCalls']+inv['vendorCalls']
   cost['externalCalls']+=lock['normalGetterBound']['externalCalls']
  for p in values:
   for k,v in p['cost'].items():cost[k]+=v
  rows.append({'className':row['name'],'classId':row['id'],'valueCount':len(values),'lockCount':len(locks),'cost':cost,'valueIds':[p['propertyId']for p in values],'excludedNonValueIds':unused})
r={'sha256':j.sha256,'rows':rows,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False,'runtimeObserved':False,'conditions':['All root and value-path conditions remain required.','Per-child coefficients use one common bound N for each relationship output list.','Array contents must match the registered properties exactly and remain stable.','Object invariants can add parent-domain invariants, list loops, and ancestor walks.','External bodies, class initialization, exception paths, and runtime admission remain separate.']};raw=json.dumps(r,indent=2).encode()
if len(raw)>8*1024**2:raise Refusal('invariant-aggregate-report-limit')
Path('/tmp/gn-9b6g-invariant-aggregate-3.json').write_bytes(raw);print('classes',len(rows),'value paths',sum(r['valueCount']for r in rows));print('max',max(rows,key=lambda x:x['cost']['vendorInstructions']));print(len(raw),r['elapsedMs'],r['peakRssBytes'])
