import sys,zipfile,time
from grid_symbols.scan import parse,instructions
from grid_doctor.ownership import constant
z=zipfile.ZipFile(sys.argv[1]); want=[tuple(x.split('#')) for x in sys.argv[2:]]
t=time.perf_counter()
for e in z.infolist():
    if not e.filename.endswith('.class'): continue
    raw=z.read(e)
    if not any(n.encode() in raw and d.encode() in raw for _,n,d in want): continue
    c=parse(raw,True)
    for m in c.methods:
        for off,op,a in instructions(m.code):
            if 182<=op<=185:
                r=constant(c,a[0]*256+a[1])
                for o,n,d in want:
                    if r['name']==n and r['descriptor']==d and (o=='*' or r['owner']==o):
                        print(c.name,m.name,m.desc,m.flags,off,op,r['owner'])
print('elapsed',time.perf_counter()-t)
