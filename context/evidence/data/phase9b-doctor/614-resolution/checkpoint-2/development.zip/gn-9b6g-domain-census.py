from pathlib import Path
from grid_symbols.scan import Jar,ancestors
from grid_doctor.receiver_trace import Declarations,ReceiverLimits
from grid_doctor.admission import Work
j=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));d=Declarations(j,Work(ReceiverLimits()))
for name,c in j.classes.items():
 if c.flags&1536:continue
 if 'bU'in set(ancestors(j.classes,name,128)):
  print(name,d.find('method',name,'uWE','()D'))
