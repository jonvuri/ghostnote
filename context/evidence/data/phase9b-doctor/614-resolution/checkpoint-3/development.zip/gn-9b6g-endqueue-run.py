import json,time
from pathlib import Path
from grid_symbols.scan import Jar,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.call_paths import paths
start=time.perf_counter();j=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));code=Code();syms=json.load(open('/tmp/gn-9b6g-resolution-5.json'))['builds'][1]
roots=[r['reference'][1:]for r in syms['members']if r['role']in('native-value-setter','cable-source-setter','module-delete','module-factory','close','associate-edit','insert-body','boolean-command','remove-mapping','restore-mapping','undo-command','disposal')];sinks=[['WWV','Hnt','()V']]
hypotheses={('aLw','UNj','(D)V'):['rce','Hgx']}
r=paths(j,roots,sinks,code,hypotheses,12);r.update(elapsedMs=(time.perf_counter()-start)*1000,peakRssBytes=rss_bytes());Path('/tmp/gn-9b6g-callpaths-endqueue-1.json').write_text(json.dumps(r,indent=2));print(json.dumps({'work':r['work'],'results':r['results'],'elapsedMs':r['elapsedMs'],'peakRssBytes':r['peakRssBytes']},indent=2))
