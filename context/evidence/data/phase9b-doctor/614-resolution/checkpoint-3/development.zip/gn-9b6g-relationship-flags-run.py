import json,time
from pathlib import Path
from grid_symbols.scan import Jar,ancestors,instructions,rss_bytes,Refusal
from grid_doctor.descriptor_resolution import Code
from grid_doctor.migrate import member
from grid_doctor.ownership import constant
from grid_doctor.fixed_descriptors import integer
start=time.perf_counter();j=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));c=Code();s=json.load(open('/tmp/gn-9b6g-resolution-5.json'))['builds'][1];p=json.load(open('/tmp/gn-9b6g-properties-4.json'))['builds'][1];rows=[]
for row in p['properties']:
 for prop in row['properties']:
  if s['types']['relationship'] not in ancestors(j.classes,prop['targetClass'],j.limits.depth):continue
  cls=c.get(j,prop['target'][0]);m=member(cls,*prop['target'][1:]);raw=instructions(m.code);calls=[]
  for i,(offset,op,args) in enumerate(raw):
   if op!=183:continue
   ref=constant(cls,args[0]*256+args[1])
   if ref['owner']!=prop['targetClass'] or ref['name']!='<init>':continue
   if not ref['descriptor'].endswith('I)V'):raise Refusal('flags-last-parameter')
   flags=integer(cls,raw[i-1][1],raw[i-1][2])
   if flags is None:raise Refusal('flags-not-literal')
   calls.append({'offset':offset,'constructor':ref,'lastIntArgument':flags,'bit32':bool(flags&32)})
  if len(calls)!=1:raise Refusal('flags-call-count')
  rows.append({'className':row['name'],'propertyName':prop['name'],'id':prop['id'],'source':prop['target'],'call':calls[0]})
r={'sha256':j.sha256,'rows':rows,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'limits':['Literal constructor arguments only. Constructor forwarding and actual field values need independent checks.','The capture does not include all ancestors or all generated properties.'],'boundedAdmission':False,'writeAuthority':False};Path('/tmp/gn-9b6g-relationship-flags-1.json').write_text(json.dumps(r,indent=2));print([(x['className'],x['propertyName'],x['call']['lastIntArgument'],x['call']['bit32'])for x in rows])
