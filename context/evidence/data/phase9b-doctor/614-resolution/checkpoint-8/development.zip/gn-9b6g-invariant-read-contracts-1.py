import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.owned_flow import runtime_parent_bindings
from grid_doctor.callee_contracts import compare_callees
from grid_doctor.fixed_read_checkpoint import membership_variants
from grid_doctor.migrate import merge
start=time.perf_counter();code=Code();jars=[Jar(Path(p))for p in ['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar']];catalogs=[]
for i,j in enumerate(jars):
 rows=json.load(open('/tmp/gn-9b6g-fixed-1.json'))['builds'][i]['rows'];registry=json.load(open('/tmp/gn-9b6g-registry-'+('old-'if i==0 else'')+'closure-1.json'))['selectedRows'];selected={(r['name'],r['id']):r for r in rows+registry};catalogs.append({'sha256':j.sha256,'rows':list(selected.values())})
seed=json.load(open('/tmp/gn-9b6g-builder-owned-contracts-1.json'));flow=json.load(open('/tmp/gn-9b6g-invariant-read-flow-2.json'));keys=sorted({tuple(x)for b in flow['batches']for x in b['methods']});traces=[dict(zip(('owner','name','descriptor'),k))for k in keys];r=compare_callees(*jars,traces,seed,code);r.update(elapsedMs=(time.perf_counter()-start)*1000,peakRssBytes=rss_bytes());raw=json.dumps(r,indent=2).encode()
if len(raw)>8*1024**2:raise Refusal('invariant-read-contract-limit')
Path('/tmp/gn-9b6g-invariant-read-contracts-1.json').write_bytes(raw);print('matched',len(r['matched']),'unmatched',r['unmatched']);print(len(raw),r['elapsedMs'],r['peakRssBytes'])
