import json,time
from pathlib import Path
from grid_symbols.scan import Jar,rss_bytes,Refusal
from grid_doctor.descriptor_resolution import Code
from grid_doctor.owned_flow import owned_collectors
start=time.perf_counter();code=Code()
inputs=[json.load(open('/tmp/gn-9b6g-'+p+'.json')) for p in ['resolution-5','fixed-1','schema-bindings-2']]
paths=['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar']
rows=[]
for i,p in enumerate(paths):
 rows.append(owned_collectors(Jar(Path(p)),code,*(v['builds'][i]for v in inputs)))
 print(i,'paths',len(rows[-1]['paths']),'methods',len(rows[-1]['methods']),'errors',[(x['className'],x['propertyName'],x['error'])for x in rows[-1]['paths']if x['error']],flush=True)
report={'builds':rows,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes()}
raw=json.dumps(report,indent=2).encode()
if len(raw)>8*1024**2:raise Refusal('report-size')
Path('/tmp/gn-9b6g-owned-collectors-1.json').write_bytes(raw)
print('bytes',len(raw),'elapsedMs',report['elapsedMs'],'rss',report['peakRssBytes'])
