exec(open('/tmp/gn-614-survey.py').read().split('index=defaultdict')[0])
a,b='QY','RuU'
while a in old.classes and b in new.classes:
    ac,bc=old.classes[a],new.classes[b]
    shape=lambda c,j:class_shape(c,lambda n:'vendor' if n in j.classes else n)
    ash,bsh=shape(ac,old),shape(bc,new)
    print(a,b,'same',ash==bsh,'counts',len(ac.fields),len(bc.fields),len(ac.methods),len(bc.methods))
    for kind,x,y in [('fields',ash[-2],bsh[-2]),('methods',ash[-1],bsh[-1])]:
        print(kind,'removed',list((Counter(tuple(z) for z in x)-Counter(tuple(z) for z in y)).elements()),'added',list((Counter(tuple(z) for z in y)-Counter(tuple(z) for z in x)).elements()))
    a,b=ac.parent,bc.parent
