import json,time
from pathlib import Path
from grid_symbols.scan import Jar,instructions,ancestors,rss_bytes,Refusal
from grid_doctor.descriptor_resolution import Code
from grid_doctor.descriptor_builders import lookup
from grid_doctor.ownership import constant
from grid_doctor.assertion_guards import requirements
from grid_doctor.read_dataflow import ReadFlow,integer
start=time.perf_counter();code=Code();seed=json.load(open('/tmp/gn-9b6g-disposal-release-contracts-1.json'));inverse={v:k for k,v in seed['typeBindings'].items()};base_new='com/bitwig/ramona/core/oDc';members={tuple(r['target']):tuple(r['source'])for r in seed['memberBindings']};builds=[]
for index,path in enumerate(['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar']):
 j=Jar(Path(path));roots=json.load(open('/tmp/gn-9b6g-constructor-bounds-2.json'))['builds'][index]['roots'];ports=json.load(open('/tmp/gn-9b6g-port-constructors-1.json'))['builds'][index]['roots'];module='com/bitwig/flt/document/core/master/device/rSf';module=module if index else inverse[module];runtimes=sorted({r['root'][0]for r in roots+ports}|{module});parent=next(r['root'][0]for r in roots if r['name']=='module_contents');base=base_new if index else inverse[base_new];desc='(L'+base+';Z)V';key=(base,'IwV',desc)if index else members[(10,base_new,'IwV','(L'+base_new+';Z)V')][1:];c,m=lookup(j,code,*key);hooks=[]
 for off,op,args in instructions(m.code):
  if op!=182:continue
  ref=constant(c,int.from_bytes(bytes(args[:2]),'big'))
  if ref['owner']==base and ref['descriptor']==desc and ref['name']!=m.name:hooks.append((base,ref['name'],desc))
 if len(hooks)!=2:raise Refusal('factory-release-hook-count')
 owners={n for r in runtimes for n in ancestors(j.classes,r,j.limits.depth)};flags=requirements(j,owners,code)['fields'];rows=[]
 for runtime in runtimes:
  receiver=('ref',runtime,'fixed');owner=('ref',parent,'managed-owner');slots=[]
  for key in hooks:
   flow=ReadFlow(j,code,flags,('unused','id','I'),0,'unused',class_tests=True);returns=flow.evaluate(*key,receiver,(owner,integer(1)));bound=flow.bounds[(*key,receiver,(owner,integer(1)),False)]
   if flow.external or bound[2]:raise Refusal('factory-release-external')
   slots.append({'slot':key,'bound':bound,'methods':sorted(flow.methods),'classTests':sorted(flow.resolved_class_tests)})
  pred=(base,'I_','()Z')if index else members[(10,base_new,'I_','()Z')][1:];flow=ReadFlow(j,code,flags,('unused','id','I'),0,'unused');result=flow.evaluate(*pred,receiver,())
  if result not in({integer(0)},{integer(1)}):raise Refusal('factory-release-managed-predicate')
  rows.append({'runtime':runtime,'managed':result=={integer(1)},'hooks':slots})
 builds.append({'sha256':j.sha256,'managedOwner':parent,'rows':rows,'guards':flags});print(index,'receivers',len(rows),'managed',[r['runtime']for r in rows if r['managed']],'maxHookInstructions',max(x['bound'][0]for r in rows for x in r['hooks']),flush=True)
r={'builds':builds,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False,'runtimeObserved':False,'conditions':['Only these exact 33 receiver classes are included.','The managed-owner argument is an exact module_contents object throughout the release walk.','The checked assertion flags must already be initialized and true.','This result covers the two hook bodies and managed predicate. It excludes collection, recursive traversal, disposal wrappers, and state stability.']};Path('/tmp/gn-9b6g-factory-release-1.json').write_text(json.dumps(r,indent=2)+'\n')
