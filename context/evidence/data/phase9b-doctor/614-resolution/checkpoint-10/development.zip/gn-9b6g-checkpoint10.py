import json,hashlib,shutil,zipfile
from pathlib import Path
base=Path('context/evidence/data/phase9b-doctor/614-resolution');dest=base/'checkpoint-10';dest.mkdir();prior={}
for path in sorted(base.glob('checkpoint-*/development-manifest.json')):
 for row in json.loads(path.read_text()):prior[row['name']]=row['sha256']
manifest=[]
with zipfile.ZipFile(dest/'development.zip','x',compression=zipfile.ZIP_DEFLATED)as z:
 for p in sorted(Path('/tmp').glob('gn-9b6g-*')):
  if not p.is_file()or p.suffix not in('.json','.txt','.log','.py','.sh','.bin'):continue
  raw=p.read_bytes();h=hashlib.sha256(raw).hexdigest()
  if prior.get(p.name)==h:continue
  z.writestr(p.name,raw);manifest.append({'name':p.name,'sha256':h,'bytes':len(raw)})
(dest/'development-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for name in ['invariant-direct-reads-1','invariant-old-direct-reads-1','invariant-direct-contracts-1','all-descriptor-reads-1','invariant-lock-read-1','invariant-local-costs-2','invariant-root-bounds-1','invariant-aggregate-3','object-invariant-closure-1','object-invariant-contracts-1','holder-null-read-1','clone-contracts-2']:
 shutil.copyfile('/tmp/gn-9b6g-'+name+'.json',dest/(name+'.json'))
shutil.copyfile('/tmp/gn-9b6g-unit-regression-17.log',dest/'unit-regression-17.log')
sources=[]
with zipfile.ZipFile(dest/'diagnostic-source.zip','x',compression=zipfile.ZIP_DEFLATED)as z:
 for p in sorted(Path('brain/src/probes/grid_doctor').glob('*.py')):
  raw=p.read_bytes();sources.append({'path':str(p),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)});z.writestr(str(p),raw)
(dest/'source-inventory.json').write_text(json.dumps(sources,indent=2)+'\n')
print('archived',len(manifest),'files',sum(x['bytes']for x in manifest),'bytes; zip',(dest/'development.zip').stat().st_size)
