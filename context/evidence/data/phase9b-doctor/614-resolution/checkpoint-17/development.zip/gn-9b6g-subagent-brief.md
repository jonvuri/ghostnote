# Shared brief for 9b.6g subagents (2026-10-22)

You continue one work item of session 9b.6g in
`/Users/jonvuri/Development/ghostnote`. The session is an offline,
bytecode-as-data investigation of the Bitwig 6.1.4 Grid doctor path. Read:

1. `AGENTS.md` (repository instructions; ASD-STE100 prose in comments).
2. `context/plan/phase-9/9b6g-agent-handoff-2026-10-22.md` — the complete
   handoff. Read all of it once, then your own numbered section in
   "Remaining work, in dependency order".
3. The 9b.6g section of
   `context/plan/phase-9/9b-grid-breadth-discovery-and-build-out.md`
   (from line 1395) and the 9b.6g section of
   `context/contracts/GHOSTNOTE_PERFORMANCE_LEDGER.md` (from line 1536).
4. Checkpoint READMEs under
   `context/evidence/data/phase9b-doctor/614-resolution/checkpoint-*/README.md`
   that your item cites. `handoff-2026-10-22/artifact-index.json` maps
   artifact basenames to the archive that holds them.

## Hard rules

- Offline only. Do not call any `mcp__ghostnote__*` or `mcp__ghostworks__*`
  tool, Bitwig, gradle, npm, or any live host. Do not initialize vendor
  classes or run vendor code in a JVM. Inert Python models over class bytes
  only. Do not run the accepted doctor or any driver.
- Do not run `git add`, `git commit`, `git stash`, or `git checkout`.
- Do not edit any tracked file, any existing untracked module under
  `brain/src/probes/grid_doctor/`, any `context/` document, any checkpoint,
  `entry-inventory.json`, or any existing `/tmp/gn-9b6g-*` file. Create new
  modules and tests only (`brain/src/probes/grid_doctor/<new>.py` and
  `test_<new>.py`). If a change to an existing module is required, describe
  the exact change in your final report instead of making it.
- New temporary artifacts use `/tmp/gn-9b6g-<your-prefix>-<n>.{py,json,log}`.
  Run `ls /tmp/gn-9b6g-<your-prefix>-*` first and use the next free number.
  Never overwrite. Keep a failed attempt and use the next number.
- Use `python3 -B` with `PYTHONPATH=brain/src/probes` from the repository
  root. `python` is unavailable. Prefer `rg` for search.
- Respect ledger limits: 120 s per scan, 768 MiB RSS, 8 MiB per report, and
  the per-check limits in the ledger. Use separate processes for large runs.
  Do not print entire maps, huge reports, or whole class dumps; inspect
  narrow members.
- Do not weaken the strict comparator or original selectors. Keep explicit
  variants separate, with a traced reason and narrow tests. Do not change
  tracking mode, drain a queue, or acquire a vendor monitor to make a guard
  pass. Keep every path that needs those things refused.
- Every report you write sets `boundedAdmission: false` and
  `runtimeClassesInitialized: 0` and lists its explicit `conditions`.
  A passing local check is a conditional result, not admission.
- Do not write E records, NOW, plan, or ledger text. The coordinating agent
  does that from your report.

## Tooling

- Class parsing: `grid_symbols.scan.parse(raw, True)`, `instructions(code)`,
  `Refusal`, `Class`, `Member`, `Jar`, `ancestors`.
- Traces: `grid_doctor.ownership.method_trace(jar, cls, method, bootstraps(raw, cls))`
  returns a dict with `instructions` rows (`offset`, `opcode`, `args`,
  `constant`) and `exceptionHandlers`. `grid_doctor.ownership.constant(cls, index)`.
- `grid_doctor.read_dataflow.signature(desc)` splits a descriptor.
- Helper scripts: `/tmp/gn-9b6g-inspect.py` (class dump incl. `<clinit>`) and
  `/tmp/gn-9b6g-resolved-methods.py` (resolve `owner#name#desc` up the
  superclass chain and print the body). Usage:
  `PYTHONPATH=brain/src/probes python3 -B /tmp/gn-9b6g-resolved-methods.py new 'fullOwner#name#descriptor'`
  (`old` for 6.0.6). Supply exact owner paths; short names are ambiguous.
- Example contract module and test: `brain/src/probes/grid_doctor/history_ancestor.py`
  and `test_history_ancestor.py`; `listener_removal.py`; `disposal_wrappers.py`;
  `conditional_contracts.py`. Match their style: small functions, `Refusal`
  on any unsupported form, returned dict with explicit bounds and conditions.
- Example inert interpreter: `/tmp/gn-9b6g-hashmap-remove-model-2.py`.
- Jar paths and SHA-256 (verified today) are in the handoff "Pinned input
  paths" table. Renamed fixtures are `/tmp/gn-9b6g-old-renamed-extra.jar`
  and `/tmp/gn-9b6g-renamed-extra.jar` with maps
  `/tmp/gn-9b6g-old-renamed-map.json` / `/tmp/gn-9b6g-renamed-map.json`.
- Extracted JDK classes (data only): `/tmp/gn-9b6g-runtime-new-arm64-9/java.base`.
- Binding seeds: `/tmp/gn-9b6g-disposal-release-variants-2.json` (richest;
  `memberBindings` is a list of rows), `/tmp/gn-9b6g-listener-mode-1.json`
  (new), `/tmp/gn-9b6g-old-invariant-seed-1.json` (old).
- Run only your own tests:
  `PYTHONPATH=brain/src/probes python3 -B -m unittest grid_doctor.test_<new> -v`.

## Final report format

Be complete but compact. Include:

1. Result: what is now established, under which exact conditions, on which
   jars (6.0.6, 6.1.4, renamed old, renamed new). Numeric bounds as formulas.
2. What remains refused or open, and why (trace facts, not guesses).
3. New files: module/test paths; artifact paths with SHA-256 and byte size.
4. Test commands and their pass/fail output lines.
5. For each new check: the limits it enforces (instruction, method, state,
   time, RSS, report) so the ledger entry can be written.
6. Any required change to an existing module (exact diff description).
7. Whether anything you found changes the fixed doctor's feasibility.
