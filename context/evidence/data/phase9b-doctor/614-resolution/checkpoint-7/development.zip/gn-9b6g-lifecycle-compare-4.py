import json,time
from pathlib import Path
from grid_symbols.scan import Jar,rss_bytes,Refusal
from grid_doctor.descriptor_resolution import Code
from grid_doctor.callee_contracts import compare_callees
from grid_doctor.migrate import merge
from grid_doctor.owned_flow import runtime_parent_bindings
from grid_doctor.dynamic_contracts import dynamic_contract
from grid_doctor.ownership import bootstraps
start=time.perf_counter();jars=[Jar(Path(p))for p in ['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar']];code=Code();seed=json.load(open('/tmp/gn-9b6g-dynamic-contracts-1.json'));lifecycle=json.load(open('/tmp/gn-9b6g-lifecycle-slots-2.json'));inv={v:k for k,v in seed['typeBindings'].items()};receivers=sorted({x['receiver']for x in lifecycle['slots']});catalogs=[{'rows':[]}for _ in jars]
for i,n in enumerate(receivers):
 if n not in inv:continue
 for catalog,owner in zip(catalogs,[inv[n],n]):catalog['rows'].append({'name':str(i),'id':i,'count':1,'matches':[{'runtimeClass':owner}]})
parents,witnesses=runtime_parent_bindings(*jars,*catalogs);seed['typeBindings']=merge([seed['typeBindings'],{}],[parents,{}])[0]
def local(j,c,m):
 try:return dynamic_contract(c,m,j.classes,bootstraps(j.zip.read(c.name+'.class'),c))
 except Refusal as e:
  if str(e).startswith(('dynamic-','contract-unsupported-constant:')):return None
  raise
traces=[dict(owner=n,name=m.name,descriptor=m.desc)for n in ['der','com/bitwig/flt/document/core/master/device/JXO','com/bitwig/flt/document/core/master/device/hgq']for m in jars[1].classes[n].methods]+lifecycle['methods']
r=compare_callees(*jars,traces,seed,code,local_contract=local);r.update(parentWitnesses=witnesses,elapsedMs=(time.perf_counter()-start)*1000,peakRssBytes=rss_bytes());Path('/tmp/gn-9b6g-lifecycle-contracts-4.json').write_text(json.dumps(r,indent=2)+'\n');print('matched',len(r['matched']),'unmatched',r['unmatched']);print(r['elapsedMs'],r['peakRssBytes'])
