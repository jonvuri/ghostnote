import json,hashlib
from pathlib import Path
reports=[]
for index,label in enumerate(('old','new')):
 source=json.load(open('/tmp/gn-9b6g-module-'+label+'-2.json'));pred=json.load(open('/tmp/gn-9b6g-relationship-predicates-1.json'))['builds'][index]
 if source['jarSha256']!=pred['sha256']:raise ValueError('jar mismatch')
 known={(r['classId'],r['propertyId']):r for r in pred['rows']};edges=[];nodes=0
 def visit(node,path):
  global nodes
  nodes+=1
  if nodes>256 or len(path)>64:raise ValueError('factory edge limit')
  for p in node['properties']:
   values=p['value']if isinstance(p['value'],list)else[p['value']]
   for slot,v in enumerate(values):
    if not isinstance(v,dict)or not('classId'in v or'reference'in v):continue
    key=node['classId'],p['id']
    if key not in known:raise ValueError('missing relationship '+str(key))
    r=known[key];edges.append({'parentClassId':key[0],'parentClassName':r['className'],'propertyId':key[1],'propertyName':r['propertyName'],'slot':slot,'inlineObject':'classId'in v,'targetClassId':v.get('classId'),'reference':v.get('reference'),'predicate':r['predicate'],'flags':r['flags'],'parentPath':path})
    if 'classId'in v:visit(v,[*path,[p['id'],slot]])
 visit(source['objects']['root'],[])
 reports.append({'jarSha256':source['jarSha256'],'moduleSha256':source['moduleSha256'],'objectCount':nodes,'edges':edges,'runtimeObserved':False,'boundedAdmission':False})
 print(label,'nodes',nodes,'edges',len(edges),'true',[(e['parentClassName'],e['propertyName'],e['targetClassId'])for e in edges if e['predicate']])
r={'builds':reports,'boundedAdmission':False,'conditions':['These are serialized relationship values, not a live ownership or mutation trace.','Constructor and predicate conditions remain required.','Defaults, generated children, clone initialization, and command effects remain separate.']};Path('/tmp/gn-9b6g-factory-history-edges-1.json').write_text(json.dumps(r,indent=2)+'\n')
