from pathlib import Path
s=Path('brain/src/probes/grid_doctor/contracts.py').read_text();s=s[:s.index('\ndef references(')]
s=s.replace('"""Compare local method contracts without whole-class dependencies.\n\nMatches are trace inputs. They do not resolve receivers or authorize writes.\n"""','"""Compare explicit dynamic call payloads as offline trace inputs only."""')
s=s.replace('def contract(cls, method, classes):','def dynamic_contract(cls, method, classes, bootstrap):')
s=s.replace('    def cp_value(index):','''    def structured(value):
        tag = value['tag']
        if tag in (3, 4, 5, 6, 8):
            return [tag, value['value']]
        if tag == 7:
            return [tag, type_key(value['value'])]
        if tag == 16:
            return [tag, descriptor(value['value'], type_key)]
        if tag in (10, 11):
            owner, name, desc = value['owner'], value['name'], value['descriptor']
            owner_key = type_key(owner)
            signature = descriptor(desc, type_key)
            label = name
            if owner in classes and name not in ('<init>', '<clinit>'):
                identity = tag, owner, name, desc
                if identity not in members:
                    members[identity] = 'member-' + str(len(members))
                label = members[identity]
            return [tag, owner_key, label, signature]
        if tag == 15:
            if value['kind'] not in (5, 6, 7, 8, 9):
                raise Refusal('dynamic-implementation-kind')
            return [tag, value['kind'], structured(value['target'])]
        raise Refusal('dynamic-argument-tag:' + str(tag))

    def dynamic(index):
        bi, nt = cls.cp[index][1]
        if bi >= len(bootstrap) or bi < 0:
            raise Refusal('dynamic-missing-entry')
        ni, di = cls.cp[nt][1]
        name, desc = cls.cp[ni][1], cls.cp[di][1]
        entry = bootstrap[bi]
        handle, args = entry['handle'], entry['arguments']
        target = handle.get('target', {})
        if handle.get('tag') != 15 or handle.get('kind') != 6 or target.get('tag') != 10:
            raise Refusal('dynamic-factory-handle')
        lookup = 'Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/String;Ljava/lang/invoke/MethodType;'
        if target.get('owner') == 'java/lang/invoke/LambdaMetafactory':
            signature = '(' + lookup + 'Ljava/lang/invoke/MethodType;Ljava/lang/invoke/MethodHandle;Ljava/lang/invoke/MethodType;)Ljava/lang/invoke/CallSite;'
            if target.get('name') != 'metafactory' or target.get('descriptor') != signature:
                raise Refusal('dynamic-lambda-factory')
            if len(args) != 3 or [v.get('tag') for v in args] != [16, 15, 16]:
                raise Refusal('dynamic-lambda-arguments')
            if args[1].get('target', {}).get('tag') not in (10, 11):
                raise Refusal('dynamic-implementation-target')
        elif target.get('owner') == 'java/lang/invoke/StringConcatFactory':
            signature = '(' + lookup + 'Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/invoke/CallSite;'
            if target.get('name') != 'makeConcatWithConstants' or target.get('descriptor') != signature:
                raise Refusal('dynamic-concat-factory')
            if name != 'makeConcatWithConstants' or not desc.endswith(')Ljava/lang/String;'):
                raise Refusal('dynamic-concat-result')
            if not 1 <= len(args) <= 256 or args[0].get('tag') != 8:
                raise Refusal('dynamic-concat-arguments')
            if any(v.get('tag') not in (3, 4, 5, 6, 7, 8) for v in args):
                raise Refusal('dynamic-concat-constant')
            if args[0]['value'].count('\\x02') != len(args) - 1:
                raise Refusal('dynamic-concat-constant-count')
        else:
            raise Refusal('dynamic-unsupported-factory')
        # Retain every payload. A match does not establish bootstrap execution.
        return [18, name, descriptor(desc, type_key), structured(handle),
                [structured(value) for value in args]]

    def cp_value(index):''')
s=s.replace('        # The existing parser does not retain BootstrapMethods. Do not treat\n        # an unchecked dynamic call as equivalent to another dynamic call.','        if tag == 18:\n            return dynamic(index)')
Path('brain/src/probes/grid_doctor/dynamic_contracts.py').write_text(s)
