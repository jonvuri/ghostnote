import json
from pathlib import Path
from grid_symbols.scan import Jar,instructions
from grid_doctor.descriptor_resolution import Code
from grid_doctor.fixed_descriptors import integer
from grid_doctor.ownership import constant,method_trace,bootstraps
j=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));code=Code();c=code.get(j,'com/bitwig/flt/document/core/master/Ljp');traces=[]
for m in c.methods:
 raw=instructions(m.code)
 for ix,(off,op,args) in enumerate(raw):
  if integer(c,op,args)==951:
   print(m.name,m.desc,'offset',off)
   for k,o,a in raw[max(0,ix-8):ix+18]:print(k,o,constant(c,int.from_bytes(bytes(a[:2]),'big'))if o in range(178,188)else constant(c,a[0]if o==18 else int.from_bytes(bytes(a),'big'))if o in(18,19)else a)
   traces.append(method_trace(j,c,m,bootstraps(j.zip.read(c.name+'.class'),c)))
Path('/tmp/gn-9b6g-ping-descriptor-1.json').write_text(json.dumps({'jarSha256':j.sha256,'methods':traces,'boundedAdmission':False},indent=2)+'\n')
