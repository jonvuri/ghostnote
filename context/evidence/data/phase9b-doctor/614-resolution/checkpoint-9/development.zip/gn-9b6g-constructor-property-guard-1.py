import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,ancestors,instructions,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.assertion_guards import requirements
from grid_doctor.descriptor_builders import lookup
from grid_doctor.owned_flow import getter_field
from grid_doctor.read_dataflow import ReadFlow
from grid_doctor.ownership import constant,method_trace,bootstraps
from grid_doctor.migrate import member
from grid_doctor.callee_contracts import compare_callees
start=time.perf_counter();jars=[Jar(Path(p))for p in ['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar']];code=Code();seed=json.load(open('/tmp/gn-9b6g-constructor-variants-1.json'));target_keys=[('com/bitwig/flt/document/core/master/device/Oug','ghS','()Lcom/bitwig/flt/document/core/master/device/WSA;'),('com/bitwig/flt/document/core/master/device/WSA','Bpn','()LdeM;')];traces=[dict(zip(('owner','name','descriptor'),k))for k in target_keys];compared=compare_callees(*jars,traces,seed,code)
if compared['unmatched']:raise Refusal('constructor-getter-contracts')
keys={tuple(r['target']):tuple(r['source'])for r in compared['matched']};out=[];traces={};symbols=json.load(open('/tmp/gn-9b6g-resolution-5.json'))['builds'];catalogs=json.load(open('/tmp/gn-9b6g-fixed-1.json'))['builds'];mapping=compared['typeBindings'];inverse={v:k for k,v in mapping.items()}
for i,j in enumerate(jars):
 anchor=next(r['matches'][0]for r in catalogs[i]['rows']if r['name']=='native_device');runtime,descriptor=anchor['runtimeClass'],anchor['descriptor'];slot=target_keys[1]if i else keys[target_keys[1]];root=target_keys[0]if i else keys[target_keys[0]];c=code.get(j,slot[0]);m=member(c,*slot[1:]);raw=instructions(m.code)
 if raw[0][1]!=178:raise Refusal('constructor-property-first-read')
 ref=constant(c,int.from_bytes(bytes(raw[0][2]),'big'));field=ref['owner'],ref['name'],ref['descriptor'];typ=ref['descriptor'][1:-1]
 owners=set()
 for name in [runtime,descriptor,typ]:owners.update(ancestors(j.classes,name,128))
 owners={n for n in owners if any(f.desc=='Z'and f.flags==4120 for f in j.classes[n].fields)};guards=requirements(j,owners,code);p=next(r['reference']for r in symbols[i]['members']if r['role']=='property-id');pc=code.get(j,p[1]);pid=getter_field(pc,member(pc,*p[2:]),'I');flow=ReadFlow(j,code,guards['fields'],pid,2018,descriptor,static_values={field:('ref',typ,'property')});values=[]
 for k,receiver in [(root,('ref',runtime,'object')),(slot,('ref',descriptor,'descriptor'))]:
  result=flow.evaluate(*k,receiver);key=(*k,receiver,(),False);values.append({'method':list(k),'receiver':receiver,'results':sorted(result),'bound':dict(zip(('vendorInstructions','vendorCalls','externalCalls'),flow.bounds[key]))})
 for k in flow.methods:
  c=code.get(j,k[0]);traces[j.sha256,*k]=method_trace(j,c,member(c,*k[1:]),bootstraps(j.zip.read(c.name+'.class'),c))
 out.append({'sha256':j.sha256,'guard':{'field':field,'propertyId':2018,'propertyClass':typ},'paths':values,'staticFields':sorted(flow.static_fields),'assertionGuards':guards})
r={'builds':out,'contracts':compared,'methods':list(traces.values()),'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False};raw=json.dumps(r,separators=(',',':')).encode()
if len(raw)>8*1024**2:raise Refusal('constructor-property-report-limit')
Path('/tmp/gn-9b6g-constructor-property-guard-1.json').write_bytes(raw);print([(b['sha256'],[(p['method'],p['bound'])for p in b['paths']])for b in out]);print(len(raw),r['elapsedMs'],r['peakRssBytes'])
