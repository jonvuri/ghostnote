"""Ad-hoc: list oDc-subtype creations (NEW or static factory return) in the methods of the given classes. Read-only."""
import sys
sys.path.insert(0, '/Users/jonvuri/Development/ghostnote/brain/src/probes')
from grid_symbols.scan import Jar, ancestors, instructions
from pathlib import Path
jar = Jar(Path(sys.argv[1])); base = sys.argv[2]
def is_doc(name):
    return name in jar.classes and base in set(ancestors(jar.classes, name))
for name in sys.argv[3:]:
    if name not in jar.classes: print('ABSENT', name); continue
    code = jar.code(name)
    for m in code.methods:
        if not m.code: continue
        out = []
        for off, op, args in instructions(m.code):
            if op == 187:
                t = code.cp[code.cp[args[0]*256+args[1]][1]][1]
                if is_doc(t): out.append(('NEW', t))
            elif op in (184, 182, 183):
                owner, nt = code.cp[args[0]*256+args[1]][1]; owner = code.cp[code.cp[owner][1]][1]
                ni, di = code.cp[nt][1]; n, d = code.cp[ni][1], code.cp[di][1]
                ret = d[d.index(')')+1:]
                if ret.startswith('L') and is_doc(ret[1:-1]) and op == 184: out.append(('STATIC', owner, n, d))
                elif op in (182,183) and any(is_doc(p) for p in __import__('re').findall(r'L([^;]+);', d[:d.index(')')])):
                    out.append(('CALL-WITH-DOC-ARG', owner, n, d))
        if out and any(o[0] in ('NEW','STATIC') for o in out):
            print(f'{name}.{m.name}{m.desc} flags={m.flags}')
            for o in out: print('    ', o)
