import sys
from pathlib import Path
from grid_symbols.scan import parse
from grid_doctor.ownership import bootstraps, method_trace
bases=[Path('/tmp/gn-9b6g-runtime-new-arm64-9/java.base'),Path('/tmp/gn-9b6g-history-growth-jdk-1/java.base')]
class R:
    def read(self,n):
        for b in bases:
            p=b/n
            if p.exists(): return p.read_bytes()
        raise KeyError(n)
j=type('J',(),{'zip':R()})()
for spec in sys.argv[1:]:
    owner,name,desc=spec.split('#')
    raw=j.zip.read(owner+'.class'); c=parse(raw,True)
    for m in c.methods:
        if (name=='*' or m.name==name) and (desc=='*' or m.desc==desc):
            t=method_trace(j,c,m,bootstraps(raw,c))
            print('METHOD',owner,m.name,m.desc,m.flags,'handlers',t['exceptionHandlers'])
            for x in t['instructions']:
                k=x.get('constant')
                if isinstance(k,dict): k=' '.join(str(k.get(f)) for f in ('owner','name','descriptor','value') if k.get(f) is not None)
                print('  ',x['offset'],x['opcode'],k if k is not None else x['args'])
