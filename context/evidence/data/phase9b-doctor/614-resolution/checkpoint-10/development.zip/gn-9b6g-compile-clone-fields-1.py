exec(open('/tmp/gn-9b6g-inspect.py').read().split('for name in sys.argv[2:]')[0])
for name,fields in [('BgP',{'ERO'}),('dpN',{'BAa'})]:
 c=jar.code(name)
 print('FIELDS',name,[(f.name,f.desc,f.flags)for f in c.fields if f.name in fields])
 for m in c.methods:
  t=method_trace(jar,c,m,bootstraps(jar.zip.read(name+'.class'),c));sites=[r for r in t['references']if r['owner']==name and r['name']in fields and r['opcode']in(179,181)]
  if not sites:continue
  print('METHOD',name,m.name,m.desc,'sites',sites)
  for s in sites:
   for x in t['instructions']:
    if s['offset']-24<=x['offset']<=s['offset']+12:print(x['offset'],x['opcode'],x.get('constant',x['args']))
