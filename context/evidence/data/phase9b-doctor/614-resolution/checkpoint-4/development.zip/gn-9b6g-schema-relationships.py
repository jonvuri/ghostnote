import json,zipfile,collections,time
from pathlib import Path
from grid_symbols.scan import Jar,ancestors,instructions,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.fixed_descriptors import integer
from grid_doctor.ownership import constant
start=time.perf_counter();wanted=collections.defaultdict(set)
def visit(x):
 if isinstance(x,dict):
  if {'classId','className','properties'}<=x.keys():
   for p in x['properties']:
    if p.get('relationship'):wanted[x['className'],x['classId']].add((p['name'],p['id']))
  for v in x.values():visit(v)
 elif isinstance(x,list):
  for v in x:visit(v)
with zipfile.ZipFile('context/evidence/data/phase9b-doctor/live-v20/captures.zip')as z:
 for n in z.namelist():visit(json.loads(z.read(n)))
j=Jar(Path('/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar'));code=Code();catalog=json.load(open('/tmp/gn-9b6g-fixed-1.json'))['builds'][0];symbols=json.load(open('/tmp/gn-9b6g-resolution-5.json'))['builds'][0];rel=symbols['types']['relationship'];rows=[]
for r in catalog['rows']:
 pair=r['name'],r['id'];todo=wanted[pair].copy();found=[];owner=r['matches'][0]['descriptor']
 while owner in j.classes and todo:
  cls=code.get(j,owner);hits=collections.defaultdict(list)
  for m in cls.methods:
   raw=instructions(m.code)
   for i,(off,op,args)in enumerate(raw):
    if op not in (18,19)or i<2 or i+1>=len(raw):continue
    c=constant(cls,args[0]if op==18 else args[0]*256+args[1]);pid=integer(cls,raw[i+1][1],raw[i+1][2])
    if c['tag']!=8 or(c['value'],pid)not in todo:continue
    if raw[i-2][1]!=187 or raw[i-1][1]!=89:continue
    a=raw[i-2][2];typ=constant(cls,a[0]*256+a[1])['value']
    if rel not in ancestors(j.classes,typ,128):continue
    hits[c['value'],pid].append({'source':[owner,m.name,m.desc],'offset':off,'class':typ})
  for key,ms in hits.items():
   found.append({'name':key[0],'id':key[1],'matches':ms});todo.remove(key)
  owner=cls.parent
 rows.append({'name':pair[0],'id':pair[1],'properties':found,'missing':sorted(todo)})
out={'sha256':j.sha256,'rows':rows,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False};Path('/tmp/gn-9b6g-schema-relationships-1.json').write_text(json.dumps(out,indent=2));print('wanted',sum(map(len,wanted.values())),'found',sum(len(r['properties'])for r in rows),'missing',[(r['name'],r['missing'])for r in rows if r['missing']]);print('duplicates',[(r['name'],p['name'],len(p['matches']))for r in rows for p in r['properties']if len(p['matches'])!=1]);print('classes',sorted({p['matches'][0]['class']for r in rows for p in r['properties']}))
