import json,time
from pathlib import Path
from grid_symbols.scan import Jar,parse,rss_bytes,Refusal
from grid_doctor.fixed_descriptors import constructor_pair
from grid_doctor.ownership import method_trace,bootstraps
start=time.perf_counter();j=Jar(Path('/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar'));labels=['analyzable_sample_reference_handle','simple_single_sample_resource'];rows=[];total=0
for name in j.classes:
 raw=j.zip.read(name+'.class');total+=len(raw)
 if total>134217728:raise Refusal('resource-label-byte-limit')
 hits=[label for label in labels if label.encode()in raw]
 if not hits:continue
 cls=parse(raw,True);bs=bootstraps(raw,cls);ctors=[m for m in cls.methods if m.name=='<init>'];rows.append({'class':name,'labels':hits,'constructors':[method_trace(j,cls,m,bs)for m in ctors]});print(name,hits,[(m.desc,constructor_pair(cls,m))for m in ctors],flush=True)
 if len(rows)>32:raise Refusal('resource-label-match-limit')
r={'sha256':j.sha256,'rows':rows,'bytesRead':total,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False};Path('/tmp/gn-9b6g-resource-label-search-1.json').write_text(json.dumps(r,indent=2)+'\n');print(r['elapsedMs'],r['peakRssBytes'])
