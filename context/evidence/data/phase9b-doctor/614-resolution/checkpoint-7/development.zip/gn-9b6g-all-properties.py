import json,zipfile,time
from pathlib import Path
from collections import defaultdict
from grid_symbols.scan import Jar,Refusal,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.property_contracts import infer_relationship_classes,bind_properties
start=time.perf_counter();jars=[Jar(Path(p))for p in ['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar']];code=Code();wanted=defaultdict(set)
def visit(v):
 if isinstance(v,dict):
  if {'classId','className','properties'}<=v.keys():
   for p in v['properties']:wanted[v['className'],v['classId']].add((p['name'],p['id']))
  for x in v.values():visit(x)
 elif isinstance(v,list):
  for x in v:visit(x)
with zipfile.ZipFile('context/evidence/data/phase9b-doctor/live-v20/captures.zip')as z:
 if len(z.infolist())>128 or sum(i.file_size for i in z.infolist())>32*1024**2:raise Refusal('capture-limit')
 for n in z.namelist():visit(json.loads(z.read(n)))
symbols=json.load(open('/tmp/gn-9b6g-resolution-5.json'))['builds'];catalogs=json.load(open('/tmp/gn-9b6g-fixed-1.json'))['builds'];captured,census=infer_relationship_classes(jars[0],catalogs[0],wanted,symbols[0]['types']['property-base'],code)
print('wanted',sum(map(len,wanted.values())),'found',sum(map(len,captured.values())),'complete',census['completeSourceCensus'],flush=True)
builds=[bind_properties(jars[0],j,catalogs[0],catalogs[i],captured,symbols[i],code)for i,j in enumerate(jars)]
r={'builds':builds,'sourcePropertyCensus':census,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False};raw=json.dumps(r,indent=2).encode()
if len(raw)>8*1024**2:raise Refusal('all-property-report-limit')
Path('/tmp/gn-9b6g-all-properties-1.json').write_bytes(raw);print('counts',[sum(len(x['properties'])for x in b['properties'])for b in builds],'missing',[[x['missing']for x in b['properties']if x['missing']]for b in builds]);print('bytes',len(raw),'ms',r['elapsedMs'],'rss',r['peakRssBytes'])
