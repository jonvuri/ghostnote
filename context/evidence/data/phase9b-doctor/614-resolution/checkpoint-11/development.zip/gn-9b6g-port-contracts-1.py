import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,rss_bytes,ancestors
from grid_doctor.descriptor_resolution import Code
from grid_doctor.descriptor_builders import lookup
from grid_doctor.callee_contracts import compare_callees
from grid_doctor.migrate import merge
from grid_doctor.dynamic_contracts import dynamic_contract
from grid_doctor.ownership import bootstraps,method_trace
start=time.perf_counter();jars=[Jar(Path(p))for p in ['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar']];code=Code();seed=json.load(open('/tmp/gn-9b6g-clone-contracts-2.json'));known=[seed['typeBindings'],{tuple(r['source']):tuple(r['target'])for r in seed['memberBindings']}];inverse={v:k for k,v in known[0].items()};parents=[]
for runtime in ('FCo','ZDH','vta'):
 old=list(ancestors(jars[0].classes,inverse[runtime],128));new=list(ancestors(jars[1].classes,runtime,128))
 if len(old)!=len(new)or old[-1]!=new[-1]:raise Refusal('port-parent-shape')
 known=merge(known,[{a:b for a,b in zip(old,new)if a in jars[0].classes},{}]);parents.append({'source':old,'target':new})
seed={'typeBindings':known[0],'memberBindings':[{'source':list(k),'target':list(v)}for k,v in known[1].items()]}
specs=[('FCo','ng_','()LdeS;'),('FCo','Ucl','()LoV;'),('ZDH','ng_','()LdeS;'),('ZDH','LaE','()LYkp;'),('FCo','<init>','()V'),('ZDH','<init>','()V'),('FCo','cfM','(Ljava/lang/String;LWgD;Lnyh;)LFCo;'),('FCo','MRY','(Ljava/lang/String;LWgD;Lnyh;)LFCo;'),('FCo','cfM','(LWgD;Lnyh;)LFCo;'),('FCo','MRY','(LWgD;Lnyh;)LFCo;'),('FCo','cfM','(ZLWgD;Lnyh;)LFCo;'),('FCo','cfM','(ZLWgD;)LFCo;'),('ZDH','cfM','(ZLjava/lang/String;ILjava/lang/String;ZLnyh;)LZDH;'),('ZDH','MRY','(ZLjava/lang/String;ILjava/lang/String;ZLnyh;)V'),('com/bitwig/nitro/uMi','Hnt','(Lcom/bitwig/nitro/CcL;IZ)V')]
for n,d in [('iHb','()LcOu;'),('tp2','()Z'),('TMF','()Ljava/lang/String;'),('E3','()I')]:specs.append(('com/bitwig/nitro/CcL',n,d))
traces={}
for spec in specs:
 c,m=lookup(jars[1],code,*spec);traces[c.name,m.name,m.desc]=method_trace(jars[1],c,m,bootstraps(jars[1].zip.read(c.name+'.class'),c))
def local(j,c,m):
 try:return dynamic_contract(c,m,j.classes,bootstraps(j.zip.read(c.name+'.class'),c))
 except Refusal as e:
  if str(e).startswith(('dynamic-','contract-unsupported-constant:')):return None
  raise
r=compare_callees(*jars,list(traces.values()),seed,code,local_contract=local);r.update(traces=list(traces.values()),parentBindings=parents,elapsedMs=(time.perf_counter()-start)*1000,peakRssBytes=rss_bytes());raw=json.dumps(r,indent=2).encode()
if len(raw)>8*1024**2:raise Refusal('port-contract-report-limit')
Path('/tmp/gn-9b6g-port-contracts-1.json').write_bytes(raw);print('matched',len(r['matched']),'unmatched',r['unmatched']);print(len(raw),r['elapsedMs'],r['peakRssBytes'])
