import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.constructor_paths import catalog_constructor_paths
from grid_doctor.property_contracts import bind_properties
start=time.perf_counter();code=Code();jars=[Jar(Path(p))for p in ['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar']];symbols=json.load(open('/tmp/gn-9b6g-resolution-5.json'))['builds'];catalogs=[]
for i,j in enumerate(jars):
 rows=json.load(open('/tmp/gn-9b6g-fixed-1.json'))['builds'][i]['rows'];registry=json.load(open('/tmp/gn-9b6g-registry-'+('old-'if i==0 else'')+'closure-1.json'))['selectedRows'];selected={(r['name'],r['id']):r for r in rows+registry};catalogs.append({'sha256':j.sha256,'rows':list(selected.values())})
labels=json.load(open('/tmp/gn-9b6g-builder-labels-1.json'))['builds'][0]['rows'];captured={}
for row in labels:
 props={}
 for p in row['properties']:
  if len(p['allocations'])!=1:raise Refusal('registration-allocation-count')
  x=p['allocations'][0];key=x['name'],x['id']
  if key in props:raise Refusal('duplicate-registered-label')
  props[key]=x['class']
 captured[row['name'],row['id']]=props
paths=[catalog_constructor_paths(j,catalogs[i],code)for i,j in enumerate(jars)]
for i,j in enumerate(jars):
 r=bind_properties(jars[0],j,catalogs[0],catalogs[i],captured,symbols[i],code,constructor_paths=(paths[0][0],paths[i][0]));r.update(elapsedMs=(time.perf_counter()-start)*1000,peakRssBytes=rss_bytes());raw=json.dumps(r,separators=(',',':')).encode()
 if len(raw)>8*1024**2:raise Refusal('builder-property-report-limit')
 Path('/tmp/gn-9b6g-builder-property-bindings-1-'+str(i)+'.json').write_bytes(raw);print(i,'properties',sum(len(x['properties'])for x in r['properties']),'missing',[(x['name'],x['missing'])for x in r['properties']if x['missing']],'bytes',len(raw),'ms',r['elapsedMs'],'rss',r['peakRssBytes'],flush=True)
