import json
from pathlib import Path
from collections import defaultdict, Counter
from grid_symbols.scan import Jar,class_shape,digest,class_trace
old=Jar(Path('/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar'))
new=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'))
rules=json.loads(Path('context/evidence/data/phase9b-doctor/v20-preparation/selectors.json').read_text())
prior=json.loads(Path('context/evidence/data/phase9b-doctor/v20-preparation/candidate.json').read_text())
index=defaultdict(list)
for n,k in new.keys.items(): index[k].append(n)
for role,r in rules['types'].items():
    ns=index[r['shape']]
    if 'codeTrace' in r: ns=[n for n in ns if class_trace(new.code(n),new.keys)==r['codeTrace']]
    print(role,len(ns),ns)
for jar in [old,new]:
    keys={n:digest(class_shape(c,lambda x:'vendor' if x in jar.classes else x)) for n,c in jar.classes.items()}
    if jar==old: key=keys[prior['types']['boolean-atom']]; c=jar.classes[prior['types']['boolean-atom']]; print('old boolean',c)
    else:
        ns=[n for n,k in keys.items() if k==key];print('new base-shape boolean',ns)
        for n in ns: print(jar.classes[n])
print(new.stats)
