import json,time
from pathlib import Path
from collections import Counter,defaultdict
from grid_symbols.scan import Jar,instructions,Refusal,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.migrate import member
from grid_doctor.ownership import constant,method_trace,bootstraps
start=time.perf_counter();jar=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));code=Code();data=json.load(open('/tmp/gn-9b6g-factory-relationships-1.json'));root=json.load(open('/tmp/gn-9b6g-module-new-2.json'))['objects']['root'];kinds={};traces={}
for row in data['builds'][1]['properties']:
 for prop in row['properties']:
  owner,name,desc=prop['target'];cls=code.get(jar,owner);m=member(cls,name,desc);raw=instructions(m.code);enum=[]
  for off,op,args in raw:
   if op!=178:continue
   ref=constant(cls,int.from_bytes(bytes(args),'big'))
   if ref['owner']=='cUb'and ref['descriptor']=='LcUb;':enum.append(ref['name'])
  if len(enum)!=1:raise Refusal('kind-getter-enum-count')
  kinds[row['id'],prop['id']]={'kindField':enum[0],'kind':{'cfM':'WEAK','MRY':'SHARED','Hnt':'STRONG'}[enum[0]],'className':row['name'],'propertyName':prop['name']}
  traces[owner,name,desc]=method_trace(jar,cls,m,bootstraps(jar.zip.read(owner+'.class'),cls))
nodes=[];edges=[]
def visit(obj):
 source=len(nodes)+1;nodes.append({'id':source,'classId':obj['classId']})
 for prop in obj['properties']:
  values=prop['value']if isinstance(prop['value'],list)else[prop['value']]
  for value in values:
   if not isinstance(value,dict):continue
   if 'classId'in value:target=visit(value)
   elif 'reference'in value:target=value['reference']
   else:continue
   if not 1<=target<=len(nodes):raise Refusal('kind-reference')
   edges.append({'source':source,'target':target,'propertyId':prop['id'],**kinds[obj['classId'],prop['id']]})
 return source
visit(root)
parents=defaultdict(list)
for e in edges:
 if e['kind']=='STRONG':parents[e['target']].append(e)
for n in nodes:
 if len(parents[n['id']])!=(0 if n['id']==1 else 1):raise Refusal('kind-parent-count:'+str(n))
depths=[]
for n in nodes:
 seen=set();cur=n['id']
 while cur!=1:
  if cur in seen or len(seen)>=64:raise Refusal('kind-parent-cycle')
  seen.add(cur);cur=parents[cur][0]['source']
 depths.append(len(seen))
r={'jarSha256':jar.sha256,'nodes':nodes,'edges':edges,'maxSerializedDepth':max(depths),'kindCounts':dict(Counter(e['kind']for e in edges)),'methodTraces':list(traces.values()),'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'limits':['Kinds use pinned cUb enum fields and the traced constructor forwarding.','This graph excludes initialization, deserialization, and clone growth.','It is not a runtime ownership or disposal proof.'],'boundedAdmission':False}
Path('/tmp/gn-9b6g-serialized-ownership-1.json').write_text(json.dumps(r,indent=2));print('nodes',len(nodes),'edges',len(edges),'kinds',r['kindCounts'],'depth',r['maxSerializedDepth'],'elapsedMs',r['elapsedMs'],'rss',r['peakRssBytes'])
