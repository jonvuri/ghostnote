import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.owned_flow import owned_collectors
start=time.perf_counter();code=Code();symbols=json.load(open('/tmp/gn-9b6g-resolution-5.json'))['builds']
for i,path in enumerate(['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar']):
 j=Jar(Path(path));rows=json.load(open('/tmp/gn-9b6g-fixed-1.json'))['builds'][i]['rows'];registry=json.load(open('/tmp/gn-9b6g-registry-'+('old-'if i==0 else'')+'closure-1.json'))['selectedRows'];selected={(r['name'],r['id']):r for r in rows+registry};catalog={'sha256':j.sha256,'rows':list(selected.values())}
 reports=[json.load(open('/tmp/gn-9b6g-builder-property-bindings-1-0.json'))]if i==0 else[json.load(open('/tmp/gn-9b6g-builder-property-bindings-3-0.json'))]+[json.load(open('/tmp/gn-9b6g-builder-property-bindings-4-'+str(n)+'.json'))for n in range(9)]
 props={'sha256':j.sha256,'properties':[row for report in reports for row in report['properties']]};r=owned_collectors(j,code,symbols[i],catalog,props);r.update(elapsedMs=(time.perf_counter()-start)*1000,peakRssBytes=rss_bytes());raw=json.dumps(r,separators=(',',':')).encode()
 if len(raw)>8*1024**2:raise Refusal('builder-owned-report-limit')
 Path('/tmp/gn-9b6g-builder-owned-flow-2-'+str(i)+'.json').write_bytes(raw);print(i,'paths',len(r['paths']),'methods',len(r['methods']),'errors',[(p['className'],p['propertyName'],p['error'])for p in r['paths']if p['error']],'work',r['work'],'bytes',len(raw),'ms',r['elapsedMs'],'rss',r['peakRssBytes'],flush=True)
