import json,subprocess,sys,time,hashlib
from pathlib import Path
from grid_doctor.mutated_fixture import write_model
old=Path('/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar');new=Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar');plan='context/evidence/data/phase9b-doctor/614-resolution/anchor-plan.json';result=[]
for change in ('missing','duplicate','access','signature','operation','parent-cycle'):
 started=time.perf_counter(); dest=Path('/tmp/gn-9b6g-mutant-'+change+'.jar');report=Path('/tmp/gn-9b6g-mutant-'+change+'.json')
 write_model(new,dest,'com/bitwig/flt/document/core/master/device/BZG','Grk','()Ljava/util/List;',change)
 p=subprocess.run([sys.executable,'-B','-m','grid_doctor.descriptor_resolution','--old-jar',str(old),'--new-jar',str(dest),'--plan',plan,'--report',str(report)],capture_output=True,text=True,timeout=125)
 log=Path('/tmp/gn-9b6g-mutant-'+change+'.log');log.write_text(p.stdout+p.stderr)
 outcome={'change':change,'returncode':p.returncode,'elapsedMs':round((time.perf_counter()-started)*1000,3),'log':str(log),'mutantSha256':hashlib.sha256(dest.read_bytes()).hexdigest()}
 if report.exists():
  r=json.loads(report.read_bytes());b=r['builds'][1];outcome['statuses']={x['role']:x['status']for x in b['members']if x['status']not in ('exact-operation-contract','field-operation-bound','abstract-slot-bound','bootstrap-local-contract')}
  outcome['symbolicCoverageComplete']=b.get('symbolTable',{}).get('symbolicCoverageComplete',False)
 print(json.dumps(outcome),flush=True);result.append(outcome)
 Path('/tmp/gn-9b6g-structural-resilience.json').write_text(json.dumps(result,indent=2))
