set -eu
export PYTHONPATH=brain/src/probes
python3 -B -m grid_doctor.wrapper_bounds --old-jar '/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar' --new-jar /tmp/gn-9b6g-old-renamed-extra.jar --symbols /tmp/gn-9b6g-old-renamed-result-1.json --properties /tmp/gn-9b6g-old-renamed-properties-1.json --slots /tmp/gn-9b6g-old-renamed-fixed-read-1/slots-1.json --report /tmp/gn-9b6g-old-renamed-wrapper-contracts-1.json
