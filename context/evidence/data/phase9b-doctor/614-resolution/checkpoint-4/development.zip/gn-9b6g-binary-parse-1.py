import struct,json,sys,collections
from pathlib import Path
raw=Path(sys.argv[1]).read_bytes();pos=0;nodes=[];depth=0;work=0

def take(n):
 global pos
 if n<0 or pos+n>len(raw):raise ValueError(('bounds',pos,n))
 b=raw[pos:pos+n];pos+=n;return b

def integer():return int.from_bytes(take(4),'big',signed=True)
def string():return take(integer()).decode('utf8')
def obj(cid=None):
 global depth,work
 work+=1;depth+=1
 if work>4096 or depth>64:raise ValueError('bound')
 start=pos;cid=integer()if cid is None else cid
 if cid==4:cid=string()
 node={'id':cid,'offset':start,'props':[]};nodes.append(node)
 while True:
  prop=integer()
  if prop==0:break
  if prop==1:prop=string()
  tag=take(1)[0];value=val(tag);node['props'].append({'id':prop,'type':tag,'value':value})
 depth-=1;return node

def val(t):
 if t in(1,2,3,4):return int.from_bytes(take({1:1,2:2,3:4,4:8}[t]),'big',signed=True)
 if t==5:return bool(take(1)[0])
 if t in(6,7):return struct.unpack('>'+('f'if t==6 else'd'),take(4 if t==6 else8))[0]
 if t==8:return string()
 if t==9:return obj()
 if t==10:return None
 if t==11:return {'ref':integer()}
 if t in(12,26):raise ValueError(('untraced-ref',t,pos))
 if t in(13,14,15,16,17,23,24):return {'arrayHex':take(integer()*{13:1,14:2,15:4,16:8,17:1,23:4,24:8}[t]).hex()}
 if t==25:return [string()for _ in range(integer())]
 if t==21:return {'uuid':take(16).hex()}
 if t==22:return {'color':list(struct.unpack('>ffff',take(16)))}
 if t==18:
  items=[]
  while True:
   cid=integer()
   if cid==3:return items
   if cid==0:items.append(None)
   elif cid==1:items.append({'ref':integer()})
   elif cid in(2,5):raise ValueError(('untraced-list-ref',cid,pos))
   else:items.append(obj(cid))
 if t==20:
  items={}
  while take(1)!=b'\0':items[string()]=obj()
  return items
 raise ValueError(('tag',t,pos))

root=obj();print('position',pos,'bytes',len(raw),'nodes',len(nodes),'classes',collections.Counter(x['id']for x in nodes));Path('/tmp/gn-9b6g-amplify-parse-1.json').write_text(json.dumps({'root':root,'bytes':pos,'totalBytes':len(raw),'classCounts':dict(collections.Counter(x['id']for x in nodes))},indent=2))
