import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.descriptor_builders import registrations
start=time.perf_counter();code=Code();out=[]
for i,path in enumerate(['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar']):
 j=Jar(Path(path));rows=json.load(open('/tmp/gn-9b6g-fixed-1.json'))['builds'][i]['rows'];registry=json.load(open('/tmp/gn-9b6g-registry-'+('old-'if i==0 else'')+'closure-1.json'))['selectedRows'];selected={(r['name'],r['id']):r for r in rows+registry};results=[]
 for pair,r in sorted(selected.items()):
  n=r['matches'][0]['descriptor']
  try:
   b=registrations(j,code,n,('cXV','ffA','(Ljava/util/List;)V')if i==0 else('der','cfM','(Ljava/util/List;)V'),('cXV','ffA','(LcYs;Ljava/util/List;)V')if i==0 else('der','cfM','(LdeN;Ljava/util/List;)V'));b.update(name=pair[0],id=pair[1]);results.append(b)
  except Refusal as e:results.append({'name':pair[0],'id':pair[1],'receiver':n,'refusal':str(e)})
 out.append({'sha256':j.sha256,'rows':results});print(i,'rows',len(results),'pass',sum('refusal'not in r for r in results),'refused',[(r['name'],r['refusal'])for r in results if'refusal'in r],flush=True)
r={'builds':out,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False};raw=json.dumps(r,indent=2).encode()
if len(raw)>8*1024**2:raise Refusal('builder-report-limit')
Path('/tmp/gn-9b6g-builder-census-1.json').write_bytes(raw);print(len(raw),r['elapsedMs'],r['peakRssBytes'])
