import json,time,difflib,re
from pathlib import Path
from grid_symbols.scan import Jar,instructions,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.ownership import constant,method_trace,bootstraps
from grid_doctor.migrate import member
start=time.perf_counter();jars=[Jar(Path(p))for p in ['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar']];code=Code();seed=json.load(open('/tmp/gn-9b6g-factory-constructor-contracts-1.json'));types=seed['typeBindings'];inv={v:k for k,v in types.items()};members={tuple(r['source']):tuple(r['target'])for r in seed['memberBindings']};rows=[]
def norm(c,m,old):
 result=[]
 for off,op,args in instructions(m.code):
  v=list(args)
  if op in(18,19,20,178,179,180,181,182,183,184,185,186,187,189,192,193,197):
   v=constant(c,args[0]if op==18 else int.from_bytes(bytes(args[:2]),'big'))
   if old:
    v=dict(v)
    if v['tag']in(9,10,11):
     k=(v['tag'],v['owner'],v['name'],v['descriptor'])
     if k in members:v=dict(zip(('tag','owner','name','descriptor'),members[k]))
     else:v.update(owner=types.get(v['owner'],v['owner']),descriptor=re.sub(r'L([^;]+);',lambda x:'L'+types.get(x[1],x[1])+';',v['descriptor']))
    elif v['tag']==7:v['value']=types.get(v['value'],v['value'])
  result.append(json.dumps([op,v],sort_keys=True))
 return result
for item in seed['unmatched']:
 target=item['target'];old=[inv[target[0]],*target[1:]];traces=[];lines=[]
 for i,key in enumerate([old,target]):
  c=code.get(jars[i],key[0]);m=member(c,*key[1:]);traces.append(method_trace(jars[i],c,m,bootstraps(jars[i].zip.read(c.name+'.class'),c)));lines.append(norm(c,m,i==0))
 diff=list(difflib.unified_diff(*lines,fromfile=str(old),tofile=str(target),lineterm=''));rows.append({'source':traces[0],'target':traces[1],'boundReferenceDiff':diff});print('\n'.join(diff))
r={'rows':rows,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False};Path('/tmp/gn-9b6g-constructor-differences-1.json').write_text(json.dumps(r,indent=2)+'\n')
