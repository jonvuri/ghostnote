import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,ancestors,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.assertion_guards import requirements
from grid_doctor.read_dataflow import ReadFlow
from grid_doctor.callee_contracts import compare_callees
start=time.perf_counter();jars=[Jar(Path(p))for p in ['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar']];code=Code();out=[]
for i,j in enumerate(jars):
 symbols=json.load(open('/tmp/gn-9b6g-resolution-5.json'))['builds'][i];slot=next(r['reference'][1:]for r in symbols['members']if r['role']=='descriptor');cat=json.load(open('/tmp/gn-9b6g-fixed-1.json'))['builds'][i]['rows']+json.load(open('/tmp/gn-9b6g-registry-'+('old-'if i==0 else'')+'closure-1.json'))['selectedRows']+json.load(open('/tmp/gn-9b6g-default-catalog-4.json'))['builds'][i]['rows'];cat=list({(r['name'],r['id']):r for r in cat}.values());owners=set()
 for row in cat:
  for k in ['descriptor','runtimeClass']:owners.update(ancestors(j.classes,row['matches'][0][k],128))
 guards=requirements(j,{n for n in owners if any(f.desc=='Z'and f.flags==4120 for f in j.classes[n].fields)},code);rows=[];methods=set()
 for row in cat:
  a=row['matches'][0];flow=ReadFlow(j,code,guards['fields'],('unused','unused','I'),-1,a['descriptor']);key=(*slot,('ref',a['runtimeClass'],'object'),(),False);returned=flow.evaluate(*slot,key[3])
  if returned!={('ref',a['descriptor'],'descriptor')}:raise Refusal('descriptor-read-result')
  methods.update(flow.methods);rows.append({'name':row['name'],'id':row['id'],'runtimeClass':a['runtimeClass'],'descriptorClass':a['descriptor'],'cost':dict(zip(('vendorInstructions','vendorCalls','externalCalls'),flow.bounds[key])),'staticFields':sorted(flow.static_fields),'methods':sorted(flow.methods)})
 out.append({'sha256':j.sha256,'rows':rows,'methods':sorted(methods),'assertionGuards':guards})
seed=json.load(open('/tmp/gn-9b6g-invariant-lock-read-1.json'))['contracts'];compared=compare_callees(*jars,[dict(zip(('owner','name','descriptor'),k))for k in out[1]['methods']],seed,code);r={'builds':out,'contracts':compared,'boundedAdmission':False,'runtimeObserved':False,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes()};raw=json.dumps(r,indent=2).encode()
if len(raw)>8*1024**2:raise Refusal('all-descriptor-read-report-limit')
Path('/tmp/gn-9b6g-all-descriptor-reads-1.json').write_bytes(raw)
for b in out:print('rows',len(b['rows']),'methods',len(b['methods']),'max',{k:max(x['cost'][k]for x in b['rows'])for k in b['rows'][0]['cost']})
print('contracts',len(compared['matched']),compared['unmatched']);print(len(raw),r['elapsedMs'],r['peakRssBytes'])
