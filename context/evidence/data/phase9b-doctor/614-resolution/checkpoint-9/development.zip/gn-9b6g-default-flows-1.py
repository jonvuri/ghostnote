import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,ancestors,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.assertion_guards import requirements
from grid_doctor.owned_flow import owned_collectors,runtime_parent_bindings
from grid_doctor.read_dataflow import fixed_read_flow
from grid_doctor.callee_contracts import compare_callees
from grid_doctor.fixed_read_checkpoint import membership_variants
from grid_doctor.migrate import merge
start=time.perf_counter();code=Code();jars=[Jar(Path(p))for p in ['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar']];catalogs=json.load(open('/tmp/gn-9b6g-default-catalog-4.json'))['builds'];symbols=json.load(open('/tmp/gn-9b6g-resolution-5.json'))['builds'];reports=[]
for i,j in enumerate(jars):
 props=json.load(open('/tmp/gn-9b6g-default-property-bindings-2-'+str(i)+'.json'));owned=owned_collectors(j,code,symbols[i],catalogs[i],props);rows=[dict(r,properties=[p for p in r['properties']if('cYE'if i==0 else'deZ')in ancestors(j.classes,p['targetClass'],128)])for r in props['properties']]
 # Derive the generic property base from the known scalar class hierarchy.
 value_base=next(n for n in ancestors(j.classes,symbols[i]['types']['relationship'],128)if any(m.desc.startswith('(L'+symbols[i]['types']['object']+';)L')and m.flags&1024 for m in j.classes[n].methods))
 rows=[dict(r,properties=[p for p in r['properties']if value_base in ancestors(j.classes,p['targetClass'],128)])for r in props['properties']]
 owners=set()
 for r in catalogs[i]['rows']:
  for k in ('descriptor','runtimeClass'):owners.update(ancestors(j.classes,r['matches'][0][k],128))
 for r in rows:
  for p in r['properties']:owners.update(ancestors(j.classes,p['targetClass'],128))
 owners={n for n in owners if any(f.desc=='Z'and f.flags==4120 for f in j.classes[n].fields)};guards=requirements(j,owners,code);reads=fixed_read_flow(j,code,symbols[i],catalogs[i],{'properties':rows},guards['fields']);reports.append({'reads':reads,'owned':owned,'assertionGuards':guards});print(i,'base',value_base,'reads',len(reads['paths']),'owned',len(owned['paths']),'errors',[p['error']for p in reads['paths']+owned['paths']if p['error']],flush=True)
seed=json.load(open('/tmp/gn-9b6g-default-descriptor-bindings-1.json'));props=json.load(open('/tmp/gn-9b6g-default-property-bindings-2-1.json'));parents,witnesses=runtime_parent_bindings(*jars,*catalogs);known=merge([seed['typeBindings'],{tuple(r['source']):tuple(r['target'])for r in seed['memberBindings']}],[props['typeBindings'],{tuple(r['source']):tuple(r['target'])for r in props['memberBindings']}]);known=merge(known,[parents,{}]);seed.update(typeBindings=known[0],memberBindings=[{'source':list(k),'target':list(v)}for k,v in known[1].items()]);traces={tuple(t[k]for k in ('owner','name','descriptor')):t for t in reports[1]['owned']['methods']}
for k in reports[1]['reads']['methods']:traces[tuple(k)]=dict(zip(('owner','name','descriptor'),k))
traces=list(traces.values());compared=compare_callees(*jars,traces,seed,code,membership_variants(jars[1],symbols[1],code,traces));r={'builds':reports,'contracts':compared,'runtimeParentInputs':witnesses,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False};raw=json.dumps(r,separators=(',',':')).encode()
if len(raw)>8*1024**2:raise Refusal('default-flow-report-limit')
Path('/tmp/gn-9b6g-default-flows-1.json').write_bytes(raw);print('matched',len(compared['matched']),'unmatched',compared['unmatched']);print(len(raw),r['elapsedMs'],r['peakRssBytes'])
