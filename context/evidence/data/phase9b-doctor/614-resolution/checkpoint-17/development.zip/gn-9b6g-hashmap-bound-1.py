"""Check the analytical HashMap.remove bound against inert bytecode execution.

The interpreter is a copy of /tmp/gn-9b6g-hashmap-remove-model-2.py with
counters by offset. It reads class bytes as data and initializes no class.
"""
import json, time, hashlib, random, sys, resource
from pathlib import Path
from collections import Counter, defaultdict
from grid_symbols.scan import parse
from grid_doctor.ownership import method_trace, bootstraps
from grid_doctor.read_dataflow import signature
from grid_doctor import hashmap_removal as hm

start = time.perf_counter()
OUT = Path('/tmp/gn-9b6g-hashmap-bound-1.json')
if OUT.exists():
    raise SystemExit('report exists')
base = Path('/tmp/gn-9b6g-runtime-new-arm64-9/java.base')
contract = hm.contract(base)


class Reader:
    def read(self, n):
        return (base / n).read_bytes()


j = type('J', (), {'zip': Reader()})()
methods = {}; hashes = {}
wanted = {'java/util/HashMap': {'remove', 'hash', 'removeNode', 'afterNodeRemoval', 'replacementNode', 'comparableClassFor'},
          'java/util/HashMap$Node': {'<init>'},
          'java/util/HashMap$TreeNode': {'getTreeNode', 'root', 'find', 'removeTreeNode', 'untreeify', 'balanceDeletion', 'rotateLeft', 'rotateRight', 'moveRootToFront'},
          'java/lang/Object': {'<init>', 'equals', 'hashCode'}}
for owner, names in wanted.items():
    raw = j.zip.read(owner + '.class'); c = parse(raw, True); hashes[owner] = hashlib.sha256(raw).hexdigest()
    for m in c.methods:
        if m.name in names:
            methods[owner, m.name, m.desc] = method_trace(j, c, m, bootstraps(raw, c))
assert hashes == hm.CLASS_SHA256
NODE = 'java/util/HashMap$Node'; TREE = 'java/util/HashMap$TreeNode'; MAP = 'java/util/HashMap'
for key in methods:
    raw = methods[key]['instructions']
    methods[key]['ix'] = {r['offset']: i for i, r in enumerate(raw)}


class Obj:
    def __init__(self, typ, **fields):
        self.typ = typ; self.fields = fields


class InjectedFailure(Exception):
    pass


BD_ARMS = {82: 'leftRedSiblingRotate', 199: 'leftInnerRotateRight', 272: 'leftFinalRotateLeft',
           110: 'leftNullSiblingAdvance', 161: 'leftRecolorAdvance', 276: 'leftRootAssign',
           304: 'rightRedSiblingRotate', 414: 'rightInnerRotateLeft', 483: 'rightFinalRotateRight',
           330: 'rightNullSiblingAdvance', 378: 'rightRecolorAdvance', 487: 'rightRootAssign',
           10: 'returnRoot', 26: 'returnParentless', 40: 'returnRed'}
coverage = Counter()   # (method, source) back edges, and balanceDeletion arms


def execute(map_object, query, fail_allocate=None):
    counts = Counter(); frames = Counter(); frame_back = Counter(); total_back = Counter()
    find = {'visits': 0, 'depth': 0}

    def run(key, args, depth=0, find_depth=0):
        if depth > 256:
            raise ValueError('stack bound')
        if key == ('java/lang/Object', 'hashCode', '()I'):
            counts['nativeIdentityHash'] += 1; return args[0].fields['hash']
        m = methods[key]; raw = m['instructions']; ix = m['ix']; name = key[1]
        local = dict(enumerate(args)); stack = []; pc = 0; counts['calls'] += 1; frames[name] += 1; back = 0
        is_find = name == 'find'; is_bd = name == 'balanceDeletion'
        if is_find:
            find_depth += 1; find['depth'] = max(find['depth'], find_depth)
        while True:
            counts['instructions'] += 1
            if counts['instructions'] > 2000000:
                raise ValueError('instruction bound')
            if is_find and pc == 3:
                find['visits'] += 1
            if is_bd and pc in BD_ARMS:
                coverage['arm', BD_ARMS[pc]] += 1
            i = ix[pc]; r = raw[i]; op = r['opcode']; a = r['args']; following = raw[i + 1]['offset'] if i + 1 < len(raw) else None
            if op == 1: stack.append(None)
            elif 2 <= op <= 8: stack.append(op - 3)
            elif op == 16: stack.append(int.from_bytes(bytes(a), 'big', signed=True))
            elif 26 <= op <= 29: stack.append(local[op - 26])
            elif 42 <= op <= 45: stack.append(local[op - 42])
            elif op in (21, 25): stack.append(local[a[0]])
            elif op in (54, 58): local[a[0]] = stack.pop()
            elif 59 <= op <= 62: local[op - 59] = stack.pop()
            elif 75 <= op <= 78: local[op - 75] = stack.pop()
            elif op == 87: stack.pop()
            elif op == 89: stack.append(stack[-1])
            elif op == 90:
                v = stack.pop(); u = stack.pop(); stack.extend([v, u, v])
            elif op == 91:
                v = stack.pop(); u = stack.pop(); w = stack.pop(); stack.extend([v, w, u, v])
            elif op == 178:
                ref = r['constant']; assert (ref['owner'], ref['name'], ref['descriptor']) == (TREE, '$assertionsDisabled', 'Z'); stack.append(1)
            elif op == 180: stack.append(stack.pop().fields[r['constant']['name']])
            elif op == 181:
                v = stack.pop(); stack.pop().fields[r['constant']['name']] = v
            elif op == 187:
                assert r['constant']['value'] == NODE; counts['allocations'] += 1
                if fail_allocate == counts['allocations']: raise InjectedFailure()
                stack.append(Obj(NODE, hash=0, key=None, value=None, next=None))
            elif op == 192:
                target = r['constant']['value']; assert target == TREE
                assert stack[-1] is None or isinstance(stack[-1], Obj) and stack[-1].typ == TREE
            elif op == 193:
                target = r['constant']['value']; v = stack.pop()
                if target == TREE: stack.append(int(isinstance(v, Obj) and v.typ == TREE))
                elif target == 'java/lang/Comparable': stack.append(0)
                else: raise ValueError(('type test', target))
            elif op == 50:
                k = stack.pop(); stack.append(stack.pop()[k])
            elif op == 83:
                v = stack.pop(); k = stack.pop(); stack.pop()[k] = v
            elif op == 190: stack.append(len(stack.pop()))
            elif op in (96, 100, 124, 126, 130):
                b = stack.pop(); v = stack.pop()
                out = v + b if op == 96 else v - b if op == 100 else (v & 0xffffffff) >> (b & 31) if op == 124 else v & b if op == 126 else v ^ b
                stack.append(((out + 2**31) % 2**32) - 2**31)
            elif op in (*range(153, 168), 198, 199):
                take = True
                if op in (198, 199): take = (stack.pop() is None) == (op == 198)
                elif 153 <= op <= 158:
                    v = stack.pop(); take = (v == 0, v != 0, v < 0, v >= 0, v > 0, v <= 0)[op - 153]
                elif 159 <= op <= 166:
                    b = stack.pop(); v = stack.pop()
                    if op >= 165: take = (v is b) == (op == 165)
                    else: take = (v == b, v != b, v < b, v >= b, v > b, v <= b)[op - 159]
                if take:
                    following = pc + int.from_bytes(bytes(a), 'big', signed=True)
                    if following <= pc:
                        back += 1; total_back[name] += 1; coverage['backEdge', name, pc] += 1
            elif op in (182, 183, 184):
                ref = r['constant']; argtypes, result = signature(ref['descriptor']); n = len(argtypes) + (op != 184); args2 = stack[-n:] if n else []
                if n: del stack[-n:]
                out = run((ref['owner'], ref['name'], ref['descriptor']), args2, depth + 1, find_depth)
                if result != 'V': stack.append(out)
            elif op in (172, 176):
                frame_back[name] = max(frame_back[name], back); return stack.pop()
            elif op == 177:
                frame_back[name] = max(frame_back[name], back); return None
            else:
                raise ValueError(('opcode', key, pc, op))
            pc = following
    try:
        value = run((MAP, 'remove', '(Ljava/lang/Object;)Ljava/lang/Object;'), [map_object, query]); failed = False
    except InjectedFailure:
        value = None; failed = True
    return value, dict(counts), {'frames': frames, 'frameBack': frame_back, 'totalBack': total_back, 'find': find}, failed


# ---------- fixtures ----------
CAP = 512


def make_nodes(n, tree, same_hash):
    keys, nodes = [], []
    for i in range(n):
        h = CAP if same_hash else (i + 1) * CAP
        key = Obj('Key', hash=h ^ (h >> 16)); keys.append(key)
        nodes.append(Obj(TREE if tree else NODE, hash=h, key=key, value=object(), next=None, parent=None, left=None, right=None, prev=None, red=False))
    return keys, nodes


def link(nodes, order):
    seq = [nodes[i] for i in order]
    for i, node in enumerate(seq):
        node.fields['next'] = seq[i + 1] if i + 1 < len(seq) else None
        node.fields['prev'] = seq[i - 1] if i else None
    return seq[0] if seq else None


def fixture(n, tree, same_hash=False):
    """Model-2 fixture: perfect black tree, list in key order."""
    keys, nodes = make_nodes(n, tree, same_hash)
    head = link(nodes, range(n))
    if tree:
        def subtree(lo, hi, parent=None):
            if lo >= hi: return None
            mid = (lo + hi) // 2; node = nodes[mid]; node.fields['parent'] = parent
            node.fields['left'] = subtree(lo, mid, node); node.fields['right'] = subtree(mid + 1, hi, node); return node
        subtree(0, n)
    table = [None] * CAP
    table[0] = head
    return Obj(MAP, table=table, size=n, modCount=0), keys, nodes


def F(n, k): return n.fields[k]


def rot_left(root, p):
    r = F(p, 'right'); p.fields['right'] = rl = F(r, 'left')
    if rl is not None: rl.fields['parent'] = p
    pp = F(p, 'parent'); r.fields['parent'] = pp
    if pp is None: root = r
    elif F(pp, 'left') is p: pp.fields['left'] = r
    else: pp.fields['right'] = r
    r.fields['left'] = p; p.fields['parent'] = r
    return root


def rot_right(root, p):
    l = F(p, 'left'); p.fields['left'] = lr = F(l, 'right')
    if lr is not None: lr.fields['parent'] = p
    pp = F(p, 'parent'); l.fields['parent'] = pp
    if pp is None: root = l
    elif F(pp, 'right') is p: pp.fields['right'] = l
    else: pp.fields['left'] = l
    l.fields['right'] = p; p.fields['parent'] = l
    return root


def rb_tree(n, insert_order, same_hash, balance=True, colors=None):
    """Build a tree by insertion in key-index order. balance=False gives a plain BST."""
    keys, nodes = make_nodes(n, True, same_hash)
    index = {id(x): i for i, x in enumerate(nodes)}
    root = None
    for i in insert_order:
        z = nodes[i]; y = None; x = root
        while x is not None:
            y = x; x = F(x, 'left') if i < index[id(x)] else F(x, 'right')
        z.fields['parent'] = y
        if y is None: root = z
        elif i < index[id(y)]: y.fields['left'] = z
        else: y.fields['right'] = z
        if not balance:
            continue
        z.fields['red'] = True
        while F(z, 'parent') is not None and F(F(z, 'parent'), 'red'):
            zp = F(z, 'parent'); g = F(zp, 'parent')
            if zp is F(g, 'left'):
                u = F(g, 'right')
                if u is not None and F(u, 'red'):
                    zp.fields['red'] = False; u.fields['red'] = False; g.fields['red'] = True; z = g
                else:
                    if z is F(zp, 'right'):
                        z = zp; root = rot_left(root, z); zp = F(z, 'parent'); g = F(zp, 'parent')
                    zp.fields['red'] = False; g.fields['red'] = True; root = rot_right(root, g)
            else:
                u = F(g, 'left')
                if u is not None and F(u, 'red'):
                    zp.fields['red'] = False; u.fields['red'] = False; g.fields['red'] = True; z = g
                else:
                    if z is F(zp, 'left'):
                        z = zp; root = rot_right(root, z); zp = F(z, 'parent'); g = F(zp, 'parent')
                    zp.fields['red'] = False; g.fields['red'] = True; root = rot_left(root, g)
        root.fields['red'] = False
    if colors is not None:
        rng = random.Random(colors)
        for x in nodes: x.fields['red'] = rng.random() < 0.3
    return keys, nodes, root


def list_order(n, nodes, root, kind, seed=0):
    ri = nodes.index(root)
    if kind == 'keyOrder': return list(range(n))
    if kind == 'rootFirst': return [ri] + [i for i in range(n) if i != ri]
    if kind == 'rootLast': return [i for i in range(n) if i != ri] + [ri]
    order = list(range(n)); random.Random(seed).shuffle(order); return order


def height(head):
    if head is None or head.typ != TREE: return 0
    root = head
    while F(root, 'parent') is not None: root = F(root, 'parent')
    def h(x):
        if x is None: return -1
        return 1 + max(h(F(x, 'left')), h(F(x, 'right')))
    return h(root)


def validate(m, expected, colors=True):
    head = m.fields['table'][0]; seen = []; current = head; ids = set()
    while current is not None:
        assert id(current) not in ids; ids.add(id(current)); seen.append(current); current = current.fields['next']
    assert m.fields['size'] == len(expected) == len(seen)
    assert {id(x.fields['key']) for x in seen} == {id(x) for x in expected}
    if head is not None and head.typ == TREE:
        root = head
        while root.fields['parent'] is not None: root = root.fields['parent']
        if colors: assert not root.fields['red']
        visited = []
        def check(node, parent):
            if node is None: return 1
            assert all(node is not v for v in visited); visited.append(node); assert node.fields['parent'] is parent
            left, right = node.fields['left'], node.fields['right']; a, b = check(left, node), check(right, node)
            if colors:
                assert a == b
                if node.fields['red']: assert (left is None or not left.fields['red']) and (right is None or not right.fields['red'])
            return a + int(not node.fields['red'])
        check(root, None); assert {id(x) for x in visited} == ids
        for i, node in enumerate(seen): assert node.fields['prev'] is (seen[i - 1] if i else None)
    elif head is not None:
        assert all(x.typ == NODE for x in seen)
    return len(seen)


# ---------- bound checks ----------
B_LINKED = contract['linkedBucket']; B_TREE = contract['treeBucket']
PER_FRAME = {hm._name(k): v for k, v in hm.LOOP_BOUNDS.items()}
maxima = defaultdict(Counter); slack = defaultdict(lambda: None); cases = Counter(); worst = {}
NAMEKEY = {k.split('#')[1]: k for k in B_TREE['methods'] if '<init>' not in k}


def check(m, query, category, expected_value, colors=True, expected_keys=None):
    head = m.fields['table'][0]; tree = head is not None and head.typ == TREE
    n = m.fields['size']; h = height(head)
    if tree: assert 0 <= h <= n - 1
    value, c, detail, failed = execute(m, query)
    assert not failed and value is expected_value, category
    if expected_keys is not None: validate(m, expected_keys, colors)
    bounds = B_TREE if tree else B_LINKED; modename = 'tree' if tree else 'linked'
    for metric, actual in (('instructions', c['instructions']), ('jdkFrames', c['calls']),
                           ('nativeIdentityHash', c.get('nativeIdentityHash', 0)), ('allocations', c.get('allocations', 0))):
        form = bounds['bounds'][metric]
        withh = hm.evaluate(form['expression'], n, h); nonly = hm.evaluate(form['nOnlyExpression'], n)
        assert actual <= withh <= nonly, (category, metric, actual, withh, nonly, n, h)
        key = (modename, metric)
        if actual > worst.get(key, {}).get('actual', -1):
            worst[key] = {'category': category, 'N': n, 'H': h, 'actual': actual, 'boundWithHeight': withh, 'boundNOnly': nonly}
        ratio = actual / withh if withh else 1.0
        if slack[key] is None or ratio > slack[key]['ratio']:
            slack[key] = {'ratio': round(ratio, 4), 'N': n, 'H': h, 'actual': actual, 'bound': withh, 'category': category}
    assert c.get('nativeIdentityHash', 0) == 1
    for name, frames in detail['frames'].items():
        if name != '<init>':
            key = NAMEKEY[name]
            assert key in bounds['methods'], (category, name)
            assert frames <= hm.evaluate(bounds['methods'][key]['framesExpression'], n, h), (category, name, frames)
        maxima['frames'][name] = max(maxima['frames'][name], frames)
    for name, back in detail['frameBack'].items():
        if name in PER_FRAME:
            assert back <= hm.evaluate(hm.LOOP_BOUNDS[[k for k in hm.LOOP_BOUNDS if hm._name(k) == name][0]], n, h), (category, name, back, n, h)
        maxima['perFrameBackEdges'][name] = max(maxima['perFrameBackEdges'][name], back)
        if name == 'balanceDeletion':
            maxima['balanceDeletionBackMinusHeight']['value'] = max(maxima['balanceDeletionBackMinusHeight'].get('value', -99), back - h)
    if tree:
        assert detail['find']['visits'] <= n and detail['frames'].get('find', 0) <= n and detail['find']['depth'] <= h + 1
    maxima['findVisits']['max'] = max(maxima['findVisits']['max'], detail['find']['visits'])
    maxima['findDepth']['max'] = max(maxima['findDepth']['max'], detail['find']['depth'])
    rot = detail['frames'].get('rotateLeft', 0) + detail['frames'].get('rotateRight', 0)
    maxima['rotationsPerCall']['max'] = max(maxima['rotationsPerCall']['max'], rot)
    cases[category] += 1


def model2_cases():
    for tree in (False, True):
        sizes = (1, 3, 7, 15, 31, 63, 127) if tree else range(65)
        for n in sizes:
            for same_hash in (False, True):
                for pos in range(-1, n):
                    m, keys, nodes = fixture(n, tree, same_hash)
                    query = keys[pos] if pos >= 0 else Obj('Key', hash=512)
                    ev = nodes[pos].fields['value'] if pos >= 0 else None
                    check(m, query, 'model2Single', ev, True, [x for x in keys if x is not query])
    for n in (7, 31, 127):
        for order in ('forward', 'reverse', 'random'):
            m, keys, nodes = fixture(n, True, True); indices = list(range(n))
            if order == 'reverse': indices.reverse()
            elif order == 'random': random.Random(614).shuffle(indices)
            expected = list(keys)
            for k in indices:
                expected.remove(keys[k]); check(m, keys[k], 'model2Repeated', nodes[k].fields['value'], True, list(expected))


def build_map(n, insert, same_hash, kind, seed, balance=True, colors=None):
    keys, nodes, root = rb_tree(n, insert, same_hash, balance, colors)
    head = link(nodes, list_order(n, nodes, root, kind, seed))
    table = [None] * CAP; table[0] = head
    return Obj(MAP, table=table, size=n, modCount=0), keys, nodes


def insertion_orders(n, seeds):
    yield 'ascending', list(range(n))
    yield 'descending', list(range(n - 1, -1, -1))
    zig = []
    lo, hi = 0, n - 1
    while lo <= hi:
        zig.append(lo); lo += 1
        if lo <= hi: zig.append(hi); hi -= 1
    yield 'zigzag', zig
    for s in seeds:
        order = list(range(n)); random.Random(1000 + s).shuffle(order); yield 'random%d' % s, order


def rb_single_cases():
    for n in range(2, 41):
        for iname, insert in insertion_orders(n, (0,)):
            for same_hash in (False, True):
                for kind in ('keyOrder', 'rootFirst', 'rootLast', 'shuffled'):
                    m0, keys0, nodes0 = build_map(n, insert, same_hash, kind, n)
                    validate(m0, keys0, True)
                    for pos in range(-1, n):
                        m, keys, nodes = build_map(n, insert, same_hash, kind, n)
                        query = keys[pos] if pos >= 0 else Obj('Key', hash=512)
                        ev = nodes[pos].fields['value'] if pos >= 0 else None
                        check(m, query, 'rbSingle', ev, True, [x for x in keys if x is not query])


def rb_repeated_cases():
    for n in (8, 16, 31, 64, 100, 127):
        for iname, insert in insertion_orders(n, (1, 2)):
            for same_hash in (False, True):
                for dname in ('forward', 'reverse', 'random', 'rootFirstEach'):
                    m, keys, nodes = build_map(n, insert, same_hash, 'shuffled', n + 7)
                    validate(m, keys, True)
                    expected = list(keys); remaining = list(range(n))
                    if dname == 'reverse': remaining.reverse()
                    elif dname == 'random': random.Random(n * 31 + len(iname)).shuffle(remaining)
                    while remaining:
                        if dname == 'rootFirstEach':
                            head = m.fields['table'][0]
                            target = head
                            if head.typ == TREE:
                                while F(target, 'parent') is not None: target = F(target, 'parent')
                            k = next(i for i in remaining if nodes[i] is target)
                            remaining.remove(k)
                        else:
                            k = remaining.pop(0)
                        expected.remove(keys[k])
                        check(m, keys[k], 'rbRepeated', nodes[k].fields['value'], True, list(expected))


stress = Counter()


def stress_cases():
    """Structurally valid trees that violate color rules. Outside the stated conditions."""
    shapes = []
    for n in (2, 3, 5, 8, 13, 21, 34, 55, 64):
        shapes.append(('leftChain', n, list(range(n - 1, -1, -1)), None))
        shapes.append(('rightChain', n, list(range(n)), None))
        zig = []
        lo, hi = 0, n - 1
        while lo <= hi:
            zig.append(lo); lo += 1
            if lo <= hi: zig.append(hi); hi -= 1
        shapes.append(('zigzagChain', n, zig, None))
        for s in range(3):
            order = list(range(n)); random.Random(77 + s * n).shuffle(order); shapes.append(('randomBst', n, order, s))
    for name, n, insert, colors in shapes:
        for color_seed in (None, 5):
            for same_hash in (False, True):
                for pos in range(-1, n):
                    m, keys, nodes = build_map(n, insert, same_hash, 'shuffled', n, balance=False, colors=color_seed)
                    query = keys[pos] if pos >= 0 else Obj('Key', hash=512)
                    ev = nodes[pos].fields['value'] if pos >= 0 else None
                    try:
                        check(m, query, 'colorInvalidStress', ev, False, [x for x in keys if x is not query])
                        stress['completed'] += 1
                    except AssertionError:
                        raise
                    except Exception as error:
                        stress['exception:' + type(error).__name__] += 1


parts = sys.argv[1:] or ['model2', 'rbSingle', 'rbRepeated', 'stress']
timing = {}
for part, fn in (('model2', model2_cases), ('rbSingle', rb_single_cases), ('rbRepeated', rb_repeated_cases), ('stress', stress_cases)):
    if part in parts:
        t = time.perf_counter(); fn(); timing[part] = round((time.perf_counter() - t) * 1000, 1)
assert cases['model2Single'] + cases['model2Repeated'] == 5293

expected_back = {('removeNode', 168), ('root', 15), ('find', 167), ('untreeify', 47), ('removeTreeNode', 200),
                 ('balanceDeletion', 112), ('balanceDeletion', 278), ('balanceDeletion', 332), ('balanceDeletion', 489)}
fired = {(k[1], k[2]): v for k, v in coverage.items() if k[0] == 'backEdge'}
arms = {k[1]: v for k, v in coverage.items() if k[0] == 'arm'}
assert set(fired) <= expected_back, set(fired) - expected_back
# Coverage of back edges in the valid-tree categories only:
report = {
    'classSha256': hashes, 'contractBounds': {m: {k: v['withHeight'] + ' | ' + v['nOnly'] for k, v in contract[m]['bounds'].items()} for m in ('linkedBucket', 'treeBucket')},
    'perIterationOwnInstructions': contract['perIterationOwnInstructions'],
    'cases': dict(cases), 'totalCases': sum(cases.values()), 'stress': dict(stress),
    'backEdgesFired': {f'{a}@{b}': v for (a, b), v in sorted(fired.items())},
    'backEdgesNeverFired': sorted(f'{a}@{b}' for a, b in expected_back - set(fired)),
    'balanceDeletionArms': dict(sorted(arms.items())), 'balanceDeletionArmsNeverRun': sorted(set(BD_ARMS.values()) - set(arms)),
    'maxima': {f'{k[0]}:{k[1]}' if isinstance(k, tuple) else k: dict(v) for k, v in maxima.items()},
    'worst': {f'{k[0]}:{k[1]}': v for k, v in worst.items()},
    'highestBoundRatio': {f'{k[0]}:{k[1]}': v for k, v in slack.items()},
    'timingMs': timing, 'elapsedMs': round((time.perf_counter() - start) * 1000, 1),
    'peakRssBytes': resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
    'boundedAdmission': False, 'runtimeClassesInitialized': 0,
    'conditions': contract['conditions'] + ['Color-invalid stress trees are outside the conditions; they check that the structural loop bounds still hold when the run completes.'],
}
raw = json.dumps(report, indent=2, default=str).encode() + b'\n'
assert len(raw) < 8 * 1024**2
with OUT.open('xb') as out:
    out.write(raw)
print(json.dumps({'totalCases': report['totalCases'], 'cases': report['cases'], 'stress': report['stress'],
                  'neverFired': report['backEdgesNeverFired'], 'armsNeverRun': report['balanceDeletionArmsNeverRun'],
                  'elapsedMs': report['elapsedMs'], 'timing': timing, 'rss': report['peakRssBytes']}))
