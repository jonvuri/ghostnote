import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.assertion_guards import requirements
from grid_doctor.constructor_bounds import direct_bounds
start=time.perf_counter();jars=[Jar(Path(p))for p in ['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar']];code=Code();seed=json.load(open('/tmp/gn-9b6g-constructor-helper-contracts-1.json'));inverse={tuple(r['target']):tuple(r['source'])for r in seed['memberBindings']};cat=json.load(open('/tmp/gn-9b6g-factory-constructor-census-1.json'))['rows'];wanted={r['id']for r in json.load(open('/tmp/gn-9b6g-registry-closure-1.json'))['selectedRows']}|{r['id']for r in json.load(open('/tmp/gn-9b6g-default-catalog-4.json'))['builds'][1]['rows']};selected=[r for r in cat if r['id']in wanted];roots=[tuple(r['constructors'][0]['method'])for r in selected];traces=json.load(open('/tmp/gn-9b6g-constructor-closure-1.json'))['rows'];target_guards={tuple(g)for r in traces for g in r['assertionGuards']};out=[]
for i,j in enumerate(jars):
 keys=roots if i else[tuple(inverse[(10,*k)][1:])for k in roots]
 flags=target_guards if i else{tuple(inverse[(9,*g)][1:])for g in target_guards if(9,*g)in inverse}
 verified={tuple(f)for owner in {k[0]for k in flags} for f in requirements(j,{owner},code)['fields']}
 if not flags <= verified:raise Refusal('unverified-constructor-guard')
 r=direct_bounds(j,code,keys,flags);r.update(sha256=j.sha256)
 for row,entry in zip(r['roots'],selected):row.update(name=entry['name'],id=entry['id'])
 out.append(r)
r={'builds':out,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False};raw=json.dumps(r,indent=2).encode()
if len(raw)>8*1024**2:raise Refusal('constructor-bound-report-limit')
Path('/tmp/gn-9b6g-constructor-bounds-2.json').write_bytes(raw)
for b in out:
 print('roots',len(b['roots']),'methods',len(b['methods']),'max',max((x['vendorInstructions'],x['vendorCalls'],x['name'])for x in b['roots']))
 print('changed-cost-inputs',[(x['name'],x['vendorInstructions'],x['vendorCalls'],x['explicitObjects'])for x in b['roots']if x['explicitObjects']or x['dynamicSites']])
print(len(raw),r['elapsedMs'],r['peakRssBytes'])
