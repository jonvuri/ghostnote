# Bounded receiver-aware call walker over class bytes as data. No vendor code runs.
import zipfile,struct
from grid_symbols.scan import parse,instructions,Refusal
from grid_doctor.ownership import constant
OLD='/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar'
NEW='/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'
class Jar:
  def __init__(s,p):s.z=zipfile.ZipFile(p);s.c={}
  def has(s,n):
    try:s.z.getinfo(n+'.class');return True
    except KeyError:return False
  def code(s,n):
    if n not in s.c:s.c[n]=parse(s.z.read(n+'.class'),True)
    return s.c[n]
def split(desc):
  i=1;out=[]
  while desc[i]!=')':
    j=i
    while desc[j]=='[':j+=1
    if desc[j]=='L':j=desc.index(';',j)
    out.append(desc[i:j+1]);i=j+1
  return out,desc[i+1:]
W=lambda t:t in('J','D')
def chain(jar,c):
  out=[]
  while c and not c.startswith('java/') and jar.has(c):
    out.append(c);c=jar.code(c).parent
  return out
def resolve(jar,owner,name,desc,special=False):
  """Resolve along the superclass chain; then interfaces for defaults."""
  for c in chain(jar,owner):
    for m in jar.code(c).methods:
      if m.name==name and m.desc==desc:return c,m
  # default methods
  seen=set();st=list(jar.code(owner).interfaces) if jar.has(owner) else []
  for c in chain(jar,owner):st+=list(jar.code(c).interfaces)
  hits=[]
  while st:
    i=st.pop()
    if i in seen or not jar.has(i):continue
    seen.add(i);ci=jar.code(i)
    for m in ci.methods:
      if m.name==name and m.desc==desc and not m.flags&0x400:hits.append((i,m))
    st+=list(ci.interfaces)
  if len(hits)==1:return hits[0]
  return None,None
_AF={}
LAZY=True
def assertion_flag(jar,owner,name):
  k=(owner,name)
  if k in _AF:return _AF[k]
  r=False
  if jar.has(owner):
    c=jar.code(owner);f=[x for x in c.fields if x.name==name and x.desc=='Z']
    if f and f[0].flags&0x1018==0x1018:
      cl=[m for m in c.methods if m.name=='<clinit>']
      if cl:
        ins=instructions(cl[0].code)
        for i,(p,op,a) in enumerate(ins[:12]):
          if op==182:
            cc=constant(c,a[0]<<8|a[1])
            if cc['name']=='desiredAssertionStatus':
              # expect: ifne ->X iconst_1 goto iconst_0 putstatic flag
              for (p2,op2,a2) in ins[i+1:i+6]:
                if op2==179:
                  c2=constant(c,a2[0]<<8|a2[1]);r=(c2['owner']==owner and c2['name']==name);break
          if r:break
  _AF[k]=r;return r
LOADS={21:'I',22:'J',23:'F',24:'D',25:'A'}
def analyze(jar,cname,m,this_type,arg_types=None,limit=4096):
  """Abstract interpretation tracking receiver identities. Values are tuples (kind,detail)."""
  cls=jar.code(cname);ins=instructions(m.code);idx={p:i for i,(p,_,_) in enumerate(ins)}
  args,_=split(m.desc);loc={};k=0
  if not m.flags&8:loc[0]=('this',this_type);k=1
  for i,a in enumerate(args):
    loc[k]=('param',(i,(arg_types or {}).get(i,a)));k+=2 if W(a) else 1
  sites=[];states={0:([],loc)};work=[0];seen=0;handlers=[(h[0],h[1],h[2]) for h in m.handlers] if m.handlers else []
  for h in (m.handlers or []):
    states.setdefault(h[2],([('exc',None)],{}));work.append(h[2])
  visited=set()
  while work:
    p=work.pop()
    key=(p,repr(states[p]))
    if key in visited:continue
    visited.add(key);seen+=1
    if seen>limit:raise Refusal('walk-state-limit')
    st,lc=states[p];st=list(st);lc=dict(lc)
    i=idx[p];pos,op,a=ins[i];nxt=[ins[i+1][0]] if i+1<len(ins) else []
    U=('?',None)
    def pop(n=1):
      r=[]
      for _ in range(n):r.append(st.pop() if st else U)
      return r
    if op in(0,):pass
    elif op==1:st.append(('null',None))
    elif 2<=op<=8 or op in(16,17):st.append(('int',a))
    elif op in(9,10,14,15):st.append(('wide',None))
    elif op in(11,12,13):st.append(U)
    elif op in(18,19):
      c=constant(cls,a[0] if op==18 else a[0]<<8|a[1]);st.append(('const',c.get('value')))
    elif op==20:st.append(('wide',None))
    elif op in(21,23):st.append(U)
    elif op in(22,24):st.append(('wide',None))
    elif op==25:st.append(lc.get(a[0],U))
    elif 26<=op<=45:
      t=(op-26)//4;n=(op-26)%4
      st.append(('wide',None) if t in(1,3) else (lc.get(n,U) if t==4 else U))
    elif 46<=op<=53:pop(2);st.append(('wide',None) if op in(47,49) else U)
    elif op in(54,56):pop();lc[a[0]]=U
    elif op in(55,57):pop();lc[a[0]]=('wide',None)
    elif op==58:lc[a[0]]=pop()[0]
    elif 59<=op<=78:
      t=(op-59)//4;n=(op-59)%4;v=pop()[0];lc[n]=v
    elif 79<=op<=86:pop(3)
    elif op==87:pop()
    elif op==88:
      v=pop()[0]
      if v[0]!='wide':pop()
    elif op==89:v=st[-1] if st else U;st.append(v)
    elif op==90:v=pop()[0];w=pop()[0];st+= [v,w,v]
    elif op==91:
      v=pop()[0];w=pop()[0]
      if w[0]=='wide':st+=[v,w,v]
      else:x=pop()[0];st+=[v,x,w,v]
    elif op==92:
      v=st[-1] if st else U
      if v[0]=='wide':st.append(v)
      else:w=st[-2];st+=[w,v]
    elif op in(93,94):
      v=pop()[0]
      if v[0]=='wide':
        w=pop()[0]
        if op==94 and w[0]!='wide':x=pop()[0];st+=[v,x,w,v]
        else:st+=[v,w,v]
      else:
        w=pop()[0];x=pop()[0]
        if op==94 and x[0]!='wide':y=pop()[0];st+=[w,v,y,x,w,v]
        else:st+=[w,v,x,w,v]
    elif op==95:v=pop()[0];w=pop()[0];st+=[v,w]
    elif 96<=op<=115:pop(2);st.append(('wide',None) if (op-96)%4 in(1,3) else U)
    elif 116<=op<=119:pop();st.append(('wide',None) if (op-116)%4 in(1,3) else U)
    elif 120<=op<=125:pop(2);st.append(('wide',None) if op in(121,123,125) else U)
    elif 126<=op<=131:pop(2);st.append(('wide',None) if op in(127,129,131) else U)
    elif op==132:lc[a[0]]=U
    elif 133<=op<=147:pop();st.append(('wide',None) if op in(133,135,138,140,141,143) else U)
    elif 148<=op<=152:pop(2);st.append(U)
    elif 153<=op<=158 or op in(198,199):
      v=pop()[0];d=struct.unpack('>h',bytes(a))[0]
      af=v[0]=='static' and assertion_flag(jar,v[1][0],v[1][1]) and op in(153,154)
      lz=v[0]=='static' and op==199 and LAZY and v[1][2].startswith('L')
      if lz:
        nxt=[pos+d];sites.append({'offset':pos,'kind':'lazy-pruned','opcode':op,'value':v})
      elif af:
        nxt=[pos+d] if op==154 else nxt
        sites.append({'offset':pos,'kind':'assert-pruned','opcode':op,'value':v})
      else:
        nxt=nxt+[pos+d]
        sites.append({'offset':pos,'kind':'branch','opcode':op,'value':v})
    elif 159<=op<=166:pop(2);d=struct.unpack('>h',bytes(a))[0];nxt=nxt+[pos+d]
    elif op==167:d=struct.unpack('>h',bytes(a))[0];nxt=[pos+d]
    elif op in(170,171):
      pop();
      if op==170:nxt=[pos+a[0]]+[pos+x for x in a[3:]]
      else:nxt=[pos+a[0]]+[pos+a[1+2*j+1] for j in range(len(a[1:])//2)]
    elif 172<=op<=177:
      if op!=177:pop()
      nxt=[]
    elif op in(178,179,180,181):
      c=constant(cls,a[0]<<8|a[1]);t=c['descriptor']
      if op==178:st.append(('static',(c['owner'],c['name'],t)) if not W(t) else ('wide',None))
      elif op==179:pop()
      elif op==180:r=pop()[0];st.append(('field',(r,c['owner'],c['name'],t)) if not W(t) else ('wide',None))
      else:v=pop()[0];r=pop()[0]
      sites.append({'offset':pos,'kind':'field','opcode':op,'ref':c,'receiver':None if op in(178,179) else (r if op==180 else r),'value':v if op in(179,181) else None})
    elif 182<=op<=185:
      c=constant(cls,a[0]<<8|a[1]);ar,ret=split(c['descriptor']);vals=pop(len(ar))[::-1]
      r=pop()[0] if op!=184 else None
      sites.append({'offset':pos,'kind':'call','opcode':op,'ref':c,'receiver':r,'args':vals})
      if r and r[0]=='new' and c['name']=='<init>':
        # mark initialized
        st=[('newi',r[1]) if x==r else x for x in st];lc={kk:(('newi',r[1]) if vv==r else vv) for kk,vv in lc.items()}
      if ret!='V':st.append(('wide',None) if W(ret) else ('ret',(c['owner'],c['name'],c['descriptor'],pos)))
    elif op==186:
      c=constant(cls,a[0]<<8|a[1]);ar,ret=split(c['descriptor']);vals=pop(len(ar))[::-1]
      sites.append({'offset':pos,'kind':'indy','opcode':op,'ref':c,'args':vals})
      st.append(('indy',(c['name'],c['descriptor'],pos)))
    elif op==187:
      c=constant(cls,a[0]<<8|a[1]);st.append(('new',(c['value'],pos)))
      sites.append({'offset':pos,'kind':'new','opcode':op,'class':c['value']})
    elif op==188:pop();st.append(('array',None));sites.append({'offset':pos,'kind':'newarray','opcode':op})
    elif op==189:pop();st.append(('array',None));sites.append({'offset':pos,'kind':'newarray','opcode':op})
    elif op==190:pop();st.append(U)
    elif op==191:pop();nxt=[]
    elif op==192:v=pop()[0];st.append(v)
    elif op==193:pop();st.append(U)
    elif op in(194,195):v=pop()[0];sites.append({'offset':pos,'kind':'monitor','opcode':op,'value':v})
    elif op==197:pop(a[2]);st.append(('array',None))
    else:raise Refusal(f'walk-op:{op}')
    for q in nxt:
      if q not in states:states[q]=(st,lc);work.append(q)
      else:
        ost,olc=states[q]
        if len(ost)!=len(st):raise Refusal('walk-stack-merge')
        mst=[x if x==y else U for x,y in zip(ost,st)];mlc={kk:vv for kk,vv in olc.items() if lc.get(kk)==vv}
        if (mst,mlc)!=(ost,olc):states[q]=(mst,mlc);work.append(q)
        else:work.append(q) if False else None
  # deduplicate sites by offset keeping the last-merged view
  out={}
  for s in sites:out[(s['offset'],s['kind'])]=s
  return [out[k] for k in sorted(out)],handlers

def closure(jar,roots,max_methods=512,max_depth=24,exact_params=None,stop=lambda o,n,d:False,overrides=None):
  """roots: list of (owner,name,desc,this_type). Returns nodes and leaves."""
  nodes={};leaves=[];order=[]
  stack=[(o,n,d,t,0,None,None) for o,n,d,t in roots]
  while stack:
    o,n,d,t,depth,parent,ptypes=stack.pop(0)
    decl,m=resolve(jar,o,n,d) if jar.has(o) else (None,None)
    key=(decl,n,d,t,repr(ptypes))
    if decl is None:
      leaves.append({'kind':'unresolved','target':(o,n,d),'from':parent});continue
    if key in nodes:continue
    if len(nodes)>=max_methods:raise Refusal('closure-method-limit')
    if not m.code:
      leaves.append({'kind':'abstract-or-native','target':(decl,n,d),'flags':m.flags,'from':parent});nodes[key]=None;continue
    sites,h=analyze(jar,decl,m,t,ptypes)
    rec={'method':(decl,n,d),'this':t,'depth':depth,'from':parent,'handlers':[list(x) for x in (m.handlers or [])],'instructions':len(instructions(m.code)),'calls':[],'news':[],'monitors':[],'indy':[],'statics':[],'branches':[s for s in sites if s['kind']=='branch' and s['value'][0] in ('static','field','ret')]}
    nodes[key]=rec;order.append(key)
    for s in sites:
      if s['kind']=='new':rec['news'].append(s['class'])
      elif s['kind']=='monitor' and s['opcode']==194:rec['monitors'].append(s['value'])
      elif s['kind']=='indy':rec['indy'].append(s['ref'])
      elif s['kind']=='field' and s['opcode'] in(178,179):rec['statics'].append((s['opcode'],s['ref']['owner'],s['ref']['name']))
      elif s['kind']=='call':
        c=s['ref'];r=s['receiver'];op=s['opcode'];co,cn,cd=c['owner'],c['name'],c['descriptor']
        row={'offset':s['offset'],'opcode':op,'target':(co,cn,cd),'receiver':r[0] if r else None}
        rec['calls'].append(row)
        if co.startswith('java/') or co.startswith('javax/') or co.startswith('jdk/') or co.startswith('sun/') or not jar.has(co):
          row['class']='external';continue
        if stop(co,cn,cd):row['class']='stopped';continue
        nt=None
        if op==184:nt=None;row['class']='static'
        elif op==183:
          if cn=='<init>' and r and r[0]=='new':nt=r[1][0];row['class']='constructor';row['newClass']=nt
          elif r and r[0]=='this':nt=t;row['class']='special-this'
          else:nt=co;row['class']='special'
        else:
          if r and r[0]=='this' and t:nt=t;row['class']='virtual-this'
          elif r and r[0] in('new','newi'):nt=r[1][0];row['class']='virtual-new'
          elif r and r[0]=='param' and exact_params and (decl,n,d,r[1][0]) in exact_params:
            nt=exact_params[(decl,n,d,r[1][0])];row['class']='virtual-param-witness';row['witness']=nt
          elif overrides and (co,cn,cd) in overrides:
            nt=overrides[(co,cn,cd)];row['class']='virtual-supplied-witness';row['witness']=nt
          else:
            import hier as _h
            tg=_h.dispatch_targets(co,cn,cd)
            if tg is not None and len(tg)==1 and isinstance(next(iter(tg)),str):
              only=next(iter(tg));row['class']='monomorphic';row['witness']=only;nt=None
              if depth+1<=max_depth:stack.append((only,cn,cd,None,depth+1,(decl,n,d,s['offset']),None))
              continue
            row['class']='open-dispatch';row['targets']=len(tg) if tg is not None else None;row['receiverValue']=repr(r)[:160];leaves.append({'kind':'open-dispatch','targets':row['targets'],'target':(co,cn,cd),'receiver':repr(r)[:160],'from':(decl,n,d),'offset':s['offset']});continue
        tgt_owner=nt if (op in(182,185) and nt) else co
        if op==183 and row['class']=='constructor':tgt_owner=co
        if depth+1>max_depth:leaves.append({'kind':'depth','target':(co,cn,cd),'from':(decl,n,d)});continue
        stack.append((tgt_owner,cn,cd,nt if op!=184 else None,depth+1,(decl,n,d,s['offset']),None))
  return [nodes[k] for k in order if nodes[k]],leaves
