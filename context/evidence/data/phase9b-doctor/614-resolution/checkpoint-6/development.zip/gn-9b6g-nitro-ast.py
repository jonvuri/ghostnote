import json,struct,hashlib,time
from pathlib import Path
from collections import Counter
from grid_symbols.scan import Jar,instructions,Refusal,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.migrate import member
from grid_doctor.fixed_descriptors import integer
from grid_doctor.ownership import constant
start=time.perf_counter();jar=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));code=Code()
def ops(owner):
 c=code.get(jar,owner);return c,instructions(member(c,'<clinit>','()V').code)
def ref(c,op):return constant(c,int.from_bytes(bytes(op[2]),'big'))
c,raw=ops('com/bitwig/nitro/XZh');ids={}
for i,x in enumerate(raw):
 if x[1]!=183:continue
 r=ref(c,x)
 if r['owner']!=c.name or r['descriptor']!='(Ljava/lang/String;II)V':continue
 ident=integer(c,*raw[i-1][1:]);field=ref(c,raw[i+1]);ids[field['name']]=ident
c,raw=ops('com/bitwig/nitro/IQl');registry={}
for i,x in enumerate(raw):
 if x[1]!=184:continue
 r=ref(c,x)
 if r['owner']!=c.name or r['descriptor']!='(Ljava/lang/Class;Lcom/bitwig/nitro/XZh;)V':continue
 field=ref(c,raw[i-1]);cls=ref(c,raw[i-2]);ident=ids[field['name']]
 if ident in registry or cls['tag']!=7:raise Refusal('ast-registry')
 registry[ident]=cls['value']
def decl(owner):
 seen=set()
 while owner and owner!='java/lang/Object':
  if owner in seen or len(seen)>64:raise Refusal('ast-inheritance')
  if owner=='com/bitwig/nitro/Declaration':return True
  seen.add(owner);owner=jar.classes[owner].parent
 return False
class Reader:
 def __init__(self,raw):self.raw=raw;self.pos=0;self.strings=[];self.nodes=[];self.depth=0;self.work=0
 def take(self,n):
  if n<0 or self.pos+n>len(self.raw):raise Refusal('ast-truncated')
  out=self.raw[self.pos:self.pos+n];self.pos+=n;return out
 def num(self,n):return int.from_bytes(self.take(n),'big',signed=True)
 def val(self):
  self.depth+=1;self.work+=1
  if self.depth>64 or self.work>4096:raise Refusal('ast-limit')
  try:return self.inner()
  finally:self.depth-=1
 def inner(self):
  off=self.pos;t=self.num(1)
  if t==1:
   ident=self.num(2)
   if ident not in registry:raise Refusal('ast-id')
   obj={'offset':off,'id':ident,'class':registry[ident],'data':[]};self.nodes.append(obj)
   while self.raw[self.pos]!=2:obj['data'].append(self.val())
   self.take(1)
   if decl(obj['class']):obj['annotations']=self.val()
   return obj
  if t==3:return None
  if t==4:
   n=self.num(4)
   if not 0<=n<=4096:raise Refusal('ast-list-limit')
   vals=[self.val()for _ in range(n)]
   if self.take(1)!=b'\x05':raise Refusal('ast-list-end')
   return vals
  if t==6:
   n=self.num(4)
   if not 0<=n<=65536:raise Refusal('ast-string-limit')
   s=self.take(n).decode('utf8');self.strings.append(s);return s
  if t==7:
   index=self.num(4)
   if not 0<=index<len(self.strings):raise Refusal('ast-string-reference')
   return self.strings[index]
  if t in(9,10):return t==9
  if t==11:return self.num(8)
  if t==12:return struct.unpack('>d',self.take(8))[0]
  raise Refusal('ast-tag:'+str((off,t)))
raw=Path('/tmp/gn-9b6g-nitro-1-decoded.bin').read_bytes();r=Reader(raw)
if r.val()is not False:raise Refusal('ast-debug-info')
root=r.val()
if r.pos!=len(raw):raise Refusal('ast-trailing')
report={'jarSha256':jar.sha256,'decodedSha256':hashlib.sha256(raw).hexdigest(),'registry':registry,'nodeCount':len(r.nodes),'types':dict(Counter(x['class']for x in r.nodes)),'strings':r.strings,'root':root,'work':r.work,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False,'limits':['Traced token stream only; constructor reader order and semantic compilation remain separate.','No vendor class is initialized.']}
Path('/tmp/gn-9b6g-nitro-ast-1.json').write_text(json.dumps(report,indent=2)+'\n');print('nodes',len(r.nodes),'types',report['types'],'strings',r.strings,'work',r.work,'elapsedMs',report['elapsedMs'],'rss',report['peakRssBytes'])
