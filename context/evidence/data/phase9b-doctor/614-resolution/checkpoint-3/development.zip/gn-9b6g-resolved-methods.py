exec(open('/tmp/gn-9b6g-inspect.py').read().split('for name in sys.argv[2:]')[0])
for spec in sys.argv[2:]:
 name,wanted,signature=spec.split('#',2);seen=set();lookup=name
 while name not in seen and name and not name.startswith('java/'):
  if len(seen)>=128:raise ValueError('depth')
  seen.add(name);cls=jar.code(name);hits=[m for m in cls.methods if m.name==wanted and m.desc==signature]
  if hits:break
  name=cls.parent
 else:raise ValueError('missing '+spec)
 if len(hits)!=1:raise ValueError('duplicate '+spec)
 m=hits[0];t=method_trace(jar,cls,m,bootstraps(jar.zip.read(name+'.class'),cls))
 print('LOOKUP',lookup,'DECLARATION',name,wanted,signature,m.flags,'HANDLERS',t['exceptionHandlers'])
 for x in t['instructions']:print(x['offset'],x['opcode'],x.get('constant',x['args']))
