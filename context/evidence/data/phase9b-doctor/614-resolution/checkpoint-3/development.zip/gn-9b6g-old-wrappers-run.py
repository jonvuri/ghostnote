import json,time
from pathlib import Path
from grid_symbols.scan import Jar,instructions,rss_bytes,Refusal
from grid_doctor.descriptor_resolution import Code
from grid_doctor.wrapper_bounds import wrapper_bound
start=time.perf_counter();j=Jar(Path('/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar'));c=Code();rows=[]
for name in ('cYz','cYy'):
 cls=c.get(j,name);hits=[m for m in cls.methods if [x[1] for x in instructions(m.code)]==[187,89,43,42,183,176]]
 if len(hits)!=1:raise Refusal('wrapper-factory-count')
 rows.append(wrapper_bound(j,c,name,hits[0].name,hits[0].desc))
r={'builds':rows,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes()};Path('/tmp/gn-9b6g-old-wrappers-1.json').write_text(json.dumps(r,indent=2));print([(x['objectAllocations'],x['constructorInstructionBound'],x['vendorConstructorCalls'])for x in rows])
