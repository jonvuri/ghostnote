import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,rss_bytes,descriptor
from grid_doctor.descriptor_resolution import Code
from grid_doctor.constructor_flags import allocation_flags
from grid_doctor.migrate import member
from grid_doctor.renamed_fixture import rename_member
from grid_doctor.read_dataflow import ReadFlow,integer
start=time.perf_counter();source=json.load(open('/tmp/gn-9b6g-relationship-flags-1.json'))['builds'];predicates=json.load(open('/tmp/gn-9b6g-relationship-predicates-1.json'))['builds'];results=[]
for i,(path,mapping)in enumerate([('/tmp/gn-9b6g-old-renamed-extra.jar','/tmp/gn-9b6g-old-renamed-map.json'),('/tmp/gn-9b6g-renamed-extra.jar','/tmp/gn-9b6g-renamed-map.json')]):
 names=json.load(open(mapping));j=Jar(Path(path));code=Code()
 def key(v):return names.get(v[0],v[0]),rename_member(v[1]),descriptor(v[2],lambda n:names.get(n,n))
 allocations={};rows=[]
 for a in source[i]['allocations']:
  k=(*key(a['allocation'][:3]),a['allocation'][3]);c=code.get(j,k[0]);m=member(c,*k[1:3]);r=allocation_flags(j,code,c,m,k[3],key(a['fieldProvenance']['field']))
  if r['flags']!=a['flags'] or r['fieldProvenance']['origin']!=a['fieldProvenance']['origin']:raise Refusal('renamed-flag-provenance')
  if r['constructor']!=list(key(a['constructor'])):raise Refusal('renamed-flag-constructor')
  allocations[tuple(a['allocation'])]=r
 for p in predicates[i]['rows']:
  a=allocations[tuple(p['witness'])];receiver=('ref',a['constructor'][0],'property');field=tuple(a['fieldProvenance']['field']);flow=ReadFlow(j,code,[],('unused','id','I'),p['propertyId'],'unused',instance_values={(receiver,field):integer(a['flags'])});slot=key(predicates[i]['slot']);out=flow.evaluate(*slot,receiver,())
  if out!={integer(int(p['predicate']))}:raise Refusal('renamed-flag-predicate')
  bound=flow.bounds[(*slot,receiver,(),False)]
  if bound!=p['predicateBound']:raise Refusal('renamed-flag-cost')
  rows.append({'classId':p['classId'],'propertyId':p['propertyId'],'flags':a['flags'],'predicate':p['predicate'],'bound':bound})
 results.append({'sha256':j.sha256,'allocations':list(allocations.values()),'rows':rows});print(i,len(allocations),'allocations',len(rows),'predicates',flush=True);del j,code
r={'builds':results,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False,'runtimeObserved':False};raw=json.dumps(r,indent=2).encode()
if len(raw)>8*1024**2:raise Refusal('renamed-flag-report-limit')
Path('/tmp/gn-9b6g-relationship-renamed-flags-1.json').write_bytes(raw);print(len(raw),r['elapsedMs'],r['peakRssBytes'])
