import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,ancestors,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.admission import Work
from grid_doctor.receiver_trace import Declarations,ReceiverLimits
from grid_doctor.migrate import member
from grid_doctor.ownership import method_trace,bootstraps
start=time.perf_counter();j=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));code=Code();work=Work(ReceiverLimits());d=Declarations(j,work);slots=[('QYb','getParallelAsyncTaskHandler','()Lcom/bitwig/base/async/Uev;'),('com/bitwig/base/async/Uev','MRY','(Lcom/bitwig/base/async/pYi;)Lcom/bitwig/base/async/z2y;'),('com/bitwig/base/async/z2y','cfM','(Ljava/lang/Object;Ljava/util/concurrent/Callable;Lcom/bitwig/base/async/oRV;)V')];rows=[];traces={}
for base,name,desc in slots:
 receivers=[]
 for cls in j.classes.values():
  if cls.flags&(512|1024):continue
  lineage=set(ancestors(j.classes,cls.name,128));work.tick('hierarchy_edges',len(lineage))
  if base not in lineage:continue
  found=d.find('method',cls.name,name,desc);receivers.append({'runtimeClass':cls.name,'declaration':found})
  if found['status']=='declaration':
   c=code.get(j,found['owner']);m=member(c,name,desc);traces[c.name,m.name,m.desc]=method_trace(j,c,m,bootstraps(j.zip.read(c.name+'.class'),c))
 rows.append({'slot':[base,name,desc],'receivers':receivers})
r={'sha256':j.sha256,'rows':rows,'methods':list(traces.values()),'work':work.counts,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'runtimeObserved':False,'boundedAdmission':False};raw=json.dumps(r,indent=2).encode()
if len(raw)>8*1024**2:raise Refusal('async-slots-report-limit')
Path('/tmp/gn-9b6g-compiler-async-slots-1.json').write_bytes(raw)
for row in rows:print(row)
print(len(raw),r['elapsedMs'],r['peakRssBytes'])
