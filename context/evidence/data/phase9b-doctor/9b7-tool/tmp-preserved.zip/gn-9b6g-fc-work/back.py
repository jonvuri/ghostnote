# Bounded backward reachability over the reverse reference index (class bytes as data).
import sys,json,collections
exec(open('/tmp/gn-9b6g-fc-work/q.py').read())
def callers_of(key):
  o,n,d=key.split('#')
  out=[]
  for row in incoming(o,n,d,virtual=True):
    ow,b,off,op=row
    if op in(182,183,184,185):out.append((b,ow,off,op))
  return out
def back(starts,depth,edge_limit=16000,extra=None):
  seen={s:0 for s in starts};front=list(starts);edges=[];parent={}
  for dpt in range(1,depth+1):
    nf=[]
    for k in front:
      cs=callers_of(k)+[(c,'handle',-1,186) for c in (extra or {}).get(k,[])]
      for b,ow,off,op in cs:
        edges.append((b,k,ow,off,op))
        if len(edges)>edge_limit:return seen,edges,parent,'edge-limit'
        if b not in seen:seen[b]=dpt;parent[b]=k;nf.append(b)
    front=nf
    if not front:break
  return seen,edges,parent,'depth' if front else 'closed'
if __name__=='__main__':
  starts=json.loads(sys.argv[1]);depth=int(sys.argv[2]);extra=json.loads(sys.argv[3]) if len(sys.argv)>3 else None
  seen,edges,parent,st=back(starts,depth,extra=extra)
  print('status',st,'methods',len(seen),'edges',len(edges))
  byd=collections.Counter(seen.values());print('byDepth',dict(sorted(byd.items())))
  json.dump({'seen':seen,'edges':edges,'parent':parent,'status':st},open('/tmp/gn-9b6g-fc-work/back-'+sys.argv[4]+'.json','w'))
