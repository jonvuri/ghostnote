"""Project disabled assertion blocks without executing vendor code."""
from grid_symbols.scan import Refusal, instructions
from .assertion_guards import disabled_field
from .ownership import constant


def assertion_ranges(cls, method):
    """Return ranges excluded only when the initialized flag is true."""
    field = disabled_field(cls)
    if field is None:
        return {'field': None, 'ranges': []}
    raw = instructions(method.code)
    if len(raw) > 4096:
        raise Refusal('conditional-instruction-limit')
    offsets = {row[0] for row in raw}
    edges, candidates = [], []
    for i, (offset, op, args) in enumerate(raw):
        if op in (168, 169, 201):
            raise Refusal('conditional-subroutine')
        if op in (*range(153, 168), 198, 199, 200):
            edges.append((offset, offset + int.from_bytes(bytes(args), 'big', signed=True)))
        elif op == 170:
            edges.extend((offset, offset + delta) for delta in [args[0], *args[3:]])
        elif op == 171:
            edges.extend((offset, offset + delta) for delta in [args[0], *args[2::2]])
        if op != 178 or i + 1 >= len(raw) or raw[i + 1][1] != 154:
            continue
        ref = constant(cls, int.from_bytes(bytes(args), 'big'))
        if (ref.get('owner'), ref.get('name'), ref.get('descriptor')) != field:
            continue
        condition, _, operands = raw[i + 1]
        end = condition + int.from_bytes(bytes(operands), 'big', signed=True)
        if end not in offsets or end <= condition:
            raise Refusal('conditional-guard-target')
        candidates.append((offset, condition, end))
    ranges = []
    for start, condition, end in candidates:
        if ranges and start < ranges[-1][1]:
            if end > ranges[-1][1]:
                raise Refusal('conditional-overlapping-guards')
            continue
        if any(not start <= origin < end and condition <= dest < end for origin, dest in edges):
            raise Refusal('conditional-entered-block')
        ranges.append((start, end))
    if ranges and method.handlers:
        raise Refusal('conditional-handler')
    if len(ranges) > 128:
        raise Refusal('conditional-guard-limit')
    return {'field': field if ranges else None, 'ranges': ranges}
