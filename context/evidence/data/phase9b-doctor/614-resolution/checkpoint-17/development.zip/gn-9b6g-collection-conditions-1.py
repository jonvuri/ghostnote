"""Extract five extra JDK class files as data from both bundled arm64 runtimes."""
import hashlib, json, subprocess, sys, time
from pathlib import Path
JIMAGE = Path('/Library/Java/JavaVirtualMachines/temurin-26.jdk/Contents/Home/bin/jimage')
IMAGES = {'old': Path('/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/PlugIns/JavaVM-arm64.bundle/Contents/Home/lib/modules'),
          'new': Path('/Applications/Bitwig Studio.app/Contents/PlugIns/JavaVM-arm64.bundle/Contents/Home/lib/modules')}
CLASSES = ['java/util/Arrays', 'java/util/Arrays$ArrayList', 'java/util/Arrays$ArrayItr',
           'java/util/Collections$EmptyIterator', 'jdk/internal/util/ArraysSupport']
def sha(p):
    h = hashlib.sha256()
    with p.open('rb') as f:
        for c in iter(lambda: f.read(1 << 20), b''): h.update(c)
    return h.hexdigest()
start = time.perf_counter(); report = {'classes': CLASSES, 'builds': {}, 'jimageSha256': sha(JIMAGE)}
for build, image in IMAGES.items():
    dest = Path('/tmp/gn-9b6g-collection-conditions-runtime-%s-1' % build)
    if dest.exists(): raise SystemExit('destination exists: %s' % dest)
    before = sha(image); dest.mkdir()
    pattern = ','.join('glob:**/' + n + '.class' for n in CLASSES)
    done = subprocess.run([str(JIMAGE), 'extract', '--include', pattern, '--dir', str(dest), str(image)],
                          capture_output=True, text=True, timeout=45)
    if done.returncode: raise SystemExit(done.stderr[:1000])
    if sha(image) != before: raise SystemExit('image changed')
    rows = {}
    for n in CLASSES:
        p = dest / 'java.base' / (n + '.class'); raw = p.read_bytes()
        if len(raw) > 1 << 20: raise SystemExit('class size')
        rows[n] = {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
    report['builds'][build] = {'image': str(image), 'imageSha256': before, 'extracted': str(dest), 'classes': rows}
report['sameBytesAcrossBuilds'] = {n: report['builds']['old']['classes'][n]['sha256'] == report['builds']['new']['classes'][n]['sha256'] for n in CLASSES}
report.update(elapsedMs=round((time.perf_counter() - start) * 1000, 3), runtimeClassesInitialized=0, boundedAdmission=False,
              conditions=['Class files are read as data. A separate JDK tool extracts them.',
                          'The bundled image is not proven to be the live Bitwig runtime.'])
out = Path('/tmp/gn-9b6g-collection-conditions-1.json')
with out.open('x') as f: f.write(json.dumps(report, indent=2) + '\n')
print(json.dumps(report['sameBytesAcrossBuilds']), report['elapsedMs'])
