import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,instructions,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.descriptor_builders import lookup
from grid_doctor.assertion_guards import requirements
from grid_doctor.dispatch_paths import reachable
from grid_doctor.ownership import method_trace,bootstraps,constant
start=time.perf_counter();j=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));code=Code();cat=json.load(open('/tmp/gn-9b6g-factory-constructor-census-1.json'))['rows'];todo=[];roots=[];seen=set();rows=[];traces=[]
for r in cat:
 c,m=lookup(j,code,r['runtimeClass'],'ar_','()V');key=c.name,m.name,m.desc;todo.append(key);roots.append({'name':r['name'],'id':r['id'],'receiver':r['runtimeClass'],'method':list(key)})
while todo:
 key=todo.pop()
 if key in seen:continue
 if len(seen)>=128:raise Refusal('object-invariant-method-limit')
 seen.add(key);c,m=lookup(j,code,*key);guards=requirements(j,{c.name},code);selected=reachable(c,m,None,set(map(tuple,guards['fields'])));body=[];calls=[]
 for off,op,args in instructions(m.code):
  if off not in selected:continue
  item={'offset':off,'opcode':op,'args':args}
  if op in(178,179,180,181,182,183,184,185,186,187,189,192,193):item['reference']=constant(c,int.from_bytes(bytes(args[:2]),'big'))
  body.append(item)
  if op in(182,183,184,185,186):
   calls.append(item)
   if op==183 and item['reference']['name']=='ar_'and item['reference']['descriptor']=='()V':
    cc,mm=lookup(j,code,item['reference']['owner'],'ar_','()V');todo.append((cc.name,mm.name,mm.desc))
 rows.append({'method':list(key),'guards':guards['fields'],'instructions':body,'calls':calls,'handlers':m.handlers});traces.append(method_trace(j,c,m,bootstraps(j.zip.read(c.name+'.class'),c)))
r={'sha256':j.sha256,'roots':roots,'rows':rows,'methods':traces,'boundedAdmission':False,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes()};raw=json.dumps(r,indent=2).encode()
if len(raw)>8*1024**2:raise Refusal('object-invariant-report-limit')
Path('/tmp/gn-9b6g-object-invariant-closure-1.json').write_bytes(raw);print('roots',len(roots),'methods',len(rows))
for row in rows:print(row['method'],'instructions',len(row['instructions']),'calls',[(x['offset'],x['reference'])for x in row['calls']],'handlers',row['handlers'])
print(len(raw),r['elapsedMs'],r['peakRssBytes'])
