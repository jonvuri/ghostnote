import json,time,hashlib
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,rss_bytes,ancestors
from grid_doctor.fixed_descriptors import catalog
start=time.perf_counter();paths=['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'];prior=json.load(open('/tmp/gn-9b6g-all-descriptor-reads-1.json'))['builds'];ports=json.load(open('/tmp/gn-9b6g-port-catalog-1.json'))['builds'];results=[]
for index,path in enumerate(paths):
 j=Jar(Path(path));c=catalog(j,{('analyzable_sample_reference_handle',5604):None,('simple_single_sample_resource',534):None})
 Path('/tmp/gn-9b6g-resource-anchor-'+str(index)+'-2.json').write_text(json.dumps(c,indent=2)+'\n')
 print('anchor counts',index,[(r['name'],r['id'],r['count'])for r in c['rows']],flush=True)
 if any(r['count']!=1 for r in c['rows']):raise Refusal('resource-anchor-count')
 resources={r['matches'][0]['runtimeClass']for r in c['rows']};fixed=[{'name':r['name'],'id':r['id'],'runtimeClass':r['runtimeClass']}for r in prior[index]['rows']]+[{'name':r['name'],'id':r['id'],'runtimeClass':r['matches'][0]['runtimeClass']}for r in ports[index]['rows']]
 if len(fixed)!=55 or len({r['id']for r in fixed})!=55 or prior[index]['sha256']!=j.sha256 or ports[index]['sha256']!=j.sha256:raise Refusal('resource-fixed-input')
 rows=[]
 for r in fixed:
  chain=set(ancestors(j.classes,r['runtimeClass'],128));hits=sorted(chain&resources);rows.append(dict(r,resourceAncestors=hits))
  if hits:raise Refusal('resource-fixed-receiver')
 results.append({'sha256':j.sha256,'resourceCatalog':c,'fixedReceivers':rows});print(index,'resources',[(r['id'],r['matches'][0]['runtimeClass'])for r in c['rows']],'excluded fixed receivers',len(rows),flush=True);del j
incoming_path=Path('/tmp/gn-9b6g-helpers-1.json');incoming=json.loads(incoming_path.read_text());sites=[r for r in incoming['sites']if r['target']['name']=='IPH'];
if len(sites)!=5 or any(s['caller']not in resources for s in sites):raise Refusal('resource-incoming-scope')
r={'builds':results,'newBuildIncoming':{'inputSha256':hashlib.sha256(incoming_path.read_bytes()).hexdigest(),'sites':sites,'methodHandles':incoming['methodHandles'],'unresolvedReferences':incoming['unresolvedReferences']},'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False,'runtimeObserved':False,'conditions':['No exact fixed catalog receiver can be a receiver of these five declared resource methods.','This does not exclude resource objects outside the catalog, application callbacks, or references obtained by a command.','The existing incoming scan retains unresolved references, native and reflective callers, and unproved dynamic edges.','Complete command closure and stable runtime receiver guards remain required.']};raw=json.dumps(r,indent=2).encode()
if len(raw)>8*1024**2:raise Refusal('resource-exclusion-report-limit')
Path('/tmp/gn-9b6g-resource-catalog-exclusion-2.json').write_bytes(raw);print(len(raw),r['elapsedMs'],r['peakRssBytes'])
