"""Ad-hoc read-only class dump. Reads the jar as data."""
import sys, json
sys.path.insert(0, '/Users/jonvuri/Development/ghostnote/brain/src/probes')
from grid_symbols.scan import Jar, parse, instructions
from pathlib import Path
jar = Jar(Path(sys.argv[1]))
for name in sys.argv[2:]:
    c = jar.classes.get(name)
    if c is None: print('ABSENT', name); continue
    print('=== CLASS', name, 'flags', c.flags, 'parent', c.parent, 'interfaces', c.interfaces)
    print('fields:', [(f.name, f.desc, f.flags) for f in c.fields])
    code = jar.code(name)
    for m in code.methods:
        refs = []
        if m.code:
            for off, op, args in instructions(m.code):
                if op in range(178,186) or op in (187,192,193):
                    idx = args[0]*256+args[1]
                    tag, val = code.cp[idx]
                    if tag == 7: refs.append((op, code.cp[val][1]))
                    else:
                        owner, nt = val; owner = code.cp[code.cp[owner][1]][1]; ni, di = code.cp[nt][1]
                        refs.append((op, owner, code.cp[ni][1], code.cp[di][1]))
                elif op in (18,19):
                    idx = args[0] if op==18 else args[0]*256+args[1]
                    tag,val = code.cp[idx]
                    if tag==8: refs.append(('str', code.cp[val][1]))
                    elif tag==3: refs.append(('int', val))
                elif op in (16,17): refs.append(('push', int.from_bytes(bytes(args),'big',signed=True)))
        print(f'  -- {m.name}{m.desc} flags={m.flags} insns={len(instructions(m.code)) if m.code else 0}')
        for r in refs: print('      ', r)
