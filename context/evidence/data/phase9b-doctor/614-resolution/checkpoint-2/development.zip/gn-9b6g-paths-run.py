import json,time
from pathlib import Path
from grid_symbols.scan import Jar,rss_bytes
from grid_doctor.dispatch_paths import read_paths
from grid_doctor.descriptor_resolution import Code
start=time.perf_counter();j=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));code=Code()
cat=json.load(open('/tmp/gn-9b6g-fixed-1.json'))['builds'][1];sym=json.load(open('/tmp/gn-9b6g-resolution-4.json'))['builds'][1];props=json.load(open('/tmp/gn-9b6g-properties-4.json'))['builds'][1]
r=read_paths(j,cat,sym,props,code);r.update(elapsedMs=(time.perf_counter()-start)*1000,peakRssBytes=rss_bytes());Path('/tmp/gn-9b6g-paths-1.json').write_text(json.dumps(r,indent=2));print(r['work']);print('frontier',len({str(e['target']) for p in r['paths']for e in p['frontier']if'target'in e}))
