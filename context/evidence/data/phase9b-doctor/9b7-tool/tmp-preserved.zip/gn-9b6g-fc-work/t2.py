import sys,json;sys.path.insert(0,'/tmp/gn-9b6g-fc-work')
import walk;from walk import *
from collections import Counter
jar=Jar(NEW)
roots=json.loads(sys.argv[1]);depth=int(sys.argv[2])
nodes,leaves=closure(jar,[tuple(r) for r in roots],max_depth=depth)
print('methods',len(nodes),'leaves',len(leaves),'instr',sum(n['instructions'] for n in nodes))
news=Counter();mons=[];indy=[];hs=[]
for n in nodes:
  for c in n['news']:news[c]+=1
  for m in n['monitors']:mons.append((n['method'],str(m)[:90]))
  for x in n['indy']:indy.append((n['method'],x['name'],x['descriptor']))
  if n['handlers']:hs.append((n['method'],n['handlers']))
print('NEW',dict(news))
print('MON');[print(' ',x) for x in mons]
print('INDY');[print(' ',x) for x in indy]
print('HANDLERS');[print(' ',x) for x in hs]
if len(sys.argv)>3:
  for n in nodes:print(n['depth'],n['method'],'this',n['this'],n['instructions'])
print('OPEN')
c=Counter((l['kind'],l['target'],l.get('targets')) for l in leaves)
for k,v in sorted(c.items(),key=lambda x:-x[1]):print(' ',v,k)
