exec(open('/tmp/gn-9b6g-anchor-explore.py').read().split('sources=[]')[0])
a=json.loads(Path('/tmp/gn-9b6g-anchors.json').read_text())
known=[a['typeBindings'],{tuple(r['source']):tuple(r['target'])for r in a['members']}]
selected={};support=[];unsupported=[]
for row in source['members']:
 if row['kind']!='field':continue
 oc=code(old,row['declaring']);key=(9,row['declaring'],row['name'],row['descriptor'])
 from grid_doctor.contracts import references
 for m in oc.methods:
  if any((9,r['owner'],r['name'],r['descriptor'])==key for r in references(oc,m)):
   r={'role':'support:'+row['declaring']+'.'+m.name+m.desc,'kind':'method','declaring':row['declaring'],'lookup':row['declaring'],'name':m.name,'descriptor':m.desc,'flags':m.flags}
   if r not in support:support.append(r)
rows=source['members']+support
for rnd in range(128):
 additions=[];states={}
 for row in rows:
  role=row['role'];o=row['declaring'];n=known[0].get(o)
  if row['kind']=='field' or not n or role in selected:continue
  oc=code(old,o);om=member(oc,row['name'],row['descriptor'])
  try:v=contract(oc,om,old.classes)
  except Refusal as e:
   if str(e).startswith('contract-unsupported-constant:'):states[role]=str(e);continue
   raise
  matches=[]
  nc=code(new,n)
  for nm in nc.methods:
   if signature_key(nm,new.classes)!=signature_key(om,old.classes):continue
   try:
    nv=contract(nc,nm,new.classes)
    if nv['digest']!=v['digest']:continue
    mapped=merge(bindings(v,nv),[{o:n},{(10,o,om.name,om.desc):(10,n,nm.name,nm.desc)}])
    mapped,u=canonical_edges(mapped,od,nd);merge(known,mapped)
   except Refusal as e:
    if str(e) in ('operation-edge-conflict','reference-alias-conflict') or str(e).startswith('contract-unsupported-constant:'):continue
    raise
   matches.append(((n,nm.name,nm.desc),mapped))
  states[role]=len(matches)
  if len(matches)==1:additions.append((row,*matches[0]))
 if not additions:break
 for row,t,m in additions:known=merge(known,m)
 for row,t,m in additions:selected[row['role']]=t
 print('round',rnd,len(additions),flush=True)
print('unselected',[(r['role'],states.get(r['role']))for r in source['members'] if r['kind']=='method' and r['role']not in selected])
for row in source['members']:
 if row['kind']=='field':print('field',row['role'],known[1].get((9,row['declaring'],row['name'],row['descriptor'])))
result={'types':{r:known[0].get(n)for r,n in source['types'].items()},'typeBindings':known[0],'members':[{'source':list(k),'target':list(v)}for k,v in known[1].items()],'selected':selected,'states':states}
Path('/tmp/gn-9b6g-roles.json').write_text(json.dumps(result,indent=2))
print('missing types',[(k,v)for k,v in result['types'].items()if v is None])
