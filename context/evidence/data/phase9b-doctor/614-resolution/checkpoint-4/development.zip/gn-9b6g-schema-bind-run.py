import json,time
from pathlib import Path
from grid_symbols.scan import Jar,rss_bytes,Refusal
from grid_doctor.descriptor_resolution import Code
from grid_doctor.property_contracts import bind_properties
start=time.perf_counter();jars=[Jar(Path(p))for p in ['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar']];code=Code();s=json.load(open('/tmp/gn-9b6g-resolution-5.json'));c=json.load(open('/tmp/gn-9b6g-fixed-1.json'));source=json.load(open('/tmp/gn-9b6g-schema-relationships-1.json'));wanted={(r['name'],r['id']):{(p['name'],p['id']):p['matches'][0]['class']for p in r['properties']}for r in source['rows']};rows=[]
for i,j in enumerate(jars):rows.append(bind_properties(jars[0],j,c['builds'][0],c['builds'][i],wanted,s['builds'][i],code))
r={'builds':rows,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'completeTable':False,'boundedAdmission':False,'writeAuthority':False};raw=json.dumps(r,indent=2).encode()
if len(raw)>8*1024**2:raise Refusal('report-size')
Path('/tmp/gn-9b6g-schema-bindings-1.json').write_bytes(raw);print('bytes',len(raw),'elapsedMs',r['elapsedMs'],'rss',r['peakRssBytes']);print([(sum(len(x['properties'])for x in b['properties']),[(x['name'],x['missing'])for x in b['properties']if x['missing']],b['work'])for b in rows]);print('types',[(r['source'],r['target'])for r in rows[1]['propertyDispatch']])
