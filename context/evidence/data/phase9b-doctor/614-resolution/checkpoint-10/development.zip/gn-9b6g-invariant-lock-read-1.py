import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,ancestors,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.assertion_guards import requirements
from grid_doctor.owned_flow import getter_field
from grid_doctor.migrate import member
from grid_doctor.read_dataflow import ReadFlow
from grid_doctor.constructor_bounds import direct_bounds
from grid_doctor.callee_contracts import compare_callees
start=time.perf_counter();jars=[Jar(Path(p))for p in ['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar']];code=Code();seed=json.load(open('/tmp/gn-9b6g-invariant-direct-contracts-1.json'));types={v:k for k,v in seed['typeBindings'].items()};members={tuple(r['target']):tuple(r['source'])for r in seed['memberBindings']};out=[]
for i,j in enumerate(jars):
 sym=json.load(open('/tmp/gn-9b6g-resolution-5.json'))['builds'][i];roles={r['role']:r['reference']for r in sym['members']};key=roles['property-id'];c=code.get(j,key[1]);pf=getter_field(c,member(c,*key[2:]),'I');anchor=next(r['matches'][0]for r in json.load(open('/tmp/gn-9b6g-fixed-1.json'))['builds'][i]['rows']if r['id']==163);pclass='deM'if i else types['deM'];root=('deM','cfM','(Lcom/bitwig/ramona/core/oDc;)Lcom/bitwig/ramona/core/IOJ;');inv=('com/bitwig/ramona/core/IOJ','ar_','()V')
 if not i:root=tuple(members[(10,*root)][1:]);inv=tuple(members[(10,*inv)][1:])
 owners=set()
 for t in [pclass,anchor['descriptor'],anchor['runtimeClass'],inv[0]]:owners.update(ancestors(j.classes,t,128))
 guards=requirements(j,{n for n in owners if any(f.desc=='Z'and f.flags==4120 for f in j.classes[n].fields)},code);flow=ReadFlow(j,code,guards['fields'],pf,2018,anchor['descriptor']);key=(*root,('ref',pclass,'property'),(('ref',anchor['runtimeClass'],'object'),),False);returns=flow.evaluate(*root,key[3],key[4]);r={'sha256':j.sha256,'root':root,'normalGetterBound':dict(zip(('vendorInstructions','vendorCalls','externalCalls'),flow.bounds[key])),'returns':sorted(returns,key=str),'methods':sorted(flow.methods),'staticFields':sorted(flow.static_fields),'assertionGuards':guards};r['invariant']=direct_bounds(j,code,[inv],guards['fields']);out.append(r)
traces={tuple(k):dict(zip(('owner','name','descriptor'),k))for k in out[1]['methods']}
for m in out[1]['invariant']['methods']:traces[tuple(m['method'])]=dict(zip(('owner','name','descriptor'),m['method']))
compared=compare_callees(*jars,list(traces.values()),seed,code);r={'builds':out,'contracts':compared,'boundedAdmission':False,'conditions':['The returned object must be the initialized exact lock wrapper from the native-device constructor.','Disabled assertion flags and the fixed runtime and descriptor identities are required.'],'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes()};raw=json.dumps(r,indent=2).encode()
if len(raw)>8*1024**2:raise Refusal('invariant-lock-report-limit')
Path('/tmp/gn-9b6g-invariant-lock-read-1.json').write_bytes(raw)
for b in out:print('getter',b['normalGetterBound'],'invariant',b['invariant']['roots'],'returns',b['returns'])
print('contracts',len(compared['matched']),compared['unmatched']);print(len(raw),r['elapsedMs'],r['peakRssBytes'])
