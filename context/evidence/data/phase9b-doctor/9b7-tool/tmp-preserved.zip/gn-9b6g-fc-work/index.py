# Build a compact reverse reference index over class bytes as data.
import sys,zipfile,pickle,time,resource
from array import array
from grid_symbols.scan import parse,instructions
from grid_doctor.ownership import bootstraps
OLD='/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar'
NEW='/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'
t0=time.time();which=sys.argv[1];z=zipfile.ZipFile(NEW if which=='new' else OLD)
ids={};names=[]
def iid(s):
  i=ids.get(s)
  if i is None:i=ids[s]=len(names);names.append(s)
  return i
callee=array('i');caller=array('i');off=array('i');ops=array('i')
hier={};decl={};handles=[];nclass=nm=ni=0
for e in z.namelist():
  if not e.endswith('.class'):continue
  raw=z.read(e);c=parse(raw,True);nclass+=1
  hier[c.name]=(c.parent,c.interfaces,c.flags)
  decl[c.name]={(m.name,m.desc):m.flags for m in c.methods}
  cp=c.cp
  def ref(i):
    tag,(o,nt)=cp[i];own=cp[cp[o][1]][1];n,d=cp[nt][1];return tag,own,cp[n][1],cp[d][1]
  for k,ent in enumerate(cp):
    if ent and ent[0]==15:
      try:
        _,own,n,d=ref(ent[1][1]);handles.append((c.name,own,n,d,ent[1][0]))
      except Exception:pass
  for m in c.methods:
    if not m.code:continue
    nm+=1;me=iid(c.name+'#'+m.name+'#'+m.desc)
    for pos,op,a in instructions(m.code):
      ni+=1
      if 178<=op<=185:
        tag,own,n,d=ref(a[0]<<8|a[1])
        callee.append(iid(own+'#'+n+'#'+d));caller.append(me);off.append(pos);ops.append(op)
      elif op==187:
        own=cp[cp[a[0]<<8|a[1]][1]][1]
        callee.append(iid(own+'#new#'));caller.append(me);off.append(pos);ops.append(op)
      elif op==186:
        i=a[0]<<8|a[1];bi,nt=cp[i][1];n,d=cp[nt][1]
        callee.append(iid('indy#'+cp[n][1]+'#'+cp[d][1]+'#'+c.name+'#'+str(bi)));caller.append(me);off.append(pos);ops.append(op)
pickle.dump({'names':names,'callee':callee,'caller':caller,'off':off,'ops':ops,'hier':hier,'decl':decl,'handles':handles},open(f'/tmp/gn-9b6g-fc-work/index-{which}.pickle','wb'),protocol=5)
print(which,'classes',nclass,'methods',nm,'instructions',ni,'edges',len(callee),'handles',len(handles),'s',round(time.time()-t0,1),'maxrss',resource.getrusage(resource.RUSAGE_SELF).ru_maxrss)
