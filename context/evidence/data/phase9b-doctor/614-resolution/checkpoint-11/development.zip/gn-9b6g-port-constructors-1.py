import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,ancestors,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.assertion_guards import requirements
from grid_doctor.constructor_bounds import direct_bounds
from grid_doctor.callee_contracts import compare_callees
start=time.perf_counter();jars=[Jar(Path(p))for p in ['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar']];code=Code();catalogs=json.load(open('/tmp/gn-9b6g-port-catalog-1.json'))['builds'];builds=[]
for i,j in enumerate(jars):
 roots=[(r['matches'][0]['runtimeClass'],'<init>','()V')for r in catalogs[i]['rows']];owners={a for r in roots for a in ancestors(j.classes,r[0],128)};flags=requirements(j,{n for n in owners if any(f.desc=='Z'and f.flags==4120 for f in j.classes[n].fields)},code)['fields'];result=direct_bounds(j,code,roots,flags);result['sha256']=j.sha256;builds.append(result);print(i,'roots',len(roots),'methods',len(result['methods']),[(r['vendorInstructions'],r['vendorCalls'])for r in result['roots']],flush=True)
seed=json.load(open('/tmp/gn-9b6g-port-flows-1.json'))['contracts'];traces=[dict(zip(('owner','name','descriptor'),r['method']))for r in builds[1]['methods']];contracts=compare_callees(*jars,traces,seed,code);r={'builds':builds,'contracts':contracts,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False};raw=json.dumps(r,indent=2).encode()
if len(raw)>8*1024**2:raise Refusal('port-constructor-report-limit')
Path('/tmp/gn-9b6g-port-constructors-1.json').write_bytes(raw);print('matches',len(contracts['matched']),'unmatched',contracts['unmatched']);print(len(raw),r['elapsedMs'],r['peakRssBytes'])
