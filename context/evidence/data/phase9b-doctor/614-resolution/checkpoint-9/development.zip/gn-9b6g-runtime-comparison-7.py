import json,hashlib
from pathlib import Path
reports={k:json.load(open('/tmp/gn-9b6g-runtime-'+k+'-7.json'))for k in ['old-arm64','old-x64','new-arm64','new-x64']};comparisons=[]
for a,b in [('old-arm64','old-x64'),('new-arm64','new-x64'),('old-arm64','new-arm64')]:
 x={c['name']:c['sha256']for c in reports[a]['classes']};y={c['name']:c['sha256']for c in reports[b]['classes']};comparisons.append({'source':a,'target':b,'classes':len(x),'different':[k for k in x if x[k]!=y[k]],'missing':sorted(set(x)^set(y))})
selected={}
for c in reports['new-arm64']['classes']:
 if c['name']not in ['java/lang/Math','java/lang/Float','java/util/LinkedHashMap','java/util/HashMap','java/util/AbstractMap']:continue
 for m in c['methods']:
  if(m['name'],m['descriptor'])not in [('min','(FF)F'),('max','(FF)F'),('floatToRawIntBits','(F)I'),('<init>','()V'),('<init>','(I)V'),('<init>','(IF)V'),('<clinit>','()V'),('tableSizeFor','(I)I')]:continue
  selected[(c['name'],m['name'],m['descriptor'])]=m
r={'inputs':{k:{'sha256':hashlib.sha256(Path('/tmp/gn-9b6g-runtime-'+k+'-7.json').read_bytes()).hexdigest(),'imageSha256':v['imageSha256'],'elapsedMs':v['elapsedMs'],'peakRssBytes':v['peakRssBytes']}for k,v in reports.items()},'comparisons':comparisons,'methods':list(selected.values()),'runtimeClassesInitialized':0,'boundedAdmission':False};Path('/tmp/gn-9b6g-runtime-comparison-7.json').write_text(json.dumps(r,indent=2)+'\n');print(comparisons)
for key,m in selected.items():
 print(key,'instructions',len(m['instructions']),'calls',[(x['owner'],x['name'],x['descriptor'])for x in m['references']if x['opcode']in(182,183,184,185)])
