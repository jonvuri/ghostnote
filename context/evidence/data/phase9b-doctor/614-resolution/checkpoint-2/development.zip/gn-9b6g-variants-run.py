import hashlib,json,time
from pathlib import Path
from grid_symbols.scan import Jar,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.explicit_variants import variants,jdk_membership
p=Path('/tmp/gn-9b6g-resolution-3.json');r=json.loads(p.read_text());code=Code();start=time.perf_counter()
paths=[Path('/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar'),Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar')]
jars=[Jar(p)for p in paths]
roots=[Path('/tmp/gn-9b6g-jdk-old'),Path('/tmp/gn-9b6g-jdk')]
jdk=[jdk_membership(p)for p in roots]
checks=[]
for jar,b,j in zip(jars,r['builds'],jdk):
 assert jar.sha256==b['sha256']
 checks.append(variants(jars[0],jar,None,b,code,j))
result={'inputHash':hashlib.sha256(p.read_bytes()).hexdigest(),'variants':checks,'jdk':jdk,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False,'writeAuthority':False}
Path('/tmp/gn-9b6g-variants-1.json').write_text(json.dumps(result,indent=2)+'\n')
print([[x['variant']for x in rows]for rows in checks])
