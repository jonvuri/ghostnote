import json,time
from pathlib import Path
from grid_symbols.scan import Jar,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.call_paths import paths
start=time.perf_counter();j=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));code=Code();syms=json.load(open('/tmp/gn-9b6g-resolution-5.json'))['builds'][1]
roots=[r['reference'][1:]for r in syms['members']if r['source']['kind']=='method'];sinks=[['com/bitwig/ramona/core/oDc','IPH','()LdgI;'],['dqr','UNj','()V'],['com/bitwig/flt/document/core/master/AJH','bLK','()V']]
r=paths(j,roots,sinks,code);r.update(elapsedMs=(time.perf_counter()-start)*1000,peakRssBytes=rss_bytes());Path('/tmp/gn-9b6g-callpaths-1.json').write_text(json.dumps(r,indent=2));print(json.dumps({'work':r['work'],'results':r['results'],'elapsedMs':r['elapsedMs'],'peakRssBytes':r['peakRssBytes']},indent=2))
