"""Ad-hoc: find descriptor classes by (name,id) constructor pair and their runtime class getter."""
import sys
sys.path.insert(0, '/Users/jonvuri/Development/ghostnote/brain/src/probes')
from grid_symbols.scan import Jar, parse, instructions
from grid_doctor.fixed_descriptors import constructor_pair
from grid_doctor.ownership import constant
from pathlib import Path
jar = Jar(Path(sys.argv[1])); wanted = set(sys.argv[2:])
for entry in jar.zip.namelist():
    if not entry.endswith('.class'): continue
    data = jar.zip.read(entry)
    if not any(w.encode() in data for w in wanted): continue
    cls = parse(data, True)
    for m in cls.methods:
        if m.name == '<init>' and m.desc == '()V' and m.code:
            pair = constructor_pair(cls, m)
            if pair and pair[0] in wanted:
                getters = []
                for g in cls.methods:
                    if g.desc == '()Ljava/lang/Class;' and g.code:
                        raw = instructions(g.code)
                        if len(raw) == 2 and raw[0][1] in (18,19):
                            _, op, args = raw[0]
                            v = constant(cls, args[0] if op == 18 else args[0]*256+args[1])
                            if v['tag'] == 7: getters.append(v['value'])
                print(cls.name, pair, 'runtime', getters)
