"""Ad-hoc: log reachability edges for one receiver using the census class."""
import sys, json
sys.path.insert(0, '/Users/jonvuri/Development/ghostnote/brain/src/probes')
from pathlib import Path
from grid_symbols.scan import Jar, instructions
from grid_doctor import owned_census as oc
jar = Jar(Path(sys.argv[1]))
symbols = json.load(open('context/evidence/data/phase9b-doctor/614-resolution/checkpoint-2/symbols.json'))
report = json.load(open('context/evidence/data/phase9b-doctor/614-resolution/checkpoint-17/collection-conditions-17.json'))
roles, members = oc.build_for(symbols, jar.sha256); forms, strong, _ = oc.collector_for(report, jar.sha256)
c = oc.Census(jar, roles, forms, strong)
receiver = sys.argv[2]; wanted = set(sys.argv[3:])
entries = c.entries([receiver]); extra = c.module_entries() if receiver == c.module else {}
todo = [(k, 'entry') for k in list(entries) + list(extra)]; visited = set(); parent = {}
while todo:
    (name, desc), via = todo.pop()
    if (name, desc) in visited: continue
    visited.add((name, desc)); parent[(name, desc)] = via
    owner = c.resolve(receiver, name, desc)
    if owner is None or owner == c.base or owner in c.chain(c.base): continue
    cls = c.code(owner); m = c.method(cls, name, desc)
    if m is None or not m.code: continue
    for off, op, args in instructions(m.code):
        if op in (182, 183, 185):
            t, n2, d2 = c.ref(cls, args)
            if t == owner or t in c.chain(receiver): todo.append(((n2, d2), f'{owner}.{name}{desc}'))
print('reachable', len(visited))
for w in wanted:
    hits = [k for k in visited if k[0] == w]
    print(w, 'reached' if hits else 'NOT reached', hits)
    for h in hits:
        path = []; cur = parent.get(h)
        while cur and cur != 'entry' and len(path) < 20:
            path.append(cur); n, d = cur.split('.', 1)[1].split('(', 1); cur = parent.get((n, '(' + d))
        print('   path:', ' <- '.join(path))
# which overrides of ap_/aq_/G_ exist in the chain
for n in ['G_', 'ap_', 'am_', 'ar_', 'aA_', 'woZ', 'bl_']:
    print(n, 'resolves to', c.resolve(receiver, n, '()V' if n not in ('am_',) else '()Z'))
