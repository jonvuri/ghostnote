import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,instructions,rss_bytes,ancestors
from grid_doctor.descriptor_resolution import Code
from grid_doctor.descriptor_builders import lookup
from grid_doctor.assertion_guards import requirements
from grid_doctor.dispatch_paths import reachable
from grid_doctor.read_dataflow import ReadFlow
from grid_doctor.ownership import constant
start=time.perf_counter();j=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));code=Code();catalog=json.load(open('/tmp/gn-9b6g-port-catalog-1.json'))['builds'][1];costs=json.load(open('/tmp/gn-9b6g-port-invariant-costs-1.json'));root=json.load(open('/tmp/gn-9b6g-invariant-root-bounds-1.json'))['builds'][1]
if any(x['sha256']!=j.sha256 for x in (catalog,costs,root)):raise Refusal('port-object-input-jar')
results=[]
for row in catalog['rows']:
 anchor=row['matches'][0];runtime=anchor['runtimeClass'];c,m=lookup(j,code,runtime,'ar_','()V');owners=set(ancestors(j.classes,runtime,128))|set(ancestors(j.classes,anchor['descriptor'],128));g=requirements(j,{n for n in owners if any(f.desc=='Z'and f.flags==4120 for f in j.classes[n].fields)},code);selected=reachable(c,m,None,set(map(tuple,g['fields'])));body=[x for x in instructions(m.code)if x[0]in selected];calls=[]
 if m.handlers or [x[1]for x in body]!=[178,154,42,183,178,154,178,154,42,182,42,182,177]:raise Refusal('port-object-invariant-shape')
 for off,op,args in body:
  if op in(182,183,184,185,186):calls.append((op,constant(c,int.from_bytes(bytes(args[:2]),'big'))))
 if [(op,r['name'],r['descriptor'])for op,r in calls]!=[(183,'ar_','()V'),(182,'ng_','()LdeS;'),(182,root['method'][1],root['method'][2])]:raise Refusal('port-object-call-shape')
 bc,bm=lookup(j,code,calls[0][1]['owner'],'ar_','()V')
 if list(bm.code)!=[177]or bm.handlers:raise Refusal('port-object-parent-invariant')
 flow=ReadFlow(j,code,g['fields'],('unused','id','I'),0,anchor['descriptor']);key=(calls[1][1]['owner'],'ng_','()LdeS;',('ref',runtime,'object'),(),False);returned=flow.evaluate(*key[:3],key[3],key[4]);getter=flow.bounds[key]
 if returned!={('ref',anchor['descriptor'],'descriptor')}:raise Refusal('port-object-descriptor-result')
 values=[p for p in costs['paths']if p['classId']==row['id']]
 if any(p['cost']['perChildInstructions']or p['cost']['perChildExternalCalls']or p['cost']['iteratorAllocations']for p in values):raise Refusal('port-object-relationship')
 expected=next(r for r in json.load(open('/tmp/gn-9b6g-port-property-bindings-1-1.json'))['properties']if r['id']==row['id'])
 if {p['propertyId']for p in values}!={p['id']for p in expected['properties']}:raise Refusal('port-object-incomplete-properties')
 rc,rm=lookup(j,code,calls[2][1]['owner'],calls[2][1]['name'],calls[2][1]['descriptor'])
 if [rc.name,rm.name,rm.desc]!=root['method']:raise Refusal('port-object-root-declaration')
 count=len(values);total={'vendorInstructions':len(body)+1+getter[0]+root['ownInstructions']['constant']+root['ownInstructions']['perValue']*count,'vendorCalls':3+getter[1]+count,'externalCalls':getter[2]+1,'explicitObjects':0}
 for p in values:
  for k in total:total[k]+=p['cost'][k]
 results.append({'name':row['name'],'id':row['id'],'valueCount':count,'objectInvariant':[c.name,m.name,m.desc],'descriptorGetterBound':getter,'normalObjectInvariantBound':total,'requiredStaticDescriptors':sorted(flow.static_fields),'assertionGuards':g['fields']})
r={'sha256':j.sha256,'rows':results,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False,'runtimeObserved':False,'conditions':['All value-path and descriptor-root conditions remain required.','The registered array contents must be exact and stable; the expression list must stay empty.','External method bodies, class initialization, and exception paths remain separate.','These counts do not include generated-port construction, setters, or attachment.']};raw=json.dumps(r,indent=2).encode();Path('/tmp/gn-9b6g-port-object-costs-2.json').write_bytes(raw);print([(x['name'],x['normalObjectInvariantBound'])for x in results]);print(len(raw),r['elapsedMs'],r['peakRssBytes'])
