import json,time
from pathlib import Path
from grid_symbols.scan import Jar,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.callee_contracts import compare_callees
start=time.perf_counter();old=Jar(Path('/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar'));new=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));code=Code()
seed=json.load(open('/tmp/gn-9b6g-dispatch-2.json'))['builds'][1];traces=json.load(open('/tmp/gn-9b6g-guarded-paths-1.json'))['methods'];members={('com/bitwig/flt/document/core/master/device/BZG','Grk','()Ljava/util/List;'),('com/bitwig/flt/document/core/master/device/i2s','SQN','()Ljava/util/List;')}
r=compare_callees(old,new,traces,seed,code,members);r.update(elapsedMs=(time.perf_counter()-start)*1000,peakRssBytes=rss_bytes());Path('/tmp/gn-9b6g-callees-1.json').write_text(json.dumps(r,indent=2));print(json.dumps({'matched':len(r['matched']),'unmatched':r['unmatched'],'work':r['work'],'elapsedMs':r['elapsedMs'],'peakRssBytes':r['peakRssBytes']},indent=2))
