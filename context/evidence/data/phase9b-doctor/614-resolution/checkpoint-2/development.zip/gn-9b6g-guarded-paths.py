import json,time
from pathlib import Path
from grid_symbols.scan import Jar,rss_bytes
from grid_doctor.dispatch_paths import read_paths
from grid_doctor.assertion_guards import requirements
from grid_doctor.descriptor_resolution import Code
start=time.perf_counter();j=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));code=Code()
cat=json.load(open('/tmp/gn-9b6g-fixed-1.json'))['builds'][1];sym=json.load(open('/tmp/gn-9b6g-resolution-5.json'))['builds'][1];props=json.load(open('/tmp/gn-9b6g-properties-4.json'))['builds'][1];prior=json.load(open('/tmp/gn-9b6g-paths-1.json'))
guards=requirements(j,{m['owner']for m in prior['methods']},code)
r=read_paths(j,cat,sym,props,code,set(map(tuple,guards['fields'])));r.update(assertionGuards=guards,elapsedMs=(time.perf_counter()-start)*1000,peakRssBytes=rss_bytes());Path('/tmp/gn-9b6g-guarded-paths-1.json').write_text(json.dumps(r,indent=2));print('work',r['work']);print('guards',len(guards['fields']));print('frontier', {str(e.get('target',e)) for p in r['paths']for e in p['frontier']})
