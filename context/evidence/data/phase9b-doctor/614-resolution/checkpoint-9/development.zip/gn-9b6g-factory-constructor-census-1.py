import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,instructions,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.constructor_paths import constructor_path
from grid_doctor.assertion_guards import requirements
from grid_doctor.dispatch_paths import reachable
from grid_doctor.migrate import member
from grid_doctor.ownership import constant,method_trace,bootstraps
start=time.perf_counter();j=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));code=Code();rows=json.load(open('/tmp/gn-9b6g-fixed-1.json'))['builds'][1]['rows']+json.load(open('/tmp/gn-9b6g-registry-closure-1.json'))['selectedRows']+json.load(open('/tmp/gn-9b6g-default-catalog-4.json'))['builds'][1]['rows'];catalog={(r['name'],r['id']):r for r in rows};results=[];traces={};bodies={}
for pair,r in sorted(catalog.items()):
 typ=r['matches'][0]['runtimeClass']
 try:
  chain=constructor_path(j,code,typ);bound=[]
  for step in chain:
   key=step['owner'],'<init>',step['descriptor']
   if key not in bodies:
    c=code.get(j,key[0]);m=member(c,*key[1:]);guard=requirements(j,{c.name},code);selected=reachable(c,m,None,set(map(tuple,guard['fields'])));effects=[]
    for off,op,args in instructions(m.code):
     if off not in selected:continue
     if op in(178,179,180,181,182,183,184,185,186,187,188,189,197)or op in(*range(153,172),198,199,200):
      e={'offset':off,'opcode':op,'args':args}
      if op in(178,179,180,181,182,183,184,185,186,187,189,197):e['reference']=constant(c,int.from_bytes(bytes(args[:2]),'big'))
      effects.append(e)
    bodies[key]={'method':list(key),'selectedInstructions':len(selected),'guard':guard['fields'],'effects':effects};traces[key]=method_trace(j,c,m,bootstraps(j.zip.read(c.name+'.class'),c))
   bound.append(bodies[key])
  results.append({'name':pair[0],'id':pair[1],'runtimeClass':typ,'constructors':bound})
 except Refusal as e:results.append({'name':pair[0],'id':pair[1],'runtimeClass':typ,'refusal':str(e)})
r={'sha256':j.sha256,'rows':results,'methods':list(traces.values()),'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False};raw=json.dumps(r,separators=(',',':')).encode()
if len(raw)>8*1024**2:raise Refusal('constructor-census-report-limit')
Path('/tmp/gn-9b6g-factory-constructor-census-1.json').write_bytes(raw);print('classes',len(results),'methods',len(traces),'refused',[r for r in results if'refusal'in r]);print('other calls')
for k,b in bodies.items():
 calls=[x for x in b['effects']if x['opcode']in(182,183,184,185,186)and x['reference'].get('name')!='<init>']
 if calls:print(k,calls)
print(len(raw),r['elapsedMs'],r['peakRssBytes'])
