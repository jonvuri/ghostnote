import json
from pathlib import Path
base=Path('context/evidence/data/phase9b-doctor/614-resolution');p=json.loads((base/'callback-followup-plan.json').read_text());p['methods']=[x for x in p['methods']if x['owner']!='OcA']
items=[('com/bitwig/ramona/core/Rzi','MJ','()V'),('com/bitwig/ramona/core/Rzi','ERO','()V'),('com/bitwig/ramona/core/Rzi','cfM','(Lcom/bitwig/ramona/core/XKG;)V'),('dqr','E3','()V'),('WWV','Hnt','()V'),('com/bitwig/flt/document/core/master/g2L','WVl','()V'),('com/bitwig/flt/document/core/master/g2L','zab','()V'),('TT','fireEvent','(Ljava/lang/Object;)V'),('dfT','MRY','(Z)Ljava/util/List;'),('dfT','cfM','(Ljava/util/ArrayList;ZLjava/util/concurrent/Semaphore;)V'),('dfI','cfM','(Ljava/lang/Runnable;)V'),('AUY','a_','(Ljava/lang/Runnable;)V')]
for item in items:
 r=dict(zip(('owner','name','descriptor'),item))
 if r not in p['methods']:p['methods'].append(r)
p['targets']=[{'kind':'field','owner':'com/bitwig/flt/document/core/master/Kiy','name':'IwV','descriptor':'Z'},{'kind':'method','owner':'com/bitwig/flt/document/core/master/JYc','name':'cfM','descriptor':'(Lfoz;)V'}]
(base/'callback-closure-plan.json').write_text(json.dumps(p,indent=2)+'\n');print(len(p['methods']))
