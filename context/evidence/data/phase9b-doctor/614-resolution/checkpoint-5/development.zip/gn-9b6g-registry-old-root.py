import json,time
from pathlib import Path
from grid_symbols.scan import Jar,rss_bytes
from grid_doctor.contracts import contract
from grid_doctor.migrate import member,bindings
from grid_doctor.descriptor_resolution import Code
s=time.perf_counter();j=Jar(Path('/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar'));n=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));c=Code();tc=c.get(n,'com/bitwig/flt/document/core/master/QfF');want=contract(tc,member(tc,'<init>','()V'),n.classes);rows=[]
for cl in j.classes.values():
 if cl.parent!='cYt':continue
 oc=c.get(j,cl.name)
 for m in oc.methods:
  if m.name=='<init>'and m.desc=='()V':
   v=contract(oc,m,j.classes);print(cl.name,v['digest']==want['digest']);
   if v['digest']==want['digest']:rows.append({'owner':cl.name,'types':bindings(v,want)[0]})
r={'rows':rows,'elapsedMs':(time.perf_counter()-s)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False};Path('/tmp/gn-9b6g-registry-old-root-1.json').write_text(json.dumps(r,indent=2));print(rows)
