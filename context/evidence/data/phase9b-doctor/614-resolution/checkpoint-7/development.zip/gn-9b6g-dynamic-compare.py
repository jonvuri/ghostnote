import json,time
from pathlib import Path
from collections import Counter
from grid_symbols.scan import Jar,Refusal,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.dynamic_contracts import dynamic_contract
from grid_doctor.callee_contracts import compare_callees
from grid_doctor.migrate import merge
from grid_doctor.ownership import bootstraps
start=time.perf_counter();jars=[Jar(Path(p))for p in ['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar']];code=Code();known=[{},{}]
for path in ['/tmp/gn-9b6g-nitro-contracts-1.json','/tmp/gn-9b6g-lifecycle-contracts-1.json']:
 r=json.load(open(path));known=merge(known,[r['typeBindings'],{tuple(x['source']):tuple(x['target'])for x in r['memberBindings']}])
seed={'typeBindings':known[0],'memberBindings':[{'source':list(k),'target':list(v)}for k,v in known[1].items()]}
keys=[{'owner':c.name,'name':m.name,'descriptor':m.desc}for c in jars[1].classes.values()if c.name in ('BgP','K1S','FRG','GRp') or c.name.startswith('com/bitwig/nitro/')for m in c.methods];matched={};unmatched={};work=Counter();rounds=[]
def local(j,c,m):
 try:return dynamic_contract(c,m,j.classes,bootstraps(j.zip.read(c.name+'.class'),c))
 except Refusal as e:
  if str(e).startswith(('dynamic-','contract-unsupported-constant:')):return None
  raise
for cycle in range(8):
 before=len(matched);todo=[k for k in keys if tuple(k.values())not in matched]
 for i in range(0,len(todo),256):
  if time.perf_counter()-start>120 or rss_bytes()>768*1024**2:raise Refusal('dynamic-budget')
  r=compare_callees(*jars,todo[i:i+256],seed,code,local_contract=local);seed=r;work.update(r['work'])
  for row in r['matched']:matched[tuple(row['target'])]=row
  for row in r['unmatched']:unmatched[tuple(row['target'])]=row
  if work['comparisons']>1000000 or work['instructions']>16000000:raise Refusal('dynamic-work-limit')
 rounds.append({'round':cycle,'matched':len(matched),'types':len(seed['typeBindings']),'work':dict(work)});print(rounds[-1],flush=True)
 if len(matched)==before:break
else:raise Refusal('dynamic-round-limit')
r={'jarHashes':[j.sha256 for j in jars],'matched':list(matched.values()),'unmatched':[v for k,v in unmatched.items()if k not in matched],'typeBindings':seed['typeBindings'],'memberBindings':seed['memberBindings'],'work':dict(work),'rounds':rounds,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False,'writeAuthority':False,'limits':['Exact dynamic payload matches are local trace inputs. Runtime linkage, initialization, dispatch, compiler closure, and memory bounds remain unproved.']};raw=json.dumps(r,indent=2).encode()
if len(raw)>8*1024**2:raise Refusal('dynamic-report-limit')
Path('/tmp/gn-9b6g-dynamic-contracts-1.json').write_bytes(raw);print('matched',len(matched),'unmatched',len(r['unmatched']),'bytes',len(raw),'ms',r['elapsedMs'],'rss',r['peakRssBytes'])
