import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.descriptor_builders import lookup
from grid_doctor.callee_contracts import compare_callees
from grid_doctor.migrate import merge
from grid_doctor.dynamic_contracts import dynamic_contract
from grid_doctor.ownership import bootstraps,method_trace
start=time.perf_counter()
jars=[Jar(Path(p))for p in ['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar']]
code=Code();seed=json.load(open('/tmp/gn-9b6g-all-descriptor-reads-1.json'))['contracts']
other=json.load(open('/tmp/gn-9b6g-object-invariant-contracts-1.json'))
a=merge([seed['typeBindings'],{tuple(r['source']):tuple(r['target'])for r in seed['memberBindings']}],[other['typeBindings'],{tuple(r['source']):tuple(r['target'])for r in other['memberBindings']}])
seed={'typeBindings':a[0],'memberBindings':[{'source':list(k),'target':list(v)}for k,v in a[1].items()]}
specs=[
('der','MRY','(Lcom/bitwig/ramona/core/OLR;Lcom/bitwig/ramona/core/RKg;Lcom/bitwig/ramona/core/bbQ;)Lcom/bitwig/ramona/core/OLR;'),
('QZn','UNj','()Lcom/bitwig/ramona/core/oDc;'),('QZn','FzB','()LBgP;'),
('BgP','<init>','()V'),('BgP','b_','(Lcom/bitwig/ramona/core/oDc;)V'),('BgP','Hnt','(Lcom/bitwig/ramona/core/oDc;)V'),('BgP','bl_','()V'),('BgP','Pgx','()V'),('BgP','BBT','()Z'),('BgP','Guv','()I'),('BgP','wYK','()I'),('BgP','cfM','(ZZZ)V'),('BgP','cfM','(Lcom/bitwig/flt/document/core/master/g2L;ZZZ)V'),('BgP','cfM','(Lcom/bitwig/nitro/bnq;Z)V'),
('Mdi','b_','(Lcom/bitwig/ramona/core/oDc;)V'),('to','b_','(Lcom/bitwig/ramona/core/oDc;)V'),('K2G','woZ','()V'),
('com/bitwig/ramona/core/RKg','<clinit>','()V'),('com/bitwig/ramona/core/RKg','cfM','(LdeZ;Lcom/bitwig/ramona/core/oDc;)Z'),('com/bitwig/ramona/core/RKg','cfM','(Lcom/bitwig/ramona/core/bnq;Lcom/bitwig/ramona/core/OLR;)Z'),
('deZ','hbP','()Z'),('nmv','pWb','()LdeT;'),('nmv','e3y','()LdeT;'),('deT','<init>','(Ljava/lang/String;ILder;Lder;LcUb;Ljava/lang/String;ILjava/lang/Integer;I)V'),('dfb','<init>','(Ljava/lang/String;ILder;Lder;LcUb;Ljava/lang/String;I)V'),('deZ','<init>','(Ljava/lang/String;ILder;I)V'),
('deT','cfM','(Lcom/bitwig/ramona/core/oDc;Lcom/bitwig/ramona/core/oDc;Lcom/bitwig/ramona/core/RKg;Lcom/bitwig/ramona/core/bbQ;)V'),('deT','Hnt','(Lcom/bitwig/ramona/core/oDc;Ljava/util/List;)V'),
('GDf','MRY','(Ljava/lang/Object;)Ljava/lang/Object;'),('vDL','cfM','(Ljava/util/UUID;)Lcom/bitwig/flt/document/core/master/device/hpW;'),
('cXR','MRY','(LQYb;Lcom/bitwig/base/async/pYi;)LTL;'),('TL','<init>','(LHpk;Lcom/bitwig/base/async/pYi;)V')]
specs += [('QZn','Ucl','()LdeT;'),('QZn','MIO','()LdeT;'),('deT','FzB','(Lcom/bitwig/ramona/core/oDc;Ljava/util/List;)V'),('QZn','cfM','(Lcom/bitwig/ramona/core/OLR;ILjava/util/List;)V'),('QZn','cfM','(LBgP;ILjava/util/List;)V'),('BgP','cfM','(Lcom/bitwig/ramona/serial/rsB;)V'),('BgP','Bpn','()Ljava/util/List;'),('BgP','iW2','()Ljava/util/List;'),('BgP','cfM','(Lgez;)V'),('BgP','MRY','(Lgez;)V')]
traces={}
for owner,name,desc in specs:
 c,m=lookup(jars[1],code,owner,name,desc)
 traces[c.name,m.name,m.desc]=method_trace(jars[1],c,m,bootstraps(jars[1].zip.read(c.name+'.class'),c))
def local(j,c,m):
 try:return dynamic_contract(c,m,j.classes,bootstraps(j.zip.read(c.name+'.class'),c))
 except Refusal as e:
  if str(e).startswith(('dynamic-','contract-unsupported-constant:')):return None
  raise
r=compare_callees(*jars,list(traces.values()),seed,code,local_contract=local)
r.update(traces=list(traces.values()),requestedLookups=[list(x)for x in specs],elapsedMs=(time.perf_counter()-start)*1000,peakRssBytes=rss_bytes(),runtimeObserved=False)
raw=json.dumps(r,indent=2).encode()
if len(raw)>8*1024**2:raise Refusal('clone-contract-report-limit')
Path('/tmp/gn-9b6g-clone-contracts-2.json').write_bytes(raw)
print('matched',len(r['matched']),'unmatched',r['unmatched']);print(len(raw),r['elapsedMs'],r['peakRssBytes'])
