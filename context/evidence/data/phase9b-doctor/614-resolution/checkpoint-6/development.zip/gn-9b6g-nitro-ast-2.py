import json,struct,hashlib,time
from pathlib import Path
from collections import Counter
from grid_symbols.scan import Jar,instructions,Refusal,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.migrate import member
from grid_doctor.fixed_descriptors import integer
from grid_doctor.ownership import constant
start=time.perf_counter();jar=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));code=Code()
def ops(owner):
 c=code.get(jar,owner);return c,instructions(member(c,'<clinit>','()V').code)
def ref(c,op):return constant(c,int.from_bytes(bytes(op[2]),'big'))
c,raw=ops('com/bitwig/nitro/XZh');ids={}
for i,x in enumerate(raw):
 if x[1]!=183:continue
 r=ref(c,x)
 if r['owner']!=c.name or r['descriptor']!='(Ljava/lang/String;II)V':continue
 ident=integer(c,*raw[i-1][1:]);field=ref(c,raw[i+1]);ids[field['name']]=ident
c,raw=ops('com/bitwig/nitro/IQl');registry={}
for i,x in enumerate(raw):
 if x[1]!=184:continue
 r=ref(c,x)
 if r['owner']!=c.name or r['descriptor']!='(Ljava/lang/Class;Lcom/bitwig/nitro/XZh;)V':continue
 field=ref(c,raw[i-1]);cls=ref(c,raw[i-2]);ident=ids[field['name']]
 if ident in registry or cls['tag']!=7:raise Refusal('ast-registry')
 registry[ident]=cls['value']
def decl(owner):
 seen=set()
 while owner and owner!='java/lang/Object':
  if owner in seen or len(seen)>64:raise Refusal('ast-inheritance')
  if owner=='com/bitwig/nitro/Declaration':return True
  seen.add(owner);owner=jar.classes[owner].parent
 return False
raw=Path('/tmp/gn-9b6g-nitro-1-decoded.bin').read_bytes();
from grid_doctor.nitro_data import AstReader
r=AstReader(raw,registry,{v for v in registry.values()if decl(v)})
root=r.read()['root']
report={'jarSha256':jar.sha256,'decodedSha256':hashlib.sha256(raw).hexdigest(),'registry':registry,'nodeCount':len(r.nodes),'types':dict(Counter(x['class']for x in r.nodes)),'strings':r.strings,'root':root,'work':r.work,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False,'limits':['Traced token stream only; constructor reader order and semantic compilation remain separate.','No vendor class is initialized.']}
Path('/tmp/gn-9b6g-nitro-ast-2.json').write_text(json.dumps(report,indent=2)+'\n');print('nodes',len(r.nodes),'types',report['types'],'strings',r.strings,'work',r.work,'elapsedMs',report['elapsedMs'],'rss',report['peakRssBytes'])
