"""Owned collector bodies, storage forms, and the serialized single-managed check."""
import hashlib, json, sys, time
from pathlib import Path
from grid_symbols.scan import Jar, Refusal, rss_bytes, ancestors
from grid_doctor.descriptor_resolution import Code
from grid_doctor.descriptor_builders import lookup
from grid_doctor import owned_collectors as oc

START = time.perf_counter()
JARS = ['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar',
        '/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar']
PINS = ['382c655d0b9e8db6bd433dc6100ef3a4ee23abf6a6615f79c40f0c2645792c93',
        '5c2b1895bbb9e7d08d9216de421985bb1f24b2ee62762c9451b4fe847df2469f']
NAMES = [{'object': 'com/bitwig/ramona/core/HEV', 'collector': 'dpx', 'dispose': ('dC_', '()V'), 'walk': ('MkF', '(Z)V')},
         {'object': 'com/bitwig/ramona/core/oDc', 'collector': 'tB1', 'dispose': ('ix_', '()V'), 'walk': ('wGc', '(Z)V')}]
RUNTIME = [[Path('/tmp/gn-9b6g-runtime-old-arm64-9/java.base'), Path('/tmp/gn-9b6g-collection-conditions-runtime-old-1/java.base'),
            Path('/tmp/gn-9b6g-collection-conditions-runtime-old-3/java.base')],
           [Path('/tmp/gn-9b6g-runtime-new-arm64-9/java.base'), Path('/tmp/gn-9b6g-collection-conditions-runtime-new-1/java.base'),
            Path('/tmp/gn-9b6g-collection-conditions-runtime-new-3/java.base')]]
INPUTS = {}


def load(path):
    raw = Path(path).read_bytes()
    INPUTS[path] = {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
    return json.loads(raw)


def bindings(b):
    files = (['/tmp/gn-9b6g-builder-property-bindings-1-0.json'] if b == 0 else
             ['/tmp/gn-9b6g-builder-property-bindings-3-0.json'] +
             ['/tmp/gn-9b6g-builder-property-bindings-4-%d.json' % i for i in range(9)])
    files += ['/tmp/gn-9b6g-default-property-bindings-2-%d.json' % b, '/tmp/gn-9b6g-port-property-bindings-1-%d.json' % b]
    rows = {}
    for f in files:
        d = load(f)
        if d['sha256'] != PINS[b]:
            raise Refusal('binding-fingerprint')
        for r in d['properties']:
            if (r['name'], r['id']) in rows:
                raise Refusal('binding-duplicate')
            rows[r['name'], r['id']] = r
    return rows


def catalog(b):
    rows = load('/tmp/gn-9b6g-fixed-1.json')['builds'][b]['rows']
    rows += load('/tmp/gn-9b6g-registry-%sclosure-1.json' % ('old-' if b == 0 else ''))['selectedRows']
    rows += load('/tmp/gn-9b6g-default-catalog-4.json')['builds'][b]['rows']
    rows += load('/tmp/gn-9b6g-port-catalog-1.json')['builds'][b]['rows']
    by = {}
    for r in rows:
        for m in r['matches']:
            by.setdefault(m['runtimeClass'], set()).add((r['name'], r['id'], m['descriptor']))
    return by


def paths(b):
    out = {}
    reports = [load('/tmp/gn-9b6g-builder-owned-flow-2-%d.json' % b),
               load('/tmp/gn-9b6g-default-flows-2.json')['builds'][b]['owned'],
               load('/tmp/gn-9b6g-port-flows-1.json')['builds'][b]['owned']]
    for r in reports:
        if r['sha256'] != PINS[b]:
            raise Refusal('path-fingerprint')
        for p in r['paths']:
            out[p['className'], p['propertyId']] = p
    return out


def run(b):
    began = time.perf_counter()

    class Bounded(Jar):
        def check(self):
            super().check()
            if time.perf_counter() - began > 115:
                raise Refusal('collection-deadline')
    jar = Bounded(Path(JARS[b]))
    try:
        if jar.sha256 != PINS[b]:
            raise Refusal('jar-fingerprint')
        code, names = Code(), NAMES[b]
        base = code.get(jar, names['object'])
        method = [m for m in base.methods if (m.name, m.desc) == (names['collector'], oc.KEY)][0]
        collector = oc.collector_contract(base, method)
        callers = oc.null_key_callers(base, [m for m in base.methods if (m.name, m.desc) in (names['dispose'], names['walk'])],
                                      collector['method'])
        if len(callers) != 2:
            raise Refusal('collector-callers')
        rel = collector['relationship']
        dcls, plist = oc.property_list_contract(jar, code, collector['descriptorGetter'][2][3:-1],
                                                collector['propertyList'], rel)
        field = {'tag': 9, 'owner': plist['arrayField'][0], 'name': plist['arrayField'][1], 'descriptor': plist['arrayField'][2]}
        strong = oc.strong_filter(jar, code, dcls, field, rel)
        array_sites = oc.field_sites(jar, [plist['arrayField']])
        outside = [s for s in array_sites['sites'] if s['class'] != dcls.name]
        if outside or array_sites['methodHandles']:
            raise Refusal('property-array-outside-access')
        forms = {}
        for name, c in jar.classes.items():
            if name != rel and rel in ancestors(jar.classes, name, 128) and not c.flags & 0x400:
                owner, slot = lookup(jar, code, name, *collector['relationshipSlot'][1:])
                forms[name] = dict(oc.relationship_form(owner, slot), declaration=owner.name)
        cat, props, flows = catalog(b), bindings(b), paths(b)
        release = load('/tmp/gn-9b6g-factory-release-2.json')['builds'][b]
        receivers, storage = [], {'list': {}, 'map': {}}
        for row in release['rows']:
            matches = cat.get(row['runtime'], set())
            if len(matches) != 1:
                raise Refusal('receiver-catalog')
            cname, cid, desc = matches.pop()
            single = oc.descriptor_singleton(jar, code, row['runtime'], collector['descriptorGetter'])
            if single['descriptor'] != desc:
                raise Refusal('receiver-descriptor')
            inv = oc.receiver_inventory(jar, code, row['runtime'], props[cname, cid], collector, strong, forms, flows)
            for p in inv['strong']:
                if p['form'] == 'list':
                    getters = []
                    flow = flows[cname, p['id']]
                    for owner, mname, mdesc in flow['methods']:
                        if mdesc == '()Ljava/util/List;' and owner != rel:
                            cls = code.get(jar, owner)
                            m = [x for x in cls.methods if (x.name, x.desc) == (mname, mdesc)][0]
                            try:
                                g = oc.list_getter_form(cls, m)
                            except Refusal:
                                continue
                            getters.append(g)
                    if len(getters) != 1:
                        raise Refusal('list-getter-count')
                    gfield = getters[0]['field']
                    if oc.declaring_field(jar, *gfield)[0] != p['storage'][0] or gfield[1:] != p['storage'][1:]:
                        raise Refusal('list-getter-field')
                    p['getter'] = getters[0]
                storage[p['form']].setdefault(tuple(p['storage']), []).append([cname, p['name']]) if p['form'] != 'single' else None
            inv['managed'] = row['managed']
            inv['descriptor'] = single
            receivers.append(inv)
        writers = {}
        every = oc.field_sites(jar, sorted(set(storage['list']) | set(storage['map'])))
        for form, wanted in (('list', 'java/util/ArrayList'), ('map', 'java/util/LinkedHashMap')):
            for f in sorted(storage[form]):
                flags = oc.declaring_field(jar, *f)[1]
                report = {'sites': [x for x in every['sites'] if tuple(x['field']) == f],
                          'methodHandles': [x for x in every['methodHandles'] if x['field'][1:] == list(f[1:])],
                          'scannedClasses': every['scannedClasses']}
                variants = {}
                if form == 'list':
                    listing = [k for k, v in forms.items() if v['form'] == 'list' and v['declaration'] == k]
                    for s in report['sites']:
                        if s['opcode'] == 181 and s['stored']['kind'] == 'unclassified' and len(listing) == 1:
                            variants[(s['class'], *s['method'], s['offset'])] = oc.parameter_list_store(jar, code, s, listing[0])
                try:
                    kinds, sites = oc.storage_kinds(report, wanted, variants)
                except Refusal as error:
                    writers['#'.join(f)] = {'form': form, 'error': str(error), 'users': storage[form][f],
                                            'writers': [s for s in report['sites'] if s['opcode'] in (179, 181)]}
                    continue
                if form == 'map' and (not flags & 16 or kinds != [wanted]
                                      or any(s['method'][0] != '<init>' or s['class'] != f[0] for s in sites)):
                    raise Refusal('map-storage-not-final-fresh')
                if form == 'list' and not set(kinds) <= {'null', wanted}:
                    raise Refusal('list-storage-kind')
                writers['#'.join(f)] = {'form': form, 'flags': flags, 'storedKinds': kinds,
                                        'elapsedMsAtCheck': round((time.perf_counter() - began) * 1000),
                                        'variants': [[*k, v] for k, v in variants.items()],
                                        'writers': [[s['class'], *s['method'], s['offset']] for s in sites],
                                        'reads': sum(s['opcode'] in (178, 180) for s in report['sites']),
                                        'users': storage[form][f], 'scannedClasses': report['scannedClasses']}
        reader = oc.JdkReader(RUNTIME[b])
        jdk = oc.jdk_bounds(reader)
        empty = 'emptyList'
        formulas = [oc.collector_formula(inv, jdk, inv['descriptor'], collector, empty) for inv in receivers]
        # Serialized single-managed check.
        module = load('/tmp/gn-9b6g-module-%s-2.json' % ('old' if b == 0 else 'new'))
        if module['jarSha256'] != PINS[b]:
            raise Refusal('module-fingerprint')
        kinds = {}
        for (cname, cid), r in props.items():
            for p in r['properties']:
                if p['targetClass'] in forms:
                    kinds[cid, p['id']] = oc.property_kind(jar, code, p, strong['kindEnum'], strong['enumNames'])[0]
        managed = {}
        for inv in receivers:
            managed[inv['classId']] = inv['managed']
        serialized = oc.serialized_single_managed(module['objects']['root'], kinds, managed)
        return {'sha256': jar.sha256, 'collector': collector, 'nullKeyCallers': callers, 'propertyList': plist,
                'strongFilter': strong, 'propertyArraySites': array_sites, 'relationshipForms': forms,
                'receivers': receivers, 'storageWriters': writers, 'jdk': jdk, 'formulas': formulas,
                'serialized': serialized, 'jarStats': jar.stats}
    finally:
        jar.close()


builds = [run(0), run(1)]
same_jdk = builds[0]['jdk'] == builds[1]['jdk']
pmax = [max(f['P'] for f in b['formulas']) for b in builds]
summary = []
for b in builds:
    worst = {k: max(f[k] for f in b['formulas']) for k in ('P', 'vendorInstructions', 'vendorCalls', 'jdkCalls', 'allocations')}
    worst['jdkConstant'] = max(f['jdkInstructions']['constant'] for f in b['formulas'])
    worst['jdkPerChild'] = max(f['jdkInstructions']['perChild'] for f in b['formulas'])
    summary.append(worst)
report = {'builds': builds, 'jdkSameAcrossBuilds': same_jdk, 'worstPerCall': summary,
          'inputs': INPUTS, 'elapsedMs': round((time.perf_counter() - START) * 1000, 3), 'peakRssBytes': rss_bytes(),
          'boundedAdmission': False, 'runtimeClassesInitialized': 0, 'conditions': oc.CONDITIONS}
raw = json.dumps(report, indent=1).encode() + b'\n'
if len(raw) > 8 * 1024 ** 2:
    raise Refusal('report-limit')
with open('/tmp/gn-9b6g-collection-conditions-17.json', 'xb') as out:
    out.write(raw)
for i, b in enumerate(builds):
    s = b['serialized']
    print(i, 'receivers', len(b['receivers']), 'forms', sorted({(v['form'], v['declaration']) for v in b['relationshipForms'].values()}),
          'worst', summary[i], 'serialized', {k: s[k] for k in ('nodes', 'edges', 'kindCounts', 'strongDepth', 'managedClassIds', 'managedNodes', 'rootClassId')})
    print('  storage', {k: (v.get('storedKinds'), v.get('error'), len(v['writers'])) for k, v in b['storageWriters'].items()})
    for k, v in b['storageWriters'].items():
        if 'error' in v: print('  ERROR', k, v['users'], [(w['class'], w['method'], w['offset'], w['stored']) for w in v['writers']])
print('jdkSame', same_jdk, 'elapsedMs', report['elapsedMs'], 'rss', report['peakRssBytes'], 'bytes', len(raw))
