import json,zipfile,collections,sys
from grid_symbols.scan import parse,instructions
from grid_doctor.ownership import constant
def load(fs):
    out=[]
    for f in fs: out+=json.load(open(f))['properties']
    return out
B={0:load(['/tmp/gn-9b6g-builder-property-bindings-1-0.json','/tmp/gn-9b6g-default-property-bindings-2-0.json','/tmp/gn-9b6g-port-property-bindings-1-0.json']),
   1:load(['/tmp/gn-9b6g-builder-property-bindings-3-0.json']+['/tmp/gn-9b6g-builder-property-bindings-4-%d.json'%i for i in range(9)]+['/tmp/gn-9b6g-default-property-bindings-2-1.json','/tmp/gn-9b6g-port-property-bindings-1-1.json'])}
cats={0:[],1:[]}
fx=json.load(open('/tmp/gn-9b6g-fixed-1.json'))['builds']
for b in (0,1):
    cats[b]+=fx[b]['rows']
    cats[b]+=json.load(open('/tmp/gn-9b6g-registry-%sclosure-1.json'%('old-' if b==0 else '')))['selectedRows']
    cats[b]+=json.load(open('/tmp/gn-9b6g-default-catalog-4.json'))['builds'][b]['rows']
    cats[b]+=json.load(open('/tmp/gn-9b6g-port-catalog-1.json'))['builds'][b]['rows']
rel=json.load(open('/tmp/gn-9b6g-factory-release-2.json'))['builds']
for b in (0,1):
    byrt=collections.defaultdict(set)
    for r in cats[b]:
        for m in r['matches']: byrt[m['runtimeClass']].add((r['name'],r['id'],m['descriptor']))
    names=[r['runtime'] for r in rel[b]['rows']]
    print('build',b,[ (n,sorted(byrt.get(n,()))) for n in names if len(byrt.get(n,()))!=1])
