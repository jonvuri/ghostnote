import json,hashlib,shutil,zipfile
from pathlib import Path
base=Path('context/evidence/data/phase9b-doctor/614-resolution');dest=base/'checkpoint-3';dest.mkdir()
prior={r['name']:r['sha256']for r in json.loads((base/'checkpoint-2/development-manifest.json').read_text())};manifest=[]
with zipfile.ZipFile(dest/'development.zip','x',compression=zipfile.ZIP_DEFLATED)as z:
 for p in sorted(Path('/tmp').glob('gn-9b6g-*')):
  if not p.is_file()or p.suffix not in ('.json','.txt','.log','.py','.sh'):continue
  data=p.read_bytes();h=hashlib.sha256(data).hexdigest()
  if prior.get(p.name)==h:continue
  z.writestr(p.name,data);manifest.append({'name':p.name,'sha256':h,'bytes':len(data)})
(dest/'development-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
files=['old-dataflow-2','new-dataflow-2','old-renamed-dataflow-2','new-renamed-dataflow-2','wrapper-contracts-1','renamed-wrapper-contracts-1','old-renamed-wrapper-contracts-1','callbacks-3','callbacks-4','relationship-flags-1','runtime-new-arm64-4']
for name in files:shutil.copyfile('/tmp/gn-9b6g-'+name+'.json',dest/(name+'.json'))
for name in ['new-tests-5','focused-tests-6','read-flow-tests-7']:shutil.copyfile('/tmp/gn-9b6g-'+name+'.txt',dest/(name+'.txt'))
shutil.copytree('/tmp/gn-9b6g-callee-mutant-reads',dest/'callee-mutant-reads')
sources=[]
for p in sorted(Path('brain/src/probes/grid_doctor').glob('*.py')):
 raw=p.read_bytes();sources.append({'path':str(p),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)})
(dest/'source-inventory.json').write_text(json.dumps(sources,indent=2)+'\n')
print('archived',len(manifest),'files',sum(x['bytes']for x in manifest),'bytes; zip',(dest/'development.zip').stat().st_size)
