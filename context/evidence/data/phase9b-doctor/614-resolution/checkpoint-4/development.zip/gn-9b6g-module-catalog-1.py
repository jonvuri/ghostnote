import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,parse,rss_bytes
from grid_doctor.fixed_descriptors import catalog,constructor_pair
start=time.perf_counter();roots=['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents','/Applications/Bitwig Studio.app/Contents'];ids=set(map(int,json.load(open('/tmp/gn-9b6g-module-files-1.json'))['builds'][0]['objects']['classCounts']));builds=[];pairs={}
for i,root in enumerate(roots):
 j=Jar(Path(root+'/Java/bitwig.jar'))
 if i==0:
  for name,c in j.classes.items():
   j.check()
   if not any(m.name=='<init>'and m.desc=='()V'for m in c.methods):continue
   cls=parse(j.zip.read(name+'.class'),True)
   for m in cls.methods:
    p=constructor_pair(cls,m)
    if p and p[1]in ids:pairs[p]=None
 b=catalog(j,pairs);builds.append(b);j.close();print(i,'missingIds',sorted(ids-{p[1]for p in pairs}),'counts',[(r['name'],r['id'],r['count'])for r in b['rows']])
r={'builds':builds,'serializedIds':sorted(ids),'missingIds':sorted(ids-{p[1]for p in pairs}),'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False,'writeAuthority':False};Path('/tmp/gn-9b6g-module-catalog-1.json').write_text(json.dumps(r,indent=2));print(r['elapsedMs'],r['peakRssBytes'])
