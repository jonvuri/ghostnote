import json,time
from pathlib import Path
from collections import Counter
from grid_symbols.scan import Jar,rss_bytes
from grid_doctor.fixed_dispatch import fixed_slots
from grid_doctor.descriptor_resolution import Code
start=time.perf_counter();old=Jar(Path('/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar'));new=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));code=Code()
cat=json.load(open('/tmp/gn-9b6g-fixed-1.json'));syms=json.load(open('/tmp/gn-9b6g-resolution-4.json'));props=json.load(open('/tmp/gn-9b6g-properties-4.json'))
domains=json.load(open('/tmp/gn-9b6g-domains-1.json'));result=[]
for i,j in enumerate([old,new]):result.append(fixed_slots(old,j,cat['builds'][0],cat['builds'][i],syms['builds'][0],syms['builds'][i],props['builds'][i],code,(domains['builds'][0],domains['builds'][i])))
r={'builds':result,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes()}
Path('/tmp/gn-9b6g-dispatch-2.json').write_text(json.dumps(r,indent=2))
print(json.dumps({'summaries':[dict(Counter(x['status']for x in b['slots']))for b in result],'elapsedMs':r['elapsedMs'],'peakRssBytes':r['peakRssBytes'],'differences':[x for x in result[1]['slots']if x['status']!='exact-concrete-local-contract']},indent=2))
