import json,time
from pathlib import Path
from grid_symbols.scan import Jar,rss_bytes,Refusal
from grid_doctor.descriptor_resolution import Code
from grid_doctor.owned_flow import owned_collectors,runtime_parent_bindings
from grid_doctor.callee_contracts import compare_callees
from grid_doctor.fixed_read_checkpoint import membership_variants
from grid_doctor.migrate import merge
start=time.perf_counter();r=json.load(open('/tmp/gn-9b6g-factory-relationships-1.json'));s=json.load(open('/tmp/gn-9b6g-resolution-5.json'))['builds'];code=Code()
paths=['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'];jars=[Jar(Path(p))for p in paths];builds=[]
for i,j in enumerate(jars):
    owned=owned_collectors(j,code,s[i],r['catalogs'][i],r['builds'][i])
    parents,rows=runtime_parent_bindings(jars[0],j,r['catalogs'][0],r['catalogs'][i])
    seed={'typeBindings':merge([r['builds'][i]['typeBindings'],{}],[parents,{}])[0],'memberBindings':s[i]['memberBindings']}
    compared=compare_callees(jars[0],j,owned['methods'],seed,code,membership_variants(j,s[i],code,owned['methods']))
    builds.append({'owned':owned,'contracts':compared,'runtimeParentInputs':rows})
    print(i,'paths',len(owned['paths']),'errors',[(p['className'],p['propertyName'],p['error'])for p in owned['paths']if p['error']],'matched',len(compared['matched']),'unmatched',compared['unmatched'],flush=True)
report={'builds':builds,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False};raw=json.dumps(report,indent=2).encode()
if len(raw)>8*1024**2:raise Refusal('report-limit')
Path('/tmp/gn-9b6g-factory-owned-1.json').write_bytes(raw);print('bytes',len(raw),'elapsedMs',report['elapsedMs'],'rss',report['peakRssBytes'])
