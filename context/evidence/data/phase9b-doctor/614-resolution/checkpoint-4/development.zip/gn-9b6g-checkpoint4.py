import json,hashlib,shutil,zipfile
from pathlib import Path
base=Path('context/evidence/data/phase9b-doctor/614-resolution');dest=base/'checkpoint-4';dest.mkdir();prior={}
for path in sorted(base.glob('checkpoint-*/development-manifest.json')):
 for row in json.loads(path.read_text()):prior[row['name']]=row['sha256']
manifest=[]
with zipfile.ZipFile(dest/'development.zip','x',compression=zipfile.ZIP_DEFLATED)as z:
 for p in sorted(Path('/tmp').glob('gn-9b6g-*')):
  if not p.is_file()or p.suffix not in('.json','.txt','.log','.py','.sh','.bin'):continue
  raw=p.read_bytes();h=hashlib.sha256(raw).hexdigest()
  if prior.get(p.name)==h:continue
  z.writestr(p.name,raw);manifest.append({'name':p.name,'sha256':h,'bytes':len(raw)})
(dest/'development-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for name in ['schema-bindings-2','disposal-wrapper-contracts-3','module-old-2','module-new-2','module-contracts-2','module-catalog-1','registry-closure-1','constructor-tree-1','lifecycle-slots-1']:
 shutil.copyfile('/tmp/gn-9b6g-'+name+'.json',dest/(name+'.json'))
for name in ['unit-regression-5.txt','property-tests-1.log','module-tests-3.log']:
 shutil.copyfile('/tmp/gn-9b6g-'+name,dest/name)
sources=[]
with zipfile.ZipFile(dest/'diagnostic-source.zip','x',compression=zipfile.ZIP_DEFLATED)as z:
 for p in sorted(Path('brain/src/probes/grid_doctor').glob('*.py')):
  raw=p.read_bytes();sources.append({'path':str(p),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)});z.writestr(str(p),raw)
(dest/'source-inventory.json').write_text(json.dumps(sources,indent=2)+'\n')
print('archived',len(manifest),'files',sum(x['bytes']for x in manifest),'bytes; zip',(dest/'development.zip').stat().st_size)
