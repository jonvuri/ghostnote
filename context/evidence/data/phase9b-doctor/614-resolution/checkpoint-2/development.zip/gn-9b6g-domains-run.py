import json,time
from pathlib import Path
from grid_symbols.scan import Jar,rss_bytes
from grid_doctor.domain_contracts import source_domains
from grid_doctor.fixed_descriptors import catalog
from grid_doctor.descriptor_resolution import Code
start=time.perf_counter();j=Jar(Path('/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar'));n=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));code=Code();syms=json.load(open('/tmp/gn-9b6g-resolution-4.json'))
pairs,rows=source_domains(j,syms['builds'][0],code);builds=[catalog(k,pairs)for k in (j,n)]
r={'sourceReceivers':rows,'builds':builds,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes()};Path('/tmp/gn-9b6g-domains-1.json').write_text(json.dumps(r,indent=2));print('source',rows);print('target',[(r['name'],r['count'],r['matches'][0]['runtimeClass'])for r in builds[1]['rows']])
