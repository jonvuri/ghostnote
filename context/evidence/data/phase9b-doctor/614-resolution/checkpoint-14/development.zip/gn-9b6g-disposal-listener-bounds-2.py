import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,rss_bytes,descriptor
from grid_doctor.descriptor_resolution import Code
from grid_doctor.migrate import member
from grid_doctor.descriptor_builders import lookup
from grid_doctor.disposal_wrappers import listener_flags_delegate
from grid_doctor.callee_contracts import compare_callees
from grid_doctor.renamed_fixture import rename_member
from grid_doctor.ownership import method_trace,bootstraps
start=time.perf_counter();paths=['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'];jars=[Jar(Path(p))for p in paths];code=Code();seed=json.load(open('/tmp/gn-9b6g-history-aggregate-1.json'))['contracts'];inverse={v:k for k,v in seed['typeBindings'].items()};member_inverse={tuple(r['target']):tuple(r['source'])for r in seed['memberBindings']};key=('Hgx','ix_','()V');old=(inverse[key[0]],*member_inverse[(10,'com/bitwig/ramona/core/oDc','ix_','()V')][2:]);builds=[];traces={}
for index,k in enumerate((old,key)):
 c,m=lookup(jars[index],code,*k);r=listener_flags_delegate(c,m);builds.append({'sha256':jars[index].sha256,'bound':r});print(index,r['method'],r['ownInstructionBound'],r['ownVendorCallBound'],flush=True)
 if index:
  traces[k]=method_trace(jars[index],c,m,bootstraps(jars[index].zip.read(c.name+'.class'),c))
  for row in r['blocks']:
   for x in ('getter','remove'):
    cc,mm=lookup(jars[index],code,*row[x]);traces[cc.name,mm.name,mm.desc]=method_trace(jars[index],cc,mm,bootstraps(jars[index].zip.read(cc.name+'.class'),cc))
renamed=[]
for index,(p,mp)in enumerate([('/tmp/gn-9b6g-old-renamed-extra.jar','/tmp/gn-9b6g-old-renamed-map.json'),('/tmp/gn-9b6g-renamed-extra.jar','/tmp/gn-9b6g-renamed-map.json')]):
 names=json.load(open(mp));j=Jar(Path(p));k=(old,key)[index];mapped=(names.get(k[0],k[0]),rename_member(k[1]),descriptor(k[2],lambda n:names.get(n,n)));c=code.get(j,mapped[0]);m=member(c,*mapped[1:]);r=listener_flags_delegate(c,m)
 for part in('ownInstructionBound','ownVendorCallBound','allFlagsFalseInstructions'):
  if r[part]!=builds[index]['bound'][part]:raise Refusal('listener-disposal-renamed-cost')
 renamed.append({'sha256':j.sha256,'bound':r});del j
compared=compare_callees(*jars,list(traces.values()),seed,code);r={'builds':builds,'renamed':renamed,'contracts':compared,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False,'runtimeObserved':False};raw=json.dumps(r,indent=2).encode()
if len(raw)>8*1024**2:raise Refusal('listener-disposal-report-limit')
Path('/tmp/gn-9b6g-disposal-listener-bounds-2.json').write_bytes(raw);print('matched',len(compared['matched']),'unmatched',compared['unmatched']);print(len(raw),r['elapsedMs'],r['peakRssBytes'])
