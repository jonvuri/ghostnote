import json,time
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,ancestors,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.assertion_guards import requirements
from grid_doctor.read_dataflow import fixed_read_flow
start=time.perf_counter();j=Jar(Path('/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar'));code=Code();symbols=json.load(open('/tmp/gn-9b6g-resolution-5.json'))['builds'][0];labels=json.load(open('/tmp/gn-9b6g-builder-labels-1.json'))['builds'][0]['rows'];catalog=json.load(open('/tmp/gn-9b6g-fixed-1.json'))['builds'][0];rows=catalog['rows']+json.load(open('/tmp/gn-9b6g-registry-old-closure-1.json'))['selectedRows'];catalog={'sha256':j.sha256,'rows':list({(r['name'],r['id']):r for r in rows}.values())};reports=[json.load(open('/tmp/gn-9b6g-builder-property-bindings-1-0.json'))];props=[];mapping=json.load(open('/tmp/gn-9b6g-builder-property-seed-4.json'))['typeBindings'];types={a for a,b in mapping.items()if b in{'deH','deJ','dey','dez','dfg'}}
for report in reports:
 for row in report['properties']:
  props.append(dict(row,properties=[p for p in row['properties']if p.get('targetClass')in types]))
owners=set()
for row in catalog['rows']:
 for key in ('descriptor','runtimeClass'):owners.update(ancestors(j.classes,row['matches'][0][key],128))
for typ in types:owners.update(ancestors(j.classes,typ,128))
owners={n for n in owners if any(f.desc=='Z'and f.flags==4120 for f in j.classes[n].fields)};guards=requirements(j,owners,code);results=[]
for batch,index in enumerate(range(0,len(props),4)):
 p={'sha256':j.sha256,'properties':props[index:index+4]};r=fixed_read_flow(j,code,symbols,catalog,p,guards['fields']);results.append(r)
r={'sha256':j.sha256,'batches':results,'assertionGuards':guards,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False};raw=json.dumps(r,separators=(',',':')).encode()
if len(raw)>8*1024**2:raise Refusal('invariant-read-report-limit')
Path('/tmp/gn-9b6g-invariant-read-flow-old-1.json').write_bytes(raw);paths=[p for r in results for p in r['paths']];print('paths',len(paths),'failures',[(p['className'],p['propertyName'],p['error'])for p in paths if p['error']]);print(len(raw),r['elapsedMs'],r['peakRssBytes'])
