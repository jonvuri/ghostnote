"""Ad-hoc: find callers of a method name/desc across the jar. Reads class bytes as data."""
import sys
sys.path.insert(0, '/Users/jonvuri/Development/ghostnote/brain/src/probes')
from grid_symbols.scan import Jar, parse, instructions
from pathlib import Path
jar = Jar(Path(sys.argv[1])); wanted_name, wanted_desc = sys.argv[2], sys.argv[3]
owners = set(sys.argv[4:])
for entry in jar.zip.namelist():
    if not entry.endswith('.class'): continue
    data = jar.zip.read(entry)
    if wanted_name.encode() not in data: continue
    cls = parse(data, True)
    for m in cls.methods:
        if not m.code: continue
        for off, op, args in instructions(m.code):
            if op in (182,183,184,185):
                owner, nt = cls.cp[args[0]*256+args[1]][1]; owner = cls.cp[cls.cp[owner][1]][1]
                ni, di = cls.cp[nt][1]
                if cls.cp[ni][1] == wanted_name and cls.cp[di][1] == wanted_desc and (not owners or owner in owners):
                    print(f'{cls.name}.{m.name}{m.desc} -> {op} {owner}.{wanted_name}{wanted_desc}')
