import json,hashlib,shutil,zipfile
from pathlib import Path
base=Path('context/evidence/data/phase9b-doctor/614-resolution');dest=base/'checkpoint-17';dest.mkdir();prior={}
# Include the handoff supplement manifest so preserved files are not archived twice.
for path in sorted(base.glob('*/development-manifest.json')):
 for row in json.loads(path.read_text()):prior[row['name']]=row['sha256']
manifest=[]
with zipfile.ZipFile(dest/'development.zip','x',compression=zipfile.ZIP_DEFLATED)as z:
 for p in sorted(Path('/tmp').glob('gn-9b6g-*')):
  if not p.is_file()or p.suffix not in('.json','.txt','.log','.py','.sh','.bin','.md'):continue
  raw=p.read_bytes();h=hashlib.sha256(raw).hexdigest()
  if prior.get(p.name)==h:continue
  z.writestr(p.name,raw);manifest.append({'name':p.name,'sha256':h,'bytes':len(raw)})
(dest/'development-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for name in ['hashmap-bound-3','collection-conditions-17','collection-conditions-18','collection-conditions-21','factory-closure-3','command-closure-2','history-growth-4']:
 shutil.copyfile('/tmp/gn-9b6g-'+name+'.json',dest/(name+'.json'))
sources=[]
with zipfile.ZipFile(dest/'diagnostic-source.zip','x',compression=zipfile.ZIP_DEFLATED)as z:
 for p in sorted(Path('brain/src/probes/grid_doctor').glob('*.py')):
  raw=p.read_bytes();sources.append({'path':str(p),'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw)});z.writestr(str(p),raw)
(dest/'source-inventory.json').write_text(json.dumps(sources,indent=2)+'\n')
print('archived',len(manifest),'files',sum(x['bytes']for x in manifest),'bytes; zip',(dest/'development.zip').stat().st_size,'sources',len(sources))
