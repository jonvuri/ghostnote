import json,time
from pathlib import Path
from grid_symbols.scan import Jar,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.callee_contracts import compare_callees
start=time.perf_counter();jars=[Jar(Path(p))for p in ['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar']];seed=json.load(open('/tmp/gn-9b6g-disposal-release-contracts-1.json'));rows=json.load(open('/tmp/gn-9b6g-factory-disposal-wrappers-1.json'))['builds'][1]['methods'];r=compare_callees(*jars,[r['trace']for r in rows],seed,Code());r.update(elapsedMs=(time.perf_counter()-start)*1000,peakRssBytes=rss_bytes());Path('/tmp/gn-9b6g-factory-disposal-contracts-1.json').write_text(json.dumps(r,indent=2)+'\n');print('matched',len(r['matched']),'unmatched',r['unmatched'])
