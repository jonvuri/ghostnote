import pickle,collections
_D=None
def load(which='new'):
  global _D
  if _D is None:
    d=pickle.load(open(f'/tmp/gn-9b6g-fc-work/index-{which}.pickle','rb'));_D={'hier':d['hier'],'decl':d['decl']}
    kids=collections.defaultdict(set)
    for c,(p,ifs,f) in d['hier'].items():
      kids[p].add(c)
      for i in ifs:kids[i].add(c)
    _D['kids']=kids
  return _D
def subs(c):
  D=load();out=set();st=[c]
  while st:
    x=st.pop()
    for k in D['kids'].get(x,()):
      if k not in out:out.add(k);st.append(k)
  return out
def leaf_exact(c):
  """Return c when it is a concrete vendor class with no vendor subclass or implementor."""
  D=load()
  if c not in D['hier']:return None
  p,ifs,f=D['hier'][c]
  if f&0x0200 or f&0x0400:return None
  return c if not subs(c) else None
def implementors(owner,name,desc):
  D=load();out=[]
  for c in subs(owner)|{owner}:
    fl=D['decl'].get(c,{}).get((name,desc))
    if fl is not None and not fl&0x400:out.append(c)
  return sorted(out)
def dispatch_targets(owner,name,desc,limit=100000):
  """Closed-world set of declarations that a receiver of static type owner can reach."""
  D=load();H=D['hier'];out=set();n=0
  cands=subs(owner)|{owner}
  for c in cands:
    if c not in H:continue
    if H[c][2]&0x0600:continue
    n+=1
    if n>limit:return None
    x=c;found=None
    while x in H:
      fl=D['decl'].get(x,{}).get((name,desc))
      if fl is not None:found=(x,fl);break
      x=H[x][0]
    out.add(found[0] if found and not found[1]&0x400 else ('default-or-missing',c))
  return out
