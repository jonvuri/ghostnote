set -eu
export PYTHONPATH=brain/src/probes
old_jar='/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar'
model_jar=/tmp/gn-9b6g-renamed-extra.jar
capture_path=context/evidence/data/phase9b-doctor/live-v20/captures.zip
symbol_path=context/evidence/data/phase9b-doctor/614-resolution/checkpoint-2/new-renamed.json
python3 -B -m grid_doctor.fixed_descriptors --old-jar "$old_jar" --new-jar "$model_jar" --captures "$capture_path" --report /tmp/gn-9b6g-renamed-catalog-1.json
python3 -B -m grid_doctor.property_contracts --old-jar "$old_jar" --new-jar "$model_jar" --captures "$capture_path" --catalog /tmp/gn-9b6g-renamed-catalog-1.json --symbols "$symbol_path" --report /tmp/gn-9b6g-renamed-properties-1.json
python3 -B -m grid_doctor.fixed_read_checkpoint --old-jar "$old_jar" --new-jar "$model_jar" --symbols "$symbol_path" --catalog /tmp/gn-9b6g-renamed-catalog-1.json --properties /tmp/gn-9b6g-renamed-properties-1.json --output /tmp/gn-9b6g-renamed-fixed-read-1
