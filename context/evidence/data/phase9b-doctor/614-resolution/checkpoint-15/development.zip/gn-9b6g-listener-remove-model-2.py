import json,time,hashlib,zipfile
from pathlib import Path
from grid_symbols.scan import parse
from grid_doctor.ownership import method_trace,bootstraps
from grid_doctor.assertion_guards import disabled_field
from grid_doctor.read_dataflow import signature
start=time.perf_counter();vendor=zipfile.ZipFile('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar');base=Path('/tmp/gn-9b6g-runtime-new-arm64-8/java.base')
class Reader:
 def read(self,n):return (base/n).read_bytes() if n.startswith('java/')else vendor.read(n)
j=type('J',(),{'zip':Reader()})();methods={};hashes={};guards=set()
for name,wanted in [('TT',('removeListener',)),('apd',('Hnt',)),('java/util/ArrayList',('remove','fastRemove','isEmpty')),('java/lang/Object',('equals',))]:
 raw=j.zip.read(name+'.class');cls=parse(raw,True);hashes[name]=hashlib.sha256(raw).hexdigest();g=disabled_field(cls)
 if g:guards.add(g)
 for m in cls.methods:
  if m.name in wanted:methods[name,m.name,m.desc]=method_trace(j,cls,m,bootstraps(raw,cls))
class Obj:
 def __init__(self,typ,**fields):self.typ=typ;self.fields=fields
class InjectedFailure(Exception):pass

def execute(storage,query,fail_copy=False):
 root=Obj('TT',mListeners=storage);counts={'vendor':0,'jdk':0,'vendorCalls':0,'jdkCalls':0,'nativeCopies':0,'copiedSlots':0};trace=[]
 def run(key,args):
  m=methods[key];raw=m['instructions'];ix={r['offset']:i for i,r in enumerate(raw)};local=dict(enumerate(args));stack=[];pc=0;kind='jdk' if key[0].startswith('java/')else'vendor'
  while True:
   counts[kind]+=1
   if sum(counts[k]for k in('vendor','jdk'))>200000:raise ValueError('instruction limit')
   i=ix[pc];r=raw[i];op=r['opcode'];a=r['args'];following=raw[i+1]['offset']if i+1<len(raw)else None
   if op==1:stack.append(None)
   elif 2<=op<=8:stack.append(op-3)
   elif 26<=op<=29:stack.append(local[op-26])
   elif 42<=op<=45:stack.append(local[op-42])
   elif op in(21,25):stack.append(local[a[0]])
   elif op in(54,58):local[a[0]]=stack.pop()
   elif 59<=op<=62:local[op-59]=stack.pop()
   elif 75<=op<=78:local[op-75]=stack.pop()
   elif op==87:stack.pop()
   elif op==89:stack.append(stack[-1])
   elif op==90:
    v=stack.pop();u=stack.pop();stack.extend([v,u,v])
   elif op==178:
    ref=r['constant'];field=(ref['owner'],ref['name'],ref['descriptor'])
    if field in guards:stack.append(1)
    elif field==('apd','Hnt','Z'):stack.append(0)
    else:raise ValueError(('static',field))
   elif op==180:
    target=stack.pop();stack.append(target.fields[r['constant']['name']])
   elif op==181:
    v=stack.pop();target=stack.pop();target.fields[r['constant']['name']]=v
   elif op==192:
    if r['constant']['value']!='java/util/List':raise ValueError('cast')
    if not isinstance(stack[-1],Obj)or stack[-1].typ!='java/util/ArrayList':raise ValueError('list type')
   elif op==193:
    if r['constant']['value']!='java/util/List':raise ValueError('type test')
    v=stack.pop();stack.append(int(isinstance(v,Obj)and v.typ=='java/util/ArrayList'))
   elif op==50:
    k=stack.pop();stack.append(stack.pop()[k])
   elif op==83:
    v=stack.pop();k=stack.pop();stack.pop()[k]=v
   elif op in(96,100):
    b=stack.pop();v=stack.pop();stack.append(v+b if op==96 else v-b)
   elif op==132:local[a[0]]+=int.from_bytes(bytes([a[1]]),'big',signed=True)
   elif op in(153,154,162,164,165,166,167,198,199):
    take=True
    if op in(153,154):take=(stack.pop()==0)==(op==153)
    elif op in(198,199):take=(stack.pop()is None)==(op==198)
    elif op in(162,164,165,166):
     b=stack.pop();v=stack.pop();take=v>=b if op==162 else v<=b if op==164 else (v is b)==(op==165)
    if take:following=pc+int.from_bytes(bytes(a),'big',signed=True)
   elif op in(182,184,185):
    ref=r['constant'];argtypes,result=signature(ref['descriptor']);n=len(argtypes)+(op!=184);args=stack[-n:]if n else[]
    if n:del stack[-n:]
    target=(ref['owner'],ref['name'],ref['descriptor']);trace.append(target)
    if target==('java/lang/System','arraycopy','(Ljava/lang/Object;ILjava/lang/Object;II)V'):
     counts['nativeCopies']+=1
     if fail_copy:raise InjectedFailure()
     source,begin,dest,end,length=args;dest[end:end+length]=source[begin:begin+length];counts['copiedSlots']+=length;out=None
    else:
     if ref['owner']=='java/util/List':target=('java/util/ArrayList',*target[1:])
     counts['jdkCalls'if target[0].startswith('java/')else'vendorCalls']+=1
     out=run(target,args)
    if result!='V':stack.append(out)
   elif op in(172,176):return stack.pop()
   elif op==177:return None
   else:raise ValueError(('opcode',key,pc,op))
   pc=following
 try:run(('TT','removeListener','(Lfoz;)V'),[root,query]);failed=False
 except InjectedFailure:failed=True
 return root.fields['mListeners'],counts,failed
# The non-null search uses one increasing index and a captured size.
remove = methods['java/util/ArrayList','remove','(Ljava/lang/Object;)Z']['instructions']
by_offset = {r['offset']: r for r in remove}
loop_offsets = [39,41,42,45,46,47,49,50,53,59,62]
assert [by_offset[x]['opcode'] for x in loop_offsets] == [21,29,162,43,44,21,50,182,153,132,167]
assert by_offset[39]['args'] == [4] and by_offset[47]['args'] == [4]
assert by_offset[59]['args'] == [4,1] and by_offset[62]['args'] == [255,233]
assert by_offset[42]['args'] == [0,23] and by_offset[53]['args'] == [0,6]
assert by_offset[14]['opcode'] == 199 and by_offset[14]['args'] == [0,25]
assert by_offset[50]['constant'] == {'tag':10,'owner':'java/lang/Object','name':'equals','descriptor':'(Ljava/lang/Object;)Z'}
assert [r['offset'] for r in remove if r['opcode'] in(54,132)] == [11,33,59]
assert by_offset[11]['args'] == [4] and by_offset[10]['opcode'] == 3
assert by_offset[6]['constant'] == {'tag':9,'owner':'java/util/ArrayList','name':'size','descriptor':'I'}
assert by_offset[9]['opcode'] == 62
rows=[];maximum={};cases=0
for n in range(65):
 for found in range(-1,n):
  query=object();values=[object()for _ in range(n)];expected=list(values)
  if found>=0:values[found]=query;expected=list(values);expected.pop(found)
  storage=Obj('java/util/ArrayList',elementData=values+[None]*3,size=n,modCount=0)
  result,c,failed=execute(storage,query)
  assert not failed and storage.fields['size']==len(expected) and storage.fields['elementData'][:len(expected)]==expected
  assert result is(None if not expected else storage)
  assert c['nativeCopies']<=1 and c['copiedSlots']<=max(0,n-1)
  assert c['jdk']<=65+17*n and c['jdkCalls']<=n+3 and c['vendor']<=35
  cases+=1
  for k,v in c.items():maximum[k]=max(maximum.get(k,0),v)
  if n in(0,1,2,64) and found in(-1,0,n-1):rows.append({'size':n,'foundIndex':found,'counts':c})
# The direct storage cases must not call any JDK method.
for kind in('null','same','other'):
 q=object();storage=None if kind=='null'else q if kind=='same'else object();result,c,f=execute(storage,q);assert c['jdk']==0 and c['nativeCopies']==0 and result is(None if kind!='other'else storage);rows.append({'storage':kind,'counts':c});cases+=1
q=object();storage=Obj('java/util/ArrayList',elementData=[q,object()],size=2,modCount=0);result,c,failed=execute(storage,q,True);assert failed and result is storage and storage.fields['size']==2 and storage.fields['modCount']==1
report={'classSha256':hashes,'methods':list(methods.values()),'cases':cases,'samples':rows,'maximum':maximum,'conditionalBound':{'vendorInstructions':35,'jdkInstructionsConstant':65,'jdkInstructionsPerListener':17,'jdkCallsConstant':3,'jdkCallsPerListener':1,'nativeArrayCopies':1,'copiedSlotsAtMost':'max(0, N - 1)'},'loopCertificate':{'indexLocal':4,'initialIndex':0,'increment':1,'capturedSizeLocal':3,'guardOffset':42,'backEdge':[62,39],'queryCondition':'non-null Object.equals receiver','maxInstructionsPerFailedIterationIncludingEquals':17,'constantIncludesExitFastRemoveAndIsEmpty':65},'copyFailure':{'propagated':failed,'sizeAfter':2,'modCountAfter':1,'retryPermitted':False},'elapsedMs':(time.perf_counter()-start)*1000,'boundedAdmission':False,'runtimeClassesInitialized':0,'conditions':['The TT assertion field must already be initialized and true.','The apd tracking flag must remain false.','Storage must be null, one listener, or an exact stable ArrayList.','The non-null query must use Object.equals.','Arraycopy is modeled with a bounded number of reference slots. Its native body and failure cost are not timed.','These finite cases do not establish an admitted listener count or command-wide growth bound.']}
Path('/tmp/gn-9b6g-listener-remove-model-2.json').write_text(json.dumps(report,indent=2)+'\n');print('cases',cases,'maximum',maximum,'ms',report['elapsedMs']);print(rows)
