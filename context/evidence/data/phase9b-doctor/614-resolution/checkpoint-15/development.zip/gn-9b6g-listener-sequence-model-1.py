import json,time,hashlib,zipfile,itertools
from pathlib import Path
from grid_symbols.scan import parse
from grid_doctor.ownership import method_trace,bootstraps
from grid_doctor.assertion_guards import disabled_field
from grid_doctor.read_dataflow import signature
start=time.perf_counter()
class Obj:
 def __init__(self,typ,**fields):self.typ=typ;self.fields=fields

def load(path,owner,listener):
 z=zipfile.ZipFile(path);raw=z.read(owner+'.class');c=parse(raw,True);jar=type('J',(),{'zip':z})();methods={m.name:method_trace(jar,c,m,bootstraps(raw,c))for m in c.methods if m.name in('addListener','removeListener','fireEvent')};return owner,listener,disabled_field(c),methods,hashlib.sha256(raw).hexdigest()
inputs=[load('/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar','rHF','Npn'),load('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar','TT','foz')]
class Program:
 def __init__(self,inp):self.owner,self.listener,self.guard,self.methods,self.sha=inp;self.root=Obj(self.owner,mListeners=None);self.events=[];self.steps=0;self.listcalls=0
 def contents(self):
  v=self.root.fields['mListeners'];return []if v is None else list(v.fields['items'])if isinstance(v,Obj)and v.typ=='java/util/ArrayList'else[v]
 def run(self,name,arg):
  raw=self.methods[name]['instructions'];ix={r['offset']:i for i,r in enumerate(raw)};local={0:self.root,1:arg};stack=[];pc=0;steps=0
  while True:
   steps+=1;self.steps+=1
   if steps>10000:raise ValueError('instruction limit')
   i=ix[pc];r=raw[i];op=r['opcode'];a=r['args'];following=raw[i+1]['offset']if i+1<len(raw)else None
   if op==1:stack.append(None)
   elif 2<=op<=8:stack.append(op-3)
   elif 26<=op<=29:stack.append(local[op-26])
   elif 42<=op<=45:stack.append(local[op-42])
   elif op in(21,25):stack.append(local[a[0]])
   elif op in(54,58):local[a[0]]=stack.pop()
   elif 59<=op<=62:local[op-59]=stack.pop()
   elif 75<=op<=78:local[op-75]=stack.pop()
   elif op==87:stack.pop()
   elif op==89:stack.append(stack[-1])
   elif op==178:
    ref=r['constant'];field=(ref['owner'],ref['name'],ref['descriptor'])
    if field==self.guard:stack.append(1)
    else:raise ValueError(('static',field))
   elif op==180:stack.append(stack.pop().fields[r['constant']['name']])
   elif op==181:
    v=stack.pop();stack.pop().fields[r['constant']['name']]=v
   elif op==187:
    if r['constant']['value']!='java/util/ArrayList':raise ValueError('allocation')
    stack.append(Obj('java/util/ArrayList',items=[]))
   elif op==189:
    if r['constant']['value']!=self.listener:raise ValueError('array type')
    stack.append([None]*stack.pop())
   elif op==192:
    if r['constant']['value']not in('java/util/List',self.listener,'[L'+self.listener+';'):raise ValueError('cast')
   elif op==193:
    if r['constant']['value']!='java/util/List':raise ValueError('type test')
    v=stack.pop();stack.append(int(isinstance(v,Obj)and v.typ=='java/util/ArrayList'))
   elif op==190:stack.append(len(stack.pop()))
   elif op==50:
    k=stack.pop();stack.append(stack.pop()[k])
   elif op==132:local[a[0]]+=int.from_bytes(bytes([a[1]]),'big',signed=True)
   elif op in(153,154,162,165,166,167,198,199):
    take=True
    if op in(153,154):take=(stack.pop()==0)==(op==153)
    elif op in(198,199):take=(stack.pop()is None)==(op==198)
    elif op in(162,165,166):
     b=stack.pop();v=stack.pop();take=v>=b if op==162 else(v is b)==(op==165)
    if take:following=pc+int.from_bytes(bytes(a),'big',signed=True)
   elif op in(182,183,184,185):
    ref=r['constant'];argtypes,result=signature(ref['descriptor']);n=len(argtypes)+(op!=184);args=stack[-n:]if n else[]
    if n:del stack[-n:]
    target=(ref['owner'],ref['name'],ref['descriptor']);out=None
    if target==('apd','Hnt','()Z'):out=0
    elif target==('java/util/ArrayList','<init>','(I)V'):
     if args[1]!=2:raise ValueError('initial capacity')
    elif ref['owner']=='java/util/List':
     self.listcalls+=1;values=args[0].fields['items'];slot=ref['name']
     if(slot,ref['descriptor'])==('add','(Ljava/lang/Object;)Z'):values.append(args[1]);out=1
     elif(slot,ref['descriptor'])==('remove','(Ljava/lang/Object;)Z'):
      pos=next((i for i,v in enumerate(values)if v is args[1]),None);out=pos is not None
      if out:values.pop(pos)
     elif(slot,ref['descriptor'])==('isEmpty','()Z'):out=not values
     elif(slot,ref['descriptor'])==('size','()I'):out=len(values)
     elif(slot,ref['descriptor'])==('toArray','([Ljava/lang/Object;)[Ljava/lang/Object;'):out=list(values)
     else:raise ValueError(('list call',target))
    elif target==(self.listener,'eventOccurred','(Ljava/lang/Object;)V'):self.events.append(args[0])
    else:raise ValueError(('call',target))
    if result!='V':stack.append(out)
   elif op==177:return
   else:raise ValueError(('opcode',name,pc,op))
   pc=following
cases=0;commands=0;maxsteps=0
# Include repeated registration, absent removal, empty lists, and re-addition.
for length in range(7):
 for sequence in itertools.product(range(4),repeat=length):
  queries=[object(),object()];reference=[];programs=[Program(inp)for inp in inputs]
  for action in sequence:
   q=queries[action%2];name='addListener'if action<2 else'removeListener'
   if action<2:reference.append(q)
   else:
    found=next((i for i,v in enumerate(reference)if v is q),None)
    if found is not None:reference.pop(found)
   for program in programs:
    program.run(name,q);assert program.contents()==reference
    program.events=[];program.run('fireEvent',None);assert program.events==reference
   commands+=1
  cases+=1;maxsteps=max(maxsteps,*(p.steps for p in programs))
r={'builds':[{'owner':x[0],'listenerType':x[1],'assertionGuard':x[2],'classSha256':x[4],'methods':list(x[3].values())}for x in inputs],'sequenceCases':cases,'pairedCommands':commands,'maxInstructionsPerSequencePerBuild':maxsteps,'elapsedMs':(time.perf_counter()-start)*1000,'boundedAdmission':False,'runtimeClassesInitialized':0,'conditions':['Assertion flags are initialized and true. The new tracking flag remains false.','Listeners are non-null and do not implement List. Equality is object identity.','ArrayList operations use an inert model. Their internal work is not counted here.','Callbacks record their receivers only. They do not mutate storage or reenter commands.','The state relation is the ordered listener sequence. Storage identity and capacity are not equivalent.']}
Path('/tmp/gn-9b6g-listener-sequence-model-1.json').write_text(json.dumps(r,indent=2)+'\n');print({k:v for k,v in r.items()if k!='builds'})
