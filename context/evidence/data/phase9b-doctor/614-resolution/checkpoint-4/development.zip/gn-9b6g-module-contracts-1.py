import json,time,collections,hashlib
from pathlib import Path
from grid_symbols.scan import Jar,Refusal,parse,rss_bytes
from grid_doctor.contracts import contract
from grid_doctor.descriptor_resolution import Code
from grid_doctor.migrate import bindings,merge,member
from grid_doctor.ownership import method_trace,bootstraps
start=time.perf_counter();roots=['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents','/Applications/Bitwig Studio.app/Contents'];jars=[Jar(Path(r+'/Java/bitwig.jar'))for r in roots];code=Code();known=[{},{}];matched=[];report=json.load(open('/tmp/gn-9b6g-module-files-1.json'));plans=[]
pairs=[(report['builds'][0]['keyMethod']['owner'],report['builds'][1]['keyMethod']['owner'])]+list(zip(report['builds'][0]['codecClasses'],report['builds'][1]['codecClasses']))
for i,(jar,build)in enumerate(zip(jars,report['builds'])):
 specs=[]
 for trace in build['codecTraces']:
  cls=code.get(jar,trace['owner']);m=member(cls,trace['name'],trace['descriptor']);specs.append({'owner':cls.name,'name':m.name,'descriptor':m.desc,'digest':contract(cls,m,{})['digest']})
 plans.append({'jarSha256':jar.sha256,'moduleSha256':build['fileSha256'],'methods':specs})
for pair in pairs:
 a,b=[code.get(j,n)for j,n in zip(jars,pair)]
 methods=[member(a,report['builds'][0]['keyMethod']['name'],report['builds'][0]['keyMethod']['descriptor'])]if pair==pairs[0]else a.methods
 for am in methods:
  ac=contract(a,am,jars[0].classes);hits=[]
  for bm in b.methods:
   bc=contract(b,bm,jars[1].classes)
   if ac['digest']!=bc['digest']:continue
   try:merged=merge(known,bindings(ac,bc))
   except Refusal:continue
   hits.append((bm,merged))
  if len(hits)!=1:raise Refusal('module-codec-match-'+str((a.name,am.name,am.desc,len(hits))))
  bm,known=hits[0];matched.append({'source':[a.name,am.name,am.desc],'target':[b.name,bm.name,bm.desc],'digest':ac['digest']})
# Compare every method in the binary reader and type dispatcher within their package.
for name in ['com/bitwig/base/serial/binary/hgq','com/bitwig/base/serial/binary/OCK','com/bitwig/base/serial/binary/CuM']:
 target=code.get(jars[1],name);expected=collections.Counter(contract(target,m,jars[1].classes)['digest']for m in target.methods);hits=[]
 for n in jars[0].classes:
  if not n.startswith('com/bitwig/base/serial/binary/'):continue
  cls=code.get(jars[0],n)
  actual=collections.Counter(contract(cls,m,jars[0].classes)['digest']for m in cls.methods)
  if actual==expected:hits.append(n)
 print('binary-class',name,hits)
 if len(hits)!=1:raise Refusal('module-binary-class-match')
 for i,n in enumerate([hits[0],name]):
  cls=code.get(jars[i],n)
  for m in cls.methods:plans[i]['methods'].append({'owner':n,'name':m.name,'descriptor':m.desc,'digest':contract(cls,m,{})['digest']})
 matched.append({'sourceClass':hits[0],'targetClass':name,'methodCount':len(target.methods),'contractMultisetEqual':True})
for i,p in enumerate(plans):Path('context/evidence/data/phase9b-doctor/614-resolution/module-file-'+str(i)+'-plan.json').write_text(json.dumps(p,indent=2)+'\n')
r={'matched':matched,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False,'writeAuthority':False};Path('/tmp/gn-9b6g-module-contracts-1.json').write_text(json.dumps(r,indent=2));print('matched',len(matched),'elapsedMs',r['elapsedMs'],'rss',r['peakRssBytes'])
