import zipfile,json,hashlib,time
from pathlib import Path
from grid_symbols.scan import parse,instructions,rss_bytes
from grid_doctor.module_file import key_bytes,decode_file,Reader
from grid_doctor.ownership import constant,method_trace,bootstraps
start=time.perf_counter();paths=['/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents','/Applications/Bitwig Studio.app/Contents'];methods=json.load(open('/tmp/gn-9b6g-resource-key-methods-1.json'));reports=[]
class Data:
 def __init__(self,z):self.zip=z
 def code(self,n):return parse(self.zip.read(n+'.class'),True)
for root,m in zip(paths,methods):
 with zipfile.ZipFile(root+'/Java/bitwig.jar')as z:
  j=Data(z);c=j.code(m['owner']);method=next(x for x in c.methods if(x.name,x.desc)==(m['name'],m['descriptor']));key=key_bytes(c,method);raw=Path(root+'/Resources/Library/modules/Amplify.bwmodule').read_bytes();header,meta,objs=decode_file(raw,key)
  report=Reader(objs).read();metadata=Reader(meta).read();print(root,header,len(meta),len(objs),report['objectCount'],report['classCounts'])
  alloc=constant(c,int.from_bytes(bytes(instructions(method.code)[515][2]),'big'))['value'];print('CODEC',alloc);cc=j.code(alloc);streams=[]
  for mm in cc.methods:
   if mm.desc=='(Ljava/io/InputStream;)Ljava/io/InputStream;':
    streams=[constant(cc,int.from_bytes(bytes(a),'big'))['value']for _,o,a in instructions(mm.code)if o==187];print('stream',mm.name,streams)
  traces=[method_trace(j,c,method,bootstraps(z.read(c.name+'.class'),c))]
  for name in [alloc,*streams]:
   cls=j.code(name)
   for mm in cls.methods:traces.append(method_trace(j,cls,mm,bootstraps(z.read(name+'.class'),cls)))
  reports.append({'path':root+'/Resources/Library/modules/Amplify.bwmodule','fileSha256':hashlib.sha256(raw).hexdigest(),'header':header,'metadata':metadata,'objects':report,'keyMethod':m,'codecClasses':[alloc,*streams],'codecTraces':traces,'decodedHashes':{'metadata':hashlib.sha256(meta).hexdigest(),'objects':hashlib.sha256(objs).hexdigest()}})
r={'builds':reports,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False,'writeAuthority':False};Path('/tmp/gn-9b6g-module-files-1.json').write_text(json.dumps(r,indent=2));print('elapsedMs',r['elapsedMs'],'rss',r['peakRssBytes'])
