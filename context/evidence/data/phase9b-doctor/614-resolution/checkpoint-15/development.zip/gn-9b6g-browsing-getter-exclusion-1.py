import json,time
from pathlib import Path
from grid_symbols.scan import Jar,instructions,rss_bytes
from grid_doctor.descriptor_resolution import Code
from grid_doctor.assertion_guards import requirements
from grid_doctor.dispatch_paths import reachable
from grid_doctor.migrate import member
from grid_doctor.ownership import constant,method_trace,bootstraps
start=time.perf_counter();j=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));code=Code()
callers=[('GiH','E3'),('Ac','Nnn'),('ImZ','E3'),('oJk','lYc'),('g2L','wGc')];prefix='com/bitwig/flt/document/core/master/device/';guards=requirements(j,{prefix+x for x,_ in callers},code);rows=[];traces=[]
for name,slot in callers:
 c=code.get(j,prefix+name);m=member(c,slot,'()V');selected=reachable(c,m,None,set(guards['fields']));allpaths=reachable(c,m,None)
 for offset,op,args in instructions(m.code):
  if op not in(182,183,184,185):continue
  ref=constant(c,int.from_bytes(bytes(args[:2]),'big'))
  if ref['owner']=='EIm' and ref['name']=='cfM' and ref['descriptor'] in ('()LivQ;','(LivQ;)V'):
   rows.append({'caller':[c.name,slot,m.desc],'offset':offset,'target':ref,'withoutGuardReachable':offset in allpaths,'guardedReachable':offset in selected,'handlers':m.handlers})
 traces.append(method_trace(j,c,m,bootstraps(j.zip.read(c.name+'.class'),c)))
getters=[r for r in rows if r['target']['descriptor']=='()LivQ;'];setters=[r for r in rows if r['target']['descriptor']=='(LivQ;)V']
assert len(getters)==4 and all(r['withoutGuardReachable'] and not r['guardedReachable']for r in getters)
assert len(setters)==2 and all(r['guardedReachable']for r in setters)
r={'sha256':j.sha256,'rows':rows,'guards':guards,'traces':traces,'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False,'runtimeObserved':False,'limits':['The assertion flags must already be initialized and true.','Two setters remain reachable. This result does not establish command exclusion or holder stability.','Incoming scan coverage remains conditional on its unresolved symbolic references.']};Path('/tmp/gn-9b6g-browsing-getter-exclusion-1.json').write_text(json.dumps(r,indent=2));print('getters excluded',len(getters),'setters reachable',len(setters),'ms',r['elapsedMs'],'rss',r['peakRssBytes'])
