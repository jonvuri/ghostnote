# Compact disassembler over class bytes as data. No vendor code runs.
import sys,zipfile
from pathlib import Path
from grid_symbols.scan import parse
from grid_doctor.ownership import bootstraps,method_trace
OLD=Path('/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar')
NEW=Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar')
N='nop aconst_null iconst_m1 iconst_0 iconst_1 iconst_2 iconst_3 iconst_4 iconst_5 lconst_0 lconst_1 fconst_0 fconst_1 fconst_2 dconst_0 dconst_1 bipush sipush ldc ldc_w ldc2_w iload lload fload dload aload iload_0 iload_1 iload_2 iload_3 lload_0 lload_1 lload_2 lload_3 fload_0 fload_1 fload_2 fload_3 dload_0 dload_1 dload_2 dload_3 aload_0 aload_1 aload_2 aload_3 iaload laload faload daload aaload baload caload saload istore lstore fstore dstore astore istore_0 istore_1 istore_2 istore_3 lstore_0 lstore_1 lstore_2 lstore_3 fstore_0 fstore_1 fstore_2 fstore_3 dstore_0 dstore_1 dstore_2 dstore_3 astore_0 astore_1 astore_2 astore_3 iastore lastore fastore dastore aastore bastore castore sastore pop pop2 dup dup_x1 dup_x2 dup2 dup2_x1 dup2_x2 swap iadd ladd fadd dadd isub lsub fsub dsub imul lmul fmul dmul idiv ldiv fdiv ddiv irem lrem frem drem ineg lneg fneg dneg ishl lshl ishr lshr iushr lushr iand land ior lor ixor lxor iinc i2l i2f i2d l2i l2f l2d f2i f2l f2d d2i d2l d2f i2b i2c i2s lcmp fcmpl fcmpg dcmpl dcmpg ifeq ifne iflt ifge ifgt ifle if_icmpeq if_icmpne if_icmplt if_icmpge if_icmpgt if_icmple if_acmpeq if_acmpne goto jsr ret tableswitch lookupswitch ireturn lreturn freturn dreturn areturn return getstatic putstatic getfield putfield invokevirtual invokespecial invokestatic invokeinterface invokedynamic new newarray anewarray arraylength athrow checkcast instanceof monitorenter monitorexit wide multianewarray ifnull ifnonnull goto_w jsr_w'.split()
BR=set(range(153,169))|{198,199}
class Data:
 def __init__(s,p):s.zip=zipfile.ZipFile(p)
 def code(s,n):return parse(s.zip.read(n+'.class'),True)
def fmt(x):
 o=x['opcode'];n=N[o] if o<len(N) else str(o);c=x.get('constant');a=x['args']
 if c:
  if 'owner' in c:return f"{n} {c['owner']}.{c['name']}{c['descriptor']}"
  return f"{n} {c.get('value',c)}"
 if o in BR:
  d=(a[0]<<8|a[1]);d=d-65536 if d>32767 else d;return f"{n} ->{x['offset']+d}"
 return f"{n} {a}" if a else n
def show(jar,spec):
 name,wanted,sig=spec.split('#',2);seen=set();look=name
 while True:
  if name in seen or not name or name.startswith('java/'):print('MISSING',spec);return
  seen.add(name);cls=jar.code(name);hits=[m for m in cls.methods if m.name==wanted and (sig=='*' or m.desc==sig)]
  if hits:break
  name=cls.parent
 for m in hits:
  t=method_trace(jar,cls,m,bootstraps(jar.zip.read(name+'.class'),cls))
  print('==',look,'decl',name,m.name,m.desc,'flags',m.flags,'H',t['exceptionHandlers'])
  for x in t['instructions']:print(' ',x['offset'],fmt(x))
if __name__=='__main__':
 jar=Data(OLD if sys.argv[1]=='old' else NEW)
 for s in sys.argv[2:]:
  if '#' in s:show(jar,s)
  else:
   c=jar.code(s);print('CLASS',s,'parent',c.parent,'ifaces',c.interfaces);print(' F',[(f.name,f.desc,f.flags) for f in c.fields]);print(' M',[(m.name,m.desc,m.flags,len(m.code)) for m in c.methods])
