import json,time
from pathlib import Path
from collections import defaultdict,Counter
from grid_symbols.scan import Jar,parse,Refusal,instructions
from grid_doctor.contracts import contract,signature_key
from grid_doctor.migrate import bindings,merge,member
from grid_doctor.role_bindings import code as raw_code,canonical_edges
from functools import lru_cache
@lru_cache(maxsize=128)
def code(jar,name):return raw_code(jar,name)
from grid_doctor.admission import Work
from grid_doctor.receiver_trace import Declarations,ReceiverLimits
ROOT=Path.cwd(); D=ROOT/'context/evidence/data/phase9b-doctor'
source=json.loads((D/'v20-preparation/candidate.json').read_text())
seeds=json.loads((D/'614-bindings/bindings.json').read_text())
old=Jar(Path('/Users/jonvuri/Bitwig Upgrade Backups/2026-10-21-pre-6.1/apps/Bitwig Studio 6.0.6.app/Contents/Java/bitwig.jar'))
new=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'))
work=Work(ReceiverLimits()); od,nd=Declarations(old,work),Declarations(new,work)
known=[dict(seeds['builds'][1]['typeBindings']),{tuple(r['source']):tuple(r['target']) for r in seeds['builds'][1]['memberBindings']}]
sources=[]; shapes=set(); digests=set(); unsupported=[]
owners=set(source['types'].values())
for o in list(owners):
 c=old.classes[o]
 while c.parent in old.classes:
  owners.add(c.parent);c=old.classes[c.parent]
for owner in sorted(owners):
 c=code(old,owner)
 for m in c.methods:
  if not m.code:continue
  try:v=contract(c,m,old.classes)
  except Refusal:unsupported.append([owner,m.name,m.desc]);continue
  sources.append((owner,m.name,m.desc,v)); shapes.add(signature_key(m,old.classes));digests.add(v['digest'])
print('sources',len(sources),'owners',len(owners),'unsupported',len(unsupported),flush=True)
hits=defaultdict(list);counts=Counter(); stats=Counter()
for owner in sorted(new.classes):
 new.check(); c=code(new,owner)
 for m in c.methods:
  stats['methods']+=1
  if not m.code or signature_key(m,new.classes) not in shapes:continue
  stats['instructions']+=len(instructions(m.code))
  try:v=contract(c,m,new.classes)
  except Refusal:continue
  if v['digest'] in digests:
   counts[v['digest']]+=1
   if counts[v['digest']]<=128:hits[v['digest']].append((owner,m.name,m.desc))
print('scanned',dict(stats),flush=True)
Path('/tmp/gn-9b6g-global-pools.json').write_text(json.dumps({'counts':dict(counts),'hits':dict(hits),'stats':dict(stats)}))
@lru_cache(maxsize=128)
def class_index(owner):
 c=code(new,owner); result=defaultdict(list)
 for m in c.methods:
  try:v=contract(c,m,new.classes)
  except Refusal as e:
   if str(e).startswith('contract-unsupported-constant:'):continue
   raise
  result[v['digest']].append((owner,m.name,m.desc))
 return result
selected={}; conflicts=[]
for rnd in range(128):
 adds=[]
 for owner,name,desc,v in sources:
  new.check()
  if (owner,name,desc) in selected:continue
  target=known[0].get(owner)
  if target:
   c=code(new,target)
   pool=class_index(target)[v['digest']]
  elif counts[v['digest']]<=128:pool=hits[v['digest']]
  else:continue
  matches=[]
  for no,nn,ds in pool:
   c=code(new,no);m=member(c,nn,ds)
   try:
    nv=contract(c,m,new.classes)
    if nv['digest']!=v['digest']:continue
    mapped=merge(bindings(v,nv),[{owner:no},{(10,owner,name,desc):(10,no,nn,ds)}])
    mapped,unresolved=canonical_edges(mapped,od,nd)
    merge(known,mapped)
   except Refusal as e:
    if str(e) in ('operation-edge-conflict','reference-alias-conflict') or str(e).startswith('contract-unsupported-constant:'):continue
    raise
   matches.append(((no,nn,ds),mapped))
  if len(matches)==1:adds.append(((owner,name,desc),*matches[0]))
 if not adds:break
 for key,target,mapped in adds:
  try:known=merge(known,mapped)
  except Refusal as e:
   conflicts.append([key,target,str(e)]);continue
  selected[key]=target
 print('round',rnd,len(adds),'mapped',len(known[0]),'roles',sum(x in known[0] for x in source['types'].values()),flush=True)
result={'types':{r:known[0].get(n) for r,n in source['types'].items()},'typeBindings':known[0],'members':[{'source':list(k),'target':list(v)}for k,v in known[1].items()],'witnesses':[{'source':list(k),'target':list(v)}for k,v in selected.items()],'conflicts':conflicts,'unsupported':unsupported,'stats':dict(stats)}
Path('/tmp/gn-9b6g-anchors.json').write_text(json.dumps(result,indent=2))
print('missing',[(k,v)for k,v in result['types'].items()if v is None]);print('conflicts',conflicts[:20])
