import json,time
from pathlib import Path
from grid_symbols.scan import Jar,rss_bytes,Refusal,ancestors
from grid_doctor.descriptor_resolution import Code
from grid_doctor.receiver_trace import Declarations,ReceiverLimits
from grid_doctor.admission import Work
from grid_doctor.disposal_wrappers import map_wrapper,false_fields_delegate
from grid_doctor.migrate import member
start=time.perf_counter();j=Jar(Path('/Applications/Bitwig Studio.app/Contents/Java/bitwig.jar'));code=Code();d=Declarations(j,Work(ReceiverLimits()));catalog=json.load(open('/tmp/gn-9b6g-fixed-1.json'))['builds'][1];classes=sorted({r['matches'][0]['runtimeClass']for r in catalog['rows']});methods={};receivers=[]
for cls in classes:
 found=d.find('method',cls,'ix_','()V');chain=[]
 while found['status']=='declaration'and found['owner']!='com/bitwig/ramona/core/oDc':
  owner=found['owner']
  if owner in chain or len(chain)>=128:raise Refusal('disposal-wrapper-chain')
  chain.append(owner)
  if owner not in methods:
   c=code.get(j,owner)
   try:methods[owner]=map_wrapper(j,code,c,member(c,'ix_','()V'))
   except Refusal as e:
    try:methods[owner]=false_fields_delegate(j,code,c,member(c,'ix_','()V'))
    except Refusal as f:methods[owner]={'owner':owner,'refusal':str(e),'flagRefusal':str(f)}
  if 'refusal'in methods[owner]:break
  found=d.find('method',*methods[owner]['delegate'])
 receivers.append({'runtimeClass':cls,'chain':chain,'baseReached':found['status']=='declaration'and found['owner']=='com/bitwig/ramona/core/oDc'})
out={'sha256':j.sha256,'receivers':receivers,'methods':list(methods.values()),'elapsedMs':(time.perf_counter()-start)*1000,'peakRssBytes':rss_bytes(),'boundedAdmission':False};Path('/tmp/gn-9b6g-disposal-wrappers-2.json').write_text(json.dumps(out,indent=2));print('receivers',len(receivers),'base',sum(x['baseReached']for x in receivers),'wrappers',len(methods),'refusals',[x for x in methods.values()if'refusal'in x])
